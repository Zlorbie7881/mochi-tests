package cc.mochi;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.IntConsumer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;

public final class ItemListEditor {
   private static List<Item> itemList;

   private static final Map<Item, ItemStack> itemStackByItem = new HashMap<>();

   private static List computeList() {
      if (itemList == null) {
         ArrayList arrayList = new ArrayList();

         for (Item item : Registries.ITEM) {
            arrayList.add(item);
         }

         arrayList.sort(Comparator.comparing(objectValue -> getString((Item)objectValue), TextStyleAccess4.getCASE_INSENSITIVE_ORDER()));
         setItemList(List.copyOf(arrayList));
      }

      return itemList;
   }

   private static void updateStateForUiContext(UiContext uiContext, Rect rect, Item item, boolean booleanValue, float progress, float floatValue2, boolean booleanValue2) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      Color color = ThemeSnapshot.computeColorForColor(themeSnapshot2.getAccent2());
      Color color2 = booleanValue ? UiRenderContext.multiplyAlpha(color, 0.18F + 0.12F * progress) : UiContext.blendColors(themeSnapshot2.getSurfaceSunken(), themeSnapshot2.getSurfaceRaised(), progress);
      Color color3 = booleanValue ? UiRenderContext.multiplyAlpha(color, 0.75F + 0.25F * progress) : UiContext.blendColors(themeSnapshot2.getHairline2(), themeSnapshot2.getAccent2(), 0.4F * progress);
      uiContext.getUiRenderContext().fillRoundedRect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), 4.0F, UiContext.multiplyAlpha(color2, floatValue2));
      uiContext.getUiRenderContext().strokeRoundedRect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), 4.0F, 1.0F, UiContext.multiplyAlpha(color3, floatValue2));
      if (booleanValue2 && floatValue2 > 0.95F) {
         uiContext.getUiRenderContext().drawItemStack(itemStackByItem.computeIfAbsent(item, item2 -> new ItemStack((ItemConvertible)((Item)item2))), rect.getX() + 1.0F, rect.getY() + 1.0F, rect.getWidth() - 2.0F);
      } else {
         String string = getString(item);
         uiContext.drawCenteredText(string.length() > 2 ? string.substring(0, 2) : string, rect.centerX(), rect.centerY(), TextStyle.CAPTION, UiContext.multiplyAlpha(themeSnapshot2.getSecondaryText2(), floatValue2));
      }
   }

   private static void updateStateForItemListSetting(ItemListSetting itemListSetting, Item item) {
      itemListSetting.removeItem(item);
      ClientSounds.updateState5();
   }

   public static String getString(Item item) {
      return item.getName().getString();
   }

   private static void updateStateForItemListSetting2(ItemListSetting itemListSetting, Item item) {
      itemListSetting.toggleItem(item);
      ClientSounds.updateState4();
   }

   private ItemListEditor() {
   }

   public static float getFloatConstant() {
      return 139.0F;
   }

   private static void updateStateForUiContext2(UiContext uiContext, String string, Rect rect, String text, boolean booleanValue, UiLayer uiLayer, Rect rect2, float floatValue, Runnable runnable) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      Rect rect3 = rect.intersection(rect2);
      float progress = uiContext.animateHover(string, uiContext.isHovered(rect3, uiLayer));
      Color color = ThemeSnapshot.computeColorForColor(themeSnapshot2.getAccent2());
      Color color2 = booleanValue ? UiRenderContext.multiplyAlpha(color, 0.28F + 0.14F * progress) : UiContext.blendColors(themeSnapshot2.getSurfaceSunken(), themeSnapshot2.getSurfaceRaised(), progress);
      Color color3 = booleanValue ? UiRenderContext.multiplyAlpha(color, 0.75F + 0.25F * progress) : UiContext.blendColors(themeSnapshot2.getHairline2(), themeSnapshot2.getAccent2(), 0.4F * progress);
      uiContext.getUiRenderContext().fillRoundedRect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), rect.getHeight() / 2.0F, UiContext.multiplyAlpha(color2, floatValue));
      uiContext.getUiRenderContext().strokeRoundedRect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), rect.getHeight() / 2.0F, 0.75F, UiContext.multiplyAlpha(color3, floatValue));
      uiContext.drawCenteredText(text, rect.centerX(), rect.centerY(), TextStyle.CAPTION, UiContext.multiplyAlpha(booleanValue ? themeSnapshot2.getPrimaryText() : UiContext.blendColors(themeSnapshot2.getSecondaryText2(), themeSnapshot2.getPrimaryText(), progress), floatValue));
      uiContext.getInputRouter().addClickRegion(rect3, uiLayer, runnable);
   }

   public static void updateStateForUiContext3(UiContext uiContext, String string, ItemListSetting itemListSetting, Rect rect, float floatValue, UiLayer uiLayer, Rect rect2, float floatValue2, boolean booleanValue, boolean booleanValue2, Runnable runnable) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      float x = rect.getX() + floatValue;
      float floatValue4 = rect.getWidth() - floatValue * 2.0F;
      float y = rect.getY() + 10.0F;
      Rect rect3 = new Rect(x + floatValue4 - 34.0F, y - 6.0F, 34.0F, 12.0F);
      updateStateForUiContext2(uiContext, string + ".edit", rect3, booleanValue2 ? "Done" : "Edit", booleanValue2, uiLayer, rect2, floatValue2, runnable);
      List items = itemListSetting.getItems();
      int intValue = max(floatValue4);
      String text = null;
      float floatValue6 = rect.getY() + 20.0F;
      if (items.isEmpty()) {
         uiContext.drawVerticallyCenteredText("No items: the key does nothing", x, floatValue6 + 9.0F, TextStyle.CAPTION, UiContext.multiplyAlpha(themeSnapshot2.getDisabledText2(), floatValue2));
      }

      for (int intValue2 = 0; intValue2 < items.size(); intValue2++) {
         Item item = (Item)items.get(intValue2);
         Rect rect4 = new Rect(x + (float)(intValue2 % intValue) * 21.0F, floatValue6 + (float)(intValue2 / intValue) * 21.0F, 18.0F, 18.0F);
         Rect rect5 = rect4.intersection(rect2);
         boolean hovered = uiContext.isHovered(rect5, uiLayer);
         if (hovered) {
            text = getString(item) + "  (click to remove)";
         }

         updateStateForUiContext(uiContext, rect4, item, true, uiContext.animateHover(string + ".c" + intValue2, hovered), floatValue2, booleanValue);
         uiContext.getInputRouter().addClickRegion(rect5, uiLayer, () -> updateStateForItemListSetting(itemListSetting, item));
      }

      if (text != null) {
         float maxWidth = rect3.getX() - x - 70.0F;
         if (maxWidth > 20.0F) {
            uiContext.drawRightAlignedText(uiContext.ellipsize(text, TextStyle.CAPTION, maxWidth), rect3.getX() - 6.0F, y, TextStyle.CAPTION, UiContext.multiplyAlpha(themeSnapshot2.getSecondaryText2(), floatValue2));
         }
      }
   }

   public static int max(float floatValue) {
      return Math.max(1, (int)((floatValue + 3.0F) / 21.0F));
   }

   private static void updateStateForIntConsumer(int intValue, int intValue2, IntConsumer intConsumer, double doubleValue) {
      int intValue3 = Math.max(0, Math.min(intValue, intValue2 - (int)Math.signum(doubleValue)));
      intConsumer.accept(intValue3);
   }

   public static List computeListForItemListSetting(ItemListSetting itemListSetting, String string) {
      String string2 = string == null ? "" : string.trim().toLowerCase(TextStyleAccess4.getROOT());
      ArrayList arrayList = new ArrayList();

      for (Item item : (java.lang.Iterable<Item>)(java.lang.Iterable<?>)(computeList())) {
         if (itemListSetting.isAllowed(item) && (string2.isEmpty() || getString(item).toLowerCase(TextStyleAccess4.getROOT()).contains(string2) || Registries.ITEM.getId(item).getPath().contains(string2))) {
            arrayList.add(item);
         }
      }

      return arrayList;
   }

   public static Rect computeRectForUiContext(
      UiContext uiContext,
      String string,
      ItemListSetting itemListSetting,
      float x,
      float floatValue2,
      float maxWidth,
      UiLayer uiLayer,
      Rect rect,
      float floatValue4,
      boolean booleanValue,
      TextInputModel textInputModel,
      int intValue,
      IntConsumer intConsumer
   ) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      List list = computeListForItemListSetting(itemListSetting, textInputModel.toString());
      Rect rect2 = new Rect(x, floatValue2 + 3.0F, maxWidth, 16.0F);
      TextInputWidget.updateStateForUiContext2(uiContext, string + ".search", rect2, uiLayer, textInputModel, "Search items", Icon.SEARCH, String.valueOf(list.size()), floatValue4);
      int intValue2 = max(maxWidth);
      int intValue3 = (list.size() + intValue2 - 1) / intValue2;
      int intValue4 = Math.max(0, intValue3 - 5);
      int intValue5 = Math.max(0, Math.min(intValue, intValue4));
      float floatValue5 = rect2.bottom() + 3.0F;
      Rect rect3 = new Rect(x, floatValue5, maxWidth, 105.0F);
      uiContext.getInputRouter().addScrollRegion(rect3.intersection(rect), uiLayer, doubleValue -> updateStateForIntConsumer(intValue4, intValue5, intConsumer, doubleValue));
      String string2 = null;
      int intValue6 = intValue5 * intValue2;
      int intValue7 = Math.min(list.size(), intValue6 + 5 * intValue2);

      for (int intValue62 = intValue6; intValue62 < intValue7; intValue62++) {
         Item item = (Item)list.get(intValue62);
         int intValue9 = intValue62 - intValue6;
         Rect rect4 = new Rect(x + (float)(intValue9 % intValue2) * 21.0F, floatValue5 + (float)(intValue9 / intValue2) * 21.0F, 18.0F, 18.0F);
         Rect rect5 = rect4.intersection(rect);
         boolean hovered = uiContext.isHovered(rect5, uiLayer);
         boolean booleanValue2 = itemListSetting.contains(item);
         if (hovered) {
            string2 = getString(item) + (booleanValue2 ? "  (click to remove)" : "  (click to add)");
         }

         updateStateForUiContext(uiContext, rect4, item, booleanValue2, uiContext.animateHover(string + ".p" + intValue9, hovered), floatValue4, booleanValue);
         uiContext.getInputRouter().addClickRegion(rect5, uiLayer, () -> updateStateForItemListSetting2(itemListSetting, item));
      }

      String text = string2 != null
         ? string2
         : (list.isEmpty() ? "Nothing matches" : (intValue4 > 0 ? "Scroll for more (" + (intValue5 + 1) + "/" + (intValue4 + 1) + ")" : "Click to add or remove"));
      uiContext.drawVerticallyCenteredText(uiContext.ellipsize(text, TextStyle.CAPTION, maxWidth), x, rect3.bottom() + 6.0F, TextStyle.CAPTION, UiContext.multiplyAlpha(string2 != null ? themeSnapshot2.getSecondaryText2() : themeSnapshot2.getDisabledText2(), floatValue4));
      return rect2.intersection(rect);
   }

   public static float computeFloat(int intValue, float floatValue) {
      int intValue2 = Math.max(1, (intValue + max(floatValue) - 1) / max(floatValue));
      return 20.0F + (float)intValue2 * 21.0F + 4.0F;
   }

   public static void setItemList(List itemList2) {
      itemList = itemList2;
   }
}
