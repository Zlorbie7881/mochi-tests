package cc.mochi;

import java.io.IOException;
import java.io.InputStream;
import java.nio.FloatBuffer;
import java.nio.charset.StandardCharsets;
import java.util.List;
import org.joml.Matrix4fc;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.system.MemoryUtil;

public final class JumpCircleRenderer {
   private CircleUniformCache circleUniformCache;

   private CircleUniformCache circleUniformCache2;

   private FloatBuffer floatBuffer;

   private CircleUniformCache circleUniformCache3;

   private boolean booleanState;

   private static final int[] intArray = new int[]{11, 12};

   private int intState;

   private CircleUniformCache circleUniformCache4;

   private CircleUniformCache circleUniformCache5;

   private CircleUniformCache circleUniformCache6;

   private FramebufferAttachment[] framebufferAttachmentArray;

   private int intState2;

   private final float[] floatArray3 = new float[16];

   private int intState3;

   private FramebufferAttachment[] framebufferAttachmentArray2;

   private CircleUniformCache circleUniformCache7;

   private int intState4;

   private boolean booleanState2;

   private int intState5;

   private int intState6;

   private CircleUniformCache circleUniformCache8;

   private FramebufferAttachment framebufferAttachment;

   private void updateStateForList(List list, int intValue, JumpCircleRenderStyle jumpCircleRenderStyle, float[] floatArray, boolean booleanValue) {
      int intValue2 = booleanValue ? 1 : 0;
      GL30.glBindVertexArray(this.intState5);
      this.circleUniformCache3.glUseProgram();
      this.updateStateForCircleUniformCache(this.circleUniformCache3, jumpCircleRenderStyle, floatArray, intValue2);

      for (JumpCircleInstance jumpCircleInstance : (java.lang.Iterable<JumpCircleInstance>)(java.lang.Iterable<?>)(list)) {
         if (!(jumpCircleInstance.floatState18 <= 0.002F) || !(jumpCircleInstance.floatState <= 0.002F) || !(jumpCircleInstance.floatState3 <= 0.002F)) {
            float floatValue = Math.max(Math.max(jumpCircleInstance.floatState6 * 1.05F, jumpCircleInstance.floatState13 * 1.6F), jumpCircleInstance.floatState > 0.002F ? jumpCircleInstance.floatState15 + 0.1F : 0.0F);
            GL20.glUniform3f(this.circleUniformCache3.computeIfAbsent("uCenter"), jumpCircleInstance.floatState2, jumpCircleInstance.floatState16, jumpCircleInstance.floatState11);
            GL20.glUniform1f(this.circleUniformCache3.computeIfAbsent("uExtent"), Math.max(floatValue, 0.05F));
            GL20.glUniform1f(this.circleUniformCache3.computeIfAbsent("uCircleRadius"), jumpCircleInstance.floatState6);
            GL20.glUniform1f(this.circleUniformCache3.computeIfAbsent("uCircleAlpha"), jumpCircleInstance.floatState18);
            GL20.glUniform1f(this.circleUniformCache3.computeIfAbsent("uSpin"), jumpCircleInstance.floatState4);
            GL20.glUniform1f(this.circleUniformCache3.computeIfAbsent("uWaveRadius"), jumpCircleInstance.floatState15);
            GL20.glUniform1f(this.circleUniformCache3.computeIfAbsent("uWaveAlpha"), jumpCircleInstance.floatState);
            GL20.glUniform1f(this.circleUniformCache3.computeIfAbsent("uPoolRadius"), jumpCircleInstance.floatState13);
            GL20.glUniform1f(this.circleUniformCache3.computeIfAbsent("uPoolAlpha"), jumpCircleInstance.floatState3);
            GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 6);
         }
      }

      this.circleUniformCache5.glUseProgram();
      this.updateStateForCircleUniformCache(this.circleUniformCache5, jumpCircleRenderStyle, floatArray, intValue2);
      GL20.glUniform1i(this.circleUniformCache5.computeIfAbsent("uMajor"), 192);
      GL20.glUniform1i(this.circleUniformCache5.computeIfAbsent("uMinor"), 24);
      GL11.glEnable(GL11.GL_CULL_FACE);
      GL11.glCullFace(GL11.GL_FRONT);

      for (JumpCircleInstance jumpCircleInstance2 : (java.lang.Iterable<JumpCircleInstance>)(java.lang.Iterable<?>)(list)) {
         if (!(jumpCircleInstance2.floatState14 <= 0.002F) && !(jumpCircleInstance2.floatState10 <= 0.01F)) {
            GL20.glUniform3f(this.circleUniformCache5.computeIfAbsent("uCenter"), jumpCircleInstance2.floatState2, jumpCircleInstance2.floatState16, jumpCircleInstance2.floatState11);
            GL20.glUniform1f(this.circleUniformCache5.computeIfAbsent("uRadius"), jumpCircleInstance2.floatState10);
            GL20.glUniform1f(this.circleUniformCache5.computeIfAbsent("uWidth"), jumpCircleInstance2.floatState5);
            GL20.glUniform1f(this.circleUniformCache5.computeIfAbsent("uAlpha"), jumpCircleInstance2.floatState14);
            GL20.glUniform1f(this.circleUniformCache5.computeIfAbsent("uSeed"), jumpCircleInstance2.floatState17);
            double doubleValue = Math.atan2((double)(-jumpCircleInstance2.floatState11), (double)(-jumpCircleInstance2.floatState2));
            int intValue3 = (int)Math.round((doubleValue < 0.0 ? doubleValue + (Math.PI * 2) : doubleValue) / (Math.PI * 2) * 192.0);
            this.updateState4(intValue3 + 48, 96);
            this.updateState4(intValue3 - 48, 96);
         }
      }

      GL11.glCullFace(GL11.GL_BACK);
      GL11.glDisable(GL11.GL_CULL_FACE);
      this.circleUniformCache6.glUseProgram();
      this.updateStateForCircleUniformCache(this.circleUniformCache6, jumpCircleRenderStyle, floatArray, intValue2);
      GL20.glUniform1i(this.circleUniformCache6.computeIfAbsent("uSegments"), 96);

      for (JumpCircleInstance jumpCircleInstance3 : (java.lang.Iterable<JumpCircleInstance>)(java.lang.Iterable<?>)(list)) {
         if (!(jumpCircleInstance3.floatState9 <= 0.002F) && !(jumpCircleInstance3.floatState12 <= 0.01F)) {
            GL20.glUniform3f(this.circleUniformCache6.computeIfAbsent("uCenter"), jumpCircleInstance3.floatState2, jumpCircleInstance3.floatState16, jumpCircleInstance3.floatState11);
            GL20.glUniform1f(this.circleUniformCache6.computeIfAbsent("uDissolve"), jumpCircleInstance3.floatState7);

            for (int intValue4 = 0; intValue4 < 2; intValue4++) {
               float floatValue2 = intValue4 == 0 ? 1.0F : 0.62F;
               GL20.glUniform1f(this.circleUniformCache6.computeIfAbsent("uRadius"), jumpCircleInstance3.floatState8 * floatValue2);
               GL20.glUniform1f(this.circleUniformCache6.computeIfAbsent("uHeight"), jumpCircleInstance3.floatState12 * (intValue4 == 0 ? 1.0F : 1.12F));
               GL20.glUniform1f(this.circleUniformCache6.computeIfAbsent("uAlpha"), jumpCircleInstance3.floatState9 * (intValue4 == 0 ? 0.8F : 1.0F));
               GL20.glUniform1f(this.circleUniformCache6.computeIfAbsent("uSeed"), jumpCircleInstance3.floatState17 + (float)intValue4 * 0.53F);
               GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 576);
            }
         }
      }

      this.circleUniformCache2.glUseProgram();
      this.updateStateForCircleUniformCache(this.circleUniformCache2, jumpCircleRenderStyle, floatArray, intValue2);
      GL20.glUniform1i(this.circleUniformCache2.computeIfAbsent("uMajor"), 160);
      GL20.glUniform1i(this.circleUniformCache2.computeIfAbsent("uMinor"), 16);

      for (JumpCircleInstance jumpCircleInstance4 : (java.lang.Iterable<JumpCircleInstance>)(java.lang.Iterable<?>)(list)) {
         for (int intValue5 = 0; intValue5 < Math.min(jumpCircleInstance4.intState, 3); intValue5++) {
            if (!(jumpCircleInstance4.floatArray[intValue5] <= 0.002F) && !(jumpCircleInstance4.floatArray3[intValue5] <= 0.0F)) {
               GL20.glUniform3f(this.circleUniformCache2.computeIfAbsent("uCenter"), jumpCircleInstance4.floatState2, jumpCircleInstance4.floatState16 + jumpCircleInstance4.floatArray3[intValue5], jumpCircleInstance4.floatState11);
               GL20.glUniform1f(this.circleUniformCache2.computeIfAbsent("uRadius"), jumpCircleInstance4.floatArray2[intValue5]);
               GL20.glUniform1f(this.circleUniformCache2.computeIfAbsent("uTube"), jumpCircleInstance4.floatArray3[intValue5]);
               GL20.glUniform1f(this.circleUniformCache2.computeIfAbsent("uAlpha"), jumpCircleInstance4.floatArray[intValue5]);
               GL20.glUniform1f(this.circleUniformCache2.computeIfAbsent("uSeed"), jumpCircleInstance4.floatState17 + (float)intValue5 * 0.71F);
               GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 15360);
            }
         }
      }

      if (intValue > 0) {
         this.circleUniformCache8.glUseProgram();
         this.updateStateForCircleUniformCache(this.circleUniformCache8, jumpCircleRenderStyle, floatArray, intValue2);
         GL30.glBindVertexArray(this.intState2);
         GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, intValue);
      }

      GL30.glBindVertexArray(this.intState5);
   }

   private void updateState() {
      updateStateForFramebufferAttachment(this.framebufferAttachment);
      if (this.framebufferAttachmentArray2 != null) {
         for (FramebufferAttachment framebufferAttachment2 : this.framebufferAttachmentArray2) {
            updateStateForFramebufferAttachment(framebufferAttachment2);
         }
      }

      if (this.framebufferAttachmentArray != null) {
         for (FramebufferAttachment framebufferAttachment3 : this.framebufferAttachmentArray) {
            updateStateForFramebufferAttachment(framebufferAttachment3);
         }
      }

      this.framebufferAttachment = null;
      this.framebufferAttachmentArray2 = this.framebufferAttachmentArray = null;
      this.intState6 = this.intState4 = 0;
   }

   private static float computeFloat(float floatValue, int intValue) {
      return 0.55F * computeFloat3(0.9F, intValue) / computeFloat3(floatValue, intValue);
   }

   private void updateState2() {
      GL30.glBindVertexArray(this.intState5);
      GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 3);
   }

   private void updateState3(int intState62, int intState42) {
      if (this.framebufferAttachment == null || this.intState6 != intState62 || this.intState4 != intState42) {
         this.updateState();
         this.intState6 = intState62;
         this.intState4 = intState42;
         this.framebufferAttachment = this.computeFramebufferAttachment(intState62, intState42);
         int intValue = 0;
         int intValue2 = intState62 / 2;

         for (int intValue3 = intState42 / 2; intValue < 6 && intValue2 >= 4 && intValue3 >= 4; intValue3 /= 2) {
            intValue++;
            intValue2 /= 2;
         }

         intValue = Math.max(1, intValue);
         this.framebufferAttachmentArray2 = new FramebufferAttachment[intValue];
         this.framebufferAttachmentArray = new FramebufferAttachment[intValue];
         intValue2 = Math.max(1, intState62 / 2);
         int intValue4 = Math.max(1, intState42 / 2);

         for (int intValue5 = 0; intValue5 < intValue; intValue5++) {
            this.framebufferAttachmentArray2[intValue5] = this.computeFramebufferAttachment(intValue2, intValue4);
            this.framebufferAttachmentArray[intValue5] = this.computeFramebufferAttachment(intValue2, intValue4);
            intValue2 = Math.max(1, intValue2 / 2);
            intValue4 = Math.max(1, intValue4 / 2);
         }
      }
   }

   private static float computeFloat2(float floatValue) {
      return floatValue <= 0.04045F ? floatValue / 12.92F : (float)Math.pow((double)((floatValue + 0.055F) / 1.055F), 2.4F);
   }

   private void updateStateForCircleUniformCache(CircleUniformCache circleUniformCache9, JumpCircleRenderStyle jumpCircleRenderStyle, float[] floatArray, int intValue) {
      GL20.glUniformMatrix4fv(circleUniformCache9.computeIfAbsent("uViewProj"), false, this.floatArray3);
      GL20.glUniform3f(circleUniformCache9.computeIfAbsent("uColor"), jumpCircleRenderStyle.floatState2, jumpCircleRenderStyle.floatState5, jumpCircleRenderStyle.floatState4);
      GL20.glUniform3f(circleUniformCache9.computeIfAbsent("uColorLinear"), floatArray[0], floatArray[1], floatArray[2]);
      GL20.glUniform1f(circleUniformCache9.computeIfAbsent("uTime"), jumpCircleRenderStyle.floatState6);
      GL20.glUniform1i(circleUniformCache9.computeIfAbsent("uEmission"), intValue);
   }

   private void updateStateForJumpCircleRenderStyle(JumpCircleRenderStyle jumpCircleRenderStyle) {
      GL11.glDisable(GL11.GL_BLEND);
      int length = this.framebufferAttachmentArray2.length;
      this.circleUniformCache.glUseProgram();
      GL20.glUniform1i(this.circleUniformCache.computeIfAbsent("uSource"), 11);
      FramebufferAttachment framebufferAttachment2 = this.framebufferAttachment;

      for (int intValue = 0; intValue < length; intValue++) {
         FramebufferAttachment framebufferAttachment3 = this.framebufferAttachmentArray2[intValue];
         GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, framebufferAttachment3.fbo());
         GL11.glViewport(0, 0, framebufferAttachment3.width(), framebufferAttachment3.height());
         updateState7(11, framebufferAttachment2.texture());
         GL20.glUniform2f(this.circleUniformCache.computeIfAbsent("uSourceTexel"), 1.0F / (float)framebufferAttachment2.width(), 1.0F / (float)framebufferAttachment2.height());
         GL20.glUniform2f(this.circleUniformCache.computeIfAbsent("uTargetSize"), (float)framebufferAttachment3.width(), (float)framebufferAttachment3.height());
         this.updateState2();
         framebufferAttachment2 = framebufferAttachment3;
      }

      float floatValue = computeFloat4(jumpCircleRenderStyle.floatState);
      FramebufferAttachment framebufferAttachment52 = this.framebufferAttachmentArray2[length - 1];
      this.circleUniformCache4.glUseProgram();
      GL20.glUniform1i(this.circleUniformCache4.computeIfAbsent("uLevel"), 11);
      GL20.glUniform1i(this.circleUniformCache4.computeIfAbsent("uCoarse"), 12);
      GL20.glUniform1f(this.circleUniformCache4.computeIfAbsent("uGrowth"), floatValue);

      for (int intValue2 = length - 2; intValue2 >= 0; intValue2--) {
         FramebufferAttachment framebufferAttachment5 = this.framebufferAttachmentArray[intValue2];
         GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, framebufferAttachment5.fbo());
         GL11.glViewport(0, 0, framebufferAttachment5.width(), framebufferAttachment5.height());
         updateState7(11, this.framebufferAttachmentArray2[intValue2].texture());
         updateState7(12, framebufferAttachment52.texture());
         GL20.glUniform2f(this.circleUniformCache4.computeIfAbsent("uCoarseTexel"), 1.0F / (float)framebufferAttachment52.width(), 1.0F / (float)framebufferAttachment52.height());
         GL20.glUniform2f(this.circleUniformCache4.computeIfAbsent("uTargetSize"), (float)framebufferAttachment5.width(), (float)framebufferAttachment5.height());
         this.updateState2();
         framebufferAttachment52 = framebufferAttachment5;
      }

      GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, this.intState3);
      GL11.glViewport(0, 0, this.intState6, this.intState4);
      GL11.glEnable(GL11.GL_BLEND);
      GL14.glBlendFuncSeparate(GL11.GL_ONE_MINUS_DST_COLOR, GL11.GL_ONE, GL11.GL_ZERO, GL11.GL_ONE);
      this.circleUniformCache7.glUseProgram();
      updateState7(11, framebufferAttachment52.texture());
      GL20.glUniform1i(this.circleUniformCache7.computeIfAbsent("uBloom"), 11);
      GL20.glUniform2f(this.circleUniformCache7.computeIfAbsent("uBloomTexel"), 1.0F / (float)framebufferAttachment52.width(), 1.0F / (float)framebufferAttachment52.height());
      GL20.glUniform2f(this.circleUniformCache7.computeIfAbsent("uResolution"), (float)this.intState6, (float)this.intState4);
      GL20.glUniform1f(this.circleUniformCache7.computeIfAbsent("uExposure"), computeFloat(floatValue, length) * jumpCircleRenderStyle.floatState3);
      this.updateState2();
   }

   private boolean checkCondition() {
      this.circleUniformCache3 = this.computeCircleUniformCache("jumpcircles/ground.vsh", "jumpcircles/ground.fsh");
      this.circleUniformCache5 = this.computeCircleUniformCache("jumpcircles/water.vsh", "jumpcircles/water.fsh");
      this.circleUniformCache6 = this.computeCircleUniformCache("jumpcircles/pillar.vsh", "jumpcircles/pillar.fsh");
      this.circleUniformCache2 = this.computeCircleUniformCache("jumpcircles/torus.vsh", "jumpcircles/torus.fsh");
      this.circleUniformCache8 = this.computeCircleUniformCache("jumpcircles/spark.vsh", "jumpcircles/spark.fsh");
      this.circleUniformCache = this.computeCircleUniformCache("outlines/fullscreen.vsh", "outlines/bloom_down.fsh");
      this.circleUniformCache4 = this.computeCircleUniformCache("outlines/fullscreen.vsh", "outlines/bloom_up.fsh");
      this.circleUniformCache7 = this.computeCircleUniformCache("outlines/fullscreen.vsh", "jumpcircles/bloom_composite.fsh");
      if (this.booleanState) {
         this.updateState6();
         return false;
      } else {
         this.intState5 = GL30.glGenVertexArrays();
         this.intState2 = GL30.glGenVertexArrays();
         this.intState = GL15.glGenBuffers();
         GL30.glBindVertexArray(this.intState2);
         GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, this.intState);
         GL20.glVertexAttribPointer(0, 3, GL11.GL_FLOAT, false, 28, 0L);
         GL20.glEnableVertexAttribArray(0);
         GL20.glVertexAttribPointer(1, 2, GL11.GL_FLOAT, false, 28, 12L);
         GL20.glEnableVertexAttribArray(1);
         GL20.glVertexAttribPointer(2, 2, GL11.GL_FLOAT, false, 28, 20L);
         GL20.glEnableVertexAttribArray(2);
         GL30.glBindVertexArray(this.intState5);
         this.intState3 = GL30.glGenFramebuffers();
         this.booleanState2 = true;
         return true;
      }
   }

   private static void updateStateForFramebufferAttachment(FramebufferAttachment framebufferAttachment2) {
      if (framebufferAttachment2 != null) {
         GL30.glDeleteFramebuffers(framebufferAttachment2.fbo());
         GL11.glDeleteTextures(framebufferAttachment2.texture());
      }
   }

   private static String computeString(String string) {
      try {
         String string2;
         try (InputStream resourceAsStream = JumpCircleRenderer.class.getResourceAsStream("/assets/mochi/shaders/" + string)) {
            string2 = resourceAsStream == null ? null : new String(resourceAsStream.readAllBytes(), StandardCharsets.UTF_8);
         }

         return string2;
      } catch (IOException failure) {
         return null;
      }
   }

   public boolean getBooleanState() {
      return this.booleanState;
   }

   private void updateState4(int intValue, int intValue2) {
      int intValue3 = Math.floorMod(intValue, 192);
      int intValue4 = Math.min(intValue2, 192 - intValue3);
      GL11.glDrawArrays(GL11.GL_TRIANGLES, intValue3 * 144, intValue4 * 144);
      if (intValue2 > intValue4) {
         GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, (intValue2 - intValue4) * 144);
      }
   }

   public void updateStateForList2(List list, float[] floatArray, int intValue, JumpCircleRenderStyle jumpCircleRenderStyle, Matrix4fc matrix4fc, int intValue2, int intValue3, int intState62, int intState42) {
      if (!this.booleanState && (!list.isEmpty() || intValue != 0) && intValue2 != 0 && intValue3 != 0 && intState62 > 0 && intState42 > 0) {
         try {
            try (
               OpenGlStateGuard openGlStateGuard = OpenGlStateGuard.capture(intArray);
               GlTextureBindings glTextureBindings = cc.mochi.GlTextureBindings.createGlTextureBindings(intArray);
            ) {
               if (this.booleanState2 || this.checkCondition()) {
                  matrix4fc.get(this.floatArray3);
                  int intValue6 = this.computeInt2(floatArray, intValue);
                  float[] floatArray2 = new float[]{computeFloat2(jumpCircleRenderStyle.floatState2), computeFloat2(jumpCircleRenderStyle.floatState5), computeFloat2(jumpCircleRenderStyle.floatState4)};
                  GL11.glDisable(GL11.GL_SCISSOR_TEST);
                  GL11.glDisable(GL11.GL_STENCIL_TEST);
                  GL11.glDisable(GL11.GL_CULL_FACE);
                  GL11.glColorMask(true, true, true, true);
                  GL11.glDepthMask(false);
                  if (jumpCircleRenderStyle.booleanState2) {
                     GL11.glDisable(GL11.GL_DEPTH_TEST);
                  } else {
                     GL11.glEnable(GL11.GL_DEPTH_TEST);
                     GL11.glDepthFunc(GL11.GL_LEQUAL);
                  }

                  GL11.glEnable(GL11.GL_BLEND);
                  GL14.glBlendEquation(GL14.GL_FUNC_ADD);
                  GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, this.intState3);
                  GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, intValue2, 0);
                  GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_DEPTH_ATTACHMENT, GL11.GL_TEXTURE_2D, intValue3, 0);

                  try {
                     if (GL30.glCheckFramebufferStatus(GL30.GL_FRAMEBUFFER) == 36053) {
                        GL11.glViewport(0, 0, intState62, intState42);
                        GL14.glBlendFuncSeparate(GL11.GL_ONE, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ONE_MINUS_SRC_ALPHA);
                        this.updateStateForList(list, intValue6, jumpCircleRenderStyle, floatArray2, false);
                        if (jumpCircleRenderStyle.booleanState && jumpCircleRenderStyle.floatState3 > 0.0F) {
                           this.updateState3(intState62, intState42);
                           GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, this.framebufferAttachment.fbo());
                           GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_DEPTH_ATTACHMENT, GL11.GL_TEXTURE_2D, intValue3, 0);

                           try {
                              if (GL30.glCheckFramebufferStatus(GL30.GL_FRAMEBUFFER) == 36053) {
                                 GL11.glViewport(0, 0, intState62, intState42);
                                 GL11.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
                                 GL11.glClear(16384);
                                 GL14.glBlendFuncSeparate(GL11.GL_ONE, GL11.GL_ONE, GL11.GL_ONE, GL11.GL_ONE);
                                 this.updateStateForList(list, intValue6, jumpCircleRenderStyle, floatArray2, true);
                                 GL11.glDisable(GL11.GL_DEPTH_TEST);
                                 this.updateStateForJumpCircleRenderStyle(jumpCircleRenderStyle);
                                 return;
                              }
                           } finally {
                              GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, this.framebufferAttachment.fbo());
                              GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_DEPTH_ATTACHMENT, GL11.GL_TEXTURE_2D, 0, 0);
                           }
                        }

                        return;
                     }

                     return;
                  } finally {
                     GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, this.intState3);
                     GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, 0, 0);
                     GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_DEPTH_ATTACHMENT, GL11.GL_TEXTURE_2D, 0, 0);
                  }
               }
            }
         } catch (RuntimeException failure) {
            this.booleanState = true;
         }
      }
   }

   public void updateState5() {
      this.updateState();
      this.updateState6();
      if (this.intState5 != 0) {
         GL30.glDeleteVertexArrays(this.intState5);
      }

      if (this.intState2 != 0) {
         GL30.glDeleteVertexArrays(this.intState2);
      }

      if (this.intState != 0) {
         GL15.glDeleteBuffers(this.intState);
      }

      if (this.intState3 != 0) {
         GL30.glDeleteFramebuffers(this.intState3);
      }

      this.intState5 = this.intState2 = this.intState = this.intState3 = 0;
      if (this.floatBuffer != null) {
         MemoryUtil.memFree(this.floatBuffer);
         this.floatBuffer = null;
      }

      this.booleanState2 = false;
      this.booleanState = false;
   }

   private static float computeFloat3(float floatValue, int intValue) {
      float floatValue2 = 0.0F;
      float floatValue3 = 1.0F;

      for (int intValue2 = 0; intValue2 < intValue; intValue2++) {
         floatValue2 += floatValue3;
         floatValue3 *= floatValue;
      }

      return floatValue2;
   }

   private void updateState6() {
      for (CircleUniformCache circleUniformCache9 : new CircleUniformCache[]{this.circleUniformCache3, this.circleUniformCache5, this.circleUniformCache6, this.circleUniformCache2, this.circleUniformCache8, this.circleUniformCache, this.circleUniformCache4, this.circleUniformCache7}) {
         if (circleUniformCache9 != null) {
            GL20.glDeleteProgram(circleUniformCache9.intState);
         }
      }

      this.circleUniformCache3 = this.circleUniformCache5 = this.circleUniformCache6 = this.circleUniformCache2 = this.circleUniformCache8 = null;
      this.circleUniformCache = this.circleUniformCache4 = this.circleUniformCache7 = null;
   }

   private CircleUniformCache computeCircleUniformCache(String string, String string2) {
      if (this.booleanState) {
         return null;
      } else {
         int intValue = this.computeInt(35633, string);
         int intValue2 = intValue == 0 ? 0 : this.computeInt(35632, string2);
         if (intValue != 0 && intValue2 != 0) {
            int intValue3 = GL20.glCreateProgram();
            GL20.glAttachShader(intValue3, intValue);
            GL20.glAttachShader(intValue3, intValue2);
            GL20.glLinkProgram(intValue3);
            GL20.glDetachShader(intValue3, intValue);
            GL20.glDetachShader(intValue3, intValue2);
            GL20.glDeleteShader(intValue);
            GL20.glDeleteShader(intValue2);
            if (GL20.glGetProgrami(intValue3, 35714) == 0) {
               GL20.glDeleteProgram(intValue3);
               this.booleanState = true;
               return null;
            } else {
               return new CircleUniformCache(intValue3);
            }
         } else {
            if (intValue != 0) {
               GL20.glDeleteShader(intValue);
            }

            this.booleanState = true;
            return null;
         }
      }
   }

   private int computeInt(int intValue, String string) {
      String string2 = computeString(string);
      if (string2 == null) {
         return 0;
      } else {
         int intValue2 = GL20.glCreateShader(intValue);
         GL20.glShaderSource(intValue2, string2);
         GL20.glCompileShader(intValue2);
         if (GL20.glGetShaderi(intValue2, 35713) == 0) {
            GL20.glDeleteShader(intValue2);
            return 0;
         } else {
            return intValue2;
         }
      }
   }

   private static void updateState7(int intValue, int intValue2) {
      GL13.glActiveTexture(33984 + intValue);
      GL11.glBindTexture(GL11.GL_TEXTURE_2D, intValue2);
   }

   private void put(float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5, float floatValue6, float floatValue7) {
      this.floatBuffer.put(floatValue).put(floatValue2).put(floatValue3).put(floatValue4).put(floatValue5).put(floatValue6).put(floatValue7);
   }

   static float computeFloat4(float floatValue) {
      return 0.55F + 0.32F * Math.max(0.5F, Math.min(3.0F, floatValue));
   }

   private FramebufferAttachment computeFramebufferAttachment(int intValue, int intValue2) {
      int intValue3 = GL11.glGenTextures();
      GL13.glActiveTexture(GL13.GL_TEXTURE11);
      GL11.glBindTexture(GL11.GL_TEXTURE_2D, intValue3);
      GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
      GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
      GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, org.lwjgl.opengl.GL12.GL_CLAMP_TO_EDGE);
      GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, org.lwjgl.opengl.GL12.GL_CLAMP_TO_EDGE);
      GL11.glTexParameteri(GL11.GL_TEXTURE_2D, org.lwjgl.opengl.GL12.GL_TEXTURE_BASE_LEVEL, 0);
      GL11.glTexParameteri(GL11.GL_TEXTURE_2D, org.lwjgl.opengl.GL12.GL_TEXTURE_MAX_LEVEL, 0);
      GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL30.GL_RGBA16F, intValue, intValue2, 0, GL11.GL_RGBA, GL11.GL_FLOAT, 0L);
      int intValue4 = GL30.glGenFramebuffers();
      GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, intValue4);
      GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, intValue3, 0);
      return new FramebufferAttachment(intValue4, intValue3, intValue, intValue2);
   }

   private int computeInt2(float[] floatArray, int intValue) {
      if (floatArray != null && intValue > 0) {
         int intValue2 = intValue * 6 * 7;
         if (this.floatBuffer == null || this.floatBuffer.capacity() < intValue2) {
            if (this.floatBuffer != null) {
               MemoryUtil.memFree(this.floatBuffer);
            }

            this.floatBuffer = MemoryUtil.memAllocFloat(Math.max(intValue2, 2048));
         }

         this.floatBuffer.clear();
         int intValue3 = 0;

         for (int intValue4 = 0; intValue4 < intValue; intValue4++) {
            int intValue5 = intValue4 * 9;
            float floatValue = floatArray[intValue5];
            float floatValue2 = floatArray[intValue5 + 1];
            float floatValue3 = floatArray[intValue5 + 2];
            float floatValue4 = floatArray[intValue5 + 3];
            float floatValue5 = floatArray[intValue5 + 4];
            float floatValue6 = floatArray[intValue5 + 5];
            float floatValue7 = floatArray[intValue5 + 6];
            float floatValue8 = floatArray[intValue5 + 7];
            float floatValue9 = floatArray[intValue5 + 8];
            float floatValue10 = (float)Math.sqrt((double)(floatValue4 * floatValue4 + floatValue5 * floatValue5 + floatValue6 * floatValue6));
            float floatValue11;
            float floatValue12;
            float floatValue13;
            if (floatValue10 > 1.0E-4F) {
               floatValue11 = floatValue4 / floatValue10;
               floatValue12 = floatValue5 / floatValue10;
               floatValue13 = floatValue6 / floatValue10;
            } else {
               floatValue11 = 0.0F;
               floatValue12 = 1.0F;
               floatValue13 = 0.0F;
            }

            float floatValue14 = Math.max(floatValue7 * 2.5F, Math.min(floatValue10 * 0.034F, 0.45F));
            float floatValue15 = floatValue12 * -floatValue3 - floatValue13 * -floatValue2;
            float floatValue16 = floatValue13 * -floatValue - floatValue11 * -floatValue3;
            float floatValue17 = floatValue11 * -floatValue2 - floatValue12 * -floatValue;
            float floatValue18 = (float)Math.sqrt((double)(floatValue15 * floatValue15 + floatValue16 * floatValue16 + floatValue17 * floatValue17));
            if (!(floatValue18 < 1.0E-5F)) {
               floatValue15 = floatValue15 / floatValue18 * floatValue7;
               floatValue16 = floatValue16 / floatValue18 * floatValue7;
               floatValue17 = floatValue17 / floatValue18 * floatValue7;
               float floatValue19 = floatValue + floatValue11 * floatValue7;
               float floatValue20 = floatValue2 + floatValue12 * floatValue7;
               float floatValue21 = floatValue3 + floatValue13 * floatValue7;
               float floatValue22 = floatValue - floatValue11 * floatValue14;
               float floatValue23 = floatValue2 - floatValue12 * floatValue14;
               float floatValue24 = floatValue3 - floatValue13 * floatValue14;
               this.put(floatValue22 - floatValue15, floatValue23 - floatValue16, floatValue24 - floatValue17, ((-1.0F)), ((-1.0F)), floatValue8, floatValue9);
               this.put(floatValue19 - floatValue15, floatValue20 - floatValue16, floatValue21 - floatValue17, 1.0F, ((-1.0F)), floatValue8, floatValue9);
               this.put(floatValue19 + floatValue15, floatValue20 + floatValue16, floatValue21 + floatValue17, 1.0F, 1.0F, floatValue8, floatValue9);
               this.put(floatValue22 - floatValue15, floatValue23 - floatValue16, floatValue24 - floatValue17, ((-1.0F)), ((-1.0F)), floatValue8, floatValue9);
               this.put(floatValue19 + floatValue15, floatValue20 + floatValue16, floatValue21 + floatValue17, 1.0F, 1.0F, floatValue8, floatValue9);
               this.put(floatValue22 + floatValue15, floatValue23 + floatValue16, floatValue24 + floatValue17, ((-1.0F)), 1.0F, floatValue8, floatValue9);
               intValue3++;
            }
         }

         if (intValue3 == 0) {
            return 0;
         } else {
            this.floatBuffer.flip();
            GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, this.intState);
            GL15.glBufferData(GL15.GL_ARRAY_BUFFER, (long)this.floatBuffer.capacity() * 4L, GL15.GL_STREAM_DRAW);
            GL15.glBufferSubData(GL15.GL_ARRAY_BUFFER, 0L, this.floatBuffer);
            return intValue3 * 6;
         }
      } else {
         return 0;
      }
   }
}
