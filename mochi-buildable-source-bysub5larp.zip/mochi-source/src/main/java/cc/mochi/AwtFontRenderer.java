package cc.mochi;

import com.google.common.base.Preconditions;
import com.mojang.blaze3d.opengl.GlStateManager;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import it.unimi.dsi.fastutil.chars.Char2IntArrayMap;
import it.unimi.dsi.fastutil.chars.Char2ObjectArrayMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectArrayMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import it.unimi.dsi.fastutil.objects.ObjectList;
import it.unimi.dsi.fastutil.objects.ObjectListIterator;
import java.awt.Color;
import java.awt.Font;
import java.io.Closeable;
import java.util.List;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

public class AwtFontRenderer implements Closeable {
   private int intState;
   private final Char2ObjectArrayMap<Glyph> char2ObjectArrayMap;

   private static final Char2IntArrayMap char2IntArrayMap = new CharAdvanceMap();

   private final float floatState;
   private final ObjectList<GlyphPage> objectList = new ObjectArrayList();
   private Font[] fontArray;
   private final int intState2;
   private final int intState3;
   private int intState4;

   private static final Object2ObjectArrayMap<Identifier, ObjectList<GlyphDraw>> object2ObjectArrayMap = new Object2ObjectArrayMap();

   private void updateState(Font[] fontArray2, float floatValue) {
      this.intState = ClientRenderHelpers.max();
      this.intState4 = this.intState;
      this.fontArray = new Font[fontArray2.length];

      for (int intValue = 0; intValue < fontArray2.length; intValue++) {
         this.fontArray[intValue] = fontArray2[intValue].deriveFont(floatValue * (float)this.intState4);
      }
   }

   public AwtFontRenderer(Font[] fontArray2, float floatState2, int intState32, int intState22) {
      this.char2ObjectArrayMap = new Char2ObjectArrayMap();
      this.intState4 = 0;
      this.intState = -1;
      Preconditions.checkArgument(fontArray2.length > 0, "fonts.length == 0");
      Preconditions.checkArgument(intState32 > 4, "Unreasonable charactersPerPage count");
      Preconditions.checkArgument(intState22 > 0, "paddingBetweenCharacters > 0");
      this.floatState = floatState2;
      this.intState3 = intState32;
      this.intState2 = intState22;
      this.updateState(fontArray2, floatState2);
   }

   public void updateStateForMatrixStack(MatrixStack matrixStack, String string, float floatValue, float floatValue2, Color color) {
      this.updateStateForMatrixStack2(matrixStack, string, floatValue - this.computeFloat2(string) / 2.0F, floatValue2, color);
   }

   public float computeFloat(String string) {
      char[] charArray = computeString(string).toCharArray();
      if (charArray.length == 0) {
         charArray = new char[]{' '};
      }

      float floatValue = 0.0F;
      float floatValue2 = 0.0F;

      for (char charValue : charArray) {
         if (charValue == '\n') {
            if (floatValue == 0.0F) {
               floatValue = (float)this.computeIfAbsent(' ').getHeight() / (float)this.intState4;
            }

            floatValue2 += floatValue;
            floatValue = 0.0F;
         } else {
            Glyph glyph = this.computeIfAbsent(charValue);
            floatValue = Math.max((float)glyph.getHeight() / (float)this.intState4, floatValue);
         }
      }

      return floatValue + floatValue2;
   }

   private void updateState2() {
      int intValue = ClientRenderHelpers.max();
      if (intValue != this.intState) {
         this.close();
         this.updateState(this.fontArray, this.floatState);
      }
   }

   private static int computeInt(int intValue, int intValue2) {
      return intValue2 * (int)Math.floor((double)intValue / (double)intValue2);
   }

   public void updateStateForMatrixStack2(MatrixStack matrixStack, String string, float floatValue, float floatValue2, Color color) {
      float floatValue3 = (float)color.getRed() / 255.0F;
      float floatValue4 = (float)color.getGreen() / 255.0F;
      float floatValue5 = (float)color.getBlue() / 255.0F;
      float floatValue6 = (float)color.getAlpha() / 255.0F;
      this.updateState2();
      float floatValue32 = floatValue3;
      float floatValue42 = floatValue4;
      float floatValue52 = floatValue5;
      matrixStack.push();
      matrixStack.translate(floatValue, floatValue2, 0.0F);
      matrixStack.scale(1.0F / (float)this.intState4, 1.0F / (float)this.intState4, 1.0F);
      GlStateManager._enableBlend();
      GlStateManager._blendFuncSeparate(770, 771, 1, 0);
      GlStateManager._disableCull();
      RenderSystemAccess.updateState2();
      Matrix4f positionMatrix = matrixStack.peek().getPositionMatrix();
      char[] charArray = string.toCharArray();
      float floatValue10 = 0.0F;
      float floatValue11 = 0.0F;
      boolean booleanValue = false;
      int intValue = 0;

      for (int intValue2 = 0; intValue2 < charArray.length; intValue2++) {
         char charValue = charArray[intValue2];
         if (booleanValue) {
            booleanValue = false;
            char charValue2 = Character.toUpperCase(charValue);
            if (char2IntArrayMap.containsKey(charValue2)) {
               int rgb = char2IntArrayMap.get(charValue2);
               int[] intArray = ColorChannels.unpackRgb(rgb);
               floatValue32 = (float)intArray[0] / 255.0F;
               floatValue42 = (float)intArray[1] / 255.0F;
               floatValue52 = (float)intArray[2] / 255.0F;
            } else if (charValue2 == 'R') {
               floatValue32 = floatValue3;
               floatValue42 = floatValue4;
               floatValue52 = floatValue5;
            }
         } else if (charValue == 167) {
            booleanValue = true;
         } else if (charValue == '\n') {
            floatValue11 += this.computeFloat(string.substring(intValue, intValue2)) * (float)this.intState4;
            floatValue10 = 0.0F;
            intValue = intValue2 + 1;
         } else {
            Glyph glyph = this.computeIfAbsent(charValue);
            if (glyph.getValue() != ' ') {
               Identifier identifier = glyph.getOwner().identifier;
               GlyphDraw glyphDraw = new GlyphDraw(floatValue10, floatValue11, floatValue32, floatValue42, floatValue52, glyph);
               ((ObjectList)object2ObjectArrayMap.computeIfAbsent(identifier, objectValue -> createObjectList(objectValue))).add(glyphDraw);
            }

            floatValue10 += (float)glyph.getWidth();
         }
      }

      ObjectIterator objectIterator = object2ObjectArrayMap.keySet().iterator();

      while (objectIterator.hasNext()) {
         Identifier identifier2 = (Identifier)objectIterator.next();
         GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_NEAREST);
         GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_NEAREST);
         List list = (List)object2ObjectArrayMap.get(identifier2);
         BufferBuilder bufferBuilder = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);

         for (GlyphDraw glyphDraw2 : (java.lang.Iterable<GlyphDraw>)(java.lang.Iterable<?>)(list)) {
            float floatValue12 = glyphDraw2.atX();
            float floatValue13 = glyphDraw2.atY();
            float floatValue14 = glyphDraw2.r();
            float floatValue15 = glyphDraw2.g();
            float floatValue16 = glyphDraw2.b();
            Glyph glyph2 = glyphDraw2.toDraw();
            GlyphPage owner = glyph2.getOwner();
            float width = (float)glyph2.getWidth();
            float height = (float)glyph2.getHeight();
            float floatValue17 = (float)glyph2.getU() / (float)owner.width;
            float floatValue18 = (float)glyph2.getV() / (float)owner.height;
            float floatValue19 = (float)(glyph2.getU() + glyph2.getWidth()) / (float)owner.width;
            float floatValue20 = (float)(glyph2.getV() + glyph2.getHeight()) / (float)owner.height;
            bufferBuilder.vertex(positionMatrix, floatValue12 + 0.0F, floatValue13 + height, 0.0F).texture(floatValue17, floatValue20).color(floatValue14, floatValue15, floatValue16, floatValue6);
            bufferBuilder.vertex(positionMatrix, floatValue12 + width, floatValue13 + height, 0.0F).texture(floatValue19, floatValue20).color(floatValue14, floatValue15, floatValue16, floatValue6);
            bufferBuilder.vertex(positionMatrix, floatValue12 + width, floatValue13 + 0.0F, 0.0F).texture(floatValue19, floatValue18).color(floatValue14, floatValue15, floatValue16, floatValue6);
            bufferBuilder.vertex(positionMatrix, floatValue12 + 0.0F, floatValue13 + 0.0F, 0.0F).texture(floatValue17, floatValue18).color(floatValue14, floatValue15, floatValue16, floatValue6);
         }

         BufferSubmission.updateStateForBufferBuilder(bufferBuilder);
      }

      matrixStack.pop();
      object2ObjectArrayMap.clear();
   }

   private Glyph computeIfAbsent(char charValue) {
      return (Glyph)this.char2ObjectArrayMap.computeIfAbsent(charValue, charValue2 -> this.computeGlyph(charValue2));
   }

   @Override
   public void close() {
      ObjectListIterator objectListIterator = this.objectList.iterator();

      while (objectListIterator.hasNext()) {
         GlyphPage glyphPage = (GlyphPage)objectListIterator.next();
         glyphPage.updateState2();
      }

      this.objectList.clear();
      this.char2ObjectArrayMap.clear();
   }

   public AwtFontRenderer(Font[] fontArray2, float floatState2) {
      this(fontArray2, floatState2, 256, 5);
   }

   public static String computeString(String string) {
      char[] charArray = string.toCharArray();
      StringBuilder stringBuilder = new StringBuilder();

      for (int intValue = 0; intValue < charArray.length; intValue++) {
         char charValue = charArray[intValue];
         if (charValue == 167) {
            intValue++;
         } else {
            stringBuilder.append(charValue);
         }
      }

      return stringBuilder.toString();
   }

   private GlyphPage computeGlyphPage(char charValue, char charValue2) {
      GlyphPage glyphPage = new GlyphPage(charValue, charValue2, this.fontArray, ClientRenderHelpers.computeIdentifier(), this.intState2);
      this.objectList.add(glyphPage);
      return glyphPage;
   }

   public float computeFloat2(String string) {
      char[] charArray = computeString(string).toCharArray();
      float floatValue = 0.0F;
      float floatValue2 = 0.0F;

      for (char charValue : charArray) {
         if (charValue == '\n') {
            floatValue2 = Math.max(floatValue, floatValue2);
            floatValue = 0.0F;
         } else {
            Glyph glyph = this.computeIfAbsent(charValue);
            floatValue += (float)glyph.getWidth() / (float)this.intState4;
         }
      }

      return Math.max(floatValue, floatValue2);
   }

   private Glyph computeGlyph(char charValue) {
      ObjectListIterator objectListIterator = this.objectList.iterator();

      while (objectListIterator.hasNext()) {
         GlyphPage glyphPage = (GlyphPage)objectListIterator.next();
         if (glyphPage.checkCondition(charValue)) {
            return glyphPage.computeGlyph(charValue);
         }
      }

      int intValue = computeInt(charValue, this.intState3);
      GlyphPage glyphPage2 = this.computeGlyphPage((char)intValue, (char)(intValue + this.intState3));
      return glyphPage2.computeGlyph(charValue);
   }

   private static ObjectList createObjectList(Object objectValue) {
      return new ObjectArrayList();
   }
}
