package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.world.GameMode;

public class MinecraftClientAccess28 {
   public static Hand getMAIN_HAND() {
      return Hand.MAIN_HAND;
   }

   public static Type getENTITY() {
      return Type.ENTITY;
   }

   public static ClientWorld getWorld(MinecraftClient minecraftClient) {
      return minecraftClient.world;
   }

   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static GameMode getSPECTATOR() {
      return GameMode.SPECTATOR;
   }

   public static HitResult getCrosshairTarget(MinecraftClient minecraftClient) {
      return minecraftClient.crosshairTarget;
   }

   public static ClientPlayerInteractionManager getInteractionManager(MinecraftClient minecraftClient) {
      return minecraftClient.interactionManager;
   }

}
