package cc.mochi;

import java.awt.Color;
import java.util.Locale;

public class ColorAccess7 {
   public static Locale getROOT() {
      return Locale.ROOT;
   }

   public static Color getColor5() {
      return LegacyUiTheme.color5;
   }

   public static FontFace getFontFace2() {
      return LegacyUiTheme.fontFace2;
   }

   public static Color getWHITE() {
      return Color.WHITE;
   }

   public static Color getColor() {
      return LegacyUiTheme.color;
   }

}
