package cc.mochi;

public class IconAccess {
   public static Icon getRESET() {
      return Icon.RESET;
   }

   public static Icon getKEYBOARD() {
      return Icon.KEYBOARD;
   }

   public static Icon getDOT() {
      return Icon.DOT;
   }

   public static Icon getLAYOUT() {
      return Icon.LAYOUT;
   }

   public static Icon getSLIDERS() {
      return Icon.SLIDERS;
   }

   public static Icon getFOLDER() {
      return Icon.FOLDER;
   }

   public static Icon getTRASH() {
      return Icon.TRASH;
   }

   public static Icon getPOWER() {
      return Icon.POWER;
   }

   public static Icon getARROW_RIGHT() {
      return Icon.ARROW_RIGHT;
   }

   public static Icon getBOLT() {
      return Icon.BOLT;
   }

   public static Icon getCLIPBOARD() {
      return Icon.CLIPBOARD;
   }

   public static Icon getPALETTE() {
      return Icon.PALETTE;
   }

   public static Icon getCHECK() {
      return Icon.CHECK;
   }

   public static Icon getGRID() {
      return Icon.GRID;
   }

   public static Icon getMOUSE() {
      return Icon.MOUSE;
   }

   public static Icon getSPARK() {
      return Icon.SPARK;
   }

   public static Icon getCHEVRON_UP() {
      return Icon.CHEVRON_UP;
   }

   public static Icon getSETTINGS() {
      return Icon.SETTINGS;
   }

   public static Icon getWRENCH() {
      return Icon.WRENCH;
   }
}
