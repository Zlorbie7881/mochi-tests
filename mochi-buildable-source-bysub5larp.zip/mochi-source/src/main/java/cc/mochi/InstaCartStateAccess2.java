package cc.mochi;

public class InstaCartStateAccess2 {
   public static InstaCartState getHOLD() {
      return InstaCartState.HOLD;
   }

   public static InstaCartState getIDLE() {
      return InstaCartState.IDLE;
   }

   public static InstaCartState getCART() {
      return InstaCartState.CART;
   }

   public static InstaCartState getCOVER() {
      return InstaCartState.COVER;
   }

}
