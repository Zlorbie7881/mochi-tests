package cc.mochi;

import java.io.File;

public class FileAccess {
   public static String getPathSeparator() {
      return File.pathSeparator;
   }
}
