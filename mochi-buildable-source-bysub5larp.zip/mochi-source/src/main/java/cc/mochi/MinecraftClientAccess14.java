package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.player.PlayerAbilities;
import net.minecraft.item.Item;
import net.minecraft.item.Items;

public class MinecraftClientAccess14 {
   public static KeyBinding getJumpKey(GameOptions gameOptions) {
      return gameOptions.jumpKey;
   }

   public static KeyBinding getSprintKey(GameOptions gameOptions) {
      return gameOptions.sprintKey;
   }

   public static GameOptions getOptions(MinecraftClient minecraftClient) {
      return minecraftClient.options;
   }

   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static boolean getFlying(PlayerAbilities playerAbilities) {
      return playerAbilities.flying;
   }

   public static Screen getCurrentScreen(MinecraftClient minecraftClient) {
      return minecraftClient.currentScreen;
   }

   public static Item getELYTRA() {
      return Items.ELYTRA;
   }

}
