package cc.mochi;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.fluid.Fluid;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public class EntityTypeAccess {
   public static ShapeType getCOLLIDER() {
      return ShapeType.COLLIDER;
   }

   public static EntityType<TntMinecartEntity> getTNT_MINECART() {
      return EntityType.TNT_MINECART;
   }

   public static FluidHandling getNONE() {
      return FluidHandling.NONE;
   }

   public static Type getBLOCK() {
      return Type.BLOCK;
   }

   public static TagKey<Fluid> getWATER() {
      return FluidTags.WATER;
   }

}
