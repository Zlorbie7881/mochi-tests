package cc.mochi;

import java.awt.Color;
import net.minecraft.client.gui.DrawContext;

public final class LayoutRenderer {
   private LayoutRenderer() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }

   public static void updateStateForDrawContext(DrawContext drawContext, GridLayout gridLayout) {
      for (GridCell gridCell : gridLayout.gridCellList) {
         LegacyWidgets.updateStateForDrawContext(drawContext, gridCell.getIntState(), gridCell.getIntState5(), gridCell.getIntState4(), gridCell.getIntState6(), 0, 1, new Color(0, 255, 0, 100));
      }
   }

   public static void updateStateForDrawContext2(DrawContext drawContext, FlexLayout flexLayout) {
      for (LayoutChild layoutChild : flexLayout.layoutChildList) {
         LegacyWidgets.updateStateForDrawContext(drawContext, layoutChild.getIntState8(), layoutChild.getIntState7(), layoutChild.getIntState3(), layoutChild.getIntState4(), 0, 1, new Color(255, 0, 0, 100));
      }
   }
}
