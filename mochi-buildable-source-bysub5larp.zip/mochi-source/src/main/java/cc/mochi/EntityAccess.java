package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;

public final class EntityAccess {
   public static boolean testPlayerEntity(PlayerEntity playerEntity) {
      if (playerEntity == null) {
         return false;
      } else {
         MinecraftClient minecraftClient = MinecraftClient.getInstance();
         if (minecraftClient.player == null) {
            return false;
         } else {
            if (FriendManager.testUUID(playerEntity.getUuid())) {
               return true;
            } else {
               if (playerEntity.getScoreboardTeam() == null) {
                  return false;
               } else {
                  return (playerEntity.getScoreboardTeam() == MinecraftClientAccess6.getPlayer(minecraftClient).getScoreboardTeam());
               }
            }
         }
      }
   }

   private EntityAccess() {
   }
}
