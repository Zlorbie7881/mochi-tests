package cc.mochi;

public record HotbarItemPattern(String item, int count, String potion, String effects, int color, boolean glint) {
   public HotbarItemPattern(String item, int count, String potion, String effects, int color, boolean glint) {
      item = item == null ? "" : item;
      potion = potion == null ? "" : potion;
      effects = effects == null ? "" : effects;

      count = Math.max(1, count);
      this.item = item;
      this.count = count;
      this.potion = potion;
      this.effects = effects;
      this.color = color;
      this.glint = glint;
   }

   public static String getEffects(HotbarItemPattern hotbarItemPattern) {
      return hotbarItemPattern.effects;
   }

   public int getColor2() {
      return getColor(this);
   }

   public String buildPatternKey() {
      return HotbarPatternSetting.buildPatternKey(getItem2(this), this.potion, getEffects(this));
   }

   public int getCount() {
      return this.count;
   }

   public static int getColor(HotbarItemPattern hotbarItemPattern) {
      return hotbarItemPattern.color;
   }

   public static boolean getGlint(HotbarItemPattern hotbarItemPattern) {
      return hotbarItemPattern.glint;
   }

   public boolean checkCondition() {
      if (this.potion.isEmpty()) {
         if (this.effects.isEmpty()) {
            return false;
         }
      }

      return true;
   }

   public boolean getGlint2() {
      return getGlint(this);
   }

   public String getItem() {
      return this.item;
   }

   public static String getItem2(HotbarItemPattern hotbarItemPattern) {
      return hotbarItemPattern.item;
   }

   public String getEffects2() {
      return this.effects;
   }

   public String getPotion() {
      return this.potion;
   }
}
