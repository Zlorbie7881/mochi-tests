package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;

public class GameOptionsAccess2 {
   public static GameOptions getOptions(MinecraftClient minecraftClient) {
      return minecraftClient.options;
   }

   public static KeyBinding getSprintKey(GameOptions gameOptions) {
      return gameOptions.sprintKey;
   }
}
