package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.component.ComponentType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.item.Item;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public class MinecraftClientAccess38 {
   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static double getX(Vec3d vec3d) {
      return vec3d.x;
   }

   public static double getMinY(Box box) {
      return box.minY;
   }

   public static double getZ(Vec3d vec3d) {
      return vec3d.z;
   }

   public static KeyBinding getUseKey(GameOptions gameOptions) {
      return gameOptions.useKey;
   }

   public static double getY(Vec3d vec3d) {
      return vec3d.y;
   }

   public static double getMaxZ(Box box) {
      return box.maxZ;
   }

   public static TagKey<Item> getSPEARS() {
      return ItemTags.SPEARS;
   }

   public static ClientWorld getWorld(MinecraftClient minecraftClient) {
      return minecraftClient.world;
   }

   public static GameOptions getOptions(MinecraftClient minecraftClient) {
      return minecraftClient.options;
   }

   public static HitResult getCrosshairTarget(MinecraftClient minecraftClient) {
      return minecraftClient.crosshairTarget;
   }

   public static void setCrosshairTarget(MinecraftClient minecraftClient, HitResult crosshairTarget) {
      minecraftClient.crosshairTarget = crosshairTarget;
   }

   public static MochiClient getINSTANCE() {
      return MochiClient.INSTANCE;
   }

   public static double getMaxY(Box box) {
      return box.maxY;
   }

   public static double getMaxX(Box box) {
      return box.maxX;
   }

   public static ComponentType<ItemEnchantmentsComponent> getENCHANTMENTS() {
      return DataComponentTypes.ENCHANTMENTS;
   }

   public static double getMinZ(Box box) {
      return box.minZ;
   }

   public static TagKey<Item> getSWORDS() {
      return ItemTags.SWORDS;
   }

   public static ActionPriority getHIGH() {
      return ActionPriority.HIGH;
   }

   public static Vec3d getZERO() {
      return Vec3d.ZERO;
   }

   public static double getMinX(Box box) {
      return box.minX;
   }

}
