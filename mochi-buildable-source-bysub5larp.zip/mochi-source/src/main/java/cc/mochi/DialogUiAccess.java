package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;

public class DialogUiAccess {
   public static TextStyle getCAPTION() {
      return TextStyle.CAPTION;
   }

   public static UiLayer getRAISED() {
      return UiLayer.RAISED;
   }

   public static ButtonVariant getSECONDARY() {
      return ButtonVariant.SECONDARY;
   }

   public static Screen getCurrentScreen(MinecraftClient minecraftClient) {
      return minecraftClient.currentScreen;
   }

   public static MochiClient getINSTANCE() {
      return MochiClient.INSTANCE;
   }

   public static Icon getCLOSE() {
      return Icon.CLOSE;
   }

   public static TextStyle computeTextStyle() {
      return TextStyle.LABEL;
   }

   public static ButtonVariant getGHOST() {
      return ButtonVariant.GHOST;
   }

   public static Icon getRESET() {
      return Icon.RESET;
   }

   public static Icon getLAYOUT() {
      return Icon.LAYOUT;
   }

   public static TextStyle getSMALL() {
      return TextStyle.SMALL;
   }

   public static UiLayer getBASE() {
      return UiLayer.BASE;
   }

}
