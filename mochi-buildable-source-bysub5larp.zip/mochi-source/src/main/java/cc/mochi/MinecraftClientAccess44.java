package cc.mochi;

import cc.mochi.event.types.TransferOrder;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.world.GameMode;

public class MinecraftClientAccess44 {
   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static ClientWorld getWorld(MinecraftClient minecraftClient) {
      return minecraftClient.world;
   }

   public static Hand getMAIN_HAND() {
      return Hand.MAIN_HAND;
   }

   public static Item getTNT_MINECART() {
      return Items.TNT_MINECART;
   }

   public static KeyBinding getUseKey(GameOptions gameOptions) {
      return gameOptions.useKey;
   }

   public static InstaCartState getTAKEBACK() {
      return InstaCartState.TAKEBACK;
   }

   public static TransferOrder getRECEIVE() {
      return TransferOrder.RECEIVE;
   }

   public static GameOptions getOptions(MinecraftClient minecraftClient) {
      return minecraftClient.options;
   }

   public static GameMode getSPECTATOR() {
      return GameMode.SPECTATOR;
   }

   public static Direction getUP() {
      return Direction.UP;
   }

   public static MochiClient getINSTANCE() {
      return MochiClient.INSTANCE;
   }

   public static double getMinY(Box box) {
      return box.minY;
   }

   public static double getMinZ(Box box) {
      return box.minZ;
   }

   public static Screen getCurrentScreen(MinecraftClient minecraftClient) {
      return minecraftClient.currentScreen;
   }

   public static double getMinX(Box box) {
      return box.minX;
   }

   public static InstaCartState getRAIL() {
      return InstaCartState.RAIL;
   }

   public static ClientPlayerInteractionManager getInteractionManager(MinecraftClient minecraftClient) {
      return minecraftClient.interactionManager;
   }

   public static InstaCartState getHOLD() {
      return InstaCartState.HOLD;
   }

   public static InstaCartState getIDLE() {
      return InstaCartState.IDLE;
   }

   public static ActionPriority getHIGH() {
      return ActionPriority.HIGH;
   }

}
