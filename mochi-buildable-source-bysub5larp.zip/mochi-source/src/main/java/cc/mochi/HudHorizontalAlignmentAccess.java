package cc.mochi;

public class HudHorizontalAlignmentAccess {
   public static HudVerticalAlignment getTOP() {
      return HudVerticalAlignment.TOP;
   }

   public static HudHorizontalAlignment getLEFT() {
      return HudHorizontalAlignment.LEFT;
   }
}
