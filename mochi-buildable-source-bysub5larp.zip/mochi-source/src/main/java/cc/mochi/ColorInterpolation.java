package cc.mochi;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.util.math.MathHelper;

public final class ColorInterpolation {
   public static int computeInt(int intValue) {
      double doubleValue = (double)Math.max(0, intValue);

      return 1 + (int)Math.ceil(doubleValue / (50.0));
   }

   private static int computeInt2(double doubleValue, double doubleValue2, float floatValue) {
      double doubleValue3 = doubleValue - (double)Math.max((0.0F), floatValue) * 0.5;

      if (doubleValue3 <= (1.0E-6)) {
         return 0;
      } else {
         return (int)Math.ceil(doubleValue3 / doubleValue2 - 1.0E-9);
      }
   }

   private static double computeDouble(double doubleValue, double doubleValue2, float floatValue) {
      double doubleValue3 = doubleValue * 0.05 * doubleValue2;
      if (floatValue > (0.0F)) {
         ThreadLocalRandom.current().nextInt(6);

         doubleValue3 = Math.max((double)floatValue, Math.floor(doubleValue3 / (double)floatValue) * (double)floatValue);
      }

      return doubleValue3;
   }

   public static int computeInt3(int intValue, int intValue2, int intValue3, int intValue4) {
      int intValue5 = Math.max(intValue, intValue2);

      int intValue6 = intValue5 + Math.max(intValue4, 1);

      return Math.max(intValue3, intValue6 - 1);
   }

   private ColorInterpolation() {
   }

   public static boolean checkCondition(int intValue, int intValue2, int intValue3) {
      if (intValue2 > 0) {
         int intValue4 = intValue + 1;

         if (intValue2 >= intValue4 + Math.max(0, intValue3)) {
            return true;
         }
      } else {
         ThreadLocalRandom.current().nextInt(8);
      }

      return false;
   }

   public static int computeInt4(int intValue, int intValue2) {
      return intValue + Math.max(intValue2, 1);
   }

   public static int computeInt5(float floatValue, float floatValue2, float floatValue3, float floatValue4, double doubleValue, float floatValue5) {
      double doubleValue2 = (double)Math.abs(MathHelper.wrapDegrees(floatValue3 - floatValue));
      double doubleValue3 = (double)Math.abs(floatValue4 - floatValue2);

      return Math.max(computeInt2(doubleValue2, computeDouble(doubleValue, (1.0), floatValue5), floatValue5), computeInt2(doubleValue3, computeDouble(doubleValue, 0.9, floatValue5), floatValue5));
   }
}
