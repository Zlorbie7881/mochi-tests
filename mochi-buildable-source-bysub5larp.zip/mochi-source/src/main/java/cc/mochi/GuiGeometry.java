package cc.mochi;

import com.mojang.blaze3d.opengl.GlStateManager;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import java.awt.Color;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;

public class GuiGeometry {
   public static void updateStateForBufferBuilder(BufferBuilder bufferBuilder, Matrix4f matrix4f, float floatValue, float floatValue2, float floatValue3, float floatValue4, Color color, Color color2) {
      updateStateForBufferBuilder3(bufferBuilder, matrix4f, floatValue, floatValue2, floatValue3, floatValue4, color, color, color2, color2);
   }

   public static void updateStateForBufferBuilder2(BufferBuilder bufferBuilder, Matrix4f matrix4f, float floatValue, float floatValue2, float floatValue3, float floatValue4, Color color) {
      updateStateForBufferBuilder3(bufferBuilder, matrix4f, floatValue, floatValue2, floatValue3, floatValue4, color, color, color, color);
   }

   public static void updateStateForMatrixStack(MatrixStack matrixStack, float floatValue, float floatValue2, float floatValue3, float floatValue4, Color color) {
      Matrix4f positionMatrix = matrixStack.peek().getPositionMatrix();
      updateState();
      RenderSystemAccess.updateState();
      BufferBuilder bufferBuilder = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_COLOR);
      bufferBuilder.vertex(positionMatrix, floatValue, floatValue4, 0.0F).color(color.getRGB());
      bufferBuilder.vertex(positionMatrix, floatValue3, floatValue4, 0.0F).color(color.getRGB());
      bufferBuilder.vertex(positionMatrix, floatValue3, floatValue2, 0.0F).color(color.getRGB());
      bufferBuilder.vertex(positionMatrix, floatValue, floatValue2, 0.0F).color(color.getRGB());
      BuiltBuffer builtBuffer = bufferBuilder.end();
      if (builtBuffer != null) {
         builtBuffer.close();
      }

      updateState2();
   }

   public static void updateState() {
      GlStateManager._enableBlend();
      GlStateManager._blendFuncSeparate(770, 771, 1, 0);
   }

   public static void updateStateForBufferBuilder3(BufferBuilder bufferBuilder, Matrix4f matrix4f, float floatValue, float floatValue2, float floatValue3, float floatValue4, Color color, Color color2, Color color3, Color color4) {
      bufferBuilder.vertex(matrix4f, floatValue3, floatValue2, 0.0F).color(color2.getRGB());
      bufferBuilder.vertex(matrix4f, floatValue, floatValue2, 0.0F).color(color.getRGB());
      bufferBuilder.vertex(matrix4f, floatValue, floatValue4, 0.0F).color(color4.getRGB());
      bufferBuilder.vertex(matrix4f, floatValue3, floatValue4, 0.0F).color(color3.getRGB());
   }

   public static void updateStateForBufferBuilder4(BufferBuilder bufferBuilder, Matrix4f matrix4f, float floatValue, float floatValue2, float floatValue3, float floatValue4, Color color, Color color2) {
      updateStateForBufferBuilder3(bufferBuilder, matrix4f, floatValue, floatValue2, floatValue3, floatValue4, color, color2, color2, color);
   }

   public static void updateStateForMatrixStack2(MatrixStack matrixStack, float floatValue, float floatValue2, float floatValue3, float floatValue4, Color color, Color color2) {
      Matrix4f positionMatrix = matrixStack.peek().getPositionMatrix();
      updateState();
      RenderSystemAccess.updateState();
      BufferBuilder bufferBuilder = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_COLOR);
      bufferBuilder.vertex(positionMatrix, floatValue, floatValue4, 0.0F).color(color.getRGB());
      bufferBuilder.vertex(positionMatrix, floatValue3, floatValue4, 0.0F).color(color.getRGB());
      bufferBuilder.vertex(positionMatrix, floatValue3, floatValue2, 0.0F).color(color.getRGB());
      bufferBuilder.vertex(positionMatrix, floatValue, floatValue2, 0.0F).color(color.getRGB());
      BuiltBuffer builtBuffer = bufferBuilder.end();
      if (builtBuffer != null) {
         builtBuffer.close();
      }

      bufferBuilder = Tessellator.getInstance().begin(DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR);
      bufferBuilder.vertex(positionMatrix, floatValue, floatValue4, 0.0F).color(color2.getRGB());
      bufferBuilder.vertex(positionMatrix, floatValue3, floatValue4, 0.0F).color(color2.getRGB());
      bufferBuilder.vertex(positionMatrix, floatValue3, floatValue2, 0.0F).color(color2.getRGB());
      bufferBuilder.vertex(positionMatrix, floatValue, floatValue2, 0.0F).color(color2.getRGB());
      bufferBuilder.vertex(positionMatrix, floatValue, floatValue4, 0.0F).color(color2.getRGB());
      builtBuffer = bufferBuilder.end();
      if (builtBuffer != null) {
         builtBuffer.close();
      }

      updateState2();
   }

   public static void updateState2() {
      GlStateManager._blendFuncSeparate(770, 771, 1, 0);
      GlStateManager._disableBlend();
   }

   public static void updateStateForMatrixStack3(MatrixStack matrixStack, float floatValue, float floatValue2, float floatValue3, float floatValue4, Color color, Color color2) {
      Matrix4f positionMatrix = matrixStack.peek().getPositionMatrix();
      updateState();
      RenderSystemAccess.updateState();
      BufferBuilder bufferBuilder = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_COLOR);
      bufferBuilder.vertex(positionMatrix, floatValue, floatValue2, 0.0F).color(color.getRGB());
      bufferBuilder.vertex(positionMatrix, floatValue, floatValue4, 0.0F).color(color.getRGB());
      bufferBuilder.vertex(positionMatrix, floatValue3, floatValue4, 0.0F).color(color2.getRGB());
      bufferBuilder.vertex(positionMatrix, floatValue3, floatValue2, 0.0F).color(color2.getRGB());
      BuiltBuffer builtBuffer = bufferBuilder.end();
      if (builtBuffer != null) {
         builtBuffer.close();
      }

      updateState2();
   }
}
