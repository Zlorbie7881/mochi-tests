package cc.mochi;

import java.io.RandomAccessFile;

import java.util.ArrayList;

import cc.mochi.utils.keybinding.simulation.SimulatedClicks;
import cc.mochi.utils.platform.OverlayWindowManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.URI;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.security.SecureRandom;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import meteordevelopment.orbit.IEventBus;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.ChatHud;
import org.slf4j.ILoggerFactory;
import org.slf4j.LoggerFactory;

public final class ClientCleanup {
   private static final String[] stringArray3 = new String[]{"cubes-without-borders", "cubes_without_borders"};

   private static final String[] stringArray2 = new String[]{"cwb-", "cwb_", "cwb."};

   private static final String[] stringArray = new String[]{".json", ".txt", ".cfg", ".conf", ".properties", ".toml", ".yml", ".yaml", ".log", ".ini"};
   private static final SecureRandom secureRandom = new SecureRandom();

   private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();

   private static final Set<String> stringSet = ConcurrentHashMap.newKeySet();
   private static volatile boolean booleanState;

   private static void updateState() {
      File file;
      try {
         file = FabricLoader.getInstance().getConfigDir().toFile();
      } catch (Throwable failure) {
         return;
      }

      ThreadLocalRandom.current().nextInt(15);

      updateStateForFile10(new File(file, "modmenu.json"));
      updateStateForFile10(new File(file, "fabric_loader_dependencies.json"));
      updateStateForFile8(new File(file, ClientText.CLIENT_NAME.toString()));
      updateStateForFile6(file);
      updateState26();
   }

   private static void updateStateForFile(File file, int intValue) {
      if (file != null) {
         if (intValue <= 4) {
            if (file.exists()) {
               if (!file.isDirectory()) {
                  if (checkCondition3(file.getName())) {
                     updateStateForFile13(file);
                     return;
                  }

                  updateStateForFile4(file);
                  return;
               }

               if (checkCondition3(file.getName())) {
                  updateStateForFile8(file);
                  return;
               }

               File[] fileArray = file.listFiles();
               if (fileArray == null) {
                  return;
               }

               File[] fileArray2 = fileArray;
               int length = fileArray.length;

               for (int intValue2 = 0; intValue2 < length; intValue2++) {
                  File file2 = fileArray2[intValue2];
                  updateStateForFile(file2, intValue + 1);
               }

               return;
            }
         }
      }
   }

   private static void updateState2() {
      try {
         Thread current = Thread.currentThread();
         for (Thread thread : Thread.getAllStackTraces().keySet()) {
            if (thread == null || thread == current || !checkCondition2(thread.getName())) continue;
            try {
               thread.setName("Worker-" + Integer.toHexString(getSecureRandom().nextInt()));
            } catch (Throwable ignored) {
            }
         }
      } catch (Throwable ignored) {
      }
   }

   private static File computeFile() {
      label48: {
         label47: {
            label52: {
               MinecraftClient minecraftClient;
               try {
                  minecraftClient = MinecraftClient.getInstance();
                  if (minecraftClient == null) {
                     break label47;
                  }
               } catch (Throwable failure) {
                  break label52;
               }

               try {
                  if (MediaFileAccess.getRunDirectory(minecraftClient) == null) {
                     break label47;
                  }
               } catch (Throwable failure2) {
                  break label52;
               }

               try {
                  return minecraftClient.runDirectory;
               } catch (Throwable failure3) {
               }
            }

            break label48;
         }
      }

      return new File(".");
   }

   static boolean checkCondition(String string) {
      if (string != null) {
         if (!string.isBlank()) {
            ThreadLocalRandom.current().nextInt(5);
            String string2 = string.toLowerCase(MediaFileAccess.getROOT());
            if (string2.contains("mochi")) {
               return true;
            }

            String[] stringArray4 = getStringArray3();
            int length = stringArray4.length;
            int intValue = 0;

            while (intValue < length) {
               String string3 = stringArray4[intValue];
               if (string2.contains(string3)) {
                  return true;
               }

               intValue++;
            }

            stringArray4 = getStringArray2();
            length = stringArray4.length;
            intValue = 0;

            while (intValue < length) {
               String string4 = stringArray4[intValue];
               if (string2.startsWith(string4)) {
                  return true;
               }

               intValue++;
            }

            return false;
         }

         ThreadLocalRandom.current().nextInt(14);
      }

      return false;
   }

   private static void updateStateForFile2(File file) {
      if (file != null) {
         if (file.isDirectory()) {
            File[] fileArray = file.listFiles();
            if (fileArray == null) {
               return;
            }

            File[] fileArray2 = fileArray;
            int length = fileArray.length;
            int intValue = 0;

            while (true) {
               if (intValue >= length) {
                  return;
               }

               File file2 = fileArray2[intValue];
               if (file2.isFile() && testFile2(file2)) {
                  if (!file2.delete()) {
                     updateStateForFile7(file2);
                  }
               }

               intValue++;
            }
         }
      }
   }

   private static void updateStateForClass(Object objectValue, Object objectValue2, Class objectValue3, int intValue) {
      if (objectValue != null) {
         if (intValue <= 1) {
            label87: {
               label88: {
                  try {
                     if (objectValue instanceof Collection var4) {
                        var4.removeIf(objectValue4 -> testClass3(objectValue2, objectValue3, objectValue4));
                        if (intValue != 0) {
                           return;
                        }
                        break label88;
                     }
                  } catch (Throwable failure) {
                     break label87;
                  }

                  try {
                     if (objectValue instanceof Map var5) {
                        var5.entrySet().removeIf(objectValue5 -> testClass2(objectValue2, objectValue3, (Entry)objectValue5));
                        return;
                     }
                  } catch (Throwable failure2) {
                     break label87;
                  }

                  return;
               }

               try {
                  for (Object objectValue6 : new ArrayList((Collection)objectValue)) {
                     updateStateForClass(objectValue6, objectValue2, objectValue3, intValue + 1);
                  }
               } catch (Throwable failure3) {
                  break label87;
               }

               return;
            }

            return;
         }
      } else {
         ThreadLocalRandom.current().nextInt(4);
      }
   }

   private static void updateState3() {
      label25: {
         try {
            ILoggerFactory iLoggerFactory = LoggerFactory.getILoggerFactory();
            Class objectValue = Class.forName("ch.qos.logback.classic.LoggerContext");
            if (!objectValue.isInstance(iLoggerFactory)) {
               break label25;
            }

            objectValue.getMethod("stop").invoke(iLoggerFactory);
         } catch (Throwable failure) {
            return;
         }
      }
   }

   public static String[] getStringArray3() {
      return stringArray3;
   }

   private static boolean testClass(Object objectValue, Object objectValue2, Class objectValue3) {
      if (objectValue == null) {
         return false;
      } else {
         if (objectValue == objectValue2) {
            return true;
         } else {
            label57: {
               try {
                  if (objectValue3.isInstance(objectValue)) {
                     return true;
                  }
               } catch (Throwable failure) {
                  break label57;
               }
            }

            String string = computeString(objectValue2);
            if (string != null) {
               if (string.equals(computeString(objectValue))) {
                  ThreadLocalRandom.current().nextInt(16);
                  return true;
               }
            }

            return false;
         }
      }
   }

   public static String[] getStringArray2() {
      return stringArray2;
   }

   private static void updateState4() {
      try {
         MochiClient.cleanupRenderers();
      } catch (Throwable failure) {
      }
   }

   public static SecureRandom getSecureRandom() {
      return secureRandom;
   }

   private static void updateState5() {
      updateState7();
      updateState9();
   }

   private static void updateStateForIEventBus(IEventBus iEventBus, Object objectValue) {
      if ((objectValue != null)) {
         try {
            iEventBus.unsubscribe(objectValue);
         } catch (Throwable failure) {
         }
      }
   }

   public static void setBooleanState(boolean booleanState2) {
      booleanState = booleanState2;
   }

   private static boolean checkCondition2(String string) {
      if (string != null) {
         if (!string.isEmpty()) {
            String string2 = string.toLowerCase(Locale.ROOT);
            if (string2.contains("mochi")) {
               return true;
            }

            Path path = computePath();
            if (path == null) {
               return false;
            }

            String string3 = path.getFileName().toString().toLowerCase(MediaFileAccess.getROOT());
            if (!string3.isEmpty()) {
               if (string2.contains(string3)) {
                  return true;
               }
            }

            return false;
         }
      }

      return false;
   }

   private static void updateStateForFile3(File file) throws IOException {
      List list = Files.readAllLines(file.toPath(), MediaFileAccess.getUTF_8());
      List list2 = computeListForList(list);
      if (list2.size() == list.size()) {
         ThreadLocalRandom.current().nextInt(5);
      } else {
         if (!(testFile(file, list2))) {
            File file2 = computeFileForFile(file.getParentFile(), ".old");
            if (file.renameTo(file2)) {
               updateStateForFile7(file2);
               updateStateForFile12(file, list2);
            } else {
               updateStateForFile7(file);
            }
         }
      }
   }

   private static void updateState6() {
      label61: {
         label60: {
            label67: {
               MinecraftClient minecraftClient;
               try {
                  minecraftClient = MinecraftClient.getInstance();
                  if (minecraftClient == null) {
                     break label60;
                  }
               } catch (Throwable failure) {
                  return;
               }

               try {
                  if (MediaFileAccess.getInGameHud(minecraftClient) == null) {
                     break label67;
                  }
               } catch (Throwable failure2) {
                  return;
               }

               try {
                  if (MediaFileAccess.getInGameHud(minecraftClient).getChatHud() == null) {
                     break label61;
                  }
               } catch (Throwable failure3) {
                  return;
               }

               try {
                  ChatHud chatHud = minecraftClient.inGameHud.getChatHud();

                  chatHud.clear(true);
               } catch (Throwable failure4) {
                  return;
               }

               break label61;
            }

            break label61;
         }
      }
   }

   private static void updateStateForFile4(File file) {
      java.util.List list;

      String string = file.getName().toLowerCase(Locale.ROOT);

      String[] stringArray4 = getStringArray();
      int length = stringArray4.length;

      int intValue = 0;

      while (true) {
         if (intValue >= length) {
            ThreadLocalRandom.current().nextInt(9);

            return;
         }

         ThreadLocalRandom.current().nextInt(14);
         String string2 = stringArray4[intValue];
         if (string.endsWith(string2)) {
            if (string.endsWith(".json")) {
               updateStateForFile10(file);
               return;
            }

            try {
               List list2 = Files.readAllLines(file.toPath(), StandardCharsets.UTF_8);
               list = computeListForList(list2);
               if (list.size() == list2.size()) {
                  return;
               }
            } catch (Throwable failure) {
               return;
            }

            label112: {
               try {
                  if (list.isEmpty()) {
                     break label112;
                  }
               } catch (Throwable failure2) {
                  return;
               }

               try {
                  updateStateForFile12(file, list);
               } catch (Throwable failure3) {
               }

               return;
            }

            label99: {
               try {
                  if (file.delete()) {
                     break label99;
                  }
               } catch (Throwable failure4) {
                  return;
               }

               try {
                  updateStateForFile7(file);
               } catch (Throwable failure5) {
                  return;
               }
            }

            try {
               return;
            } catch (Throwable failure6) {
               return;
            }
         }

         intValue++;
      }
   }

   private static File computeFileForFile(File file, String string) {
      String string2 = Long.toHexString(getSecureRandom().nextLong());
      String string3 = Long.toHexString(getSecureRandom().nextLong());
      String string4 = string3 + string2 + string;
      return new File(file, string4);
   }

   private static void updateState7() {
      java.lang.String property;

      label232: {
         label209: {
            label215: {
               Iterator iterator;
               try {
                  iterator = new ArrayList<>(System.getProperties().stringPropertyNames()).iterator();
               } catch (Throwable failure) {
                  break label215;
               }

               while (true) {
                  try {
                     if (!iterator.hasNext()) {
                        break;
                     }
                  } catch (Throwable failure2) {
                     break label215;
                  }

                  label224: {
                     String string;
                     try {
                        string = (String)iterator.next();
                        if (string == null) {
                           break label224;
                        }
                     } catch (Throwable failure3) {
                        break label215;
                     }

                     try {
                        if (!string.toLowerCase(MediaFileAccess.getROOT()).startsWith("mochi.")) {
                           continue;
                        }
                     } catch (Throwable failure4) {
                        break label215;
                     }

                     try {
                        System.clearProperty(string);
                        continue;
                     } catch (Throwable failure5) {
                        break label215;
                     }
                  }
               }

               try {
                  property = System.getProperty("fabric.addMods");
                  if (property == null) {
                     break label209;
                  }
               } catch (Throwable failure6) {
                  break label215;
               }

               try {
                  if (property.isEmpty()) {
                     return;
                  }
               } catch (Throwable failure7) {
                  break label215;
               }

               String string2;
               label218: {
                  try {
                     Path path = computePath();
                     if (path != null) {
                        string2 = path.getFileName().toString();
                        break label218;
                     }
                  } catch (Throwable failure8) {
                     break label215;
                  }

                  try {
                     string2 = null;
                  } catch (Throwable failure9) {
                     break label215;
                  }
               }

               String string22;
               ArrayList arrayList;
               String[] stringArray4;
               int length;
               int intValue;
               try {
                  string22 = string2;
                  arrayList = new ArrayList();
                  stringArray4 = property.split(Pattern.quote(File.pathSeparator));
                  length = stringArray4.length;
                  intValue = 0;
               } catch (Throwable failure10) {
                  break label215;
               }

               while (true) {
                  try {
                     if (intValue >= length) {
                        break;
                     }
                  } catch (Throwable failure11) {
                     break label215;
                  }

                  label226: {
                     String string4;
                     try {
                        string4 = stringArray4[intValue];
                        if (string4 == null) {
                           break label226;
                        }
                     } catch (Throwable failure12) {
                        break label215;
                     }

                     try {
                        if (string4.isBlank()) {
                           break label226;
                        }
                     } catch (Throwable failure13) {
                        break label215;
                     }

                     String name;
                     try {
                        name = new File(string4).getName();
                        if (checkCondition(name)) {
                           break label226;
                        }
                     } catch (Throwable failure14) {
                        break label215;
                     }

                     label227: {
                        label222: {
                           try {
                              if (string22 == null) {
                                 break label222;
                              }
                           } catch (Throwable failure15) {
                              break label215;
                           }

                           try {
                              if (name.equalsIgnoreCase(string22)) {
                                 break label227;
                              }
                           } catch (Throwable failure16) {
                              break label215;
                           }
                        }

                        try {
                           arrayList.add(string4);
                           break label226;
                        } catch (Throwable failure17) {
                           break label215;
                        }
                     }
                  }

                  try {
                     intValue++;
                  } catch (Throwable failure18) {
                     break label215;
                  }
               }

               label223: {
                  try {
                     if (arrayList.isEmpty()) {
                        break label223;
                     }
                  } catch (Throwable failure19) {
                     break label215;
                  }

                  ThreadLocalRandom.current().nextInt(7);

                  try {
                     System.setProperty("fabric.addMods", String.join(File.pathSeparator, arrayList));
                     break label232;
                  } catch (Throwable failure20) {
                     break label215;
                  }
               }

               try {
                  System.clearProperty("fabric.addMods");
                  break label232;
               } catch (Throwable failure21) {
               }
            }

            break label232;
         }

         return;
      }
   }

   private static void updateState8() {
      updateState3();
      File file = new File(computeFile(), "logs");
      File[] fileArray = file.listFiles();
      if (fileArray != null) {
         File[] fileArray2 = fileArray;
         int length = fileArray.length;
         int intValue = 0;

         for (; intValue < length; intValue++) {
            File file2 = fileArray2[intValue];
            String string = file2.getName().toLowerCase(Locale.ROOT);

            label75: {
               label74: {
                  try {
                     if (string.endsWith(".log")) {
                        break label74;
                     }
                  } catch (Throwable failure) {
                     continue;
                  }

                  try {
                     if (!string.endsWith(".log.gz")) {
                        break label75;
                     }
                  } catch (Throwable failure2) {
                     continue;
                  }

                  try {
                     updateStateForFile5(file2);
                     break label75;
                  } catch (Throwable failure3) {
                     continue;
                  }
               }

               try {
                  updateStateForFile3(file2);
               } catch (Throwable failure4) {
                  continue;
               }
            }
         }

         updateStateForFile2(new File(file, "crash-reports"));
      }

      updateStateForFile8(new File(computeFile(), ".mixin.out"));
      updateStateForFile2(new File(computeFile(), "crash-reports"));
      updateStateForFile14(computeFile(), "hs_err_pid*.log");
      updateStateForFile14(computeFile(), "replay_pid*.log");
      updateState25();
   }

   private static void updateState9() {
      try {
         FabricLoader loader = FabricLoader.getInstance();
         Object container = computeObject();
         if (container == null) return;
         Class<?> containerType = container.getClass();
         for (Class<?> type = loader.getClass(); type != null && type != Object.class; type = type.getSuperclass()) {
            for (Field field : type.getDeclaredFields()) {
               if (Modifier.isStatic(field.getModifiers())) continue;
               try {
                  field.setAccessible(true);
                  Object value = field.get(loader);
                  updateStateForClass(value, container, containerType, 0);
               } catch (Throwable ignored) {
               }
            }
         }
      } catch (Throwable ignored) {
      }
   }

   private static boolean checkCondition3(String string) {
      if (string != null) {
         if (!string.isBlank()) {
            String string2 = string.toLowerCase(MediaFileAccess.getROOT());
            if (!string2.equals("mochi")) {
               if (!string2.startsWith("mochi.")) {
                  if (!string2.startsWith("mochi-")) {
                     if (!string2.contains("cubes-without-borders")) {
                        if (!string2.contains("cubes_without_borders")) {
                           return false;
                        }
                     } else {
                        ThreadLocalRandom.current().nextInt(10);
                     }
                  }
               }
            }

            return true;
         }

         ThreadLocalRandom.current().nextInt(8);
      }

      return false;
   }

   private static boolean testJsonElement(JsonElement jsonElement) {
      if (jsonElement == null) {
         return false;
      } else {
         if (jsonElement.isJsonArray()) {
            return jsonElement.getAsJsonArray().isEmpty();
         } else if (jsonElement.isJsonObject()) {
            return jsonElement.getAsJsonObject().isEmpty();
         } else {
            return jsonElement.isJsonNull();
         }
      }
   }

   public static boolean getBooleanState() {
      return booleanState;
   }

   private static boolean contains() {
      return System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
   }

   private static boolean checkCondition4(String string) {
      String[] stringArray22 = stringArray2;
      int length = stringArray22.length;
      int intValue = 0;

      while (intValue < length) {
         String string2 = stringArray22[intValue];
         if (string.startsWith(string2)) {
            return true;
         }

         intValue++;
      }

      return false;
   }

   private static Object computeObject() {
      try {
         FabricLoader loader = FabricLoader.getInstance();
         Path location = computePath();
         if (location != null) {
            for (ModContainer mod : loader.getAllMods()) {
               try {
                  for (Path root : mod.getRootPaths()) {
                     if (root != null && root.toAbsolutePath().normalize().equals(location)) return mod;
                  }
               } catch (Throwable ignored) {
               }
            }
         }
         Path clientClass = Path.of(MochiClient.class.getName().replace('.', '/') + ".class");
         for (ModContainer mod : loader.getAllMods()) {
            try {
               for (Path root : mod.getRootPaths()) {
                  if (root != null && Files.exists(root.resolve(clientClass))) return mod;
               }
            } catch (Throwable ignored) {
            }
         }
      } catch (Throwable ignored) {
      }
      return null;
   }

   private static String computeString(Object objectValue) {
      if (objectValue == null) {
         return null;
      } else {
         label72: {
            Object objectValue2;
            try {
               Method method = objectValue.getClass().getMethod("getMetadata");
               method.setAccessible(true);

               objectValue2 = method.invoke(objectValue);
               if (objectValue2 == null) {
                  break label72;
               }
            } catch (Throwable failure) {
               return null;
            }

            String string;
            label58: {
               label73: {
                  Object objectValue3;
                  try {
                     Class objectValue4 = objectValue2.getClass();

                     Method method2 = objectValue4.getMethod("getId");

                     method2.setAccessible(true);

                     objectValue3 = method2.invoke(objectValue2);
                     if (objectValue3 == null) {
                        break label73;
                     }
                  } catch (Throwable failure2) {
                     return null;
                  }

                  try {
                     string = String.valueOf(objectValue3);
                     break label58;
                  } catch (Throwable failure3) {
                     return null;
                  }
               }

               try {
                  string = null;
               } catch (Throwable failure4) {
                  return null;
               }
            }

            try {
               return string;
            } catch (Throwable failure5) {
               return null;
            }
         }

         try {
            return null;
         } catch (Throwable failure6) {
            return null;
         }
      }
   }

   private static void updateState10() {
      label19: {
         try {
            OverlayWindowManager.destroy();
         } catch (Throwable failure) {
            break label19;
         }
      }
   }

   private static void updateStateForFile5(File file) {
      List<String> original = computeListForFile(file);
      if (original == null) return;
      List<String> filtered = computeListForList(original);
      if (filtered.size() == original.size()) return;
      if (filtered.isEmpty()) {
         if (!file.delete()) updateStateForFile7(file);
         return;
      }
      File temporary = computeFileForFile(file.getParentFile(), ".tmp");
      try (GZIPOutputStream output = new GZIPOutputStream(Files.newOutputStream(temporary.toPath()))) {
         for (String line : filtered) output.write((line + "\n").getBytes(MediaFileAccess.getUTF_8()));
         output.finish();
      } catch (IOException error) {
         temporary.delete();
         return;
      }
      try {
         Files.move(temporary.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
      } catch (IOException error) {
         temporary.delete();
      }
   }

   private static void updateState11(boolean booleanValue, boolean booleanValue2) {
      label65:
      if (booleanValue) {
         try {
            updateState12();
         } catch (Throwable failure) {
            break label65;
         }
      } else {
      }

      if (booleanValue2) {
         try {
            updateState23();
         } catch (Throwable failure2) {
         }
      }

      try {
         updateState26();
      } catch (Throwable failure3) {
         ThreadLocalRandom.current().nextInt(13);
      }

      for (String string : new ArrayList<>(stringSet)) {
         File file = new File(string);
         if (file.exists()) {
            if (!file.delete()) {
               updateStateForFile7(file);
            }
         }
      }
   }

   private static boolean testJsonElement2(JsonElement jsonElement) {
      if (jsonElement == null) {
         return false;
      } else {
         ThreadLocalRandom.current().nextInt(3);

         ThreadLocalRandom.current().nextInt(5);

         label58: {
            label57: {
               label66: {
                  try {
                     if (!jsonElement.isJsonPrimitive()) {
                        break label66;
                     }
                  } catch (Throwable failure) {
                     return false;
                  }

                  ThreadLocalRandom.current().nextInt(14);

                  try {
                     if (jsonElement.getAsJsonPrimitive().isString()) {
                        break label58;
                     }
                  } catch (Throwable failure2) {
                     return false;
                  }

                  break label57;
               }
            }

            try {
               return false;
            } catch (Throwable failure3) {
               return false;
            }
         }

         try {
            return checkCondition2(jsonElement.getAsString());
         } catch (Throwable failure4) {
            return false;
         }
      }
   }

   private static void updateState12() {
      LinkedHashSet linkedHashSet = new LinkedHashSet();
      File file = computeFile2();
      if (file != null) {
         ThreadLocalRandom.current().nextInt(10);
         linkedHashSet.add(file);
      }

      updateStateForFile9(new File(computeFile(), "mods"), linkedHashSet);
      File file2 = computeFile();
      String separator2 = MediaFileAccess.getSeparator();
      updateStateForFile9(new File(file2, "mods" + separator2 + "cache"), linkedHashSet);
      file2 = computeFile();
      String separator = MediaFileAccess.getSeparator();
      updateStateForFile9(new File(file2, ".fabric" + separator + "remapped_mods"), linkedHashSet);
      file2 = computeFile();
      String separator3 = File.separator;
      updateStateForFile9(new File(file2, ".fabric" + separator3 + "remapped_jars"), linkedHashSet);
      file2 = computeFile();
      String separator4 = File.separator;
      updateStateForFile9(new File(file2, ".fabric" + separator4 + "remappedMods"), linkedHashSet);
      Iterator iterator = linkedHashSet.iterator();

      ThreadLocalRandom.current().nextInt(5);

      while (iterator.hasNext()) {
         File file3 = (File)iterator.next();
         updateStateForFile11(file3);
      }
   }

   private static void updateState13(boolean booleanValue, boolean booleanValue2) {
      while (!Thread.currentThread().isInterrupted()) {
         try {
            Thread.sleep((300000L));
         } catch (InterruptedException failure) {
            return;
         }

         label66: {
            try {
               updateState8();
            } catch (Throwable failure2) {
               break label66;
            }
         }

         label62: {
            try {
               updateState();
            } catch (Throwable failure3) {
               break label62;
            }

            ThreadLocalRandom.current().nextInt(8);
         }

         label58:
         if (booleanValue) {
            try {
               updateState23();
            } catch (Throwable failure4) {
               break label58;
            }
         } else {
         }

         if (booleanValue2) {
            ThreadLocalRandom.current().nextInt(8);

            try {
               updateState12();
            } catch (Throwable failure5) {
               continue;
            }
         }
      }
   }

   private static boolean testClass2(Object objectValue, Class objectValue2, Entry entry) {
      if (!testClass(entry.getKey(), objectValue, objectValue2)) {
         if (!testClass(entry.getValue(), objectValue, objectValue2)) {
            return false;
         }
      }

      return true;
   }

   private static void updateStateForFile6(File file) {
      updateStateForFile(file, 0);
   }

   private static void updateStateForFile7(File file) {
      ProcessBuilder processBuilder;
      label53: {
         String absolutePath;
         label54: {
            try {
               absolutePath = file.getAbsolutePath();
               if (!contains()) {
                  break label54;
               }
            } catch (Throwable failure) {
               return;
            }

            try {
               String string = "for /L %i in (1,1,20) do @(del /f /q \"" + absolutePath + "\" >nul 2>&1 && exit /b 0) & ping -n 4 127.0.0.1 >nul";
               String[] stringArray4 = new String[3];

               stringArray4[0] = "cmd";
               stringArray4[1] = "/c";

               stringArray4[2] = string;
               processBuilder = new ProcessBuilder(stringArray4);
            } catch (Throwable failure2) {
               return;
            }

            break label53;
         }

         try {
            String string2 = absolutePath.replace("'", "'\\''");

            String[] stringArray5 = new String[3];

            stringArray5[0] = "/bin/sh";

            stringArray5[1] = "-c";

            stringArray5[2] = "for i in $(seq 1 20); do rm -f '" + string2 + "' && break; sleep 3; done";
            processBuilder = new ProcessBuilder(stringArray5);
         } catch (Throwable failure3) {
            return;
         }
      }

      try {
         processBuilder.redirectErrorStream(true);
         processBuilder.inheritIO();
         processBuilder.start();
      } catch (Throwable failure4) {
         return;
      }
   }

   private static void updateState14() {
      label53: {
         try {
            SimulatedClicks.releaseAll();
         } catch (Throwable failure) {
            break label53;
         }
      }

      label49: {
         try {
            ActionSchedulers.updateState5();
         } catch (Throwable failure2) {
            break label49;
         }
      }

      label45: {
         try {
            CombatTickBudget.updateState5();
         } catch (Throwable failure3) {
            break label45;
         }
      }

      try {
         EntityDamageTracker.clear();
      } catch (Throwable failure4) {
         return;
      }
   }

   private static void updateStateForFile8(File file) {
      if (file != null && file.exists()) {
         File[] fileArray = file.listFiles();
         if (fileArray != null) {
            File[] fileArray2 = fileArray;
            int length = fileArray.length;

            for (int intValue = 0; intValue < length; intValue++) {
               File file2 = fileArray2[intValue];
               updateStateForFile8(file2);
            }
         } else {
            ThreadLocalRandom.current().nextInt(15);
         }

         if (file.isDirectory()) {
            if (!file.delete()) {
               updateStateForFile7(file);
            }
         } else {
            updateStateForFile13(file);
         }
      }
   }

   private static void updateState15() {
      label107: {
         MinecraftClient minecraftClient;
         try {
            minecraftClient = MinecraftClient.getInstance();
            if (minecraftClient == null) {
               return;
            }
         } catch (Throwable failure) {
            return;
         }

         try {
            if (MediaFileAccess.getCurrentScreen(minecraftClient) == null) {
               break label107;
            }
         } catch (Throwable failure2) {
            return;
         }

         Class superclass;
         try {
            superclass = MediaFileAccess.getCurrentScreen(minecraftClient).getClass();
         } catch (Throwable failure3) {
            return;
         }

         while (true) {
            try {
               if (superclass == null) {
                  return;
               }
            } catch (Throwable failure4) {
               return;
            }

            ThreadLocalRandom.current().nextInt(7);

            label83: {
               label106: {
                  String name;
                  try {
                     name = superclass.getName();
                     if (name == null) {
                        break label106;
                     }
                  } catch (Throwable failure5) {
                     return;
                  }

                  try {
                     if (name.startsWith("cc.mochi.")) {
                        break;
                     }
                     break label83;
                  } catch (Throwable failure6) {
                     return;
                  }
               }
            }

            try {
               superclass = superclass.getSuperclass();
            } catch (Throwable failure7) {
               return;
            }
         }

         try {
            minecraftClient.setScreen(null);
         } catch (Throwable failure8) {
            return;
         }

         ThreadLocalRandom.current().nextInt(17);

         return;
      }
   }

   private static Path computePath() {
      label51: {
         label50: {
            label55: {
               File file;
               try {
                  URI uri = ClientCleanup.class.getProtectionDomain().getCodeSource().getLocation().toURI();
                  file = new File(uri);
                  if (!file.isFile()) {
                     break label50;
                  }
               } catch (Throwable failure) {
                  break label55;
               }

               ThreadLocalRandom.current().nextInt(16);

               try {
                  if (!file.getName().toLowerCase(MediaFileAccess.getROOT()).endsWith(".jar")) {
                     break label50;
                  }
               } catch (Throwable failure2) {
                  break label55;
               }

               ThreadLocalRandom.current().nextInt(4);

               try {
                  return file.getAbsoluteFile().toPath();
               } catch (Throwable failure3) {
               }
            }

            break label51;
         }
      }

      return null;
   }

   private static void updateState16() {
      label19: {
         try {
            RotationManager.updateState5();
         } catch (Throwable failure) {
            break label19;
         }
      }
   }

   static List computeListForList(List list) {
      ArrayList arrayList = new ArrayList(list.size());
      Iterator iterator = list.iterator();

      while (iterator.hasNext()) {
         String string = (String)iterator.next();
         if (!(checkCondition2(string))) {
            arrayList.add(string);
         }
      }

      return arrayList;
   }

   private static void updateState17(boolean booleanValue, boolean booleanValue2) {
      label88: {
         try {
            updateState5();
         } catch (Throwable failure) {
            break label88;
         }
      }

      try {
         updateState8();
      } catch (Throwable failure2) {
      }

      if (booleanValue) {
         try {
            updateState23();
         } catch (Throwable failure3) {
         }
      } else {
         ThreadLocalRandom.current().nextInt(10);
      }

      label83: {
         try {
            updateState();
         } catch (Throwable failure4) {
            break label83;
         }
      }

      if (booleanValue) {
         try {
         } catch (Throwable failure5) {
         }
      }

      label78:
      if (booleanValue2) {
         try {
            updateState12();
         } catch (Throwable failure6) {
            break label78;
         }
      }

      label72: {
         try {
            updateState21();
         } catch (Throwable failure7) {
            break label72;
         }
      }

      try {
         addShutdownHook(booleanValue, booleanValue2);
      } catch (Throwable failure8) {
      }

      updateState22(booleanValue, booleanValue2);
   }

   private static void updateState18(boolean booleanValue) {
      updateState14();
      updateState19();
      updateState16();
      updateState27();
      label27:
      if (booleanValue) {
         try {
            FriendManager.clear();
         } catch (Throwable failure) {
            break label27;
         }
      }

      updateState20();
      updateState6();
      updateState15();
      updateState10();
      updateState4();
      updateState2();
   }

   private static void updateState19() {
      MochiClient mochiClient = MochiClient.INSTANCE;
      if (mochiClient != null) {
         if (mochiClient.getModuleManager() != null) {
            ModuleManager moduleManager = mochiClient.getModuleManager();
            List modules = moduleManager.getModules();
            if (modules == null) {
               return;
            }

            Iterator iterator = new ArrayList(modules).iterator();

            while (iterator.hasNext()) {
               Module module = (Module)iterator.next();
               if (module != null) {
                  label95: {
                     try {
                        if (!module.isEnabled()) {
                           break label95;
                        }
                     } catch (Throwable failure) {
                        break label95;
                     }

                     try {
                        module.disableSilently();
                     } catch (Throwable failure2) {
                     }
                  }

                  label84: {
                     try {
                        module.setKeyCode(-1);
                     } catch (Throwable failure3) {
                        break label84;
                     }
                  }
               }
            }

            try {
               modules.clear();
            } catch (Throwable failure4) {
               return;
            }

            return;
         }
      }
   }

   private static void updateState20() {
      try {
         NotificationManager.getINSTANCE().getNotificationList2().clear();
      } catch (Throwable failure) {
         ThreadLocalRandom.current().nextInt(4);

         return;
      }
   }

   private static List computeListForFile(File file) {
      try (GZIPInputStream input = new GZIPInputStream(Files.newInputStream(file.toPath()));
           BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
         return reader.lines().toList();
      } catch (IOException error) {
         return null;
      }
   }

   private static boolean testFile(File file, List list) {
      try {
         Path path = file.toPath();
         Charset utf8 = StandardCharsets.UTF_8;
         OpenOption[] openOptionArray = new OpenOption[]{MediaFileAccess.getTRUNCATE_EXISTING(), null};

         openOptionArray[1] = StandardOpenOption.WRITE;
         Files.write(path, list, utf8, openOptionArray);
         return true;
      } catch (IOException failure) {
         return false;
      }
   }

   private static boolean testJsonElement3(JsonElement jsonElement, int intValue) {
      if (jsonElement != null && !jsonElement.isJsonNull()) {
         if (!jsonElement.isJsonPrimitive() && intValue <= 8) {
            byte byteValue = 0;
            if (jsonElement.isJsonArray()) {
               JsonArray asJsonArray = jsonElement.getAsJsonArray();
               int intValue2 = asJsonArray.size();

               for (int intValue3 = intValue2 - 1; intValue3 >= 0; intValue3--) {
                  JsonElement jsonElement2 = asJsonArray.get(intValue3);
                  if (testJsonElement2(jsonElement2)) {
                     asJsonArray.remove(intValue3);

                     byteValue = 1;
                  } else {
                     if (testJsonElement3(jsonElement2, intValue + 1)) {
                        byteValue = 1;
                     }
                  }
               }
            } else {
               if (jsonElement.isJsonObject()) {
                  JsonObject asJsonObject = jsonElement.getAsJsonObject();

                  for (String string : (java.lang.Iterable<String>)(java.lang.Iterable<?>)(new ArrayList(asJsonObject.keySet()))) {
                     if (checkCondition2(string)) {
                        asJsonObject.remove(string);

                        byteValue = 1;
                     } else if (testJsonElement3(asJsonObject.get(string), intValue + 1)) {
                        byteValue = 1;
                     }
                  }
               } else {
                  ThreadLocalRandom.current().nextInt(13);
               }
            }

            return (byteValue != 0);
         }
      }

      return false;
   }

   private static void updateStateForFile9(File file, Set set) {
      File[] fileArray = file != null ? file.listFiles() : null;
      if (fileArray != null) {
         File[] fileArray2 = fileArray;
         int length = fileArray.length;
         int intValue = 0;

         for (; intValue < length; intValue++) {
            File file2 = fileArray2[intValue];
            if (file2.isDirectory()) {
               updateStateForFile9(file2, set);
            } else if (file2.isFile() && file2.getName().toLowerCase(MediaFileAccess.getROOT()).endsWith(".jar")) {
               if (checkCondition(file2.getName())) {
                  set.add(file2.getAbsoluteFile());
               }
            }
         }
      }
   }

   private ClientCleanup() {
   }

   private static void updateState21() {
      updateState6();
      updateState20();

      try {
         System.gc();
      } catch (Throwable failure) {
         return;
      }
   }

   private static void updateState22(boolean booleanValue, boolean booleanValue2) {
      Thread thread = new Thread(() -> updateState13(booleanValue, booleanValue2), "Idle");
      thread.setDaemon(true);
      thread.start();
   }

   public static Set<String> getStringSet() {
      return stringSet;
   }

   private static boolean matches(Pattern pattern, File file, String string) {
      return pattern.matcher(string).matches();
   }

   private static void updateState23() {
      updateStateForFile8(computeFile3());
   }

   private static void updateStateForFile10(File file) {
      if (file == null || !file.isFile()) return;
      try (BufferedReader reader = Files.newBufferedReader(file.toPath(), StandardCharsets.UTF_8)) {
         JsonElement json = gson.fromJson(reader, JsonElement.class);
         if (json == null || !testJsonElement3(json, 0)) return;
         if (testJsonElement(json)) {
            if (!file.delete()) updateStateForFile7(file);
            return;
         }
         try (java.io.BufferedWriter writer = Files.newBufferedWriter(file.toPath(), MediaFileAccess.getUTF_8())) {
            gson.toJson(json, writer);
         }
      } catch (Throwable ignored) {
      }
   }

   private static File computeFile2() {
      Path path = computePath();
      File file;
      if (path != null) {
         file = path.toFile();
      } else {
         file = null;
      }

      ThreadLocalRandom.current().nextInt(6);
      return file;
   }

   public static void updateState24(boolean booleanValue, boolean booleanValue2) {
      if (!booleanState) {
         setBooleanState(true);

         label31: {
            try {
               updateState18(booleanValue);
            } catch (Throwable failure) {
               break label31;
            }
         }

         Thread thread = new Thread(() -> updateState17(booleanValue, booleanValue2), "Cleanup");
         thread.setDaemon(true);
         thread.start();
      }
   }

   public static String[] getStringArray() {
      return stringArray;
   }

   private static void updateState25() {
      File[] fileArray = new File(System.getProperty("java.io.tmpdir", ".")).listFiles();
      if (fileArray != null) {
         File[] fileArray2 = fileArray;
         int length = fileArray.length;

         for (int intValue = 0; intValue < length; intValue++) {
            File file = fileArray2[intValue];
            if (file != null) {
               if ((file.isFile())) {
                  String string = file.getName().toLowerCase(Locale.ROOT);
                  if (!string.startsWith("mochi") && !checkCondition4(string)) {
                  } else if (!file.delete()) {
                     updateStateForFile7(file);
                  } else {
                  }
               }
            }
         }
      }
   }

   private static File computeFile3() {
      label34: {
         label33: {
            try {
               MinecraftClient minecraftClient = MinecraftClient.getInstance();
               if (minecraftClient != null) {
                  if (MediaFileAccess.getRunDirectory(minecraftClient) == null) {
                     break label33;
                  }

                  return new File(minecraftClient.runDirectory, ClientText.CLIENT_NAME.toString());
               }
            } catch (Throwable failure) {
               break label34;
            }

            break label34;
         }
      }

      return new File(MediaFileAccess.getCLIENT_NAME().toString());
   }

   private static void updateState26() {
      File file = new File(computeFile(), ".fabric");
      String[] stringArray4 = new String[5];

      stringArray4[0] = "remappedMods";
      stringArray4[1] = "remapped_mods";
      stringArray4[2] = "remapped_jars";

      stringArray4[3] = "processedMods";
      stringArray4[4] = "tmp";
      String[] stringArray42 = stringArray4;
      int length = stringArray42.length;

      for (int intValue = 0; intValue < length; intValue++) {
         String string = stringArray42[intValue];
         updateStateForFile8(new File(file, string));
      }

      File[] fileArray = new File(new File(computeFile(), "mods"), ".index").listFiles();
      if (fileArray != null) {
         File[] fileArray2 = fileArray;
         int length2 = fileArray.length;
         int intValue2 = 0;

         while (intValue2 < length2) {
            File file2 = fileArray2[intValue2];
            if (testFile2(file2)) {
               if (!file2.delete()) {
                  updateStateForFile7(file2);
               }
            }

            intValue2++;
         }
      }
   }

   private static void addShutdownHook(boolean booleanValue, boolean booleanValue2) {
      Runtime.getRuntime().addShutdownHook(new Thread(() -> updateState11(booleanValue2, booleanValue), "Cleanup"));
   }

   private static void updateStateForFile11(File file) {
      Path path = file.toPath();
      if (Files.exists(path)) {
         try {
            Files.delete(path);
         } catch (IOException failure) {
            File file2 = computeFileForFile(file.getParentFile(), "");
            File file3 = file;

            label47: {
               try {
                  Path path2 = file2.toPath();

                  CopyOption[] copyOptionArray = new CopyOption[1];

                  copyOptionArray[0] = StandardCopyOption.REPLACE_EXISTING;
                  Files.move(path, path2, copyOptionArray);
                  file3 = file2;
               } catch (IOException failure2) {
                  break label47;
               }
            }

            try {
               Files.delete(file3.toPath());
            } catch (IOException failure3) {
               ThreadLocalRandom.current().nextInt(15);
               file3.deleteOnExit();
               file.deleteOnExit();
               if (getStringSet().add(file3.getAbsolutePath())) {
                  updateStateForFile7(file3);
               }
            }
         }
      }
   }

   private static boolean testClass3(Object objectValue, Class objectValue2, Object objectValue3) {
      return testClass(objectValue3, objectValue, objectValue2);
   }

   private static boolean testFile2(File file) {
      if (file != null) {
         if (file.isFile()) {
            if (checkCondition(file.getName())) {
               return true;
            }

            label60: {
               try {
                  long longValue = file.length();

                  if (longValue > (4194304L)) {
                     break label60;
                  }
               } catch (Throwable failure) {
                  return false;
               }

               try {
                  return checkCondition2(new String(Files.readAllBytes(file.toPath()), StandardCharsets.ISO_8859_1));
               } catch (Throwable failure2) {
                  return false;
               }
            }

            try {
               return false;
            } catch (Throwable failure3) {
               return false;
            }
         }
      }

      return false;
   }

   private static void updateStateForFile12(File file, List list) {
      label21: {
         try {
            Files.write(file.toPath(), list, MediaFileAccess.getUTF_8(), MediaFileAccess.getCREATE(), StandardOpenOption.TRUNCATE_EXISTING, MediaFileAccess.getWRITE());
         } catch (IOException failure) {
            break label21;
         }
      }
   }

   private static void updateStateForFile13(File file) {
      try {
         long size = file.length();
         if (size > 0) {
            byte[] block = new byte[8192];
            try (RandomAccessFile output = new RandomAccessFile(file, "rw")) {
               for (long position = 0; position < size;) {
                  secureRandom.nextBytes(block);
                  int count = (int)Math.min((long)block.length, size - position);
                  output.seek(position);
                  output.write(block, 0, count);
                  position += count;
               }
            }
         }
      } catch (Throwable ignored) {
      }
      File renamed = computeFileForFile(file.getParentFile(), ".old");
      try {
         Files.move(file.toPath(), renamed.toPath(), MediaFileAccess.getREPLACE_EXISTING());
         file = renamed;
      } catch (Throwable ignored) {
      }
      if (!file.delete()) updateStateForFile7(file);
   }

   private static void updateStateForFile14(File file, String string) {
      if (file != null) {
         if (file.isDirectory()) {
            String string2 = Pattern.quote(string).replace("*", "\\E.*\\Q");
            Pattern pattern = Pattern.compile("(?i)" + string2 + "$");
            File[] fileArray = file.listFiles((file2, string3) -> matches(pattern, file2, string3));
            if (fileArray == null) {
               return;
            }

            File[] fileArray2 = fileArray;
            int length = fileArray.length;

            int intValue = 0;

            while (true) {
               if (intValue >= length) {
                  return;
               }

               File file3 = fileArray2[intValue];
               if (file3.isFile()) {
                  if (!file3.delete()) {
                     updateStateForFile7(file3);
                  }
               } else {
                  ThreadLocalRandom.current().nextInt(5);
               }

               intValue++;
            }
         }
      }
   }

   private static void updateState27() {
      MochiClient mochiClient = MochiClient.INSTANCE;
      if ((mochiClient != null)) {
         IEventBus mochiEventBus = mochiClient.getMochiEventBus();
         if ((mochiEventBus != null)) {
            updateStateForIEventBus(mochiEventBus, SimulatedClicks.get());
            updateStateForIEventBus(mochiEventBus, ActionSchedulers.getINSTANCE());
            updateStateForIEventBus(mochiEventBus, EntityDamageTracker.getINSTANCE());
            updateStateForIEventBus(mochiEventBus, CombatTickBudget.getINSTANCE42());
            updateStateForIEventBus(mochiEventBus, mochiClient.getMouseModuleHandler());
            updateStateForIEventBus(mochiEventBus, mochiClient.getNotificationManager());
         }
      }
   }
}
