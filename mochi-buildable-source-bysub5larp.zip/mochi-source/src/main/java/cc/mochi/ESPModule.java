package cc.mochi;

import cc.mochi.event.impl.render.Render2DEvent;
import cc.mochi.event.impl.render.Render3DEvent;
import java.awt.Color;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;

public class ESPModule extends Module {
   private final BooleanSetting outlineSetting;
   private final BooleanSetting fillSetting;
   private final BooleanSetting healthSetting;

   private final BooleanSetting distanceSetting;
   private final ChoiceSetting modeSetting = new ChoiceSetting("Mode", "Box", "Box", "Corners", "Filled", "3D Box");

   private final BooleanSetting showSelfSetting;

   private final BooleanSetting labelBackgroundSetting;

   private final ColorSetting hostileColorSetting;

   private final DoubleSetting labelSizeSetting;

   private final ColorSetting playerColorSetting;
   private final BooleanSetting nameSetting;

   private static final FontFace fontFace = FontFace.SEMIBOLD;

   private final BooleanSetting playersSetting;

   private final BooleanSetting passivesSetting;

   private final DoubleSetting rangeSetting;

   private final ColorSetting passiveColorSetting;

   private final BooleanSetting hostilesSetting;
   private final DoubleSetting fillAlphaSetting;

   private final ChoiceSetting colorModeSetting;

   private final BooleanSetting teamCheckSetting;

   private final Map<Integer, Long> longByInteger;

   private static final FontFace fontFace2 = FontFace.MEDIUM;

   private final BooleanSetting healthBarSetting;

   private final ColorSetting friendColorSetting;

   private final BooleanSetting fadeInSetting;

   @EventHandler
   private void onRender3D(Render3DEvent render3DEvent) {
      if (this.modeSetting.equals("3D Box") && !this.isWorldUnavailable() && mc.world != null && mc.player != null) {
         if (!GlCapabilities.checkCondition5()) {
            long longValue = System.currentTimeMillis();
            float tickDelta = render3DEvent.getTickDelta();

            for (Entity entity : mc.world.getEntities()) {
               if (this.testEntity(entity) && this.longByInteger.containsKey(entity.getId())) {
                  float floatValue = this.computeFloatForEntity(entity, longValue);
                  if (!(floatValue <= 0.01F)) {
                     double doubleValue = MathHelper.lerp((double)tickDelta, entity.lastX, entity.getX()) - entity.getX();
                     double doubleValue2 = MathHelper.lerp((double)tickDelta, entity.lastY, entity.getY()) - entity.getY();
                     double doubleValue3 = MathHelper.lerp((double)tickDelta, entity.lastZ, entity.getZ()) - entity.getZ();
                     Box box = entity.getBoundingBox().offset(doubleValue, doubleValue2, doubleValue3).expand(0.02);
                     int rgb = this.computeColorForEntity(entity).getRGB();
                     if (this.fillSetting.getValue()) {
                        Render3D.updateStateForBox2(box, Render3D.computeInt2(rgb, (int)(this.fillAlphaSetting.getValue() * (double)floatValue)), true);
                     }

                     if (this.outlineSetting.getValue()) {
                        Render3D.updateStateForBox(box, Render3D.computeFloat(1.5F), Render3D.computeInt2(rgb, (int)(235.0F * floatValue)), true);
                     }
                  }
               }
            }
         }
      }
   }

   private void updateStateForRender2DEvent(Render2DEvent render2DEvent, Entity entity, float[] floatArray, long longValue) {
      float x = floatArray[0];
      float y = floatArray[1];
      float width = floatArray[2];
      float height = floatArray[3];
      if (!(width < 1.5F) && !(height < 1.5F)) {
         float floatValue = this.computeFloatForEntity(entity, longValue);
         if (!(floatValue <= 0.01F)) {
            Color color = this.computeColorForEntity(entity);
            if (!this.modeSetting.equals("3D Box") && (this.fillSetting.getValue() || this.modeSetting.equals("Filled"))) {
               int intValue = (int)(Math.max(this.modeSetting.equals("Filled") ? 40.0 : 0.0, this.fillAlphaSetting.getValue()) * (double)floatValue);
               if (intValue > 0) {
                  HudBloomRenderer.fillRoundedRect(x, y, width, height, 1.5F, createColor(color, intValue));
               }
            }

            if (this.modeSetting.equals("Corners")) {
               updateStateForColor(x, y, width, height, color, floatValue);
            } else if (this.outlineSetting.getValue() && !this.modeSetting.equals("3D Box")) {
               HudBloomRenderer.strokeRoundedRect(x, y, width, height, 1.5F, MathHelper.clamp(width * 0.012F, 1.0F, 2.2F), createColor(color, (int)(235.0F * floatValue)));
            }

            if (this.healthBarSetting.getValue() && entity instanceof LivingEntity var15) {
               this.updateStateForLivingEntity(x, y, width, height, var15, color, floatValue);
            }

            this.updateStateForRender2DEvent2(render2DEvent, entity, x, y, width, height, color, floatValue);
         }
      }
   }

   private static Color createColor(Color color, int intValue) {
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), MathHelper.clamp(intValue, 0, 255));
   }

   private Boolean equals() {
      return this.colorModeSetting.equals("Per Type");
   }

   @EventHandler
   private void onRender2D(Render2DEvent render2DEvent) {
      if (!this.isWorldUnavailable() && mc.world != null && mc.player != null) {
         if (!GlCapabilities.checkCondition5()) {
            long longValue = System.currentTimeMillis();
            float tickProgress = mc.getRenderTickCounter().getTickProgress(true);

            try (UiRenderBackend uiRenderBackend = HudBloomRenderer.computeUiRenderBackendForRender2DEvent(render2DEvent)) {
               for (Entity entity : mc.world.getEntities()) {
                  if (this.testEntity(entity)) {
                     this.longByInteger.putIfAbsent(entity.getId(), longValue);
                     double doubleValue = MathHelper.lerp((double)tickProgress, entity.lastX, entity.getX());
                     double doubleValue2 = MathHelper.lerp((double)tickProgress, entity.lastY, entity.getY());
                     double doubleValue3 = MathHelper.lerp((double)tickProgress, entity.lastZ, entity.getZ());
                     float[] floatArray = ScreenProjectionMath.computeFloatArray(doubleValue, doubleValue2, doubleValue3, (double)entity.getWidth() / 2.0, (double)entity.getHeight());
                     if (floatArray != null && !(floatArray[2] * floatArray[3] > 400000.0F)) {
                        this.updateStateForRender2DEvent(render2DEvent, entity, floatArray, longValue);
                     }
                  }
               }
            }

            this.longByInteger.keySet().removeIf(integer -> checkCondition(integer));
         }
      }
   }

   private static boolean checkCondition(Integer integer) {
      return mc.world.getEntityById(integer) == null;
   }

   @Override
   public void onDisable() {
      this.longByInteger.clear();
      super.onDisable();
   }

   public ESPModule() {
      super("ESP", "Draws entities through walls with labels", -1, ModuleCategory.RENDER);
      this.outlineSetting = new BooleanSetting("Outline", true);
      this.fillSetting = new BooleanSetting("Fill", false);
      this.fillAlphaSetting = new DoubleSetting("Fill Alpha", 0.0, 120.0, 38.0, 2.0);
      this.healthBarSetting = new BooleanSetting("Health Bar", true);
      this.nameSetting = new BooleanSetting("Name", true);
      this.healthSetting = new BooleanSetting("Health", true);
      this.distanceSetting = new BooleanSetting("Distance", true);
      this.labelSizeSetting = new DoubleSetting("Label Size", 7.0, 16.0, 9.0, 1.0);
      this.labelBackgroundSetting = new BooleanSetting("Label Background", true);
      this.rangeSetting = new DoubleSetting("Range", 10.0, 256.0, 96.0, 4.0);
      this.showSelfSetting = new BooleanSetting("Show Self", false);
      this.playersSetting = new BooleanSetting("Players", true);
      this.passivesSetting = new BooleanSetting("Passives", false);
      this.hostilesSetting = new BooleanSetting("Hostiles", true);
      this.teamCheckSetting = new BooleanSetting("Team Check", true);
      this.colorModeSetting = new ChoiceSetting("Color Mode", "Theme", "Theme", "Per Type");
      this.playerColorSetting = new ColorSetting("Player Color", new Color(255, 255, 255));
      this.passiveColorSetting = new ColorSetting("Passive Color", new Color(120, 235, 120));
      this.hostileColorSetting = new ColorSetting("Hostile Color", new Color(255, 85, 85));
      this.friendColorSetting = new ColorSetting("Friend Color", new Color(176, 96, 232));
      this.fadeInSetting = new BooleanSetting("Fade In", true);
      this.longByInteger = new HashMap<>();
      this.addSettings(
         new Setting[]{
            this.modeSetting,
            this.outlineSetting,
            this.fillSetting,
            this.fillAlphaSetting,
            this.healthBarSetting,
            this.nameSetting,
            this.healthSetting,
            this.distanceSetting,
            this.labelSizeSetting,
            this.labelBackgroundSetting,
            this.rangeSetting,
            this.showSelfSetting,
            this.playersSetting,
            this.passivesSetting,
            this.hostilesSetting,
            this.teamCheckSetting,
            this.colorModeSetting,
            this.playerColorSetting,
            this.passiveColorSetting,
            this.hostileColorSetting,
            this.friendColorSetting,
            this.fadeInSetting
         }
      );
      this.outlineSetting.setVisibility(() -> this.computeBoolean());
      this.fillAlphaSetting.setVisibility(() -> this.fillSetting.getValue());
      this.playerColorSetting.setVisibility(() -> this.equals3());
      this.passiveColorSetting.setVisibility(() -> this.equals2());
      this.hostileColorSetting.setVisibility(() -> this.equals4());
      this.friendColorSetting.setVisibility(() -> this.equals());
   }

   private Color computeColorForEntity(Entity entity) {
      if (entity instanceof PlayerEntity var2 && FriendManager.testUUID(var2.getUuid())) {
         return this.friendColorSetting.getValue();
      }

      if (this.colorModeSetting.equals("Theme")) {
         return ThemeSnapshot.computeColorForColor(ClickGuiModule.computeThemeSnapshot().getAccent2());
      } else if (entity instanceof PlayerEntity) {
         return this.playerColorSetting.getValue();
      } else if (entity instanceof PassiveEntity) {
         return this.passiveColorSetting.getValue();
      } else {
         return entity instanceof HostileEntity ? this.hostileColorSetting.getValue() : ThemeSnapshot.computeColorForColor(ClickGuiModule.computeThemeSnapshot().getAccent2());
      }
   }

   private void updateStateForLivingEntity(float floatValue, float y, float floatValue2, float height, LivingEntity livingEntity, Color color, float floatValue3) {
      float floatValue4 = MathHelper.clamp(livingEntity.getHealth() / Math.max(livingEntity.getMaxHealth(), 1.0F), 0.0F, 1.0F);
      boolean booleanValue = floatValue - 3.5F > 1.0F;
      float x = booleanValue ? floatValue - 3.5F : floatValue + floatValue2 + 1.5F;
      HudBloomRenderer.fillRect(x, y, 2.0F, height, new Color(0, 0, 0, (int)(150.0F * floatValue3)));
      Color color2 = new Color(90, 224, 120);
      Color color3 = new Color(232, 76, 76);
      Color color4 = floatValue4 > 0.5F ? color2 : computeColorForColor(color3, color2, floatValue4 * 2.0F);
      HudBloomRenderer.fillRect(x, y + height * (1.0F - floatValue4), 2.0F, height * floatValue4, createColor(color4, (int)(245.0F * floatValue3)));
      HudBloomRenderer.fillRect(booleanValue ? x + 2.0F : x - 0.6F, y + height * (1.0F - floatValue4), 0.6F, Math.max(1.0F, height * floatValue4), createColor(color, (int)(170.0F * floatValue3)));
   }

   private static Color computeColorForColor(Color color, Color color2, float floatValue) {
      floatValue = MathHelper.clamp(floatValue, 0.0F, 1.0F);
      return new Color(
         Math.round((float)color.getRed() + (float)(color2.getRed() - color.getRed()) * floatValue),
         Math.round((float)color.getGreen() + (float)(color2.getGreen() - color.getGreen()) * floatValue),
         Math.round((float)color.getBlue() + (float)(color2.getBlue() - color.getBlue()) * floatValue)
      );
   }

   private Boolean equals2() {
      return this.colorModeSetting.equals("Per Type");
   }

   private Boolean equals3() {
      return this.colorModeSetting.equals("Per Type");
   }

   private float computeFloatForEntity(Entity entity, long longValue) {
      if (!this.fadeInSetting.getValue()) {
         return 1.0F;
      } else {
         long longValue2 = this.longByInteger.getOrDefault(entity.getId(), longValue);
         float floatValue = MathHelper.clamp((float)(longValue - longValue2) / 200.0F, 0.0F, 1.0F);
         return 1.0F - (1.0F - floatValue) * (1.0F - floatValue);
      }
   }

   private Boolean equals4() {
      return this.colorModeSetting.equals("Per Type");
   }

   private Boolean computeBoolean() {
      return this.modeSetting.equals("Box") || this.modeSetting.equals("3D Box");
   }

   private void updateStateForRender2DEvent2(Render2DEvent render2DEvent, Entity entity, float floatValue, float floatValue2, float floatValue3, float floatValue4, Color color, float floatValue5) {
      if (this.nameSetting.getValue() || this.healthSetting.getValue() || this.distanceSetting.getValue()) {
         float value = (float)this.labelSizeSetting.getValue();
         String string = entity.getName().getString();
         String text = "";
         if (this.healthSetting.getValue() && entity instanceof LivingEntity var12) {
            text = String.format(Locale.ROOT, "%.1f", var12.getHealth());
         }

         String text2 = this.distanceSetting.getValue() ? String.valueOf(Math.round(mc.player.distanceTo(entity))) : "";
         float floatValue6 = HudBloomRenderer.measureFontHeight(value, fontFace);
         float floatValue7 = this.nameSetting.getValue() ? HudBloomRenderer.measureText(string, value, fontFace) : 0.0F;
         float floatValue8 = 0.0F;
         if (!text.isEmpty()) {
            floatValue8 = (4.0F) + HudBloomRenderer.measureText(text, value - 0.5F, fontFace2);
         }

         if (!text2.isEmpty()) {
            floatValue8 += 4.0F + HudBloomRenderer.measureText(text2, value - 0.5F, fontFace2);
         }

         float floatValue9 = floatValue7 + floatValue8;
         if (!(floatValue9 <= 0.0F)) {
            float floatValue10 = floatValue + floatValue3 / 2.0F;
            float x = floatValue10 - floatValue9 / 2.0F;
            float y = floatValue2 - floatValue6 - 3.5F;
            if (this.labelBackgroundSetting.getValue()) {
               HudBloomRenderer.fillRoundedRect(x - 2.5F, y - 1.5F, floatValue9 + 5.0F, floatValue6 + 3.0F, 2.5F, new Color(0, 0, 0, (int)(120.0F * floatValue5)));
            }

            float x2 = x;
            if (this.nameSetting.getValue()) {
               HudBloomRenderer.drawText(string, x, y, value, createColor(color, (int)(250.0F * floatValue5)), fontFace);
               x2 = x + floatValue7;
            }

            if (!text.isEmpty()) {
               x2 += 4.0F;
               HudBloomRenderer.drawText(text, x2, y + 0.4F, value - 0.5F, createColor(new Color(255, 255, 255), (int)(225.0F * floatValue5)), fontFace2);
               x2 += HudBloomRenderer.measureText(text, value - 0.5F, fontFace2);
            }

            if (!text2.isEmpty()) {
               x2 += 4.0F;
               HudBloomRenderer.drawText(text2, x2, y + 0.4F, value - 0.5F, createColor(new Color(200, 200, 205), (int)(215.0F * floatValue5)), fontFace2);
            }
         }
      }
   }

   private static void updateStateForColor(float floatValue, float floatValue2, float floatValue3, float floatValue4, Color color, float floatValue5) {
      float floatValue6 = MathHelper.clamp(Math.min(floatValue3, floatValue4) * 0.22F, 3.0F, 12.0F);
      float thickness = MathHelper.clamp(floatValue3 * 0.02F, 1.0F, 2.4F);
      Color color2 = createColor(color, (int)(240.0F * floatValue5));
      float[][] floatArrayArray = new float[][]{
         {floatValue, floatValue2, 1.0F, 1.0F}, {floatValue + floatValue3, floatValue2, ((-1.0F)), 1.0F}, {floatValue, floatValue2 + floatValue4, 1.0F, ((-1.0F))}, {floatValue + floatValue3, floatValue2 + floatValue4, ((-1.0F)), ((-1.0F))}
      };

      for (float[] floatArray : floatArrayArray) {
         HudBloomRenderer.drawLine(floatArray[0], floatArray[1], floatArray[0] + floatValue6 * floatArray[2], floatArray[1], thickness, color2);
         HudBloomRenderer.drawLine(floatArray[0], floatArray[1], floatArray[0], floatArray[1] + floatValue6 * floatArray[3], thickness, color2);
      }
   }

   private boolean testPlayerEntity(PlayerEntity playerEntity) {
      return mc.player.getScoreboardTeam() != null && playerEntity.getScoreboardTeam() != null ? mc.player.getScoreboardTeam().equals(playerEntity.getScoreboardTeam()) : false;
   }

   private boolean testEntity(Entity entity) {
      if (entity == mc.player && !this.showSelfSetting.getValue()) {
         return false;
      } else if ((double)mc.player.distanceTo(entity) > this.rangeSetting.getValue()) {
         return false;
      } else if (entity instanceof PlayerEntity var2) {
         return !this.playersSetting.getValue() ? false : !this.teamCheckSetting.getValue() || !this.testPlayerEntity(var2);
      } else if (entity instanceof PassiveEntity) {
         return this.passivesSetting.getValue();
      } else {
         return entity instanceof HostileEntity ? this.hostilesSetting.getValue() : false;
      }
   }
}
