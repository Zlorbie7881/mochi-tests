package cc.mochi;

public record AnimationSpec(float startValue, float targetValue, long duration, long delay, EasingFunction easing) {
   public long getDuration() {
      return this.duration;
   }

   public float getTargetValue() {
      return this.targetValue;
   }

   public float getStartValue() {
      return this.startValue;
   }

   public long getDelay() {
      return this.delay;
   }

   public AnimationSpec(float floatValue, float floatValue2, long longValue) {
      this(floatValue, floatValue2, longValue, 0L, EasingFunctionAccess.OUT_CUBIC);
   }

   public EasingFunction getEasing() {
      return this.easing;
   }
}
