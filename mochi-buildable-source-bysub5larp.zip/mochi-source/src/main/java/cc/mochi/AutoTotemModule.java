package cc.mochi;

import cc.mochi.event.impl.network.PacketEvent;
import cc.mochi.event.impl.player.TickEndEvent;
import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.event.impl.render.Render2DEvent;
import cc.mochi.event.types.TransferOrder;
import cc.mochi.mixin.HandledScreenAccessor;
import cc.mochi.utils.combat.SystemInputSimulator;
import cc.mochi.utils.keybinding.simulation.ClickSimulator;
import cc.mochi.utils.keybinding.simulation.CursorMovementSimulator;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.slot.Slot;
import org.lwjgl.glfw.GLFW;

public class AutoTotemModule extends Module {
   private final BooleanSetting strictTickPacingSetting;
   private final DoubleSetting silentRetriesSetting;

   private final CursorMovementSimulator cursorMovementSimulator;

   private final ChoiceSetting cursorModeSetting;

   private final DoubleSetting fumbleDelayMsSetting;

   private int intState;

   private final HotbarSlotSetting hotbarSlotSetting;

   private final ChoiceSetting openModeSetting;

   private long longState;

   private final BooleanSetting legitFallbackSetting;
   private final BooleanSetting autoCloseSetting;

   private final BooleanSetting autoOpenInvSetting;

   private final BooleanSetting clickSimSetting;

   private boolean booleanState;

   private final Stopwatch stopwatch;

   private int intState2;

   private final BooleanSetting hotbarSetting;

   private final DoubleSetting cursorSpeedSetting;

   private final DoubleSetting retryDelayMsSetting;

   private final BooleanSetting debugMessagesSetting;

   private final Random random;

   private boolean booleanState2;

   private final DoubleSetting fastDelayMsSetting;

   private long longState2;

   private long longState3;

   private final BooleanSetting simCursorSetting;

   private Slot slot;

   private final DoubleSetting fumbleChanceSetting;

   public static Random getRandom(AutoTotemModule autoTotemModule) {
      return autoTotemModule.random;
   }

   public static HotbarSlotSetting getHotbarSlotSetting(AutoTotemModule autoTotemModule) {
      return autoTotemModule.hotbarSlotSetting;
   }

   public static void setIntState(AutoTotemModule autoTotemModule, int intState3) {
      autoTotemModule.intState = intState3;
   }

   private Boolean valueOf() {
      return Boolean.valueOf((!this.equals()));
   }

   @EventHandler
   private void onTickEndEvent(TickEndEvent tickEndEvent) {
      if (this.intState2 == 4) {
         if (mc.player != null) {
            if (this.strictTickPacingSetting.isOn() && !HotbarSelectionManager.checkCondition2()) {
               return;
            }

            if (InventoryPlayerAccess.getCurrentScreen(mc) == null) {
               this.updateState8();
            } else if (mc.currentScreen instanceof InventoryScreen var2) {
               if (getSlot(this) != null) {
                  if (this.testHandledScreen2(var2, getSlot(this))) {
                     this.updateState2(3, (long)(60 + getRandom(this).nextInt(60)));
                  }
               }
            } else {
            }

            return;
         }

         ThreadLocalRandom.current().nextInt(10);
      }
   }

   public static void setLongState3(AutoTotemModule autoTotemModule, long longState32) {
      autoTotemModule.longState3 = longState32;
   }

   public static BooleanSetting getClickSimSetting(AutoTotemModule autoTotemModule) {
      return autoTotemModule.clickSimSetting;
   }

   private boolean equals() {
      return getOpenModeSetting(this).equals("Silent");
   }

   private Boolean computeBoolean() {
      byte byteValue;
      if (!this.equals()) {
         byteValue = 1;

         ThreadLocalRandom.current().nextInt(16);
      } else {
         byteValue = 0;
      }

      return Boolean.valueOf((byteValue != 0));
   }

   private void updateState() {
      if (!PlayerStateUtils.isPlayerUnavailable()) {
         if (InventoryPlayerAccess.getInteractionManager(mc) != null) {
            if (InventoryPlayerAccess.getCurrentScreen(mc) == null) {
               this.updateState4();
            } else {
               Screen currentScreen = mc.currentScreen;
               if (currentScreen instanceof InventoryScreen) {
                  InventoryScreen currentScreen2 = (InventoryScreen)currentScreen;
                  this.updateStateForHandledScreen(currentScreen2);
               } else {
                  HotbarSelectionManager.updateState3(this);
                  this.updateState6();
               }
            }

            return;
         }
      }

      HotbarSelectionManager.updateState3(this);
      this.updateState6();
   }

   public static CursorMovementSimulator getCursorMovementSimulator(AutoTotemModule autoTotemModule) {
      return autoTotemModule.cursorMovementSimulator;
   }

   private boolean testHandledScreen(HandledScreen handledScreen, Slot slot2) {
      if (!getSimCursorSetting(this).isOn()) {
         ThreadLocalRandom.current().nextInt(11);

         getCursorMovementSimulator(this).cancel();
         return true;
      } else {
         ThreadLocalRandom.current().nextInt(16);
         if (this.testHandledScreen3(handledScreen, slot2)) {
            if (mc.getWindow() != null) {
               HandledScreenAccessor handledScreen2 = (HandledScreenAccessor)handledScreen;
               double doubleValue = (double)(handledScreen2.getX() + InventoryPlayerAccess.getX(slot2)) + 8.0;
               double doubleValue2 = (double)(handledScreen2.getY() + InventoryPlayerAccess.getY(slot2));

               double doubleValue3 = doubleValue2 + (8.0);
               if (!getCursorMovementSimulator(this).moveToScaled(handledScreen.width, handledScreen.height, doubleValue, doubleValue3, this.cursorSpeedSetting.getValue(), this.cursorModeSetting.getSelected())) {
                  return false;
               }

               double scaledCursorX = SystemInputSimulator.getScaledCursorX(handledScreen.width);
               double scaledCursorY = SystemInputSimulator.getScaledCursorY(handledScreen.height);
               if (handledScreen2.getFocusedSlot() == slot2) {
                  double doubleValue4 = Math.abs(scaledCursorX - doubleValue);

                  if (doubleValue4 <= (10.0) && Math.abs(scaledCursorY - doubleValue3) <= 10.0) {
                     return true;
                  }
               }

               return false;
            }
         }

         getCursorMovementSimulator(this).cancel();
         return false;
      }
   }

   public static int getIntState(AutoTotemModule autoTotemModule) {
      return autoTotemModule.intState;
   }

   private void updateState2(int intState22, long longValue) {
      this.intState2 = intState22;
      this.longState2 = Math.max(0L, longValue);
      getStopwatch(this).updateTimestampMillis();
   }

   private static boolean isOf(ItemStack itemStack) {
      return itemStack.isOf(Items.TOTEM_OF_UNDYING);
   }

   private void updateState3() {
      if (!this.booleanState2) {
         if (getDebugMessagesSetting(this).isOn()) {
            this.booleanState2 = true;
            ChatMessages.updateState4("AutoTotem: the server ignored the silent swap, using the inventory instead.");
            return;
         }

         ThreadLocalRandom.current().nextInt(15);
      }
   }

   public static void setLongState(AutoTotemModule autoTotemModule, long longState4) {
      autoTotemModule.longState = longState4;
   }

   public static DoubleSetting getSilentRetriesSetting(AutoTotemModule autoTotemModule) {
      return autoTotemModule.silentRetriesSetting;
   }

   private void updateState4() {
      if (this.checkCondition4()) {
         HotbarSelectionManager.updateState3(this);
         this.updateState6();
      } else {
         if (!this.checkCondition2()) {
            ThreadLocalRandom.current().nextInt(7);

            HotbarSelectionManager.updateState3(this);
            this.updateState6();
         } else if (!this.equals()) {
            this.updateState5(false);
         } else {
            ThreadLocalRandom.current().nextInt(17);
            if (getIntState(this) >= this.silentRetriesSetting.intValue()) {
               if (!this.legitFallbackSetting.isOn()) {
                  HotbarSelectionManager.updateState3(this);
                  this.updateState6();
               } else {
                  this.updateState3();
                  this.updateState5(true);
               }
            } else {
               switch (getIntState2(this)) {
                  case 0:
                     if (this.computeInt() < 0) {
                        this.updateState6();
                        return;
                     }

                     long longValue = 832511365944333811L;
                     longValue = 832511365944333811L;
                     long longValue2 = 622590302L;
                     int intValue = 622590302;
                     int intValue2 = 622590298;
                     byte byteValue = 4;
                     intValue = 622590302;
                     int intValue3 = 622590298;
                     this.updateState2(4, this.computeLong2());
                     return;
                  case 1:

                  case 2:
                  default:
                     break;
                  case 3:

                     break;
                  case 4:
                     HotbarSelectionManager.updateState(this);

                     ThreadLocalRandom.current().nextInt(16);
                     return;
                  case 5:
                     if (this.checkCondition4()) {
                        this.updateState10();
                        return;
                     }

                     if (!this.checkCondition3()) {
                        return;
                     }

                     long longValue3 = -6150436293652969885L;
                     longValue3 = -6150436293652969885L;
                     long longValue4 = 2860497754L;
                     int intValue4 = -1434469542;
                     int intValue5 = -1434469541;
                     intValue4 = -1434469541;
                     int intValue6 = -1434469541;
                     intValue4 = -1434469542;
                     int intValue7 = 1434469540;
                     setIntState(this, this.intState + 1);
                     if (this.intState >= getSilentRetriesSetting(this).intValue()) {
                        this.updateState6();
                        return;
                     }

                     this.updateState2(7, Math.round(this.retryDelayMsSetting.getValue()));
                     return;
                  case 6:

                     break;
                  case 7:

                     ThreadLocalRandom.current().nextInt(11);
                     if (!this.checkCondition3()) {
                        return;
                     }

                     setIntState22(this, 0);
                     return;
               }

               this.updateState6();
            }
         }
      }
   }

   public static boolean getBooleanState(AutoTotemModule autoTotemModule) {
      return autoTotemModule.booleanState;
   }

   private static boolean isOf2(ItemStack itemStack) {
      return itemStack.isOf(InventoryPlayerAccess.getTOTEM_OF_UNDYING());
   }

   @Override
   public void onDisable() {
      HotbarSelectionManager.updateState3(this);
      this.updateState6();
      super.onDisable();
   }

   public static Slot getSlot(AutoTotemModule autoTotemModule) {
      return autoTotemModule.slot;
   }

   public static void setSlot(AutoTotemModule autoTotemModule, Slot slot2) {
      autoTotemModule.slot = slot2;
   }

   private Slot computeSlotForHandledScreen(HandledScreen handledScreen, Slot slot2) {
      if (slot2 != null) {
         label45:
         if (slot2.hasStack() && slot2.getStack().isOf(Items.TOTEM_OF_UNDYING)) {
            ThreadLocalRandom.current().nextInt(12);
            if (this.isOn()) {
               if (slot2.getIndex() == this.hotbarSlotSetting.getSlotIndex()) {
                  break label45;
               }
            }

            return slot2;
         }
      }

      return this.computeSlotForHandledScreen2(handledScreen);
   }

   public static BooleanSetting getSimCursorSetting(AutoTotemModule autoTotemModule) {
      return autoTotemModule.simCursorSetting;
   }

   private static boolean isOf3(ItemStack itemStack) {
      return itemStack.isOf(Items.TOTEM_OF_UNDYING);
   }

   public static void setIntState22(AutoTotemModule autoTotemModule, int intState22) {
      autoTotemModule.intState2 = intState22;
   }

   public static BooleanSetting getDebugMessagesSetting(AutoTotemModule autoTotemModule) {
      return autoTotemModule.debugMessagesSetting;
   }

   public static long getLongState3(AutoTotemModule autoTotemModule) {
      return autoTotemModule.longState3;
   }

   private boolean checkCondition() {
      if (mc.getWindow() == null) {
         return false;
      } else {
         long handle = mc.getWindow().getHandle();

         return (GLFW.glfwGetWindowAttrib(handle, 131073) == 1);
      }
   }

   public static ChoiceSetting getOpenModeSetting(AutoTotemModule autoTotemModule) {
      return autoTotemModule.openModeSetting;
   }

   public static BooleanSetting getHotbarSetting(AutoTotemModule autoTotemModule) {
      return autoTotemModule.hotbarSetting;
   }

   public static long getLongState2(AutoTotemModule autoTotemModule) {
      return autoTotemModule.longState2;
   }

   private long computeLong() {
      int latency = 0;
      if (mc.getNetworkHandler() != null) {
         PlayerListEntry playerListEntry = mc.getNetworkHandler().getPlayerListEntry(InventoryPlayerAccess.getPlayer(mc).getUuid());
         if (playerListEntry != null) {
            latency = playerListEntry.getLatency();
         }
      }

      return Math.max(200L, Math.min(1000L, 150L + (long)latency));
   }

   public AutoTotemModule() {
      super("Auto Totem", "Keeps a totem in your offhand or a chosen hotbar slot", ModuleCategory.PLAYER);
      String[] stringArray = new String[]{"Silent", null};

      stringArray[1] = "Legit";
      this.openModeSetting = new ChoiceSetting("Open Mode", "Silent", stringArray);
      this.hotbarSetting = new BooleanSetting("Hotbar", false);
      this.hotbarSlotSetting = new HotbarSlotSetting("Hotbar Slot", 1);

      this.silentRetriesSetting = new DoubleSetting("Silent Retries", 0.0, 5.0, (2.0), (1.0));

      this.retryDelayMsSetting = new DoubleSetting("Retry Delay (ms)", 0.0, (500.0), 120.0, 5.0);

      this.legitFallbackSetting = new BooleanSetting("Legit Fallback", true);

      this.strictTickPacingSetting = new BooleanSetting("Strict Tick Pacing", true);

      this.autoOpenInvSetting = new BooleanSetting("Auto Open Inv", true);
      this.autoCloseSetting = new BooleanSetting("Auto Close", true);
      this.clickSimSetting = new BooleanSetting("ClickSim", false);
      this.simCursorSetting = new BooleanSetting("SimCursor", false);

      this.cursorSpeedSetting = new DoubleSetting("Cursor Speed", (1.0), (100.0), (18.0), 1.0);

      stringArray = new String[3];

      stringArray[0] = "Smooth";
      stringArray[1] = "Heuristic";
      stringArray[2] = "Instant";
      this.cursorModeSetting = new ChoiceSetting("Cursor Mode", "Smooth", stringArray);

      this.fastDelayMsSetting = new DoubleSetting("Fast Delay (ms)", 0.0, (300.0), (67.0), 1.0);

      this.fumbleDelayMsSetting = new DoubleSetting("Fumble Delay (ms)", 0.0, 800.0, 325.0, (1.0));

      this.fumbleChanceSetting = new DoubleSetting("Fumble Chance %", 0.0, (100.0), 55.0, 1.0);

      this.debugMessagesSetting = new BooleanSetting("Debug Messages", false);
      this.random = new Random();
      this.cursorMovementSimulator = new CursorMovementSimulator();
      this.stopwatch = new Stopwatch();
      this.intState2 = 0;

      Setting[] settingArray = new Setting[]{this.openModeSetting, null, null};

      settingArray[1] = this.hotbarSetting;

      settingArray[2] = this.hotbarSlotSetting;
      this.addSettings(settingArray);
      Setting[] settingArray2 = new Setting[4];

      settingArray2[0] = this.silentRetriesSetting;

      settingArray2[1] = this.retryDelayMsSetting;
      settingArray2[2] = this.legitFallbackSetting;
      settingArray2[3] = this.strictTickPacingSetting;
      this.addSettings(settingArray2);
      Setting[] settingArray3 = new Setting[6];

      settingArray3[0] = this.autoOpenInvSetting;
      settingArray3[1] = this.autoCloseSetting;

      settingArray3[2] = this.clickSimSetting;
      settingArray3[3] = this.simCursorSetting;

      settingArray3[4] = this.cursorSpeedSetting;
      settingArray3[5] = this.cursorModeSetting;
      this.addSettings(settingArray3);
      this.addSettings(new Setting[]{this.fastDelayMsSetting, this.fumbleDelayMsSetting, this.fumbleChanceSetting, this.debugMessagesSetting});
      this.hotbarSlotSetting.setVisibility(() -> this.hotbarSetting.isOn());
      this.silentRetriesSetting.setVisibility(() -> this.equals());
      this.retryDelayMsSetting.setVisibility(() -> this.equals());
      this.legitFallbackSetting.setVisibility(() -> this.equals());
      this.autoOpenInvSetting.setVisibility(() -> this.valueOf());
      this.autoCloseSetting.setVisibility(() -> this.computeBoolean());
      this.cursorSpeedSetting.setVisibility(() -> this.simCursorSetting.isOn());
      this.cursorModeSetting.setVisibility(() -> this.simCursorSetting.isOn());
   }

   private boolean isOn() {
      return getHotbarSetting(this).isOn();
   }

   public static void setBooleanState2(AutoTotemModule autoTotemModule, boolean booleanState22) {
      autoTotemModule.booleanState2 = booleanState22;
   }

   private boolean checkCondition2() {
      int intValue;
      ThreadLocalRandom.current().nextInt(3);
      intValue = InventoryUtils.computeIntForPredicate(objectValue -> isOf2((ItemStack)objectValue));

      return ((intValue != -1 ? 1 : 0) != 0);
   }

   public static Stopwatch getStopwatch(AutoTotemModule autoTotemModule) {
      return autoTotemModule.stopwatch;
   }

   private boolean checkCondition3() {
      return getStopwatch(this).checkCondition(getLongState2(this));
   }

   public static DoubleSetting getFumbleChanceSetting(AutoTotemModule autoTotemModule) {
      return autoTotemModule.fumbleChanceSetting;
   }

   @Override
   public void onEnable() {
      setIntState(this, 0);
      setBooleanState2(this, false);
      setLongState(this, 0L);

      this.longState3 = (0L);
      this.updateState6();
      super.onEnable();
   }

   private void updateState5(boolean booleanValue) {
      switch (this.intState2) {
         case 1:
            if (!this.checkCondition3()) {
               return;
            }

            long longValue = -1972723289528930733L;
            longValue = -1972723289528930733L;
            long longValue2 = 2753325874L;
            int intValue = -1541641422;
            int intValue2 = -1541641421;
            byte byteValue = 0;
            intValue = -1541641422;
            int intValue3 = -1541641421;
            this.booleanState = true;
            mc.setScreen(new InventoryScreen(mc.player));
            this.updateState2(2, 0L);
            break;
         case 2:
            if (!this.checkCondition3()) {
               return;
            }

            this.updateState6();
            break;
         case 4:

         case 5:
         default:
            this.updateState6();
            break;
         case 6:

         case 0:
         case 3:
            if (!booleanValue) {
               if (!getAutoOpenInvSetting(this).isOn()) {
                  this.updateState6();
                  return;
               }
            }

            this.updateState2(1, this.computeLong2());
      }
   }

   private long computeLong2() {
      byte byteValue;
      if (this.random.nextInt(100) < (int)getFumbleChanceSetting(this).getValue()) {
         byteValue = 1;
      } else {
         byteValue = 0;
      }

      byte byteValue2 = byteValue;
      double doubleValue = byteValue2 != 0 ? getFumbleDelayMsSetting(this).getValue() : this.fastDelayMsSetting.getValue();
      double doubleValue2;
      if (byteValue2 != 0) {
         doubleValue2 = 50.0;
      } else {
         doubleValue2 = 20.0;
      }

      double doubleValue22 = doubleValue2;
      long longValue = Math.round(doubleValue + getRandom(this).nextGaussian() * doubleValue22);

      return Math.max(1L, Math.min(longValue, (1500L)));
   }

   private boolean testHandledScreen2(HandledScreen handledScreen, Slot slot2) {
      if (getSimCursorSetting(this).isOn()) {
         if (!this.testHandledScreen(handledScreen, slot2)) {
            return false;
         }
      }

      byte byteValue;
      if (!this.isOn()) {
         byteValue = 1;
      } else {
         byteValue = 20;
         ThreadLocalRandom.current().nextInt(17);
         byteValue = 0;
      }

      byte byteValue2 = byteValue;
      if (byteValue2 != 0) {
         if (getClickSimSetting(this).isOn()) {
            if (this.checkCondition()) {
               ClickSimulator.tapKey(InventoryPlayerAccess.getSwapHandsKey(InventoryPlayerAccess.getOptions(mc)));
               HotbarSelectionManager.updateState6();
               return true;
            }
         }
      }

      if (this.isOn()) {
         InventoryUtils.updateState2(slot2.id, getHotbarSlotSetting(this).getSlotIndex());
      } else {
         InventoryUtils.updateState(InventoryPlayerAccess.getId(slot2));
      }

      return true;
   }

   public static int getIntState2(AutoTotemModule autoTotemModule) {
      return autoTotemModule.intState2;
   }

   private boolean testHandledScreen3(HandledScreen handledScreen, Slot slot2) {
      if (mc.player != null) {
         if (mc.currentScreen == handledScreen) {
            if (mc.player.currentScreenHandler == handledScreen.getScreenHandler()) {
               ThreadLocalRandom.current().nextInt(5);

               if (slot2 != null) {
                  if (InventoryPlayerAccess.getSlots(handledScreen.getScreenHandler()).contains(slot2)) {
                     if (slot2.hasStack()) {
                        if (slot2.getStack().isOf(Items.TOTEM_OF_UNDYING)) {
                           return true;
                        }
                     }
                  }
               }
            }
         }
      }

      return false;
   }

   private void updateState6() {
      HotbarSelectionManager.updateState3(this);
      this.cursorMovementSimulator.cancel();

      this.intState2 = 0;

      this.longState2 = (0L);
      getStopwatch(this).updateTimestampMillis();
      this.slot = null;
      this.booleanState = false;
   }

   private int computeInt() {
      int intValue = InventoryUtils.computeIntForPredicate(objectValue -> isOf((ItemStack)objectValue));
      if (intValue < 0) {
         return -1;
      } else {
         return InventoryUtils.computeInt2(intValue);
      }
   }

   private boolean checkCondition4() {
      if (this.isOn()) {
         return InventoryUtils.testItem(this.hotbarSlotSetting.getSlotIndex(), Items.TOTEM_OF_UNDYING);
      } else {
         return InventoryUtils.testItem3(Items.TOTEM_OF_UNDYING);
      }
   }

   public static BooleanSetting getAutoOpenInvSetting(AutoTotemModule autoTotemModule) {
      return autoTotemModule.autoOpenInvSetting;
   }

   private void updateState7() {
      HotbarSelectionManager.updateState3(this);
      if (getBooleanState(this)) {
         if (this.autoCloseSetting.isOn()) {
            this.updateState2(6, (long)(100 + getRandom(this).nextInt(100)));
            return;
         }
      }

      this.updateState6();
   }

   private void updateState8() {
      int intValue = this.computeInt();
      if (intValue < 0) {
         this.updateState6();
      } else {
         ThreadLocalRandom.current().nextInt(15);
         if (this.isOn()) {
            InventoryUtils.updateState2(intValue, getHotbarSlotSetting(this).getSlotIndex());
         } else {
            InventoryUtils.updateState(intValue);
         }

         this.updateState2(5, this.computeLong());
      }
   }

   private void updateState9() {
      if (getBooleanState(this)) {
         if (mc.player != null) {
            if (mc.currentScreen != null) {
               ThreadLocalRandom.current().nextInt(13);

               mc.player.closeHandledScreen();
            }
         }
      } else {
         ThreadLocalRandom.current().nextInt(13);
      }
   }

   private Slot computeSlotForHandledScreen2(HandledScreen handledScreen) {
      boolean on = this.simCursorSetting.isOn();
      double doubleValue;
      if (on) {
         doubleValue = SystemInputSimulator.getScaledCursorX(handledScreen.width);
      } else {
         doubleValue = 0.0;
      }

      double doubleValue2 = doubleValue;
      if (on) {
         doubleValue = SystemInputSimulator.getScaledCursorY(handledScreen.height);
      } else {
         doubleValue = (0.0);
      }

      double doubleValue3 = doubleValue;
      return InventoryUtils.computeSlotForHandledScreen(handledScreen, objectValue -> isOf3((ItemStack)objectValue), doubleValue2, doubleValue3, on);
   }

   private void updateState10() {
      int intState3;

      long longState4 = System.currentTimeMillis();
      long longValue2 = longState4 - getLongState(this);

      byte byteValue;
      if (longValue2 < 3000L) {
         byteValue = 1;
      } else {
         byteValue = 0;
      }

      byte byteValue2 = byteValue;
      longValue2 = longState4 - getLongState3(this);

      byte byteValue3;
      if (longValue2 < 3000L) {
         byteValue3 = 1;
      } else {
         byteValue3 = 0;
      }

      label39: {
         byte byteValue32 = byteValue3;
         if (byteValue2 != 0) {
            if (byteValue32 == 0) {
               intState3 = getIntState(this) + 1;
               break label39;
            }

            ThreadLocalRandom.current().nextInt(15);
         }

         intState3 = 0;
      }

      this.intState = intState3;
      setLongState(this, longState4);
      this.updateState6();
   }

   @EventHandler
   private void onRender2D(Render2DEvent render2DEvent) {
      int intState22 = getIntState2(this);

      if (intState22 == 4) {
         if (this.simCursorSetting.isOn() && mc.currentScreen instanceof InventoryScreen var2) {
            if (this.slot != null) {
               if (((PlayerScreenHandler)var2.getScreenHandler()).slots.contains(this.slot)) {
                  ThreadLocalRandom.current().nextInt(11);
                  if (getSlot(this).hasStack()) {
                     if (getSlot(this).getStack().isOf(InventoryPlayerAccess.getTOTEM_OF_UNDYING())) {
                        if (!PlayerStateUtils.isPlayerUnavailable()) {
                           this.testHandledScreen(var2, this.slot);
                           return;
                        }
                     }
                  }
               }
            }
         }
      }

      getCursorMovementSimulator(this).cancel();
   }

   public static long getLongState(AutoTotemModule autoTotemModule) {
      return autoTotemModule.longState;
   }

   @EventHandler
   private void onPacketEvent(PacketEvent packetEvent) {
      if (packetEvent.getOrder() == TransferOrder.RECEIVE) {
         if (InventoryPlayerAccess.getPlayer(mc) != null) {
            if (packetEvent.getPacket() instanceof EntityStatusS2CPacket var2) {
               if (var2.getStatus() != 35) {
                  return;
               }

               Entity entity = var2.getEntity(mc.world);
               if (entity != null) {
                  if (entity.equals(mc.player)) {
                     setLongState3(this, System.currentTimeMillis());
                  }
               }

               return;
            }

            return;
         }
      }
   }

   public static DoubleSetting getFumbleDelayMsSetting(AutoTotemModule autoTotemModule) {
      return autoTotemModule.fumbleDelayMsSetting;
   }

   @EventHandler
   private void onTickEvent(TickEvent tickEvent) {
      HotbarSelectionManager.updateState2();
      this.updateState();
   }

   private void updateStateForHandledScreen(HandledScreen handledScreen) {
      if (!handledScreen.getScreenHandler().getCursorStack().isEmpty()) {
         HotbarSelectionManager.updateState3(this);
         setSlot(this, null);

         this.updateState2(3, 200L);
      } else {
         switch (getIntState2(this)) {
            case 0:

            case 1:
            case 2:

               if (this.checkCondition4()) {
                  this.updateState7();
                  return;
               }

               byte byteValue = 13;
               ThreadLocalRandom.current().nextInt(8);
               if (!this.checkCondition2()) {
                  this.updateState6();
                  return;
               }

               this.updateState2(3, (long)getRandom(this).nextInt(50));
               break;
            case 3:

               if (!this.checkCondition3()) {
                  return;
               }

               if (this.checkCondition4()) {
                  this.updateState7();
                  return;
               }

               Slot slot2 = this.computeSlotForHandledScreen2(handledScreen);
               if (slot2 == null) {
                  this.updateState6();
                  return;
               }

               setSlot(this, slot2);
               long longValue = 2786715607052543387L;
               longValue = 2786715607052543387L;
               long longValue2 = 2704604528L;
               int intValue = -1590362768;
               int intValue2 = -1590362764;
               byte byteValue2 = 0;
               intValue = -1590362768;
               int intValue3 = -1590362764;
               this.updateState2(4, this.computeLong2());
               break;
            case 4:
               this.slot = this.computeSlotForHandledScreen(handledScreen, getSlot(this));
               if (getSlot(this) == null) {
                  this.updateState6();
                  return;
               }

               if (!this.testHandledScreen(handledScreen, getSlot(this))) {
                  return;
               }

               HotbarSelectionManager.updateState(this);
               break;
            case 5:

            default:
               this.updateState6();
               break;
            case 6:
               if (!this.checkCondition3()) {
                  return;
               }

               this.updateState9();
               this.updateState6();
         }
      }
   }

}
