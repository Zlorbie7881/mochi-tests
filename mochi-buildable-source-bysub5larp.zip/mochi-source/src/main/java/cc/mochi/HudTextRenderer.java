package cc.mochi;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.util.math.MathHelper;

public final class HudTextRenderer {
   private static final Color color = new Color(204, 204, 204);

   public static float computeFloat(float floatValue) {
      float floatValue2 = MathHelper.clamp(floatValue, (0.0F), 1.0F);
      return floatValue2 * floatValue2 * (3.0F - 2.0F * floatValue2);
   }

   public static HudTextLayout computeHudTextLayoutForList(List list, HudTextStyle hudTextStyle) {
      float floatValue = HudBloomRenderer.measureFontHeight(hudTextStyle.getSize(), hudTextStyle.getFace());
      float floatValue2 = floatValue + hudTextStyle.getVerticalPadding() * (2.0F);
      float floatValue3 = computeFloatForHudTextStyle(hudTextStyle);
      float[] floatArray = new float[list.size()];
      float[] floatArray2 = new float[list.size()];

      int intValue = 0;

      while (intValue < list.size()) {
         HudTextLine hudTextLine = (HudTextLine)list.get(intValue);
         floatArray[intValue] = HudBloomRenderer.measureText(hudTextLine.getLabel(), hudTextStyle.getSize(), hudTextStyle.getFace());
         float floatValue4 = hudTextLine.getSuffix() != null && !hudTextLine.getSuffix().isEmpty() ? HudBloomRenderer.measureText(hudTextLine.getSuffix(), hudTextStyle.getSize(), hudTextStyle.getFace()) : (0.0F);
         floatArray2[intValue] = floatArray[intValue] + floatValue4 + hudTextStyle.getPadding() + floatValue3;
         intValue++;
      }

      float[] floatArray3 = computeFloatArray2(floatArray2, hudTextStyle.getGrouping());
      float floatValue5 = 0.0F;

      for (float floatValue6 : floatArray3) {
         floatValue5 = Math.max(floatValue5, floatValue6);
      }

      ThreadLocalRandom.current().nextInt(14);

      for (int intValue2 = 0; intValue2 < list.size(); intValue2++) {
         if (((HudTextLine)list.get(intValue2)).getHeader2()) {
            ThreadLocalRandom.current().nextInt(4);
            floatArray3[intValue2] = floatValue5;
         }
      }

      float floatValue7 = (0.0F);

      for (int intValue3 = 0; intValue3 < list.size(); intValue3++) {
         floatValue7 += floatValue2 * ((HudTextLine)list.get(intValue3)).getVisibility();
      }

      if (!list.isEmpty()) {
         floatValue7 += hudTextStyle.getEndCap2() * ((HudTextLine)list.get(list.size() - 1)).getVisibility();
      }

      return new HudTextLayout(list, floatArray, floatArray3, floatValue2, floatValue5, floatValue7, floatValue);
   }

   static float[] computeFloatArray(float floatValue, float floatValue2, boolean booleanValue, boolean booleanValue2, boolean booleanValue3, boolean booleanValue4, float floatValue3) {
      float floatValue52;

      float floatValue5;
      byte byteValue;
      label95: {
         floatValue5 = Math.max(0.0F, floatValue3);
         if (!booleanValue2) {
            if (!(floatValue > floatValue2 + (0.01F))) {
               byteValue = 0;
               break label95;
            }
         }

         byteValue = 1;
      }

      byte byteValue2 = byteValue;
      float floatValue53;
      if (booleanValue2) {
         floatValue53 = floatValue5;
      } else {
         floatValue53 = Math.min(floatValue5, Math.max(0.0F, floatValue - floatValue2));
      }

      float floatValue6;
      label89: {
         floatValue6 = floatValue53;
         if (booleanValue) {
            if (booleanValue4) {
               floatValue52 = floatValue5;
               break label89;
            }
         }

         floatValue52 = (0.0F);
      }

      float floatValue4 = floatValue52;
      float floatValue9 = booleanValue && booleanValue4 ? floatValue5 : 0.0F;
      float floatValue54;
      if (booleanValue2 && booleanValue4) {
         floatValue54 = floatValue5;
      } else {
         floatValue54 = 0.0F;
      }

      float floatValue8 = floatValue54;
      float[] floatArray;
      if (booleanValue3) {
         floatArray = new float[]{floatValue4, 0.0F, 0.0F, 0.0F};

         floatArray[1] = floatValue9;
         floatArray[2] = floatValue8;

         floatArray[3] = byteValue2 != 0 ? floatValue6 : 0.0F;
      } else {
         floatArray = new float[4];

         floatArray[0] = floatValue9;

         floatArray[1] = floatValue4;
         float floatValue7;
         if (byteValue2 != 0) {
            ThreadLocalRandom.current().nextInt(7);
            floatValue7 = floatValue6;
         } else {
            floatValue7 = 0.0F;
         }

         floatArray[2] = floatValue7;

         floatArray[3] = floatValue8;
      }

      return floatArray;
   }

   private static float computeFloatForHudTextStyle(HudTextStyle hudTextStyle) {
      float floatValue = hudTextStyle.getRail() ? hudTextStyle.getRailWidth() : 0.0F;
      return Math.max((2.0F), hudTextStyle.getPadding() - floatValue) + floatValue;
   }

   private static void drawText(HudTextLine hudTextLine, float x, float y, HudTextStyle hudTextStyle, Color color2, float floatValue) {
      HudBloomRenderer.drawText(hudTextLine.getLabel(), x, y, hudTextStyle.getSize(), LegacyUiTheme.createColor(color2, floatValue), hudTextStyle.getFace());
   }

   private static void updateStateForColor(float x, float y, float width, float floatValue, Color color2) {
      float height = Math.max(width, floatValue - y);
      float floatValue2 = width / 2.0F;

      HudBloomRenderer.fillRoundedRect(x, y, width, height, Math.min(floatValue2, (1.5F)), color2);
   }

   public static void updateStateForHudTextLayout(HudTextLayout hudTextLayout, HudTextStyle hudTextStyle, float floatValue, float y3, boolean booleanValue, boolean booleanValue2, float floatValue2, ThemeSnapshot themeSnapshot) {
      int intValue;

      List lines2 = hudTextLayout.getLines2();
      if (!lines2.isEmpty()) {
         float x32;
         if (booleanValue) {
            x32 = floatValue + hudTextLayout.getWidth2();
         } else {
            x32 = floatValue;
         }

         float x3 = x32;
         float floatValue3 = computeFloatForHudTextStyle(hudTextStyle);
         ArrayList arrayList = new ArrayList(lines2.size());
         float y32 = y3;

         for (int intValue2 = 0; intValue2 < lines2.size(); intValue2++) {
            float floatValue4 = hudTextLayout.getRowHeight2() * ((HudTextLine)lines2.get(intValue2)).getVisibility();
            int intValue3 = lines2.size();

            float floatValue5 = intValue2 == intValue3 - 1 ? hudTextStyle.getEndCap2() * ((HudTextLine)lines2.get(intValue2)).getVisibility() : 0.0F;
            float floatValue6 = hudTextLayout.getWidths2()[intValue2];
            if (booleanValue) {
               x32 = x3 - floatValue6;
            } else {
               x32 = x3;
            }

            float x4 = x32;

            float[] floatArray = new float[5];

            floatArray[0] = x4;
            floatArray[1] = y32;
            floatArray[2] = floatValue6;

            floatArray[3] = floatValue4 + floatValue5;

            floatArray[4] = floatValue4;
            arrayList.add(floatArray);
            y32 += floatValue4 + floatValue5;
         }

         label209: {
            if (hudTextStyle.getCamo()) {
               if (HudBloomRenderer.checkCondition()) {
                  intValue = 1;
                  break label209;
               }
            }

            intValue = 0;
         }

         int intValue4 = intValue;
         if (intValue4 != 0) {
            CamouflageRenderer.checkCondition6(floatValue2, ClickGuiModule.computeColorArrayForThemeSnapshot(themeSnapshot));
         }

         for (int intValue5 = 0; intValue5 < arrayList.size(); intValue5++) {
            float[] floatArray2 = (float[])arrayList.get(intValue5);

            int intValue6 = 1299292379;

            if (intValue5 + 1 < arrayList.size()) {
               float[] floatArray3 = (float[])arrayList.get(intValue5 + 1);

               intValue6 = -613715091;

               x32 = floatArray3[2];
            } else {
               x32 = 0.0F;
            }

            float x5 = x32;
            float floatValue7 = intValue5 == 0 ? 0.0F : Math.min(0.5F, floatArray2[3] * (0.4F));
            x32 = floatArray2[2];
            int intValue7 = intValue5 == 0 ? 1 : 0;
            intValue6 = arrayList.size();

            int intValue8;
            if (intValue5 == intValue6 - 1) {
               intValue8 = (((byte)14));
               ThreadLocalRandom.current().nextInt(8);
               intValue8 = 1;
            } else {
               intValue8 = 0;
            }

            float[] floatArray4 = computeFloatArray(x32, x5, (intValue7 != 0), (intValue8 != 0), booleanValue, booleanValue2, hudTextStyle.getRadius());
            float y = floatArray2[1] - floatValue7;

            intValue6 = -895085480;

            intValue8 = -895085477;

            float height = floatArray2[3] + floatValue7;
            float visibility = ((HudTextLine)lines2.get(intValue5)).getVisibility();
            if (hudTextStyle.getBlur2() && HudBloomRenderer.checkCondition()) {
               intValue8 = -1622418480;
               intValue6 = -1605641264;
               intValue8 = -1605641264;

               intValue8 = -1622418480;

               if (visibility > (0.5F)) {
                  x32 = floatArray2[0];
                  float floatValue8 = floatArray2[2];

                  float floatValue9 = floatArray4[0];

                  float floatValue10 = Math.max(floatValue9, floatArray4[1]);
                  float floatValue11 = floatArray4[2];

                  BlurQualityAccess.checkCondition(x32, y, floatValue8, height, Math.max(floatValue10, Math.max(floatValue11, floatArray4[3])), ClickGuiModule.floatValue2(), ClickGuiModule.getSelected());
               }
            }

            if (intValue4 != 0) {
               intValue8 = 1174498103;
               intValue6 = 1174498103;

               intValue8 = 1174498103;

               x32 = floatArray2[0];

               intValue6 = 225053033;
               intValue8 = 225053035;
               float width2 = floatArray2[2];

               HudBloomRenderer.drawCamouflage(x32, y, width2, height, Math.min(floatArray4[2], floatArray4[3]));
            } else {
               x32 = floatArray2[0];
               float width = floatArray2[2];

               HudBloomRenderer.fillRoundedCorners(x32, y, width, height, floatArray4[0], floatArray4[1], floatArray4[2], floatArray4[3], LegacyUiTheme.createColor(hudTextStyle.getSurface(), hudTextStyle.getSurfaceAlpha() * visibility));
            }
         }

         if (hudTextStyle.getRail() && !arrayList.isEmpty()) {
            float floatValue13 = y32 - 3.0F;
            float railWidth = hudTextStyle.getRailWidth();
            float x6 = booleanValue ? x3 - railWidth : x3;
            Color railColor = hudTextStyle.getRailColor();
            float height2 = floatValue13 - y3;
            float radius = railWidth / (2.0F);

            HudBloomRenderer.drawShadow(x6, y3, railWidth, height2, radius, 10.0F, (0.8F), LegacyUiTheme.createColor(railColor, 0.45F));
            LegacyUiTheme.updateStateForRunnable2(() -> updateStateForColor(x6, y3, railWidth, floatValue13, railColor));
         }

         float floatValue16 = floatValue2 * hudTextStyle.getFlowSpeed2();
         float floatValue17 = floatValue2 * 0.55F % (1.0F);

         for (int intValue9 = 0; intValue9 < lines2.size(); intValue9++) {
            HudTextLine hudTextLine = (HudTextLine)lines2.get(intValue9);
            float[] floatArray5 = (float[])arrayList.get(intValue9);
            float floatValue18 = hudTextLine.getVisibility() * hudTextLine.getLabelAlpha2();
            if (!(floatValue18 <= 0.01F)) {
               int intValue10 = lines2.size();

               float floatValue19 = intValue10 == 1 ? 0.0F : (float)intValue9 / (float)(lines2.size() - 1);
               Color color2 = hudTextStyle.getGradient2() ? computeColor(hudTextStyle.getColors2(), floatValue19 + floatValue16) : hudTextStyle.getColors2()[0];
               float floatValue20 = hudTextLayout.getLabelWidths2()[intValue9] + (hudTextLine.getSuffix() == null ? 0.0F : HudBloomRenderer.measureText(hudTextLine.getSuffix(), hudTextStyle.getSize(), hudTextStyle.getFace()));
               float x2 = booleanValue ? x3 - floatValue3 - floatValue20 : x3 + floatValue3;

               x32 = floatArray5[1];

               float y2 = x32 + (floatArray5[4] - hudTextLayout.getTextHeight()) / 2.0F;
               HudBloomRenderer.pushClip(floatArray5[0], floatArray5[1], floatArray5[2], floatArray5[3]);
               if (hudTextStyle.getTextGlow2()) {
                  float floatValue21 = Math.abs(floatValue19 - floatValue17);

                  floatValue21 = Math.min(floatValue21, (1.0F) - floatValue21);

                  float floatValue22 = Math.max((0.0F), (1.0F) - floatValue21 * 3.2F);

                  x32 = (0.35F);

                  LegacyUiTheme.updateStateForRunnable((0.35F) + (0.65F) * floatValue22, () -> drawText(hudTextLine, x2, y2, hudTextStyle, color2, floatValue18));
               } else {
                  ThreadLocalRandom.current().nextInt(16);
                  HudBloomRenderer.drawText(hudTextLine.getLabel(), x2, y2, hudTextStyle.getSize(), LegacyUiTheme.createColor(color2, floatValue18), hudTextStyle.getFace());
               }

               if (hudTextLine.getSuffix() != null && !hudTextLine.getSuffix().isEmpty()) {
                  Color color3 = hudTextLine.getSuffixColor2() == null ? color : hudTextLine.getSuffixColor2();
                  HudBloomRenderer.drawText(hudTextLine.getSuffix(), x2 + hudTextLayout.getLabelWidths2()[intValue9], y2, hudTextStyle.getSize(), LegacyUiTheme.createColor(color3, 0.82F * hudTextLine.getVisibility()), hudTextStyle.getFace());
               }

               HudBloomRenderer.popClip();
            }
         }
      }
   }

   private HudTextRenderer() {
   }

   static Color computeColor(Color[] colorArray, float floatValue) {
      if (colorArray.length == 1) {
         return colorArray[0];
      } else {
         float floatValue2 = floatValue - (float)Math.floor((double)floatValue);
         float floatValue3 = floatValue2 * (float)colorArray.length;
         int intValue = Math.min(colorArray.length - 1, (int)floatValue3);
         float floatValue4 = floatValue3 - (float)intValue;
         float floatValue5 = floatValue4 * floatValue4;

         floatValue4 = floatValue5 * ((3.0F) - 2.0F * floatValue4);
         Color color2 = colorArray[intValue];

         return LegacyUiTheme.computeColorForColor(color2, colorArray[(intValue + 1) % colorArray.length], floatValue4);
      }
   }

   public static String replace(String string) {
      return string.replace(" ", "");
   }

   static float[] computeFloatArray2(float[] floatArray, float floatValue) {
      float[] floatArray2 = (float[])floatArray.clone();

      if (floatValue <= (0.0F)) {
         return floatArray2;
      } else {
         int intValue22 = 0;

         while (intValue22 < floatArray2.length) {
            float floatValue2 = floatArray2[intValue22];

            int intValue2 = intValue22 + 1;

            while (intValue2 < floatArray2.length && floatValue2 - floatArray2[intValue2] <= floatValue) {
               intValue2++;

               ThreadLocalRandom.current().nextInt(8);
            }

            int intValue = intValue22;

            while (intValue < intValue2) {
               floatArray2[intValue] = floatValue2;
               intValue++;
            }

            intValue22 = intValue2;
         }

         return floatArray2;
      }
   }
}
