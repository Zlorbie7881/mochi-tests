package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;

public class GameOptionsAccess {
   public static GameOptions getOptions(MinecraftClient minecraftClient) {
      return minecraftClient.options;
   }

   public static KeyBinding getBackKey(GameOptions gameOptions) {
      return gameOptions.backKey;
   }

   public static KeyBinding getForwardKey(GameOptions gameOptions) {
      return gameOptions.forwardKey;
   }

   public static KeyBinding getLeftKey(GameOptions gameOptions) {
      return gameOptions.leftKey;
   }

   public static KeyBinding getRightKey(GameOptions gameOptions) {
      return gameOptions.rightKey;
   }

}
