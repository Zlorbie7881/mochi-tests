package cc.mochi;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public final class CommandPaletteCommands {
   private static String computeStringForTheme(Theme theme) {
      return theme.getName().equals(ThemeManager.getString()) ? "Current" : null;
   }

   private static void updateStateForModuleBrowser(ModuleBrowser moduleBrowser, Module module2) {
      moduleBrowser.updateStateForModuleCategory(module2.getCategory());
      moduleBrowser.updateStateForModule(module2);
   }

   private CommandPaletteCommands() {
   }

   private static void accept(Consumer consumer, ClickGuiTab clickGuiTab) {
      consumer.accept(clickGuiTab);
   }

   private static void select(Theme theme) {
      ClickGuiTabAccess.getThemeSetting().select(theme.getName());
   }

   private static String computeStringForModule(Module module) {
      String string = module.getKeybind() == null ? null : KeybindCapture.computeString(module.getKeybind().getKeyCode());
      String string2 = module.isEnabled() ? "On" : "Off";
      return string == null ? string2 : string2 + "  ·  " + string;
   }

   private static void updateStateForModuleBrowser2(ModuleBrowser moduleBrowser, ModuleCategory moduleCategory) {
      moduleBrowser.updateStateForModuleCategory(moduleCategory);
   }

   static List computeListForModuleBrowser(ModuleBrowser moduleBrowser, Consumer consumer) {
      ArrayList arrayList = new ArrayList();

      for (ClickGuiTab clickGuiTab : ClickGuiTab.values()) {
         arrayList.add(new PaletteCommand("tool." + clickGuiTab.name(), "Tool", ClickGuiTabAccess.getLabel(clickGuiTab), () -> getDetail(clickGuiTab), ClickGuiTabAccess.getIcon(clickGuiTab), ClickGuiTabAccess.getKeywords(clickGuiTab), () -> accept(consumer, clickGuiTab), false, null));
      }

      for (ModuleCategory moduleCategory : (java.lang.Iterable<ModuleCategory>)(java.lang.Iterable<?>)(ModuleBrowser.computeList2())) {
         for (Module module2 : (java.lang.Iterable<Module>)(java.lang.Iterable<?>)(ModuleBrowser.computeListForModuleCategory(moduleCategory))) {
            arrayList.add(
               new PaletteCommand(
                  "module." + module2.getName(),
                  moduleCategory.getName(),
                  module2.getName(),
                  () -> computeStringForModule(module2),
                  Icon.BOLT,
                  module2.getDescription(),
                  () -> module2.toggle(),
                  true,
                  () -> module2.isEnabled(),
                  () -> updateStateForModuleBrowser(moduleBrowser, module2)
               )
            );
         }
      }

      for (ModuleCategory moduleCategory2 : (java.lang.Iterable<ModuleCategory>)(java.lang.Iterable<?>)(ModuleBrowser.computeList2())) {
         arrayList.add(new PaletteCommand("category." + moduleCategory2.name(), "Go to", moduleCategory2.getName(), null, Icon.GRID, "category " + moduleCategory2.getName(), () -> updateStateForModuleBrowser2(moduleBrowser, moduleCategory2), false, null));
      }

      for (Theme theme : (java.lang.Iterable<Theme>)(java.lang.Iterable<?>)(ThemeManager.unmodifiableList())) {
         arrayList.add(
            new PaletteCommand(
               "theme." + theme.getName(),
               "Theme",
               theme.getName(),
               () -> computeStringForTheme(theme),
               Icon.PALETTE,
               "theme palette colour " + theme.getName(),
               () -> select(theme),
               true,
               () -> equals(theme)
            )
         );
      }

      return arrayList;
   }

   private static boolean equals(Theme theme) {
      return theme.getName().equals(ThemeManager.getString());
   }

   private static String getDetail(ClickGuiTab clickGuiTab) {
      return ClickGuiTabAccess.getDetail(clickGuiTab);
   }
}
