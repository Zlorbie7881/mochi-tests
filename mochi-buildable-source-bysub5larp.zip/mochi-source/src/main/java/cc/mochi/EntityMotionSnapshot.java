package cc.mochi;

import net.minecraft.util.math.Vec3d;

public record EntityMotionSnapshot(int id, Vec3d position, Vec3d velocity) {
   public static Vec3d getPosition(EntityMotionSnapshot entityMotionSnapshot) {
      return entityMotionSnapshot.position;
   }

   public Vec3d getVelocity() {
      return this.velocity;
   }

   public Vec3d getPosition2() {
      return getPosition(this);
   }

   public int getId() {
      return this.id;
   }
}
