package cc.mochi;

public interface AttackInputBlocker {
   boolean shouldBlockAttackInput();
}
