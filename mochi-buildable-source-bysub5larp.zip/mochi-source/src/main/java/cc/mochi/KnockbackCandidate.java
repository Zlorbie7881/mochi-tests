package cc.mochi;

import net.minecraft.util.math.Vec3d;

public record KnockbackCandidate(float yaw, HazardVolume hazard, Vec3d contact, int ticks, double score) {
   public float getYaw() {
      return this.yaw;
   }

   public HazardVolume getHazard2() {
      return getHazard(this);
   }

   public Vec3d getContact2() {
      return getContact(this);
   }

   public int getTicks() {
      return this.ticks;
   }

   public double getScore() {
      return this.score;
   }

   public static Vec3d getContact(KnockbackCandidate knockbackCandidate) {
      return knockbackCandidate.contact;
   }

   public static HazardVolume getHazard(KnockbackCandidate knockbackCandidate) {
      return knockbackCandidate.hazard;
   }
}
