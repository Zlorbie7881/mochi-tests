package cc.mochi;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL33;

public final class GlassPanelRenderer {
   private static final GlFramebufferTarget glFramebufferTarget = new GlFramebufferTarget();
   private static boolean booleanState;
   private static final List<GlassPanelUniforms> glassPanelUniformsList = new ArrayList<>();
   private static int intState = -1;
   private static boolean booleanState2;

   private static int intState2 = -1;

   private static float floatState = 18.0F;

   private static float floatState2 = 10.0F;
   private static boolean booleanState3 = true;

   private static int intState3;

   private static int intState4;

   private static float floatState3 = ((-1.0F));

   private static float floatState4 = ((-1.0F));

   private static float floatState5 = 1.0F;

   private static boolean booleanState4;

   private static boolean booleanState5;
   private static float floatState6 = 1.0F;

   private static boolean booleanState6;

   private GlassPanelRenderer() {
   }

   private static void updateState() {
      if (intState3 != 0 && GL30.glIsFramebuffer(intState3)) {
         GL30.glDeleteFramebuffers(intState3);
      }

      if (intState4 != 0 && GL11.glIsTexture(intState4)) {
         GL11.glDeleteTextures(intState4);
      }

      intState3 = 0;
      intState4 = 0;
      intState = -1;
      intState2 = -1;
   }

   private static void updateState2(String string) {
      booleanState4 = true;
      if (!booleanState5) {
         booleanState5 = true;
      }
   }

   private static boolean checkCondition() {
      if (booleanState4) {
         return false;
      } else {
         Integer integer = ShaderProgramCache.get("glass_panel");
         if (integer == null || integer == 0 || !GL20.glIsProgram(integer)) {
            integer = ShaderProgramCache.loadProgram("glass_panel", "shaders/glass/glass.vsh", "shaders/glass/panel.fsh");
         }

         if (integer == 0) {
            updateState2("GlassLayer: shader initialization failed");
            return false;
         } else if (glFramebufferTarget.isValid()) {
            return true;
         } else {
            OpenGlStateSnapshot openGlStateSnapshot = OpenGlStateSnapshot.capture();

            try {
               if (!glFramebufferTarget.ensureInitialized()) {
                  updateState2("GlassLayer: full-screen geometry initialization failed");
                  return false;
               }
            } finally {
               openGlStateSnapshot.restore();
            }

            return true;
         }
      }
   }

   public static boolean testGlassPanelStyle(GlassPanelStyle glassPanelStyle, float floatValue, float floatValue2) {
      if (!booleanState6 || !checkCondition2() || glassPanelStyle == null || glassPanelStyle.getWidth() <= 0.0F || glassPanelStyle.getHeight() <= 0.0F || floatValue <= 0.0F || floatValue2 <= 0.0F) {
         return false;
      } else if (!checkCondition3()) {
         return false;
      } else {
         MinecraftClient minecraftClient = MinecraftClient.getInstance();
         Framebuffer framebuffer = minecraftClient == null ? null : minecraftClient.getFramebuffer();
         if (framebuffer == null || framebuffer.textureWidth <= 0 || framebuffer.textureHeight <= 0) {
            return false;
         } else if (!checkCondition4(framebuffer.textureWidth, framebuffer.textureHeight)) {
            return false;
         } else {
            floatState5 = (float)intState / floatValue;
            floatState6 = (float)intState2 / floatValue2;
            float floatValue3 = glassPanelStyle.getX() * floatState5;
            float floatValue4 = glassPanelStyle.getWidth() * floatState5;
            float floatValue5 = glassPanelStyle.getHeight() * floatState6;
            float floatValue6 = (float)intState2 - (glassPanelStyle.getY() + glassPanelStyle.getHeight()) * floatState6;
            float floatValue7 = glassPanelStyle.getUnitScale() * Math.min(floatState5, floatState6);
            glassPanelUniformsList.add(
               new GlassPanelUniforms(floatValue3, floatValue6, floatValue4, floatValue5, glassPanelStyle.getRadius() * Math.min(floatState5, floatState6), floatValue7, computeFloatArrayForColor(glassPanelStyle.getTint(), glassPanelStyle.getTintMix()), computeFloatArrayForColor2(glassPanelStyle.getRim()), glassPanelStyle.getHoverStrength(), Math.max(0.0F, glassPanelStyle.getBrightness()))
            );
            return true;
         }
      }
   }

   public static int computeInt() {
      return intState4 != 0 && GL11.glIsTexture(intState4) ? intState4 : 0;
   }

   public static void updateState3(float floatState7, float floatState22, boolean booleanState32) {
      glassPanelUniformsList.clear();
      booleanState6 = true;
      booleanState = false;
      booleanState2 = false;
      floatState = floatState7;
      floatState2 = floatState22;
      booleanState3 = booleanState32;
      floatState3 = ((-1.0F));
      floatState4 = ((-1.0F));
   }

   public static void updateState4() {
      if (booleanState6) {
         updateState6();
      }
   }

   public static boolean getBooleanState6() {
      return booleanState6;
   }

   public static boolean checkCondition2() {
      return !booleanState4 && GlassBackdropRenderer.isNotBooleanState2();
   }

   public static int getIntState() {
      return intState;
   }

   public static void updateState5() {
      if (booleanState6) {
         booleanState6 = false;
         updateState6();
      }
   }

   private static float[] computeFloatArrayForColor(Color color, float floatValue) {
      Color color2 = color == null ? Color.BLACK : color;
      return new float[]{(float)color2.getRed() / 255.0F, (float)color2.getGreen() / 255.0F, (float)color2.getBlue() / 255.0F, Math.max(0.0F, Math.min(1.0F, floatValue))};
   }

   private static void updateState6() {
      if (!glassPanelUniformsList.isEmpty() && booleanState2) {
         RenderSystem.assertOnRenderThread();
         int intValue = GlassBackdropRenderer.computeInt();
         if (intValue != 0 && checkCondition() && computeInt() != 0) {
            OpenGlStateSnapshot openGlStateSnapshot = OpenGlStateSnapshot.capture();

            try {
               GL11.glDisable(GL11.GL_BLEND);
               GL11.glDisable(GL11.GL_DEPTH_TEST);
               GL11.glDepthMask(false);
               GL11.glDisable(GL11.GL_CULL_FACE);
               GL11.glDisable(GL11.GL_STENCIL_TEST);
               GL11.glColorMask(true, true, true, true);
               GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, intState3);
               GL11.glViewport(0, 0, intState, intState2);
               GL11.glDisable(GL11.GL_SCISSOR_TEST);
               GL11.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
               GL11.glClear(16384);
               GL13.glActiveTexture(GL13.GL_TEXTURE0);
               GL11.glBindTexture(GL11.GL_TEXTURE_2D, intValue);
               GL33.glBindSampler(0, 0);
               ShaderProgramCache.bind("glass_panel");
               ShaderProgramCache.uniform1i("glass_panel", "u_backdrop", 0);
               ShaderProgramCache.uniform2f("glass_panel", "u_resolution", (float)intState, (float)intState2);
               ShaderProgramCache.uniform1f("glass_panel", "u_refraction", floatState2);
               boolean booleanValue = booleanState3 && floatState3 >= 0.0F && floatState4 >= 0.0F;
               ShaderProgramCache.uniform2f("glass_panel", "u_mouse", booleanValue ? floatState3 * floatState5 : ((-1.0F)), booleanValue ? (float)intState2 - floatState4 * floatState6 : ((-1.0F)));
               GL11.glEnable(GL11.GL_SCISSOR_TEST);

               for (GlassPanelUniforms glassPanelUniforms : glassPanelUniformsList) {
                  int intValue2 = (int)Math.floor((double)glassPanelUniforms.getX()) - 2;
                  int intValue3 = (int)Math.floor((double)glassPanelUniforms.getY()) - 2;
                  int intValue4 = (int)Math.ceil((double)glassPanelUniforms.getWidth()) + 4;
                  int intValue5 = (int)Math.ceil((double)glassPanelUniforms.getHeight()) + 4;
                  GL11.glScissor(Math.max(0, intValue2), Math.max(0, intValue3), Math.max(1, intValue4), Math.max(1, intValue5));
                  ShaderProgramCache.uniform4f("glass_panel", "u_rect", glassPanelUniforms.getX(), glassPanelUniforms.getY(), glassPanelUniforms.getWidth(), glassPanelUniforms.getHeight());
                  ShaderProgramCache.uniform1f("glass_panel", "u_radius", glassPanelUniforms.getRadius());
                  ShaderProgramCache.uniform1f("glass_panel", "u_unit", glassPanelUniforms.getUnit());
                  ShaderProgramCache.uniform4f("glass_panel", "u_tint", glassPanelUniforms.getTint()[0], glassPanelUniforms.getTint()[1], glassPanelUniforms.getTint()[2], glassPanelUniforms.getTint()[3]);
                  ShaderProgramCache.uniform3f("glass_panel", "u_rim", glassPanelUniforms.getRim()[0], glassPanelUniforms.getRim()[1], glassPanelUniforms.getRim()[2]);
                  ShaderProgramCache.uniform1f("glass_panel", "u_brightness", glassPanelUniforms.getBrightness());
                  ShaderProgramCache.uniform1f("glass_panel", "u_hoverRadius", 90.0F * glassPanelUniforms.getUnit());
                  ShaderProgramCache.uniform1f("glass_panel", "u_hoverStrength", booleanValue ? glassPanelUniforms.getHover() : 0.0F);
                  glFramebufferTarget.draw();
               }
            } catch (RuntimeException failure) {
               updateState2("GlassLayer: disabled after an OpenGL failure: " + failure.getMessage());
            } finally {
               openGlStateSnapshot.restore();
               glassPanelUniformsList.clear();
            }
         } else {
            glassPanelUniformsList.clear();
         }
      } else {
         glassPanelUniformsList.clear();
      }
   }

   public static int getIntState2() {
      return intState2;
   }

   public static boolean checkCondition3() {
      if (!booleanState6) {
         return false;
      } else {
         if (!booleanState) {
            booleanState = true;
            booleanState2 = GlassBackdropRenderer.checkCondition(floatState);
         }

         return booleanState2;
      }
   }

   private static float[] computeFloatArrayForColor2(Color color) {
      Color color2 = color == null ? Color.WHITE : color;
      return new float[]{(float)color2.getRed() / 255.0F, (float)color2.getGreen() / 255.0F, (float)color2.getBlue() / 255.0F};
   }

   public static void updateState7(float floatState32, float floatState42) {
      floatState3 = floatState32;
      floatState4 = floatState42;
   }

   private static boolean checkCondition4(int intState5, int intState22) {
      if (intState3 != 0 && intState == intState5 && intState2 == intState22 && GL30.glIsFramebuffer(intState3) && GL11.glIsTexture(intState4)) {
         return true;
      } else {
         OpenGlStateSnapshot openGlStateSnapshot = OpenGlStateSnapshot.capture();

         try {
            updateState();
            intState4 = GL11.glGenTextures();
            intState3 = GL30.glGenFramebuffers();
            if (intState4 == 0 || intState3 == 0) {
               updateState();
               updateState2("GlassLayer: layer framebuffer creation failed");
               return false;
            }

            GL13.glActiveTexture(GL13.GL_TEXTURE0);
            GL11.glBindTexture(GL11.GL_TEXTURE_2D, intState4);
            GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA8, intState5, intState22, 0, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, 0L);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, org.lwjgl.opengl.GL12.GL_CLAMP_TO_EDGE);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, org.lwjgl.opengl.GL12.GL_CLAMP_TO_EDGE);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, org.lwjgl.opengl.GL12.GL_TEXTURE_BASE_LEVEL, 0);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, org.lwjgl.opengl.GL12.GL_TEXTURE_MAX_LEVEL, 0);
            GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, intState3);
            GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, intState4, 0);
            GL11.glDrawBuffer(36064);
            if (GL30.glCheckFramebufferStatus(GL30.GL_FRAMEBUFFER) == 36053) {
               intState = intState5;
               intState2 = intState22;
               return true;
            }

            updateState();
            updateState2("GlassLayer: layer framebuffer is incomplete");
         } finally {
            openGlStateSnapshot.restore();
         }

         return false;
      }
   }

   public static void updateState8() {
      RenderSystem.assertOnRenderThread();
      updateState();
      glFramebufferTarget.destroy();
      ShaderProgramCache.deleteProgram("glass_panel");
      GlassBackdropRenderer.updateState3();
      glassPanelUniformsList.clear();
      booleanState6 = false;
      booleanState4 = false;
      booleanState5 = false;
   }
}
