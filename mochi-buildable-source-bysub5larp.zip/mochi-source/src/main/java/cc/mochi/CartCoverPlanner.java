package cc.mochi;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.SlabBlock;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public final class CartCoverPlanner {
   private static boolean testWorld(World world, Vec3d vec3d, Entity entity, Vec3d vec3d2) {
      return (world.raycast(new RaycastContext(vec3d2, vec3d, ShapeType.COLLIDER, FluidHandling.NONE, entity)).getType() == BlockShapeAccess.getMISS());
   }

   static List computeListForBox(Box box) {
      double lengthX = box.getLengthX();

      double doubleValue = (1.0) / (lengthX * (2.0) + 1.0);
      double doubleValue2 = box.getLengthY() * 2.0;

      double doubleValue3 = 1.0 / (doubleValue2 + (1.0));
      double doubleValue4 = box.getLengthZ() * 2.0;

      double doubleValue5 = 1.0 / (doubleValue4 + (1.0));

      double doubleValue6 = ((1.0) - Math.floor((1.0) / doubleValue) * doubleValue) / 2.0;

      double doubleValue7 = 1.0 - Math.floor((1.0) / doubleValue5) * doubleValue5;

      double doubleValue8 = doubleValue7 / (2.0);
      ArrayList arrayList = new ArrayList();

      for (double doubleValue9 = (0.0); doubleValue9 <= 1.0; doubleValue9 += doubleValue) {
         double doubleValue10 = (0.0);

         while (true) {
            if (!(doubleValue10 <= (1.0))) {
               break;
            }

            ThreadLocalRandom.current().nextInt(17);

            double doubleValue11 = 0.0;

            while (doubleValue11 <= 1.0) {
               arrayList.add(
                  new Vec3d(
                     BlockShapeAccess.getMinX(box) + doubleValue9 * box.getLengthX() + doubleValue6, BlockShapeAccess.getMinY(box) + doubleValue10 * box.getLengthY(), BlockShapeAccess.getMinZ(box) + doubleValue11 * box.getLengthZ() + doubleValue8
                  )
               );
               doubleValue11 += doubleValue5;
            }

            doubleValue10 += doubleValue3;
         }
      }

      ThreadLocalRandom.current().nextInt(5);

      return List.copyOf(arrayList);
   }

   private static BlockState computeBlockStateForWorld(World world, ClientPlayerEntity clientPlayerEntity, BlockPos blockPos, ItemStack itemStack, BlockHitResult blockHitResult) {
      if (itemStack.getItem() instanceof BlockItem var5 && blockHitResult != null && blockHitResult.getType() == Type.BLOCK) {
         ItemPlacementContext itemPlacementContext = new ItemPlacementContext(clientPlayerEntity, Hand.MAIN_HAND, itemStack, blockHitResult);
         BlockState blockState = world.getBlockState(blockHitResult.getBlockPos());
         if (itemPlacementContext.getBlockPos().equals(blockPos)) {
            if (itemPlacementContext.canPlace() && !blockState.hasBlockEntity()) {
               if (!testBlockState(blockState) && world.getBlockState(blockPos).canReplace(itemPlacementContext)) {
                  if (world.getFluidState(blockPos).isEmpty()) {
                     BlockState placementState = var5.getBlock().getPlacementState(itemPlacementContext);
                     if (placementState != null) {
                        if (placementState.canPlaceAt(world, blockPos)) {
                           if (world.canPlace(placementState, blockPos, ShapeContext.of(clientPlayerEntity))) {
                              ThreadLocalRandom.current().nextInt(10);
                              return placementState;
                           }
                        }
                     }

                     return null;
                  }
               }
            }
         }

         return null;
      }

      return null;
   }

   public static boolean testItemStack(ItemStack itemStack) {
      if (!itemStack.isEmpty() && itemStack.getItem() instanceof BlockItem) {
         if (!itemStack.isIn(ItemTags.PLANKS)) {
            ThreadLocalRandom.current().nextInt(16);

            if (!itemStack.isIn(ItemTags.LOGS)) {
               if (!itemStack.isIn(BlockShapeAccess.getWOODEN_SLABS())) {
                  return false;
               }
            }
         }

         return true;
      } else {
         return false;
      }
   }

   private static List toList(World world, BlockPos blockPos, BlockState blockState) {
      return blockState.getCollisionShape(world, blockPos).getBoundingBoxes().stream().map(box -> offset(blockPos, (Box)box)).toList();
   }

   private CartCoverPlanner() {
   }

   private static boolean noneMatch(List list, Vec3d vec3d, Vec3d vec3d2) {
      return list.stream().noneMatch(objectValue -> testVec3d(vec3d2, vec3d, (Box)objectValue));
   }

   public static boolean testWorld2(World world, ClientPlayerEntity clientPlayerEntity, CoverPlacementPlan coverPlacementPlan, BlockHitResult blockHitResult) {
      byte byteValue;
      if (computeBlockStateForWorld(world, clientPlayerEntity, coverPlacementPlan.getCell(), coverPlacementPlan.getItem2().getDefaultStack(), blockHitResult) == coverPlacementPlan.getState()) {
         byteValue = 17;
         ThreadLocalRandom.current().nextInt(11);

         byteValue = 1;
      } else {
         byteValue = 0;
      }

      return (byteValue != 0);
   }

   public static boolean testBlockHitResult(BlockHitResult blockHitResult, CoverPlacementPlan coverPlacementPlan) {
      if (coverPlacementPlan != null) {
         if (blockHitResult != null) {
            if (blockHitResult.getType() == BlockShapeAccess.getBLOCK()) {
               if (blockHitResult.getBlockPos().equals(coverPlacementPlan.getSupport2())) {
                  if (blockHitResult.getSide() == coverPlacementPlan.getFace()) {
                     ThreadLocalRandom.current().nextInt(14);

                     if (coverPlacementPlan.getCell().equals(BlockInteractUtils.computeBlockPosForBlockHitResult(blockHitResult))) {
                        return true;
                     }
                  } else {
                     ThreadLocalRandom.current().nextInt(6);
                  }
               }
            }
         } else {
            ThreadLocalRandom.current().nextInt(7);
         }
      }

      return false;
   }

   private static boolean testWorld3(World world, ClientPlayerEntity clientPlayerEntity, CartInterceptPlan cartInterceptPlan, BlockPos blockPos, BlockState blockState, List list) {
      if (testWorld5(world, cartInterceptPlan, blockPos)) {
         if (!list.isEmpty()) {
            Box box = ProjectileAimPlanner.computeBoxForBlockPos(cartInterceptPlan.getRail2());
            Iterator iterator = list.iterator();

            while (true) {
               if (!iterator.hasNext()) {
                  if (blockState.canPlaceAt(world, blockPos)) {
                     if (world.canPlace(blockState, blockPos, ShapeContext.of(clientPlayerEntity))) {
                        if (!testList2(cartInterceptPlan.getPath(), cartInterceptPlan.getIntercept2(), list, cartInterceptPlan.getPlaceOffset2())) {
                           return true;
                        }

                        ThreadLocalRandom.current().nextInt(17);
                     }
                  }

                  return false;
               }

               Box box2 = (Box)iterator.next();
               if (box2.intersects(box) || box2.intersects(cartInterceptPlan.getServerBox2())) {
                  break;
               }

               if (box2.intersects(cartInterceptPlan.getPlaceBox2()) || box2.intersects(cartInterceptPlan.getExposedBox2())) {
                  break;
               }
            }

            return false;
         }
      }

      return false;
   }

   static double computeDoubleForList(List list, int intValue, Vec3d vec3d, List list2) {
      long longValue = list.stream().filter(objectValue -> noneMatch(list2, vec3d, (Vec3d)objectValue)).count();
      return (double)longValue / (double)intValue;
   }

   static boolean testList(List list, int intValue, Box box, int intValue2) {
      return testList2(list, intValue, List.of(box), intValue2);
   }

   public static double computeDoubleForWorld(World world, Entity entity, Vec3d vec3d, Box box) {
      List list = computeListForBox(box);
      return (double)toList2(world, entity, vec3d, list).size() / (double)list.size();
   }

   public static CoverPlacementPlan computeCoverPlacementPlanForWorld(World world, ClientPlayerEntity clientPlayerEntity, CoverPlacementPlan coverPlacementPlan, Vec3d vec3d, float floatValue) {
      BlockAim blockAim = ProjectileAimPlanner.computeBlockAimForWorld(world, clientPlayerEntity, vec3d, coverPlacementPlan.getSupport2(), coverPlacementPlan.getFace(), coverPlacementPlan.getCell(), floatValue, objectValue -> testWorld4(world, clientPlayerEntity, coverPlacementPlan, (BlockHitResult)objectValue));
      if (blockAim == null) {
         return null;
      } else {
         ThreadLocalRandom.current().nextInt(9);

         return new CoverPlacementPlan(coverPlacementPlan.getCell(), coverPlacementPlan.getSupport2(), coverPlacementPlan.getFace(), blockAim.getPoint2(), blockAim.getYaw2(), blockAim.getPitch2(), coverPlacementPlan.getItem2(), coverPlacementPlan.getState(), coverPlacementPlan.getCollision2(), coverPlacementPlan.getExposureBefore(), coverPlacementPlan.getExposureAfter2());
      }
   }

   static boolean testList2(List list, int intValue, List list2, int intValue2) {
      int intValue3 = Math.max(1, intValue2 + 1);

      label48:
      while (intValue3 <= intValue) {
         if (intValue3 < list.size()) {
            Iterator iterator = list2.iterator();

            Box box;
            do {
               if (!iterator.hasNext()) {
                  intValue3++;

                  continue label48;
               }

               box = (Box)iterator.next();
               if (box.contains((Vec3d)list.get(intValue3 - 1))) {
                  break;
               }
            } while (!box.raycast((Vec3d)list.get(intValue3 - 1), (Vec3d)list.get(intValue3)).isPresent());

            return true;
         }

         break;
      }

      return false;
   }

   private static boolean testWorld4(World world, ClientPlayerEntity clientPlayerEntity, CoverPlacementPlan coverPlacementPlan, BlockHitResult blockHitResult) {
      return testWorld2(world, clientPlayerEntity, coverPlacementPlan, blockHitResult);
   }

   public static CoverPlacementPlan computeCoverPlacementPlanForWorld2(World world, ClientPlayerEntity clientPlayerEntity, CartInterceptPlan cartInterceptPlan, float floatValue, List list) {
      if (cartInterceptPlan.getIntercept2() >= 1) {
         if (!list.isEmpty()) {
            Vec3d vec3d = cartInterceptPlan.computeVec3d();
            List list2 = computeListForBox(cartInterceptPlan.getExposedBox2());
            List list3 = toList2(world, clientPlayerEntity, vec3d, list2);
            List list4 = computeListForBox(cartInterceptPlan.getPlaceBox2());
            List list5 = toList2(world, clientPlayerEntity, vec3d, list4);
            double doubleValue = (double)list3.size() / (double)list2.size();
            if (doubleValue <= 0.0) {
               return null;
            }

            double doubleValue2 = (double)list5.size() / (double)list4.size();
            ArrayList arrayList = new ArrayList();
            Box exposedBox2 = cartInterceptPlan.getExposedBox2();
            double x = BlockShapeAccess.getX(exposedBox2.getCenter());
            double minY = BlockShapeAccess.getMinY(exposedBox2);

            BlockPos blockPos = BlockPos.ofFloored(x, minY + (0.001), exposedBox2.getCenter().z);
            int intValue = -2;

            do {
               int intValue2 = -2;

               do {
                  int intValue3 = -1;

                  do {
                     BlockPos blockPos2 = blockPos.add(intValue, intValue3, intValue2);
                     if (testBox(exposedBox2, vec3d, blockPos2) && testWorld5(world, cartInterceptPlan, blockPos2)) {
                        HashMap hashMap = new HashMap();

                        for (ItemStack itemStack : (java.lang.Iterable<ItemStack>)(java.lang.Iterable<?>)(list)) {
                           if (testItemStack(itemStack)) {
                              BlockState defaultState = ((BlockItem)itemStack.getItem()).getBlock().getDefaultState();

                              for (BlockState blockState : defaultState.getBlock() instanceof SlabBlock
                                 ? List.of((BlockState)defaultState.with(SlabBlock.TYPE, BlockShapeAccess.getBOTTOM()), (BlockState)defaultState.with(SlabBlock.TYPE, BlockShapeAccess.getTOP()))
                                 : List.of(defaultState)) {
                                 List list6 = toList(world, blockPos2, blockState);
                                 if (testWorld3(world, clientPlayerEntity, cartInterceptPlan, blockPos2, blockState, list6)) {
                                    ExposureScore exposureScore = (ExposureScore)(hashMap.computeIfAbsent(list6, objectValue -> computeExposureScoreForList(list3, list2, vec3d, doubleValue, list5, list4, doubleValue2, (List)objectValue)));
                                    if (Double.isFinite(exposureScore.getScore())) {
                                       arrayList.add(new CoverPlacementScore(blockPos2, itemStack, list6, exposureScore.getAfter2(), exposureScore.getScore(), exposedBox2.getCenter().squaredDistanceTo(blockPos2.toCenterPos())));
                                    }
                                 }
                              }
                           }
                        }
                     }

                     intValue3++;
                  } while (intValue3 <= 2);

                  intValue2++;
               } while (intValue2 <= 2);
            } while (++intValue <= 2);

            arrayList.sort(Comparator.<Object>comparingDouble(objectValue2 -> ((CoverPlacementScore)objectValue2).getScore()).thenComparingDouble(objectValue3 -> ((CoverPlacementScore)objectValue3).getDistance()));

            for (CoverPlacementScore coverPlacementScore : (java.lang.Iterable<CoverPlacementScore>)(java.lang.Iterable<?>)(arrayList)) {
               CoverPlacementPlan coverPlacementPlan = computeCoverPlacementPlanForWorld3(world, clientPlayerEntity, cartInterceptPlan, coverPlacementScore.getCell(), coverPlacementScore.getStack(), coverPlacementScore.getCollision(), doubleValue, coverPlacementScore.getAfter2(), floatValue);
               if (coverPlacementPlan != null) {
                  return coverPlacementPlan;
               }
            }

            return null;
         }
      }

      return null;
   }

   static List toList2(World world, Entity entity, Vec3d vec3d, List list) {
      return list.stream().filter(objectValue -> testWorld(world, vec3d, entity, (Vec3d)objectValue)).toList();
   }

   private static boolean testWorld5(World world, CartInterceptPlan cartInterceptPlan, BlockPos blockPos) {
      if (!blockPos.equals(cartInterceptPlan.getRail2())) {
         ThreadLocalRandom.current().nextInt(6);
         if (world.isChunkLoaded(blockPos)) {
            if (world.getWorldBorder().contains(blockPos)) {
               if (world.getBlockState(blockPos).isReplaceable() && world.getFluidState(blockPos).isEmpty()) {
                  return true;
               }
            }
         }
      }

      ThreadLocalRandom.current().nextInt(13);
      return false;
   }

   private static boolean testWorld6(World world, ClientPlayerEntity clientPlayerEntity, BlockPos blockPos, ItemStack itemStack, List list, BlockHitResult blockHitResult) {
      BlockState blockState = computeBlockStateForWorld(world, clientPlayerEntity, blockPos, itemStack, blockHitResult);
      if (blockState != null) {
         if (toList(world, blockPos, blockState).equals(list)) {
            return true;
         }
      }

      return false;
   }

   public static boolean testWorld7(World world, ClientPlayerEntity clientPlayerEntity, CartInterceptPlan cartInterceptPlan, CoverPlacementPlan coverPlacementPlan) {
      if (coverPlacementPlan != null) {
         if (cartInterceptPlan.getIntercept2() >= 1) {
            if (testWorld3(world, clientPlayerEntity, cartInterceptPlan, coverPlacementPlan.getCell(), coverPlacementPlan.getState(), coverPlacementPlan.getCollision2())) {
               Vec3d vec3d = cartInterceptPlan.computeVec3d();
               List list = computeListForBox(cartInterceptPlan.getExposedBox2());
               List list2 = toList2(world, clientPlayerEntity, vec3d, list);
               if (!list2.isEmpty()) {
                  if (computeDoubleForList(list2, list.size(), vec3d, coverPlacementPlan.getCollision2()) < (double)list2.size() / (double)list.size()) {
                     return true;
                  }

                  ThreadLocalRandom.current().nextInt(16);
               }

               return false;
            }
         }
      }

      return false;
   }

   private static boolean testVec3d(Vec3d vec3d, Vec3d vec3d2, Box box) {
      if (!box.contains(vec3d)) {
         if (!box.contains(vec3d2)) {
            ThreadLocalRandom.current().nextInt(5);
            if (!box.raycast(vec3d, vec3d2).isPresent()) {
               return false;
            }
         }
      }

      return true;
   }

   static boolean testBox(Box box, Vec3d vec3d, BlockPos blockPos) {
      Vec3d center = box.getCenter();
      double doubleValue = vec3d.x - center.x;
      double doubleValue2 = vec3d.z - BlockShapeAccess.getZ(center);
      double x = (double)blockPos.getX();

      double doubleValue3 = x + (0.5) - center.x;
      double doubleValue4 = (double)blockPos.getZ() + 0.5 - center.z;
      double doubleValue5 = Math.sqrt(doubleValue * doubleValue + doubleValue2 * doubleValue2);
      if (doubleValue5 < 0.1) {
         return true;
      } else {
         return (((doubleValue3 * doubleValue + doubleValue4 * doubleValue2) / doubleValue5 > ((-0.25)) ? 1 : 0) != 0);
      }
   }

   private static Box offset(BlockPos blockPos, Box box) {
      return box.offset(blockPos);
   }

   static double computeDoubleForList2(List list, int intValue, Vec3d vec3d, Box box) {
      return computeDoubleForList(list, intValue, vec3d, List.of(box));
   }

   static boolean testBlockState(BlockState blockState) {
      if (!blockState.isIn(BlockShapeAccess.getDOORS())) {
         if (!blockState.isIn(BlockShapeAccess.getTRAPDOORS())) {
            if (!blockState.isIn(BlockShapeAccess.getFENCE_GATES())) {
               if (!blockState.isIn(BlockShapeAccess.getRAILS()) && !blockState.isOf(BlockShapeAccess.getCRAFTING_TABLE())) {
                  if (!blockState.isOf(BlockShapeAccess.getSMITHING_TABLE())) {
                     if (!blockState.isOf(Blocks.CARTOGRAPHY_TABLE)) {
                        if (!blockState.isOf(Blocks.LOOM)) {
                           ThreadLocalRandom.current().nextInt(7);
                           if (!blockState.isOf(BlockShapeAccess.getSTONECUTTER()) && !blockState.isOf(Blocks.GRINDSTONE)) {
                              if (!blockState.isOf(Blocks.ANVIL)
                                 && !blockState.isOf(Blocks.CHIPPED_ANVIL)
                                 && !blockState.isOf(BlockShapeAccess.getDAMAGED_ANVIL())
                                 && !blockState.isOf(Blocks.NOTE_BLOCK)
                                 && !blockState.isOf(BlockShapeAccess.getRESPAWN_ANCHOR())
                                 && !blockState.isOf(Blocks.DRAGON_EGG)) {
                                 return false;
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      return true;
   }

   private static CoverPlacementPlan computeCoverPlacementPlanForWorld3(World world, ClientPlayerEntity clientPlayerEntity, CartInterceptPlan cartInterceptPlan, BlockPos blockPos, ItemStack itemStack, List list, double doubleValue, double doubleValue2, float floatValue) {
      Direction[] directionArray = new Direction[6];

      directionArray[0] = BlockShapeAccess.getUP();
      directionArray[1] = Direction.NORTH;
      directionArray[2] = Direction.SOUTH;
      directionArray[3] = Direction.WEST;

      directionArray[4] = Direction.EAST;
      directionArray[5] = BlockShapeAccess.getDOWN();
      Direction[] directionArray2 = directionArray;
      int length = directionArray2.length;
      int intValue = 0;

      for (; intValue < length; intValue++) {
         ThreadLocalRandom.current().nextInt(11);
         Direction direction = directionArray2[intValue];
         BlockPos blockPos2 = blockPos.offset(direction.getOpposite());
         BlockState blockState = world.getBlockState(blockPos2);
         if (!blockState.isReplaceable()) {
            if (!blockState.hasBlockEntity()) {
               if (!testBlockState(blockState)) {
                  if (blockState.isSideSolidFullSquare(world, blockPos2, direction)) {
                     ThreadLocalRandom.current().nextInt(15);
                     BlockAim blockAim = ProjectileAimPlanner.computeBlockAimForWorld(world, clientPlayerEntity, cartInterceptPlan.getEye(), blockPos2, direction, blockPos, floatValue, objectValue -> testWorld6(world, clientPlayerEntity, blockPos, itemStack, list, (BlockHitResult)objectValue));
                     if (blockAim != null) {
                        BlockState blockState2 = computeBlockStateForWorld(world, clientPlayerEntity, blockPos, itemStack, blockAim.getHit());
                        return new CoverPlacementPlan(blockPos, blockPos2, direction, blockAim.getPoint2(), blockAim.getYaw2(), blockAim.getPitch2(), itemStack.getItem(), blockState2, list, doubleValue, doubleValue2);
                     }
                  }
               }
            }
         }
      }

      return null;
   }

   private static ExposureScore computeExposureScoreForList(List list, List list2, Vec3d vec3d, double doubleValue, List list3, List list4, double doubleValue2, List list5) {
      double doubleValue3 = computeDoubleForList(list, list2.size(), vec3d, list5);

      if (doubleValue3 >= doubleValue - (1.0E-9)) {
         return new ExposureScore(doubleValue3, (Double.POSITIVE_INFINITY));
      } else {
         double doubleValue4 = computeDoubleForList(list3, list4.size(), vec3d, list5);
         double doubleValue5 = doubleValue3 * 0.7;
         double doubleValue6 = Math.min(doubleValue4, doubleValue2);

         return new ExposureScore(doubleValue3, doubleValue5 + doubleValue6 * (0.3));
      }
   }
}
