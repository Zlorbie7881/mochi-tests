package cc.mochi;

public final class CriticalHitTiming {
   private CriticalHitTiming() {
   }

   public static AttackWaitState computeAttackWaitStateForCriticalHitState(CriticalHitState criticalHitState) {
      if (criticalHitState.getCritTiming2()) {
         if (criticalHitState.getInCritRange2()) {
            if (criticalHitState.checkCondition2()) {
               return AttackWaitState.SWING;
            }

            if (!criticalHitState.getAirborne2()) {
               if (criticalHitState.getJumpHeld()) {
         return AttackWaitState.WAIT;
      } else {
         return AttackWaitState.SWING;
      }
            }

            return criticalHitState.checkCondition() ? AttackWaitState.RELEASE_AND_WAIT : AttackWaitState.WAIT;
         }
      }

      return AttackWaitState.SWING;
   }
}
