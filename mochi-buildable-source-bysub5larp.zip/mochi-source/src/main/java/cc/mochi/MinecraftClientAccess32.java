package cc.mochi;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerAbilities;
import net.minecraft.fluid.Fluid;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Direction.AxisDirection;

public class MinecraftClientAccess32 {
   public static Item getBUCKET() {
      return Items.BUCKET;
   }

   public static Item getAIR() {
      return Items.AIR;
   }

   public static AxisDirection getPOSITIVE() {
      return AxisDirection.POSITIVE;
   }

   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static double getMaxZ(Box box) {
      return box.maxZ;
   }

   public static ClientWorld getWorld(MinecraftClient minecraftClient) {
      return minecraftClient.world;
   }

   public static GameOptions getOptions(MinecraftClient minecraftClient) {
      return minecraftClient.options;
   }

   public static TagKey<Fluid> getLAVA() {
      return FluidTags.LAVA;
   }

   public static ItemStack getEMPTY() {
      return ItemStack.EMPTY;
   }

   public static TagKey<Fluid> getWATER() {
      return FluidTags.WATER;
   }

   public static ClientPlayerInteractionManager getInteractionManager(MinecraftClient minecraftClient) {
      return minecraftClient.interactionManager;
   }

   public static boolean getAllowModifyWorld(PlayerAbilities playerAbilities) {
      return playerAbilities.allowModifyWorld;
   }

   public static Hand getMAIN_HAND() {
      return Hand.MAIN_HAND;
   }

   public static ActionPriority getLOW() {
      return ActionPriority.LOW;
   }

   public static Block getCOBWEB() {
      return Blocks.COBWEB;
   }

   public static Item getPUFFERFISH_BUCKET() {
      return Items.PUFFERFISH_BUCKET;
   }

   public static double getMaxY(Box box) {
      return box.maxY;
   }

   public static GameRenderer getGameRenderer(MinecraftClient minecraftClient) {
      return minecraftClient.gameRenderer;
   }

   public static double getMinX(Box box) {
      return box.minX;
   }

   public static double getMinZ(Box box) {
      return box.minZ;
   }

   public static Item getCOBWEB2() {
      return Items.COBWEB;
   }

   public static double getX(Vec3d vec3d) {
      return vec3d.x;
   }

   public static double getZ(Vec3d vec3d) {
      return vec3d.z;
   }

   public static Item getWATER_BUCKET() {
      return Items.WATER_BUCKET;
   }

   public static KeyBinding getAttackKey(GameOptions gameOptions) {
      return gameOptions.attackKey;
   }

   public static double getMinY(Box box) {
      return box.minY;
   }

}
