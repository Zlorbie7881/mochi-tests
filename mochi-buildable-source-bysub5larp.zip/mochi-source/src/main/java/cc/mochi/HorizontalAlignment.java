package cc.mochi;

public enum HorizontalAlignment {
   LEFT,
   CENTER,
   RIGHT;

   private static HorizontalAlignment[] createValues() {
      return new HorizontalAlignment[]{LEFT, CENTER, RIGHT};
   }
}
