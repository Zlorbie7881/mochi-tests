package cc.mochi;

import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public record AnchorPlacementCandidate(BlockPos cell, BlockHitResult supportHit, Vec3d aimPoint, boolean alreadyPlaced, double score) {
   public Vec3d getAimPoint() {
      return this.aimPoint;
   }

   public static BlockHitResult getSupportHit(AnchorPlacementCandidate anchorPlacementCandidate) {
      return anchorPlacementCandidate.supportHit;
   }

   public BlockPos getCell2() {
      return getCell(this);
   }

   public BlockHitResult getSupportHit2() {
      return getSupportHit(this);
   }

   public boolean getAlreadyPlaced() {
      return this.alreadyPlaced;
   }

   public static BlockPos getCell(AnchorPlacementCandidate anchorPlacementCandidate) {
      return anchorPlacementCandidate.cell;
   }

   public double getScore() {
      return this.score;
   }
}
