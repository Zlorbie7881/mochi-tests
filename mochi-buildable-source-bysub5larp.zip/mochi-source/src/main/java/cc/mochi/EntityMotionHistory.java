package cc.mochi;

import net.minecraft.util.math.Vec3d;

public final class EntityMotionHistory {
   public long timestampMillis;
   public int intState;

   public Vec3d vec3d;
   public double doubleState;

   public Vec3d vec3d2;
   public Vec3d vec3d3;
   public boolean booleanState;
   public double doubleState2;

   public Vec3d vec3d4;
   public double doubleState3;
   public Vec3d vec3d5;

   public Vec3d vec3d6;

   public int age = Integer.MIN_VALUE;

   public int intState2;

   public EntityMotionHistory() {
      this.vec3d = Vec3d.ZERO;
      this.vec3d4 = Vec3d.ZERO;
      this.vec3d2 = Vec3d.ZERO;
      this.vec3d6 = Vec3d.ZERO;
      this.intState2 = -1;
      this.timestampMillis = 0L;

      this.doubleState2 = (0.4);

      this.intState = -1;
      this.vec3d3 = Vec3d.ZERO;
      this.vec3d5 = Vec3d.ZERO;
      this.doubleState3 = 1.0;
   }
}
