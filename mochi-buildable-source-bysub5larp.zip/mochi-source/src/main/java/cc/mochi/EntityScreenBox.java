package cc.mochi;

import net.minecraft.entity.LivingEntity;

public record EntityScreenBox(LivingEntity entity, float[] box) {
   public float[] getBox() {
      return this.box;
   }

   public LivingEntity getEntity() {
      return this.entity;
   }
}
