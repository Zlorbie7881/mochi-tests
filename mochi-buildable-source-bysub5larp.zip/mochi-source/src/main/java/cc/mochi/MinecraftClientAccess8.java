package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Hand;
import net.minecraft.util.ActionResult.SwingSource;
import net.minecraft.util.hit.HitResult.Type;

public class MinecraftClientAccess8 {
   public static ClientWorld getWorld(MinecraftClient minecraftClient) {
      return minecraftClient.world;
   }

   public static Hand getOFF_HAND() {
      return Hand.OFF_HAND;
   }

   public static TagKey<Item> getHOES() {
      return ItemTags.HOES;
   }

   public static ClientPlayerInteractionManager getInteractionManager(MinecraftClient minecraftClient) {
      return minecraftClient.interactionManager;
   }

   public static Hand getMAIN_HAND() {
      return Hand.MAIN_HAND;
   }

   public static Screen getCurrentScreen(MinecraftClient minecraftClient) {
      return minecraftClient.currentScreen;
   }

   public static TagKey<Item> getSHOVELS() {
      return ItemTags.SHOVELS;
   }

   public static GameOptions getOptions(MinecraftClient minecraftClient) {
      return minecraftClient.options;
   }

   public static SwingSource getCLIENT() {
      return SwingSource.CLIENT;
   }

   public static KeyBinding getAttackKey(GameOptions gameOptions) {
      return gameOptions.attackKey;
   }

   public static Item getEND_CRYSTAL() {
      return Items.END_CRYSTAL;
   }

   public static Type getBLOCK() {
      return Type.BLOCK;
   }

   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static RegistryEntry<StatusEffect> getSTRENGTH() {
      return StatusEffects.STRENGTH;
   }

}
