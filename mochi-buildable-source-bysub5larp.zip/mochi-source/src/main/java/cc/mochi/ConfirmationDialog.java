package cc.mochi;

import java.util.List;

public final class ConfirmationDialog {
   private Runnable runnable;
   private String string;
   private long longState;

   private boolean booleanState;
   private String string2;
   private ControlTone controlTone = ControlTone.DANGER;
   private String string3;

   public static Runnable getRunnable(ConfirmationDialog confirmationDialog) {
      return confirmationDialog.runnable;
   }

   public static boolean getBooleanState(ConfirmationDialog confirmationDialog) {
      return confirmationDialog.booleanState;
   }

   public static long getLongState(ConfirmationDialog confirmationDialog) {
      return confirmationDialog.longState;
   }

   public boolean getBooleanState2() {
      return this.booleanState;
   }

   public void updateStateForControlTone(String string32, String string4, String string22, ControlTone controlTone2, Runnable runnable2) {
      this.string3 = string32;
      setString(this, string4);
      this.string2 = string22;
      this.controlTone = controlTone2;
      this.runnable = runnable2;
      this.booleanState = true;
      this.longState = getLongState(this) + 1L;
      ClientSounds.updateState5();
   }

   private static void updateState(int intValue, double doubleValue, double doubleValue2) {
   }

   public void updateStateForUiContext(UiContext uiContext, String string4, float floatValue, float floatValue2, float floatValue3) {
      String string5 = string4 + "." + this.longState;
      float floatValue4 = uiContext.getAnimations().exponential(string5, 0.0F, this.booleanState ? 1.0F : 0.0F, 0.05F);
      if (!(floatValue4 <= 0.01F)) {
         ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
         float floatValue5 = floatValue3 * floatValue4;
         uiContext.getUiRenderContext().flushBloom();
         PanelRenderer.updateStateForUiContext6(uiContext, floatValue, floatValue2, floatValue5);
         if (getBooleanState(this)) {
            uiContext.getInputRouter().addModalCatcher(UiLayer.MODAL, () -> this.updateState2());
         }

         List list = uiContext.wrapText(getString(this), TextStyle.BODY, 240.0F, 4);
         float height = 70.0F + (float)list.size() * 11.0F + 34.0F;
         Rect rect = Rect.centered(floatValue / 2.0F, floatValue2 / 2.0F + 6.0F * (1.0F - floatValue4), 280.0F, height);
         uiContext.getUiRenderContext().pushTransform();
         uiContext.getUiRenderContext().scaleAroundPoint(0.96F + 0.04F * floatValue4, rect.centerX(), rect.centerY());
         PanelRenderer.drawCard(uiContext, rect, floatValue5);
         if (getBooleanState(this)) {
            uiContext.getInputRouter().addPressRegion(rect, UiLayer.MODAL, (intValue, doubleValue, doubleValue2) -> updateState(intValue, doubleValue, doubleValue2));
         }

         float x = rect.getX() + 20.0F;
         uiContext.getUiRenderContext().fillCircle(x + 9.0F, rect.getY() + 27.0F, 11.0F, UiContext.multiplyAlpha(this.controlTone.computeColorForThemeSnapshot2(themeSnapshot2), 0.16F * floatValue5));
         UiShapeRenderer.updateStateForUiRenderContext3(uiContext.getUiRenderContext(), this.controlTone == ControlTone.DANGER ? Icon.TRASH : Icon.RESET, x + 9.0F, rect.getY() + 27.0F, 11.0F, UiContext.multiplyAlpha(this.controlTone.computeColorForThemeSnapshot2(themeSnapshot2), floatValue5));
         uiContext.drawVerticallyCenteredText(uiContext.ellipsize(this.string3, TextStyle.TITLE, 210.0F), x + 28.0F, rect.getY() + 27.0F, TextStyle.TITLE, UiContext.multiplyAlpha(themeSnapshot2.getPrimaryText(), floatValue5));
         float y = rect.getY() + 52.0F;

         for (String text : (java.lang.Iterable<String>)(java.lang.Iterable<?>)(list)) {
            uiContext.drawVerticallyCenteredText(text, x, y, TextStyle.BODY, UiContext.multiplyAlpha(themeSnapshot2.getSecondaryText2(), floatValue5));
            y += 11.0F;
         }

         float floatValue9 = rect.bottom() - 16.0F - 24.0F;
         float floatValue10 = ButtonWidgets.computeFloatForUiContext(uiContext, this.string2, null);
         float floatValue11 = ButtonWidgets.computeFloatForUiContext(uiContext, "Cancel", null);
         Rect rect2 = new Rect(rect.right() - 16.0F - floatValue10, floatValue9, floatValue10, 24.0F);
         Rect rect3 = new Rect(rect2.getX() - 6.0F - floatValue11, floatValue9, floatValue11, 24.0F);
         boolean booleanValue = this.booleanState && floatValue4 > 0.6F;
         ButtonWidgets.updateStateForUiContext4(uiContext, string5 + ".cancel", rect3, UiLayer.MODAL, ButtonVariant.SECONDARY, "Cancel", null, floatValue5, booleanValue ? () -> this.updateState2() : null);
         ButtonWidgets.updateStateForUiContext4(uiContext, string5 + ".confirm", rect2, UiLayer.MODAL, this.controlTone == ControlTone.DANGER ? ButtonVariant.DANGER : ButtonVariant.PRIMARY, this.string2, null, floatValue5, booleanValue ? () -> this.updateState3() : null);
         uiContext.getUiRenderContext().popTransform();
      }
   }

   public void updateState2() {
      if (this.booleanState) {
         ClientSounds.updateState5();
      }

      this.booleanState = false;
   }

   public static String getString(ConfirmationDialog confirmationDialog) {
      return confirmationDialog.string;
   }

   public static void setString(ConfirmationDialog confirmationDialog, String string4) {
      confirmationDialog.string = string4;
   }

   private void updateState3() {
      this.booleanState = false;
      if (getRunnable(this) != null) {
         getRunnable(this).run();
      }
   }
}
