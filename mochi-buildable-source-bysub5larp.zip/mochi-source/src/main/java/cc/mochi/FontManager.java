package cc.mochi;

import java.awt.Font;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class FontManager {
   private final Map<FontKey, AwtFontRenderer> awtFontRendererByFontKey = new HashMap<>();

   public AwtFontRenderer computeIfAbsent(int intValue, FontFamily fontFamily) {
      return this.awtFontRendererByFontKey.computeIfAbsent(new FontKey(intValue, fontFamily), fontKey -> this.computeAwtFontRendererForFontFamily(intValue, fontFamily, fontKey));
   }

   private AwtFontRenderer computeAwtFontRendererForFontFamily(int intValue, FontFamily fontFamily, FontKey fontKey) {
      return this.computeAwtFontRenderer((float)intValue, fontFamily.getType());
   }

   public void updateState() {
      for (FontFamily fontFamily : FontFamily.values()) {
         for (int intValue = 4; intValue <= 32; intValue++) {
            this.awtFontRendererByFontKey.put(new FontKey(intValue, fontFamily), this.computeAwtFontRenderer((float)intValue, fontFamily.getType()));
         }
      }
   }

   public AwtFontRenderer computeAwtFontRenderer(float floatValue, String string) {
      try {
         String string2 = "mochi/fonts/" + string + ".ttf";

         AwtFontRenderer awtFontRenderer;
         try (InputStream resourceAsStream = MochiClient.class.getClassLoader().getResourceAsStream(string2)) {
            Font[] fonts = Font.createFonts(Objects.requireNonNull(resourceAsStream));
            awtFontRenderer = new AwtFontRenderer(fonts, floatValue, 256, 2);
         }

         return awtFontRenderer;
      } catch (Throwable failure) {
         throw UncheckedExceptions.rethrow(failure);
      }
   }
}
