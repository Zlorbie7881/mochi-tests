package cc.mochi;

import java.awt.Color;

public record GlassPanelStyle(
   float x,
   float y,
   float width,
   float height,
   float radius,
   float unitScale,
   float alpha,
   Color tint,
   float tintMix,
   Color rim,
   float hoverStrength,
   float brightness
) {
   public Color getRim() {
      return this.rim;
   }

   public float getRadius() {
      return this.radius;
   }

   public float getHoverStrength() {
      return this.hoverStrength;
   }

   public float getBrightness() {
      return this.brightness;
   }

   public float getAlpha() {
      return this.alpha;
   }

   public float getY() {
      return this.y;
   }

   public float getX() {
      return this.x;
   }

   public float getTintMix() {
      return this.tintMix;
   }

   public Color getTint() {
      return this.tint;
   }

   public float getUnitScale() {
      return this.unitScale;
   }

   public float getHeight() {
      return this.height;
   }

   public float getWidth() {
      return this.width;
   }
}
