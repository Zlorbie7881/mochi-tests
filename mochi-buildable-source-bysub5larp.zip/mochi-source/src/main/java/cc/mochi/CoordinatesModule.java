package cc.mochi;

import cc.mochi.event.impl.render.Render2DEvent;
import java.awt.Color;
import java.util.Locale;
import java.util.Optional;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.registry.RegistryKey;

public class CoordinatesModule extends Module implements HudElement {
   private final BooleanSetting shadowSetting;

   private final DoubleSetting sizeSetting;

   private final DoubleSetting decimalsSetting;

   private static final Color color3 = new Color(255, 120, 130);

   private final BooleanSetting facingSetting;

   private final HudLayout hudLayout;

   private static final Color color2 = new Color(130, 226, 150);
   private final DoubleSetting bGAlphaSetting;

   private final BooleanSetting uppercaseSetting;
   private final DoubleSetting paddingSetting;

   private final ChoiceSetting modeSetting = new ChoiceSetting("Mode", "Full", "Full", "Compact");

   private final BooleanSetting camoSetting;

   private final BooleanSetting colouredAxesSetting;

   private final BooleanSetting biomeSetting;

   private final BooleanSetting dimensionSetting = new BooleanSetting("Dimension", false);

   private static final Color color = new Color(120, 176, 255);

   @Override
   public HudLayout computeHudLayout() {
      return this.hudLayout;
   }

   @Override
   public float getFloatConstant() {
      return 48.0F;
   }

   private String computeString2() {
      StringBuilder stringBuilder = new StringBuilder();
      if (this.facingSetting.getValue()) {
         stringBuilder.append(this.computeString5());
      }

      if (this.dimensionSetting.getValue()) {
         updateStateForStringBuilder(stringBuilder, this.computeString6());
      }

      if (this.biomeSetting.getValue()) {
         updateStateForStringBuilder(stringBuilder, this.computeString4());
      }

      String string = stringBuilder.toString();
      return this.uppercaseSetting.getValue() ? string.toUpperCase(Locale.ROOT) : string;
   }

   @EventHandler
   private void onRender2D(Render2DEvent render2DEvent) {
      if (mc.player != null && mc.world != null) {
         if (mc.currentScreen == null || mc.currentScreen instanceof ChatScreen) {
            if (!GlCapabilities.checkCondition3()) {
               ThemeSnapshot themeSnapshot = ClickGuiModule.computeThemeSnapshot();
               float value = (float)this.sizeSetting.getValue();
               float size = Math.max(6.0F, value - 0.5F);
               float value2 = (float)this.paddingSetting.getValue();
               boolean booleanValue = this.modeSetting.equals("Compact");
               int intValue = (int)Math.round(this.decimalsSetting.getValue());

               try (UiRenderBackend uiRenderBackend = HudBloomRenderer.computeUiRenderBackendForRender2DEvent(render2DEvent)) {
                  String[] stringArray = new String[]{"X", "Y", "Z"};
                  double[] doubleArray = new double[]{mc.player.getX(), mc.player.getY(), mc.player.getZ()};
                  Color[] colorArray = new Color[]{color3, color2, color};
                  float floatValue = value * 0.4F;
                  float floatValue2 = value * 1.4F;
                  float floatValue3 = 0.0F;

                  for (int intValue2 = 0; intValue2 < 3; intValue2++) {
                     floatValue3 += measureText(stringArray[intValue2], value) + floatValue + LegacyUiTheme.measureText(this.computeString3(doubleArray[intValue2], intValue), value, LegacyUiTheme.fontFace);
                     if (intValue2 < 2) {
                        floatValue3 += floatValue2;
                     }
                  }

                  String text = this.computeString2();
                  float size2 = booleanValue ? value * 0.85F : size;
                  float floatValue4 = text.isEmpty() ? 0.0F : LegacyUiTheme.measureText(text, size2, LegacyUiTheme.fontFace);
                  String text2 = this.uppercaseSetting.getValue() ? "COORDINATES" : "Coordinates";
                  float floatValue5 = LegacyUiTheme.measureFontHeight(size, LegacyUiTheme.fontFace2);
                  float floatValue6 = LegacyUiTheme.measureFontHeight(value, LegacyUiTheme.fontFace);
                  float width;
                  float height;
                  if (booleanValue) {
                     width = 10.0F + floatValue3 + (text.isEmpty() ? 0.0F : floatValue2 + floatValue4) + value2;
                     height = floatValue6 + value2 * 2.0F;
                  } else {
                     float floatValue7 = LegacyUiTheme.measureText(text2, size, LegacyUiTheme.fontFace2) + (text.isEmpty() ? 0.0F : floatValue2 + floatValue4);
                     width = 10.0F + Math.max(floatValue3, floatValue7) + value2;
                     height = value2 * 2.0F + floatValue5 + 4.0F + floatValue6;
                  }

                  this.updateState4(width, height);
                  float x = this.hudLayout.getX();
                  float y = this.hudLayout.getY();
                  LegacyUiTheme.updateStateForThemeSnapshot(x, y, width, height, (int)this.bGAlphaSetting.getValue(), true, this.shadowSetting.getValue(), this.camoSetting.getValue(), true, themeSnapshot);
                  float y2;
                  if (booleanValue) {
                     y2 = y + value2;
                  } else {
                     LegacyUiTheme.drawText(text2, x + 10.0F, y + value2, size, LegacyUiTheme.color5, LegacyUiTheme.fontFace2);
                     if (!text.isEmpty()) {
                        LegacyUiTheme.drawText3(text, x + width - value2, y + value2, size2, LegacyUiTheme.color5, LegacyUiTheme.fontFace);
                     }

                     y2 = y + value2 + floatValue5 + 4.0F;
                  }

                  float x2 = x + 10.0F;
                  boolean value3 = this.colouredAxesSetting.getValue();

                  for (int intValue3 = 0; intValue3 < 3; intValue3++) {
                     String text3 = this.uppercaseSetting.getValue() ? stringArray[intValue3] : stringArray[intValue3].toLowerCase(Locale.ROOT);
                     LegacyUiTheme.drawText(text3, x2, y2, value, value3 ? colorArray[intValue3] : LegacyUiTheme.color5, LegacyUiTheme.fontFace2);
                     x2 += measureText(stringArray[intValue3], value) + floatValue;
                     String text4 = this.computeString3(doubleArray[intValue3], intValue);
                     LegacyUiTheme.drawText(text4, x2, y2, value, LegacyUiTheme.color3, LegacyUiTheme.fontFace);
                     x2 += LegacyUiTheme.measureText(text4, value, LegacyUiTheme.fontFace);
                     if (intValue3 < 2) {
                        x2 += floatValue2;
                     }
                  }

                  if (booleanValue && !text.isEmpty()) {
                     LegacyUiTheme.drawText2(text, x2 + floatValue2, y2 + floatValue6 / 2.0F, size2, LegacyUiTheme.color5, LegacyUiTheme.fontFace);
                  }
               }
            }
         }
      }
   }

   private String computeString3(double doubleValue, int intValue) {
      return intValue <= 0 ? String.valueOf((int)Math.floor(doubleValue)) : String.format("%." + intValue + "f", doubleValue);
   }

   @Override
   public boolean checkCondition() {
      return false;
   }

   private static void updateStateForStringBuilder(StringBuilder stringBuilder, String string) {
      if (string != null && !string.isBlank()) {
         if (!stringBuilder.isEmpty()) {
            stringBuilder.append("  ·  ");
         }

         stringBuilder.append(string);
      }
   }

   private String computeString4() {
      try {
         Optional key = mc.world.getBiome(mc.player.getBlockPos()).getKey();
         return (String)(key.<String>map(objectValue -> computeStringForRegistryKey((RegistryKey)objectValue)).orElse(""));
      } catch (RuntimeException failure) {
         return "";
      }
   }

   private String computeString5() {
      String string;
      switch (mc.player.getHorizontalFacing()) {
         case NORTH:
            string = "North";
            break;
         case SOUTH:
            string = "South";
            break;
         case EAST:
            string = "East";
            break;
         case WEST:
            string = "West";
            break;
         default:
            string = "";
      }

      String string2 = string;
      if (this.modeSetting.equals("Compact") && !string2.isEmpty()) {
         string2 = string2.substring(0, 1);
      }

      return string2;
   }

   @Override
   public void updateState() {
      this.hudLayout.setAlignmentAndInsets(HudHorizontalAlignment.LEFT, HudVerticalAlignment.BOTTOM, 4.0F, 4.0F);
   }

   @Override
   public float getFloatConstant2() {
      return 218.0F;
   }

   private static float measureText(String text, float size) {
      return LegacyUiTheme.measureText(text, size, LegacyUiTheme.fontFace2);
   }

   public CoordinatesModule() {
      super("Coordinates", "Your position, facing, dimension and biome", -1, ModuleCategory.RENDER);
      this.biomeSetting = new BooleanSetting("Biome", false);
      this.facingSetting = new BooleanSetting("Facing", true);
      this.colouredAxesSetting = new BooleanSetting("Coloured Axes", true);
      this.uppercaseSetting = new BooleanSetting("Uppercase", true);
      this.decimalsSetting = new DoubleSetting("Decimals", 0.0, 2.0, 1.0, 1.0);
      this.sizeSetting = new DoubleSetting("Size", 7.0, 24.0, 11.5, 0.5);
      this.paddingSetting = new DoubleSetting("Padding", 2.0, 14.0, 8.0, 1.0);
      this.bGAlphaSetting = new DoubleSetting("BG Alpha", 0.0, 255.0, 150.0, 5.0);
      this.shadowSetting = new BooleanSetting("Shadow", true);
      this.camoSetting = new BooleanSetting("Camo", false);
      this.hudLayout = new HudLayout(4.0F, 4.0F, 218.0F, 48.0F);
      this.addSettings(new Setting[]{this.modeSetting, this.dimensionSetting, this.biomeSetting, this.facingSetting, this.colouredAxesSetting, this.uppercaseSetting, this.decimalsSetting, this.sizeSetting, this.paddingSetting, this.bGAlphaSetting, this.shadowSetting, this.camoSetting});
   }

   private static String computeStringForRegistryKey(RegistryKey registryKey) {
      return computeString7(registryKey.getValue().getPath());
   }

   private String computeString6() {
      String path = mc.world.getRegistryKey().getValue().getPath();
      return computeString7(path);
   }

   private static String computeString7(String string) {
      String[] stringArray = string.replace('_', ' ').split(" ");
      StringBuilder stringBuilder = new StringBuilder();

      for (String string2 : stringArray) {
         if (!string2.isEmpty()) {
            if (!stringBuilder.isEmpty()) {
               stringBuilder.append(' ');
            }

            stringBuilder.append(Character.toUpperCase(string2.charAt(0))).append(string2.substring(1));
         }
      }

      return stringBuilder.toString();
   }

   @Override
   public String computeString() {
      return this.getName();
   }
}
