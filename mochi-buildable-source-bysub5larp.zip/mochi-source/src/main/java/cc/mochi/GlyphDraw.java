package cc.mochi;

import org.jetbrains.annotations.NotNull;

record GlyphDraw(float atX, float atY, float r, float g, float b, Glyph toDraw) {
   public float getG() {
      return this.g;
   }

   public float getB() {
      return this.b;
   }

   public float getAtY() {
      return this.atY;
   }

   public Glyph getToDraw() {
      return this.toDraw;
   }

   @NotNull
   @Override
   public String toString() {
      return "DrawEntry[atX=" + this.atX + ", atY=" + this.atY + ", r=" + this.r + ", g=" + this.g + ", b=" + this.b + ", toDraw=" + this.toDraw + "]";
   }

   public float getR() {
      return this.r;
   }

   public float getAtX() {
      return this.atX;
   }
}
