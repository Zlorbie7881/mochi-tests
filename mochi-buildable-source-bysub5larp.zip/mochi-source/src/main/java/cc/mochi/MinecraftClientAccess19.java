package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.registry.tag.TagKey;

public class MinecraftClientAccess19 {
   public static Item getSHIELD() {
      return Items.SHIELD;
   }

   public static GameOptions getOptions(MinecraftClient minecraftClient) {
      return minecraftClient.options;
   }

   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static TagKey<Item> getAXES() {
      return ItemTags.AXES;
   }

   public static Item getMACE() {
      return Items.MACE;
   }

   public static KeyBinding getUseKey(GameOptions gameOptions) {
      return gameOptions.useKey;
   }

   public static TagKey<Item> getSWORDS() {
      return ItemTags.SWORDS;
   }

   public static Item getTRIDENT() {
      return Items.TRIDENT;
   }

}
