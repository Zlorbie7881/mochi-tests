package cc.mochi;

import java.util.List;
import java.util.function.IntConsumer;

public final class ChoiceDropdown {
   public static void updateStateForUiContext(UiContext uiContext, String string, Rect rect, UiLayer uiLayer, List list, int intValue, float floatValue, IntConsumer intConsumer) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      int intValue2 = Math.max(1, list.size());
      float radius = Math.min(8.0F, rect.getHeight() / 2.0F);
      uiContext.getUiRenderContext().fillRoundedRect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), radius, UiContext.multiplyAlpha(themeSnapshot2.getSurfaceSunken(), floatValue));
      float floatValue3 = rect.getWidth() / (float)intValue2;
      float floatValue4 = uiContext.getAnimations().springDefault(string + ".thumb", (float)intValue, (float)Math.max(0, intValue));
      Rect rect2 = new Rect(rect.getX() + floatValue3 * floatValue4 + 2.0F, rect.getY() + 2.0F, floatValue3 - 4.0F, rect.getHeight() - 4.0F);
      if (intValue >= 0) {
         uiContext.getUiRenderContext().drawGlowOutline(rect2.getX(), rect2.getY(), rect2.getWidth(), rect2.getHeight(), radius - 2.0F, 5.0F, 1.0F, UiContext.multiplyAlpha(themeSnapshot2.getTheme().getShadow2(), 0.35F * floatValue));
         uiContext.getUiRenderContext().fillRoundedRect(rect2.getX(), rect2.getY(), rect2.getWidth(), rect2.getHeight(), radius - 2.0F, UiContext.multiplyAlpha(themeSnapshot2.getSurfaceRaised(), floatValue));
      }

      for (int intValue3 = 0; intValue3 < list.size(); intValue3++) {
         Rect rect3 = new Rect(rect.getX() + floatValue3 * (float)intValue3, rect.getY(), floatValue3, rect.getHeight());
         boolean hovered = uiContext.isHovered(rect3, uiLayer);
         float floatValue5 = uiContext.animateHover(string + "." + intValue3, hovered);
         float progress = Math.max(0.0F, 1.0F - Math.abs(floatValue4 - (float)intValue3));
         uiContext.drawCenteredText(
            uiContext.ellipsize((String)list.get(intValue3), TextStyle.SMALL, floatValue3 - 6.0F),
            rect3.centerX(),
            rect3.centerY(),
            TextStyle.SMALL,
            UiContext.multiplyAlpha(UiContext.blendColors(UiContext.blendColors(themeSnapshot2.getSecondaryText2(), themeSnapshot2.getPrimaryText(), floatValue5 * 0.6F), themeSnapshot2.getPrimaryText(), progress), floatValue)
         );
         int intValue32 = intValue3;
         if (intConsumer != null) {
            uiContext.getInputRouter().addClickRegion(rect3, uiLayer, () -> updateStateForIntConsumer(intValue32, intValue, intConsumer));
         }
      }
   }

   private ChoiceDropdown() {
   }

   private static void updateStateForIntConsumer(int intValue, int intValue2, IntConsumer intConsumer) {
      if (intValue != intValue2) {
         ClientSounds.updateState4();
         intConsumer.accept(intValue);
      }
   }
}
