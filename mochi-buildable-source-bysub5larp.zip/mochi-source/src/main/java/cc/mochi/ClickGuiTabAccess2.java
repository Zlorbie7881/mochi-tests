package cc.mochi;

public class ClickGuiTabAccess2 {
   public static ClickGuiTab getFRIENDS() {
      return ClickGuiTab.FRIENDS;
   }
}
