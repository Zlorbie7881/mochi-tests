package cc.mochi;

public class InstaCartStateAccess {
   public static InstaCartState getCART() {
      return InstaCartState.CART;
   }

   public static InstaCartState getCOVER() {
      return InstaCartState.COVER;
   }

   public static InstaCartState getIDLE() {
      return InstaCartState.IDLE;
   }
}
