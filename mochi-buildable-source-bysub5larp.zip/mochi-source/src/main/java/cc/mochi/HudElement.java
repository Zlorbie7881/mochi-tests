package cc.mochi;

import java.util.concurrent.ThreadLocalRandom;

public interface HudElement {
   default void updateState4(float floatValue, float floatValue2) {
      HudLayout hudLayout = this.computeHudLayout();
      if ((hudLayout != null)) {
         ThreadLocalRandom.current().nextInt(13);

         hudLayout.setWidth(Math.max((1.0F), floatValue));
         hudLayout.setHeight(Math.max(1.0F, floatValue2));
         this.updateState8();
      }
   }

   float getFloatConstant2();

   default void updateState5(float floatValue) {
      if (this.checkCondition()) {
         if (!(this.getFloatConstant2() <= 0.0F)) {
            float floatConstant = this.getFloatConstant();

            if (!(floatConstant <= (0.0F))) {
               float floatValue2 = Math.max(0.4F, Math.min((3.5F), floatValue));
               HudLayout hudLayout = this.computeHudLayout();
               hudLayout.setWidth(Math.max(this.getFloatConstant4(), this.getFloatConstant2() * floatValue2));
               hudLayout.setHeight(Math.max(this.getFloatConstant3(), this.getFloatConstant() * floatValue2));
               return;
            }
         }
      }
   }

   default float getFloatConstant3() {
      return (24.0F);
   }

   default boolean checkCondition2() {
      HudLayout hudLayout = this.computeHudLayout();
      if (hudLayout != null) {
         if (hudLayout.isDirty()) {
            ThreadLocalRandom.current().nextInt(6);

            return true;
         }
      }

      return false;
   }

   String computeString();

   HudLayout computeHudLayout();

   default void updateState6(boolean booleanValue) {
      HudLayout hudLayout = this.computeHudLayout();
      if (hudLayout != null) {
         hudLayout.markUserPositioned(booleanValue);
      }
   }

   default float computeFloat6() {
      float floatConstant2 = this.getFloatConstant2();
      if (floatConstant2 <= (0.0F)) {
         ThreadLocalRandom.current().nextInt(6);

         return 1.0F;
      } else {
         return this.computeHudLayout().getWidth() / floatConstant2;
      }
   }

   default boolean checkCondition() {
      return true;
   }

   default void updateState7() {
      HudLayout hudLayout = this.computeHudLayout();
      if ((hudLayout != null)) {
         hudLayout.reset();
         if (this.checkCondition()) {
            hudLayout.setWidth(this.getFloatConstant2());
            hudLayout.setHeight(this.getFloatConstant());
         }

         this.updateState();
         hudLayout.markDirty();
      }
   }

   float getFloatConstant();

   default void updateState() {
   }

   default float getFloatConstant4() {
      return (44.0F);
   }

   default void updateState8() {
      HudLayout hudLayout = this.computeHudLayout();
      if (hudLayout != null) {
         if (!hudLayout.isUserPositioned()) {
            this.updateState();

            ThreadLocalRandom.current().nextInt(17);
         }

         hudLayout.applyAlignment();
         hudLayout.clampToViewport();
         hudLayout.markDirty();
      }
   }
}
