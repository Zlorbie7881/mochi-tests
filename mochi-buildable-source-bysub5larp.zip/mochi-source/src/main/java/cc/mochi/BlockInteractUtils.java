package cc.mochi;

import java.util.concurrent.ThreadLocalRandom;
import java.util.function.BiFunction;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public final class BlockInteractUtils implements MinecraftAccess {
   public static boolean testWorld(World world, ClientPlayerEntity clientPlayerEntity, BlockHitResult blockHitResult, Vec3d vec3d) {
      if (world != null) {
         ThreadLocalRandom.current().nextInt(6);
         if (clientPlayerEntity != null) {
            return testBlockHitResult2(blockHitResult, vec3d, clientPlayerEntity.getBlockInteractionRange(), (objectValue, objectValue2) -> raycast(world, clientPlayerEntity, (Vec3d)objectValue, (Vec3d)objectValue2));
         }
      }

      return false;
   }

   public static BlockPos computeBlockPosForBlockHitResult(BlockHitResult blockHitResult) {
      if (blockHitResult != null) {
         if (MinecraftClientAccess4.getWorld(mc) != null) {
            byte byteValue;
            label44: {
               BlockState blockState = mc.world.getBlockState(blockHitResult.getBlockPos());
               if (!blockState.isReplaceable()) {
                  if (!blockState.isOf(MinecraftClientAccess4.getFIRE())) {
                     if (!blockState.isOf(Blocks.SOUL_FIRE)) {
                        byteValue = 0;
                        break label44;
                     }
                  }
               }

               byteValue = 1;
            }

            byte byteValue2 = byteValue;
            return byteValue2 != 0 ? blockHitResult.getBlockPos() : blockHitResult.getBlockPos().offset(blockHitResult.getSide());
         }
      }

      return null;
   }

   public static BlockPos computeBlockPos() {
      BlockHitResult blockHitResult = computeBlockHitResult2();
      if (blockHitResult != null) {
         if (blockHitResult.getType() == MinecraftClientAccess4.getBLOCK()) {
            return computeBlockPosForBlockHitResult(blockHitResult);
         }
      }

      return null;
   }

   public static HitResult computeHitResult(float floatValue, float floatValue2, double doubleValue) {
      if (mc.player != null) {
         if (mc.world != null) {
            Vec3d eyePos = MinecraftClientAccess4.getPlayer(mc).getEyePos();
            Vec3d vec3d = computeVec3d(floatValue2, floatValue);
            double blockInteractionRange = mc.player.getBlockInteractionRange();
            Vec3d vec3d2 = eyePos.add(vec3d.multiply(blockInteractionRange));
            BlockHitResult blockHitResult = MinecraftClientAccess4.getWorld(mc).raycast(new RaycastContext(eyePos, vec3d2, MinecraftClientAccess4.getOUTLINE(), MinecraftClientAccess4.getNONE(), mc.player));
            Vec3d vec3d3 = eyePos.add(vec3d.multiply(doubleValue));
            Box box = new Box(eyePos, vec3d3).expand(1.0);
            EntityHitResult entityCollision = ProjectileUtil.getEntityCollision(MinecraftClientAccess4.getWorld(mc), mc.player, eyePos, vec3d3, box, entity -> testEntity((Entity)entity), 0.3F);
            if (entityCollision != null) {
               double doubleValue2;
               if (blockHitResult != null) {
                  doubleValue2 = eyePos.squaredDistanceTo(blockHitResult.getPos());
               } else {
                  doubleValue2 = (1.7976931348623157E308);
               }

               double doubleValue22 = doubleValue2;
               double doubleValue4 = eyePos.squaredDistanceTo(entityCollision.getPos());
               if (doubleValue4 < doubleValue22) {
                  return entityCollision;
               }
            }

            return blockHitResult;
         }
      }

      return null;
   }

   public static HitResult computeHitResult2() {
      if (mc.player != null) {
         if (mc.world != null) {
            ClientPlayerEntity player4 = MinecraftClientAccess4.getPlayer(mc);

            return player4.getCrosshairTarget((1.0F), mc.player);
         }
      }

      return null;
   }

   public static BlockHitResult computeBlockHitResult(float floatValue, float floatValue2) {
      if (MinecraftClientAccess4.getPlayer(mc) != null) {
         if (MinecraftClientAccess4.getWorld(mc) != null) {
            ThreadLocalRandom.current().nextInt(15);
            Vec3d eyePos = mc.player.getEyePos();
            Vec3d vec3d = computeVec3d(floatValue2, floatValue);
            double blockInteractionRange = MinecraftClientAccess4.getPlayer(mc).getBlockInteractionRange();
            return MinecraftClientAccess4.getWorld(mc).raycast(new RaycastContext(eyePos, eyePos.add(vec3d.multiply(blockInteractionRange)), MinecraftClientAccess4.getOUTLINE(), MinecraftClientAccess4.getNONE(), MinecraftClientAccess4.getPlayer(mc)));
         }
      }

      return null;
   }

   public static BlockHitResult computeBlockHitResult2() {
      if (MinecraftClientAccess4.getPlayer(mc) != null) {
         if (mc.world != null) {
            Vec3d eyePos = MinecraftClientAccess4.getPlayer(mc).getEyePos();

            Vec3d rotationVec = mc.player.getRotationVec((1.0F));
            double blockInteractionRange = mc.player.getBlockInteractionRange();
            return MinecraftClientAccess4.getWorld(mc).raycast(new RaycastContext(eyePos, eyePos.add(rotationVec.multiply(blockInteractionRange)), ShapeType.OUTLINE, FluidHandling.NONE, MinecraftClientAccess4.getPlayer(mc)));
         }
      }

      return null;
   }

   public static BlockHitResult computeBlockHitResult3() {
      if (mc.player != null) {
         if (MinecraftClientAccess4.getWorld(mc) != null) {
            Vec3d eyePos = mc.player.getEyePos();
            Vec3d vec3d = eyePos.add(MinecraftClientAccess4.getPlayer(mc).getRotationVec(1.0F).multiply(mc.player.getBlockInteractionRange()));
            BlockHitResult blockHitResult = mc.world.raycast(new RaycastContext(eyePos, vec3d, MinecraftClientAccess4.getOUTLINE(), MinecraftClientAccess4.getSOURCE_ONLY(), mc.player));
            if (blockHitResult.getType() == MinecraftClientAccess4.getBLOCK()) {
               if (blockHitResult instanceof BlockHitResult var3) {
                  return var3;
               }
            }

            return null;
         }
      }

      return null;
   }

   private static boolean testEntity(Entity entity) {
      if (!entity.isSpectator()) {
         if (entity != mc.player) {
            if (entity.canHit()) {
               ThreadLocalRandom.current().nextInt(13);
               return true;
            }
         }
      }

      return false;
   }

   public static boolean testBlockHitResult(BlockHitResult blockHitResult, Vec3d vec3d) {
      return testWorld(mc.world, mc.player, blockHitResult, vec3d);
   }

   private static BlockHitResult raycast(World world, ClientPlayerEntity clientPlayerEntity, Vec3d vec3d, Vec3d vec3d2) {
      return world.raycast(new RaycastContext(vec3d, vec3d2, ShapeType.OUTLINE, MinecraftClientAccess4.getNONE(), clientPlayerEntity));
   }

   static boolean testBlockHitResult2(BlockHitResult blockHitResult, Vec3d vec3d, double doubleValue, BiFunction biFunction) {
      if (blockHitResult != null && blockHitResult.getType() == Type.BLOCK && testVec3d(vec3d) && testVec3d(blockHitResult.getPos())) {
         if (Double.isFinite(doubleValue)) {
            if (!(doubleValue <= (0.0))) {
               if (biFunction != null) {
                  Vec3d vec3d2 = blockHitResult.getPos().subtract(vec3d);
                  double doubleValue2 = vec3d2.length();
                  if (Double.isFinite(doubleValue2) && !(doubleValue2 < 1.0E-7)) {
                     if (!(doubleValue2 > doubleValue)) {
                        Vec3d vec3d3 = blockHitResult.getPos().add(vec3d2.multiply(1.0E-4 / doubleValue2));
                        BlockHitResult blockHitResult2 = (BlockHitResult)biFunction.apply(vec3d, vec3d3);
                        if (blockHitResult2 != null) {
                           if (blockHitResult2.getType() == MinecraftClientAccess4.getBLOCK()) {
                              if (blockHitResult2.getBlockPos().equals(blockHitResult.getBlockPos())) {
                                 if (blockHitResult2.getSide() == blockHitResult.getSide()) {
                                    return true;
                                 }
                              }
                           }
                        }

                        return false;
                     }
                  }

                  return false;
               }
            }
         }
      }

      return false;
   }

   public static BlockPos computeBlockPos2() {
      BlockHitResult blockHitResult = computeBlockHitResult2();
      if (blockHitResult != null) {
         if (blockHitResult.getType() == Type.BLOCK) {
            return blockHitResult.getBlockPos();
         }
      }

      return null;
   }

   public static BlockHitResult computeBlockHitResultForBlockPos(BlockPos blockPos) {
      BlockHitResult blockHitResult = computeBlockHitResult3();
      if (blockHitResult != null) {
         if (blockHitResult.getBlockPos().equals(blockPos)) {
            return blockHitResult;
         }
      }

      return null;
   }

   public static BlockHitResult computeBlockHitResultForBlockPos2(BlockPos blockPos) {
      BlockHitResult blockHitResult = computeBlockHitResult2();
      if (blockHitResult != null) {
         if (blockHitResult.getType() == MinecraftClientAccess4.getBLOCK()) {
            if (blockPos.equals(computeBlockPosForBlockHitResult(blockHitResult))) {
               return blockHitResult;
            }
         }
      }

      return null;
   }

   public static HitResult computeHitResult3(float floatValue, float floatValue2) {
      double entityInteractionRange;
      if (MinecraftClientAccess4.getPlayer(mc) != null) {
         entityInteractionRange = MinecraftClientAccess4.getPlayer(mc).getEntityInteractionRange();
      } else {
         entityInteractionRange = (3.0);

         ThreadLocalRandom.current().nextInt(7);
      }

      double entityInteractionRange2 = entityInteractionRange;
      return computeHitResult(floatValue, floatValue2, entityInteractionRange2);
   }

   public static Vec3d computeVec3d(float floatValue, float floatValue2) {
      float floatValue3 = floatValue * (float) (Math.PI / 180.0);
      float floatValue4 = -floatValue2 * (float) (Math.PI / 180.0);
      float floatValue5 = (float)Math.cos((double)floatValue4);
      float floatValue6 = (float)Math.sin((double)floatValue4);
      float floatValue7 = (float)Math.cos((double)floatValue3);
      float floatValue8 = (float)Math.sin((double)floatValue3);
      return new Vec3d((double)(floatValue6 * floatValue7), (double)(-floatValue8), (double)(floatValue5 * floatValue7));
   }

   private BlockInteractUtils() {
   }

   public static BlockHitResult computeBlockHitResultForBlockPos3(BlockPos blockPos) {
      BlockHitResult blockHitResult = computeBlockHitResult2();
      if (blockHitResult != null) {
         ThreadLocalRandom.current().nextInt(9);
         if (blockHitResult.getType() == MinecraftClientAccess4.getBLOCK() && blockHitResult.getBlockPos().equals(blockPos)) {
            return blockHitResult;
         }
      }

      return null;
   }

   private static boolean testVec3d(Vec3d vec3d) {
      if (vec3d != null) {
         if (Double.isFinite(MinecraftClientAccess4.getX(vec3d))) {
            if (Double.isFinite(MinecraftClientAccess4.getY(vec3d))) {
               if (Double.isFinite(vec3d.z)) {
                  return true;
               }
            }
         }
      }

      return false;
   }
}
