package cc.mochi;

public final class EmptyStateWidget {
   public static void updateStateForUiContext(UiContext uiContext, Rect rect, Icon icon, String text, String string2, float floatValue) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      float floatValue2 = rect.centerY() - 10.0F;
      uiContext.getUiRenderContext().fillCircle(rect.centerX(), floatValue2 - 12.0F, 15.0F, UiContext.multiplyAlpha(themeSnapshot2.getAccentSoft2(), floatValue));
      uiContext.getUiRenderContext().strokeCircle(rect.centerX(), floatValue2 - 12.0F, 15.0F, 1.0F, UiContext.multiplyAlpha(themeSnapshot2.getAccent2(), 0.3F * floatValue));
      UiShapeRenderer.updateStateForUiRenderContext3(uiContext.getUiRenderContext(), icon, rect.centerX(), floatValue2 - 12.0F, 13.0F, UiContext.multiplyAlpha(themeSnapshot2.getAccentText2(), floatValue));
      uiContext.drawCenteredText(text, rect.centerX(), floatValue2 + 14.0F, TextStyle.STRONG, UiContext.multiplyAlpha(themeSnapshot2.getPrimaryText(), floatValue));
      if (string2 != null) {
         float y = floatValue2 + 27.0F;

         for (String text2 : (java.lang.Iterable<String>)(java.lang.Iterable<?>)(uiContext.wrapText(string2, TextStyle.SMALL, Math.min(rect.getWidth() - 24.0F, 200.0F), 3))) {
            uiContext.drawCenteredText(text2, rect.centerX(), y, TextStyle.SMALL, UiContext.multiplyAlpha(themeSnapshot2.getSecondaryText2(), floatValue));
            y += 10.0F;
         }
      }
   }

   private EmptyStateWidget() {
   }
}
