package cc.mochi;

public enum KnockbackDisplaceState {
   IDLE,
   ARMED,
   TURNING,
   HOLD;

   private static final KnockbackDisplaceState[] ENUM_VALUES = {IDLE, ARMED, TURNING, HOLD};

   public static KnockbackDisplaceState[] getENUM_VALUES() {
      return ENUM_VALUES;
   }

   public static KnockbackDisplaceState getARMED() {
      return ARMED;
   }

   private static KnockbackDisplaceState[] createValues() {
      return new KnockbackDisplaceState[]{IDLE, getARMED(), TURNING, HOLD};
   }
}
