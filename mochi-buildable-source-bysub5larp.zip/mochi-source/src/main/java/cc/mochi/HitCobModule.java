package cc.mochi;

import cc.mochi.event.impl.player.AttackEvent;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Blocks;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class HitCobModule extends Module {
   @EventHandler
   private void onAttack(AttackEvent attackEvent) {
      if (!this.isWorldUnavailable() && attackEvent.getTarget() instanceof PlayerEntity var2) {
         int intValue = this.computeInt();

         if ((intValue != -1)) {
            BlockPos blockPos = var2.getBlockPos();
            if (mc.world.getBlockState(blockPos).getBlock() == PlayerInteractionAccess.getCOBWEB()) {
            } else if (mc.world.getBlockState(blockPos).getBlock() != Blocks.WATER) {
               double doubleValue = mc.player.getEntityPos().distanceTo(Vec3d.ofCenter(blockPos));
               if (!(doubleValue > 4.5)) {
                  double doubleValue2 = Math.hypot(var2.getVelocity().x, PlayerInteractionAccess.getZ(var2.getVelocity()));
                  Vec3d vec3d = var2.getEntityPos().subtract(mc.player.getEntityPos()).normalize();

                  double doubleValue3;
                  if (doubleValue2 < (0.05)) {
                     ThreadLocalRandom.current().nextInt(16);
                     doubleValue3 = PlayerInteractionAccess.getPlayer(mc).isSprinting() ? 1.8 : 1.2;
                  } else {
                     if (doubleValue2 < (0.13)) {
                        ThreadLocalRandom.current().nextInt(12);
                        double doubleValue4;
                        if (mc.player.isSprinting()) {
                           doubleValue4 = (1.5);
                        } else {
                           doubleValue4 = 1.0;
                        }

                        doubleValue3 = doubleValue4;
                     } else {
                        double doubleValue5;
                        if (PlayerInteractionAccess.getPlayer(mc).isSprinting()) {
                           doubleValue5 = 1.2;
                        } else {
                           doubleValue5 = 0.8;
                        }

                        doubleValue3 = doubleValue5;
                     }
                  }

                  Vec3d vec3d2 = var2.getEntityPos().add(vec3d.multiply(doubleValue3));
                  BlockPos blockPos2 = BlockPos.ofFloored(vec3d2);
                  if (mc.world.getBlockState(blockPos2).getBlock() != Blocks.COBWEB) {
                     if (mc.world.getBlockState(blockPos2).getBlock() != PlayerInteractionAccess.getWATER()) {
                        if (!mc.world.getBlockState(blockPos2).isAir()) {
                           blockPos2 = blockPos;
                        }

                        BlockPos blockPos3 = blockPos2.down();
                        if (!mc.world.getBlockState(blockPos3).isAir()) {
                           double doubleValue6 = PlayerInteractionAccess.getPlayer(mc).getEntityPos().distanceTo(Vec3d.ofCenter(blockPos2));

                           if (!(doubleValue6 > (4.5))) {
                              int selectedSlot = mc.player.getInventory().getSelectedSlot();
                              float yaw = mc.player.getYaw();
                              float pitch = mc.player.getPitch();
                              Vec3d vec3d3 = Vec3d.ofCenter(blockPos3);

                              Vec3d vec3d4 = vec3d3.add((0.0), 0.5, 0.0);
                              float[] floatArray = this.computeFloatArrayForVec3d(vec3d4);
                              ClientPlayerEntity player3 = PlayerInteractionAccess.getPlayer(mc);

                              player3.setYaw(floatArray[0]);

                              mc.player.setPitch(floatArray[1]);
                              mc.player.getInventory().setSelectedSlot(intValue);
                              Direction up = PlayerInteractionAccess.getUP();

                              BlockHitResult blockHitResult = new BlockHitResult(vec3d4, up, blockPos3, false);
                              if (PlayerInteractionAccess.getInteractionManager(mc) != null) {
                                 mc.interactionManager.interactBlock(PlayerInteractionAccess.getPlayer(mc), Hand.MAIN_HAND, blockHitResult);
                              }

                              mc.player.getInventory().setSelectedSlot(selectedSlot);
                              mc.player.setYaw(yaw);
                              PlayerInteractionAccess.getPlayer(mc).setPitch(pitch);
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   public HitCobModule() {
      super("Hit Cob", "Places cobweb at player feet when you hit them (DO NOT USE ITS BEING TESTED)", ModuleCategory.COMBAT);
   }

   private float[] computeFloatArrayForVec3d(Vec3d vec3d) {
      Vec3d vec3d2 = vec3d.subtract(PlayerInteractionAccess.getPlayer(mc).getEyePos());
      double doubleValue = Math.sqrt(PlayerInteractionAccess.getX(vec3d2) * PlayerInteractionAccess.getX(vec3d2) + vec3d2.z * PlayerInteractionAccess.getZ(vec3d2));
      float floatValue = (float)Math.toDegrees(Math.atan2(PlayerInteractionAccess.getZ(vec3d2), PlayerInteractionAccess.getX(vec3d2))) - 90.0F;
      float floatValue2 = (float)(-Math.toDegrees(Math.atan2(vec3d2.y, doubleValue)));

      float[] floatArray = new float[2];

      floatArray[0] = MathHelper.wrapDegrees(floatValue);

      floatArray[1] = MathHelper.clamp(floatValue2, ((-89.0F)), (89.0F));
      return floatArray;
   }

   private int computeInt() {
      int intValue = 0;

      while (true) {
         if (intValue >= 9) {
            return -1;
         }

         ItemStack stack = PlayerInteractionAccess.getPlayer(mc).getInventory().getStack(intValue);
         if (!stack.isEmpty()) {
            if (stack.getItem() == PlayerInteractionAccess.getCOBWEB2()) {
               return intValue;
            }
         }

         intValue++;
      }
   }
}
