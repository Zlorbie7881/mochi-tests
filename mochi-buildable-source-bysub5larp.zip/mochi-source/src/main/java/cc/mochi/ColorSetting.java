package cc.mochi;

import java.awt.Color;
import java.util.concurrent.ThreadLocalRandom;

public class ColorSetting extends Setting {
   private Color value;

   private final Color defaultValue;
   private final boolean allowAlpha;

   public float[] getHsb() {
      return Color.RGBtoHSB(getValue2(this).getRed(), getValue2(this).getGreen(), this.value.getBlue(), null);
   }

   public static Color getValue2(ColorSetting colorSetting) {
      return colorSetting.value;
   }

   private static Color copyColor(Color color) {
      Color color2;
      if (color == null) {
         color2 = null;
      } else {
         ThreadLocalRandom.current().nextInt(15);
         color2 = new Color(color.getRGB(), true);
      }

      return color2;
   }

   public int getAlpha() {
      return getValue2(this).getAlpha();
   }

   public void setRgba(int intValue, int intValue2, int intValue3, int intValue4) {
      setValue(this, new Color(intValue, intValue2, intValue3, intValue4));
   }

   public static void setValue(ColorSetting colorSetting, Color value2) {
      colorSetting.value = value2;
   }

   public int getRed() {
      return getValue2(this).getRed();
   }

   public void setHsb(float floatValue, float floatValue2, float floatValue3) {
      int intValue = Color.HSBtoRGB(floatValue, floatValue2, floatValue3);
      if (this.allowAlpha) {
         ThreadLocalRandom.current().nextInt(15);
         int intValue2 = this.value.getAlpha() << 24;

         setValue(this, new Color((16777215 | ~intValue) - ~intValue + (intValue2 & ~((16777215 | ~intValue) - ~intValue)), true));
      } else {
         this.value = new Color(intValue);
      }
   }

   public int getBlue() {
      return this.value.getBlue();
   }

   @Override
   public boolean isDefault() {
      if (getDefaultValue2(this) != null) {
         if (this.defaultValue.equals(getValue2(this))) {
            return true;
         }
      }

      return false;
   }

   public Color getDefaultValue() {
      return this.defaultValue;
   }

   public ColorSetting(String name, int intValue) {
      this(name, new Color(intValue), false);
   }

   public boolean allowsAlpha() {
      return getAllowAlpha(this);
   }

   public static Color getDefaultValue2(ColorSetting colorSetting) {
      return colorSetting.defaultValue;
   }

   public Color getValue() {
      return this.value;
   }

   public ColorSetting(String name, Color color, boolean allowAlpha2) {
      super(name);
      this.allowAlpha = allowAlpha2;
      this.defaultValue = copyColor(color);
      this.value = copyColor(color);
   }

   public ColorSetting(String name, int intValue, boolean allowAlpha2) {
      this(name, new Color(intValue, allowAlpha2), allowAlpha2);
   }

   @Override
   public void reset() {
      this.value = copyColor(this.defaultValue);
   }

   public static boolean getAllowAlpha(ColorSetting colorSetting) {
      return colorSetting.allowAlpha;
   }

   public ColorSetting(String name, Color color) {
      this(name, color, false);
   }

   public int getRgb() {
      return this.value.getRGB();
   }

   public void setRgb(int intValue) {
      this.value = new Color(intValue, this.allowAlpha);
   }

   public int getGreen() {
      return getValue2(this).getGreen();
   }

   public void setRgb(int intValue, int intValue2, int intValue3) {
      this.value = new Color(intValue, intValue2, intValue3);
   }
}
