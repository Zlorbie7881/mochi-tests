package cc.mochi;

public enum ElytraSpeedState {
   GROUND,
   RELEASE,
   DEPLOY,
   GLIDING;

   private static final ElytraSpeedState[] ENUM_VALUES = {GROUND, RELEASE, DEPLOY, GLIDING};

   private static ElytraSpeedState[] computeElytraSpeedStateArray() {
      ElytraSpeedState[] elytraSpeedStateArray = new ElytraSpeedState[4];

      elytraSpeedStateArray[0] = GROUND;

      elytraSpeedStateArray[1] = RELEASE;
      elytraSpeedStateArray[2] = DEPLOY;

      elytraSpeedStateArray[3] = GLIDING;
      return elytraSpeedStateArray;
   }

   public static ElytraSpeedState[] getENUM_VALUES() {
      return ENUM_VALUES;
   }
}
