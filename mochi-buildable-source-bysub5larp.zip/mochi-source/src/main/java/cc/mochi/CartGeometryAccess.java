package cc.mochi;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.SlabBlock;
import net.minecraft.block.enums.SlabType;
import net.minecraft.fluid.Fluid;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Direction.Type;
import net.minecraft.world.RaycastContext.ShapeType;

public class CartGeometryAccess {
   public static SlabType getBOTTOM() {
      return SlabType.BOTTOM;
   }

   public static double getX(Vec3d vec3d) {
      return vec3d.x;
   }

   public static double getMinY(Box box) {
      return box.minY;
   }

   public static double getMinZ(Box box) {
      return box.minZ;
   }

   public static EnumProperty<SlabType> getTYPE() {
      return SlabBlock.TYPE;
   }

   public static double getZ(Vec3d vec3d) {
      return vec3d.z;
   }

   public static double getY(Vec3d vec3d) {
      return vec3d.y;
   }

   public static double getMaxZ(Box box) {
      return box.maxZ;
   }

   public static Direction getUP() {
      return Direction.UP;
   }

   public static Direction getWEST() {
      return Direction.WEST;
   }

   public static Direction getSOUTH() {
      return Direction.SOUTH;
   }

   public static double getMinX(Box box) {
      return box.minX;
   }

   public static Direction getEAST() {
      return Direction.EAST;
   }

   public static Type getHORIZONTAL() {
      return Type.HORIZONTAL;
   }

   public static ShapeType getCOLLIDER() {
      return ShapeType.COLLIDER;
   }

   public static Direction getNORTH() {
      return Direction.NORTH;
   }

   public static TagKey<Fluid> getWATER() {
      return FluidTags.WATER;
   }

   public static TagKey<Block> getFIRE() {
      return BlockTags.FIRE;
   }

   public static Block getTNT() {
      return Blocks.TNT;
   }

}
