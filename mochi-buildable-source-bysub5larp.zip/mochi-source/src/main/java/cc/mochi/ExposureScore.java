package cc.mochi;

public record ExposureScore(double after, double score) {
   public double getAfter2() {
      return getAfter(this);
   }

   public double getScore() {
      return this.score;
   }

   public static double getAfter(ExposureScore exposureScore) {
      return exposureScore.after;
   }
}
