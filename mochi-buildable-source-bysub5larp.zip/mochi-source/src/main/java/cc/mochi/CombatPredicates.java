package cc.mochi;

import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttackRangeComponent;
import net.minecraft.component.type.PiercingWeaponComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public final class CombatPredicates {
   private CombatPredicates() {
   }

   private static boolean canHit(ClientPlayerEntity clientPlayerEntity, Entity entity) {
      return PiercingWeaponComponent.canHit(clientPlayerEntity, entity);
   }

   public static boolean testItemStack(ItemStack itemStack) {
      if (!itemStack.isEmpty()) {
         if (itemStack.isIn(ItemTags.SPEARS)) {
            if (itemStack.contains(DataComponentTypes.PIERCING_WEAPON)) {
               if (itemStack.contains(DataComponentTypes.ATTACK_RANGE)) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   private static Collection computeCollectionForCollection(Collection collection) {
      return collection;
   }

   private static double squaredMagnitude(Vec3d vec3d, EntityHitResult entityHitResult) {
      return entityHitResult.getEntity().getBoundingBox().squaredMagnitude(vec3d);
   }

   private static boolean testEntityHitResult(EntityHitResult entityHitResult) {
      Entity entity = entityHitResult.getEntity();
      if (entity instanceof PlayerEntity) {
         PlayerEntity entity2 = (PlayerEntity)entity;
         if (FriendManager.testPlayerEntity(entity2)) {
            return true;
         }
      }

      return false;
   }

   private static boolean canHit2(ClientPlayerEntity clientPlayerEntity, Entity entity) {
      return PiercingWeaponComponent.canHit(clientPlayerEntity, entity);
   }

   public static boolean testVec3d(Vec3d vec3d, Box box, double doubleValue) {
      ThreadLocalRandom.current().nextInt(8);
      double doubleValue2 = box.squaredMagnitude(vec3d);
      if (Double.isFinite(doubleValue2) && Double.isFinite(doubleValue)) {
         if (doubleValue > 3.0) {
            if (doubleValue2 > (9.0)) {
               if (doubleValue2 <= Math.min(4.5, doubleValue) * Math.min(4.5, doubleValue)) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   public static Collection computeCollectionForClientPlayerEntity(ClientPlayerEntity clientPlayerEntity, ItemStack itemStack) {
      AttackRangeComponent attackRangeComponent = (AttackRangeComponent)itemStack.get(DataComponentTypes.ATTACK_RANGE);
      if (attackRangeComponent == null) {
         return List.of();
      } else {
         return (Collection)ProjectileUtil.collectPiercingCollisions(clientPlayerEntity, attackRangeComponent, entity -> canHit(clientPlayerEntity, (Entity)entity), ShapeType.COLLIDER)
            .map(blockHitResult -> of((BlockHitResult)blockHitResult), collection -> computeCollectionForCollection((Collection)collection));
      }
   }

   public static Collection computeCollectionForClientPlayerEntity2(ClientPlayerEntity clientPlayerEntity, ItemStack itemStack, Vec3d vec3d, Vec3d vec3d2) {
      AttackRangeComponent attackRangeComponent = (AttackRangeComponent)itemStack.get(cc.mochi.DataComponentTypesAccess.getATTACK_RANGE());
      Object objectValue;
      if (attackRangeComponent == null) {
         objectValue = List.of();
      } else {
         objectValue = computeCollectionForClientPlayerEntity3(clientPlayerEntity, itemStack, vec3d, vec3d2, attackRangeComponent.hitboxMargin());
      }

      return (Collection)objectValue;
   }

   private static boolean testEntityHitResult2(EntityHitResult entityHitResult) {
      if (entityHitResult.getEntity() instanceof PlayerEntity var1) {
         if (FriendManager.testPlayerEntity(var1)) {
            return true;
         }
      }

      return false;
   }

   public static Collection computeCollectionForClientPlayerEntity3(ClientPlayerEntity clientPlayerEntity, ItemStack itemStack, Vec3d vec3d, Vec3d vec3d2, float floatValue) {
      AttackRangeComponent attackRangeComponent = (AttackRangeComponent)itemStack.get(cc.mochi.DataComponentTypesAccess.getATTACK_RANGE());
      if (attackRangeComponent != null) {
         if (vec3d != null) {
            if (vec3d2 != null) {
               Vec3d vec3d3 = vec3d.add(vec3d2.multiply((double)attackRangeComponent.getEffectiveMinRange(clientPlayerEntity)));

               Vec3d pos = vec3d.add(vec3d2.multiply(Math.min((4.5), (double)attackRangeComponent.getEffectiveMaxRange(clientPlayerEntity))));
               BlockHitResult collisionsIncludingWorldBorder = clientPlayerEntity.getEntityWorld()
                  .getCollisionsIncludingWorldBorder(new RaycastContext(vec3d, pos, cc.mochi.DataComponentTypesAccess.getCOLLIDER(), FluidHandling.NONE, clientPlayerEntity));
               if (collisionsIncludingWorldBorder.getType() != cc.mochi.DataComponentTypesAccess.getMISS()) {
                  pos = collisionsIncludingWorldBorder.getPos();
                  if (vec3d.squaredDistanceTo(pos) < vec3d.squaredDistanceTo(vec3d3)) {
                     return List.of();
                  }
               }

               Box box = Box.of(vec3d3, (double)attackRangeComponent.hitboxMargin(), (double)attackRangeComponent.hitboxMargin(), (double)attackRangeComponent.hitboxMargin()).stretch(pos.subtract(vec3d3));

               Box box2 = box.expand((1.0));
               return ProjectileUtil.collectPiercingCollisions(
                  clientPlayerEntity.getEntityWorld(), clientPlayerEntity, vec3d3, pos, box2, entity -> canHit2(clientPlayerEntity, (Entity)entity), floatValue, ShapeType.COLLIDER, true
               );
            }
         }
      }

      return List.of();
   }

   private static Collection of(BlockHitResult blockHitResult) {
      return List.of();
   }

   public static boolean anyMatch(Collection collection) {
      return collection.stream().anyMatch(objectValue -> testEntityHitResult((EntityHitResult)objectValue));
   }

   public static LivingEntity computeLivingEntityForPlayerEntity(PlayerEntity playerEntity, Vec3d vec3d, Collection collection, boolean booleanValue, double doubleValue) {
      if (collection.stream().anyMatch(objectValue -> testEntityHitResult2((EntityHitResult)objectValue))) {
         return null;
      } else {
         EntityHitResult entityHitResult = (EntityHitResult)((EntityHitResult)(collection.stream().min(Comparator.comparingDouble(objectValue2 -> squaredMagnitude(vec3d, (EntityHitResult)objectValue2))).orElse(null)));
         if (entityHitResult != null) {
            ThreadLocalRandom.current().nextInt(11);
            Entity entity = entityHitResult.getEntity();
            if (entity instanceof LivingEntity) {
               LivingEntity entity2 = (LivingEntity)entity;
               if (booleanValue) {
                  ThreadLocalRandom.current().nextInt(15);
                  if (!(entity2 instanceof PlayerEntity)) {
                     return null;
                  }
               }

               if (entity2.isAlive()) {
                  if (entity2.isAttackable() && playerEntity.canSee(entity2) && testVec3d(vec3d, entity2.getBoundingBox(), doubleValue)) {
                     double doubleValue2 = entityHitResult.getPos().squaredDistanceTo(vec3d);

                     double doubleValue3 = Math.min((4.5), doubleValue);

                     if (!(doubleValue2 > doubleValue3 * Math.min((4.5), doubleValue))) {
                        return entity2;
                     }
                  }
               }
            }
         }

         return null;
      }
   }
}
