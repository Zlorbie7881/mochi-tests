package cc.mochi;

import java.awt.Color;

public class LegacyUiColors {
   public static final Color color10 = new Color(15, 15, 15, 180);

   public static final Color color = new Color(25, 25, 25, 200);

   public static final Color color16 = new Color(150, 64, 255);

   public static final Color color13 = new Color(76, 175, 80);

   public static final Color color2 = new Color(244, 67, 54);
   public static final Color color7 = new Color(255, 152, 0);

   public static final Color color12 = new Color(156, 39, 176);
   public static final Color color3 = new Color(255, 255, 255);

   public static final Color color4 = new Color(180, 180, 180);
   public static final Color color5 = new Color(120, 120, 120);
   public static final Color color15 = new Color(60, 60, 60);

   public static final Color color9 = new Color(30, 30, 30);
   public static final Color color6 = new Color(76, 175, 80);
   public static final Color color14 = new Color(255, 193, 7);

   public static final Color color8 = new Color(244, 67, 54);
   public static final Color color11 = new Color(33, 150, 243);
}
