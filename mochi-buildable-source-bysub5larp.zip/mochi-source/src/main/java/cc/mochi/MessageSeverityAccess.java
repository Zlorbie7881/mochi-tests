package cc.mochi;

import net.minecraft.text.Style;

public class MessageSeverityAccess {
   public static MessageSeverity getINFO() {
      return MessageSeverity.INFO;
   }

   public static MessageSeverity getWARNING() {
      return MessageSeverity.WARNING;
   }

   public static XorText getCLIENT_NAME() {
      return ClientText.CLIENT_NAME;
   }

   public static Style getEMPTY() {
      return Style.EMPTY;
   }
}
