package cc.mochi;

import net.minecraft.entity.Entity;

@FunctionalInterface
public interface EntityFlagProvider {
   int flags(Entity entity);
}
