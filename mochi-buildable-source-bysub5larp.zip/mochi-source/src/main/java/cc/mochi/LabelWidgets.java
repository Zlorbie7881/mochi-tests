package cc.mochi;

import java.awt.Color;

public final class LabelWidgets {
   private LabelWidgets() {
   }

   public static float computeFloatForUiContext(UiContext uiContext, float floatValue, float y, String text, ControlTone controlTone, float floatValue3) {
      float floatValue4 = computeFloatForUiContext4(uiContext, text);
      computeFloatForUiContext7(uiContext, floatValue - floatValue4, y, text, controlTone, floatValue3);
      return floatValue4;
   }

   public static float computeFloatForUiContext2(UiContext uiContext, float x, float floatValue2, String text, float floatValue3) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      float width = max(uiContext, text);
      float y = floatValue2 - 7.0F;
      Color color = themeSnapshot2.getLight4() ? UiContext.blendColors(themeSnapshot2.getSurfaceRaised(), Color.WHITE, 0.5F) : UiContext.blendColors(themeSnapshot2.getSurfaceRaised(), TextStyleAccess13.getWHITE(), 0.04F);
      uiContext.getUiRenderContext().fillRoundedRect(x, y + 1.0F, width, 14.0F, 4.0F, UiContext.multiplyAlpha(UiContext.blendColors(color, TextStyleAccess13.getBLACK(), 0.35F), floatValue3));
      uiContext.getUiRenderContext().fillRoundedRect(x, y, width, 14.0F, 4.0F, UiContext.multiplyAlpha(color, floatValue3));
      uiContext.getUiRenderContext().strokeRoundedRect(x, y, width, 14.0F, 4.0F, 1.0F, UiContext.multiplyAlpha(themeSnapshot2.getHairline2(), floatValue3));
      uiContext.drawCenteredText(text, x + width / 2.0F, floatValue2 - 0.3F, TextStyle.CAPTION, UiContext.multiplyAlpha(themeSnapshot2.getSecondaryText2(), floatValue3));
      return width;
   }

   public static float computeFloatForUiContext3(UiContext uiContext, String... stringArray) {
      float floatValue = 0.0F;

      for (int intValue = 0; intValue < stringArray.length; intValue++) {
         floatValue += max(uiContext, stringArray[intValue]);
         if (intValue < stringArray.length - 1) {
            floatValue += 3.0F;
         }
      }

      return floatValue;
   }

   public static float max(UiContext uiContext, String text) {
      return Math.max(18.0F, uiContext.measureText(text, TextStyle.CAPTION) + 12.0F);
   }

   public static float computeFloatForUiContext4(UiContext uiContext, String text) {
      return uiContext.measureText(text, TextStyle.CAPTION) + 16.0F - 2.0F;
   }

   public static float computeFloatForUiContext5(UiContext uiContext, float floatValue, float floatValue2, String text, float floatValue3) {
      float floatValue4 = max(uiContext, text);
      computeFloatForUiContext2(uiContext, floatValue - floatValue4, floatValue2, text, floatValue3);
      return floatValue4;
   }

   public static float computeFloatForUiContext6(UiContext uiContext, float floatValue, float floatValue2, float floatValue3, String... stringArray) {
      float floatValue4 = floatValue;

      for (int intValue = 0; intValue < stringArray.length; intValue++) {
         floatValue4 += computeFloatForUiContext2(uiContext, floatValue4, floatValue2, stringArray[intValue], floatValue3);
         if (intValue < stringArray.length - 1) {
            floatValue4 += 3.0F;
         }
      }

      return floatValue4 - floatValue;
   }

   public static float computeFloatForUiContext7(UiContext uiContext, float x, float y, String text, ControlTone controlTone, float floatValue3) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      float width = computeFloatForUiContext4(uiContext, text);
      Color color = controlTone.computeColorForThemeSnapshot2(themeSnapshot2);
      uiContext.getUiRenderContext().fillRoundedRect(x, y - 7.0F, width, 14.0F, 7.0F, UiRenderContext.withAlpha(color, (controlTone == ControlTone.NEUTRAL ? 26.0F : 36.0F) * floatValue3));
      uiContext.drawCenteredText(text, x + width / 2.0F, y, TextStyle.CAPTION, UiContext.multiplyAlpha(controlTone.computeColorForThemeSnapshot(themeSnapshot2), floatValue3));
      return width;
   }

   public static void updateStateForUiContext(UiContext uiContext, Rect rect, String text, KeybindCaptureState keybindCaptureState, float floatValue, float floatValue2) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      float radius = Math.min(5.0F, rect.getHeight() / 2.0F);
      switch (keybindCaptureState) {
         case BOUND:
            uiContext.getUiRenderContext().fillRoundedRect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), radius, UiContext.multiplyAlpha(UiContext.blendColors(themeSnapshot2.getSurfaceRaised(), themeSnapshot2.getAccentSoft2(), 0.4F * floatValue), floatValue2));
            uiContext.drawCenteredText(
               uiContext.ellipsize(text, TextStyle.CAPTION, rect.getWidth() - 6.0F), rect.centerX(), rect.centerY(), TextStyle.CAPTION, UiContext.multiplyAlpha(UiContext.blendColors(themeSnapshot2.getSecondaryText2(), themeSnapshot2.getPrimaryText(), 0.5F + 0.5F * floatValue), floatValue2)
            );
            break;
         case CAPTURING:
            float floatValue4 = uiContext.pulse(1.4F);
            uiContext.getUiRenderContext().fillRoundedRect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), radius, UiContext.multiplyAlpha(themeSnapshot2.getAccentSoft2(), (1.2F + floatValue4) * floatValue2));
            uiContext.getUiRenderContext().pushBloom(themeSnapshot2.computeFloat3(0.6F) * (0.5F + 0.5F * floatValue4) * floatValue2);
            uiContext.getUiRenderContext().strokeRoundedRect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), radius, 1.0F, UiContext.multiplyAlpha(themeSnapshot2.getAccent2(), floatValue2));
            uiContext.getUiRenderContext().popBloom();
            uiContext.drawCenteredText("…", rect.centerX(), rect.centerY(), TextStyle.CAPTION, UiContext.multiplyAlpha(themeSnapshot2.getAccentText2(), floatValue2));
            break;
         default:
            uiContext.getUiRenderContext().fillRoundedRect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), radius, UiContext.multiplyAlpha(UiContext.blendColors(themeSnapshot2.getSurfaceSunken(), themeSnapshot2.getAccentSoft2(), 0.5F * floatValue), (0.7F + 0.3F * floatValue) * floatValue2));
            uiContext.drawCenteredText(floatValue > 0.5F ? "Bind" : "–", rect.centerX(), rect.centerY(), TextStyle.CAPTION, UiContext.multiplyAlpha(floatValue > 0.5F ? themeSnapshot2.getSecondaryText2() : themeSnapshot2.getDisabledText2(), floatValue2));
      }
   }

   public static float max2(UiContext uiContext, String text) {
      return Math.max(26.0F, uiContext.measureText(text, TextStyle.CAPTION) + 16.0F);
   }
}
