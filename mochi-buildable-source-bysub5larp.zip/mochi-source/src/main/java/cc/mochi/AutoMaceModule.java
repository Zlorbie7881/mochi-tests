package cc.mochi;

import cc.mochi.event.impl.combat.AutoMaceSyncEvent;
import cc.mochi.event.impl.combat.MaceHitEvent;
import cc.mochi.event.impl.combat.ShieldDrainEvent;
import cc.mochi.event.impl.network.DisconnectEvent;
import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.event.impl.render.Render2DEvent;
import cc.mochi.event.impl.world.WorldChangeEvent;
import cc.mochi.mixin.KeyBindingAccessor;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Supplier;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.MaceItem;
import net.minecraft.item.ShieldItem;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos.Mutable;

public class AutoMaceModule extends Module implements AttackInputBlocker {
   private int intState;
   private boolean booleanState;
   private boolean booleanState2;

   private final BooleanSetting aimWhileGlidingSetting;

   private final DoubleSetting cooldownMsSetting;

   private final BooleanSetting densityOnlySetting;

   private final BooleanSetting axeOnlySetting;

   private final CombatTargetTracker combatTargetTracker;

   private final DoubleSetting shieldDrainMaxCPSSetting;

   private int intState2;

   private int intState3;

   private final DoubleRangeSetting shieldSlamTicksSetting;

   private int intState4;

   private final RateAccumulator rateAccumulator;

   private final DoubleSetting aimSpeedSetting;

   private double doubleState;

   private boolean booleanState3;

   private PlayerEntity playerEntity;

   private final DoubleSetting aimRangeSetting;

   private final ChoiceSetting aimModeSetting;

   private final BooleanSetting weaponOnlySetting;

   private final DoubleSetting shieldDrainMinCPSSetting;

   private final DoubleSetting minFallDistSetting;
   private boolean booleanState4;

   private long longState;

   private boolean booleanState5;

   private long longState2;

   private final DoubleSetting densityHeightSetting;

   private final AttackRangeTimer attackRangeTimer;
   private boolean booleanState6;

   private long longState3;

   private final DoubleSetting shieldSlamChanceSetting;

   private int intState5;

   private int intState6;

   private final BooleanSetting booleanSetting;

   private long timestampMillis;

   private final BooleanSetting swapBackSetting;
   private boolean booleanState7;

   private int intState7;

   private final ChoiceSetting shieldBreakSetting;

   private final ChoiceSetting stopAimSetting;

   private PlayerEntity playerEntity2;
   private boolean booleanState8;

   private final DoubleSetting initialHitDelaySetting;

   private final DoubleSetting maceFOVSetting;

   private int intState8;

   private final BooleanSetting triggerWhileGlidingSetting;

   private final HumanizedRandom humanizedRandom;
   private int intState9;

   private int selectedSlot2;

   private PlayerEntity computePlayerEntity() {
      if (mc.world != null && MinecraftClientAccess38.getPlayer(mc) != null) {
         if (getBooleanSetting(this).isOn()) {
            CombatTargetTracker combatTargetTracker2 = getCombatTargetTracker(this);

            LivingEntity livingEntity = combatTargetTracker2.computeLivingEntityForLivingEntity3(null, true);
            if (livingEntity instanceof PlayerEntity) {
               PlayerEntity livingEntity2 = (PlayerEntity)livingEntity;
               if (FriendManager.testPlayerEntity(livingEntity2)) {
                  return null;
               }

               return (double)MinecraftClientAccess38.getPlayer(mc).distanceTo(livingEntity2) <= this.computeDouble2() ? livingEntity2 : null;
            }
         }

         PlayerEntity playerEntity52 = null;
         double maxValue = Double.MAX_VALUE;
         double doubleValue = this.computeDouble2();

         for (PlayerEntity playerEntity5 : MinecraftClientAccess38.getWorld(mc).getPlayers()) {
            if (playerEntity5 != MinecraftClientAccess38.getPlayer(mc)) {
               if (!FriendManager.testPlayerEntity(playerEntity5)) {
                  double doubleValue2;
                  if (playerEntity5.isAlive() && !((doubleValue2 = mc.player.squaredDistanceTo(playerEntity5)) > doubleValue * doubleValue)) {
                     double value = getMaceFOVSetting(this).getValue();

                     if (this.testEntity3(playerEntity5, value / (2.0))) {
                        if ((doubleValue2 < maxValue)) {
                           maxValue = doubleValue2;
                           playerEntity52 = playerEntity5;
                        }
                     }
                  }
               }
            }
         }

         if (this.booleanSetting.isOn() && playerEntity52 != null && getCombatTargetTracker(this).computeLivingEntityForLivingEntity3(playerEntity52, true) instanceof PlayerEntity var17 && !FriendManager.testPlayerEntity(var17)) {
            playerEntity52 = var17;
         }

         return playerEntity52;
      } else {
         return null;
      }
   }

   public static boolean getBooleanState4(AutoMaceModule autoMaceModule) {
      return autoMaceModule.booleanState4;
   }

   private int computeIntForItemStack(ItemStack itemStack, String string) {
      if (itemStack.isEmpty()) {
         return 0;
      } else {
         ItemEnchantmentsComponent itemEnchantmentsComponent = (ItemEnchantmentsComponent)itemStack.get(MinecraftClientAccess38.getENCHANTMENTS());
         if (itemEnchantmentsComponent == null) {
            return 0;
         } else {
            for (RegistryEntry registryEntry : itemEnchantmentsComponent.getEnchantments()) {
               if (registryEntry.getKey().isPresent()) {
                  if (((RegistryKey)registryEntry.getKey().get()).getValue().getPath().contains(string)) {
                     ThreadLocalRandom.current().nextInt(17);
                     return itemEnchantmentsComponent.getLevel(registryEntry);
                  }
               } else {
                  ThreadLocalRandom.current().nextInt(4);
               }
            }

            return 0;
         }
      }
   }

   private boolean checkCondition() {
      if (MinecraftClientAccess38.getPlayer(mc) != null && MinecraftClientAccess38.getWorld(mc) != null) {
         Box boundingBox = mc.player.getBoundingBox();
         BlockPos blockPos = BlockPos.ofFloored(boundingBox.minX, boundingBox.minY, MinecraftClientAccess38.getMinZ(boundingBox));
         BlockPos blockPos2 = BlockPos.ofFloored(boundingBox.maxX, MinecraftClientAccess38.getMaxY(boundingBox), boundingBox.maxZ);
         Mutable mutable = new Mutable();
         int x = blockPos.getX();

         while (x <= blockPos2.getX()) {
            int y = blockPos.getY();

            while (true) {
               if (y > blockPos2.getY()) {
                  ThreadLocalRandom.current().nextInt(6);
                  x++;
                  break;
               }

               int z = blockPos.getZ();

               while (true) {
                  if (z > blockPos2.getZ()) {
                     y++;
                     break;
                  }

                  mutable.set(x, y, z);
                  BlockState blockState = MinecraftClientAccess38.getWorld(mc).getBlockState(mutable);
                  if (blockState.getFluidState().isIn(FluidTags.WATER) || blockState.getBlock() == Blocks.COBWEB) {
                     return true;
                  }

                  ThreadLocalRandom.current().nextInt(13);
                  z++;
               }
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public static ChoiceSetting getShieldBreakSetting(AutoMaceModule autoMaceModule) {
      return autoMaceModule.shieldBreakSetting;
   }

   private boolean equals() {
      return this.shieldBreakSetting.equals("Shield Slam");
   }

   public static DoubleSetting getCooldownMsSetting(AutoMaceModule autoMaceModule) {
      return autoMaceModule.cooldownMsSetting;
   }

   private boolean testPlayerEntity(PlayerEntity playerEntity3) {
      if (MinecraftClientAccess38.getPlayer(mc) != null) {
         if (playerEntity3 != null) {
            if (!MinecraftClientAccess38.getPlayer(mc).canSee(playerEntity3)) {
               return false;
            }

            Vec3d eyePos = mc.player.getEyePos();
            Vec3d center = playerEntity3.getBoundingBox().getCenter();
            double doubleValue = MinecraftClientAccess38.getX(center) - MinecraftClientAccess38.getX(eyePos);
            double doubleValue2 = MinecraftClientAccess38.getZ(center) - eyePos.z;
            if (doubleValue * doubleValue + doubleValue2 * doubleValue2 <= 1.0E-6) {
               return true;
            }

            float floatValue = (float)Math.toDegrees(Math.atan2(doubleValue2, doubleValue)) - 90.0F;
            float floatValue2 = Math.abs(MathHelper.wrapDegrees(mc.player.getYaw() - floatValue));
            double doubleValue3 = (double)((Integer)MinecraftClientAccess38.getOptions(mc).getFov().getValue()).intValue();

            double doubleValue4 = MathHelper.clamp(doubleValue3, 30.0, (170.0));
            return (((double)floatValue2 <= doubleValue4 * 0.5 ? 1 : 0) != 0);
         }
      }

      return false;
   }

   private boolean checkCondition2() {
      if (mc.player == null) {
         return false;
      } else {
         ThreadLocalRandom.current().nextInt(5);

         if (mc.player.fallDistance > 1.5) {
            if (!MinecraftClientAccess38.getPlayer(mc).isGliding()) {
               return true;
            }
         }

         return false;
      }
   }

   public static void setIntState3(AutoMaceModule autoMaceModule, int intState32) {
      autoMaceModule.intState3 = intState32;
   }

   public static int getIntState6(AutoMaceModule autoMaceModule) {
      return autoMaceModule.intState6;
   }

   public static PlayerEntity getPlayerEntity(AutoMaceModule autoMaceModule) {
      return autoMaceModule.playerEntity;
   }

   public static PlayerEntity getPlayerEntity2(AutoMaceModule autoMaceModule) {
      return autoMaceModule.playerEntity2;
   }

   private void updateStateForVec3d(Vec3d vec3d, ActionPriority actionPriority) {
      this.updateStateForVec3d2(vec3d, actionPriority, this.checkCondition5());
   }

   public static long getLongState(AutoMaceModule autoMaceModule) {
      return autoMaceModule.longState;
   }

   private void updateState() {
      if ((this.checkCondition14())) {
         if (!this.checkCondition2()) {
            this.updateState18();

            setIntState3(this, 0);
            this.intState5 = -1;
            this.updateState15();
         } else if (!this.checkCondition7()) {
         } else {
            boolean booleanValue = AttackActions.testMinecraftClient(mc, "combat.attack.automace");
            if (booleanValue) {
               MinecraftClientAccess38.getINSTANCE().getMochiEventBus().post(new MaceHitEvent());
               setIntState3(this, 0);
               setDoubleState(this, mc.player.getY());
               setIntState7(this, 8);
               this.timestampMillis = System.currentTimeMillis();
               this.updateState15();

               ThreadLocalRandom.current().nextInt(10);
            } else {
               this.updateState18();
               setIntState3(this, 0);
               setIntState5(this, -1);
               this.updateState15();
            }
         }
      }
   }

   public static boolean getBooleanState(AutoMaceModule autoMaceModule) {
      return autoMaceModule.booleanState;
   }

   public static HumanizedRandom getHumanizedRandom(AutoMaceModule autoMaceModule) {
      return autoMaceModule.humanizedRandom;
   }

   private void updateState2() {
      if (this.equals2()) {
         this.updateState16();
      } else {
         ThreadLocalRandom.current().nextInt(7);

         this.updateState9();
      }
   }

   public static void setDoubleState(AutoMaceModule autoMaceModule, double doubleState2) {
      autoMaceModule.doubleState = doubleState2;
   }

   public static void setIntState5(AutoMaceModule autoMaceModule, int intState52) {
      autoMaceModule.intState5 = intState52;
   }

   public static DoubleSetting getAimSpeedSetting(AutoMaceModule autoMaceModule) {
      return autoMaceModule.aimSpeedSetting;
   }

   public static void setIntState(AutoMaceModule autoMaceModule, int intState10) {
      autoMaceModule.intState = intState10;
   }

   private void updateState3() {
      if (!this.booleanState3) {
         if (this.checkCondition14()) {
            if (!this.checkCondition2()) {
               this.updateState18();
               this.booleanState2 = false;
            } else {
               if ((this.checkCondition7())) {
                  label62:
                  if (this.checkCondition10()) {
                     if (mc.crosshairTarget != null) {
                        if (MinecraftClientAccess38.getCrosshairTarget(mc) instanceof EntityHitResult) {
                           break label62;
                        }
                     }

                     MinecraftClientAccess38.setCrosshairTarget(mc, BlockInteractUtils.computeHitResult(RotationManager.computeFloat2(), RotationManager.computeFloat7(), 4.5));
                  } else {
                     ThreadLocalRandom.current().nextInt(9);
                  }

                  boolean booleanValue = AttackActions.testMinecraftClient(mc, "combat.attack.automace");
                  if (booleanValue) {
                     MinecraftClientAccess38.getINSTANCE().getMochiEventBus().post(new MaceHitEvent());
                     this.timestampMillis = System.currentTimeMillis();

                     long longValue;

                     this.booleanState3 = true;
                     longValue = System.currentTimeMillis();
                     HumanizedRandom humanizedRandom2 = this.humanizedRandom;

                     this.longState3 = longValue + humanizedRandom2.computeLong3(5.0, (15.0));
                  } else {
                     this.updateState18();

                     ThreadLocalRandom.current().nextInt(13);
                  }
               }
            }
         }
      }
   }

   private Vec3d computeVec3d() {
      Vec3d vec3d;
      if (this.playerEntity != null) {
         vec3d = this.computeVec3dForEntity2(getPlayerEntity(this));

         ThreadLocalRandom.current().nextInt(11);
      } else {
         vec3d = null;
      }

      return vec3d;
   }

   private boolean checkCondition3() {
      return this.checkCondition12();
   }

   public static DoubleSetting getShieldDrainMaxCPSSetting(AutoMaceModule autoMaceModule) {
      return autoMaceModule.shieldDrainMaxCPSSetting;
   }

   private void updateState4(int intState52, boolean booleanValue) {
      if (!booleanValue && this.equals2()) {
         if (getPlayerEntity(this) != null) {
            if (getPlayerEntity(this).isAlive()) {
               if (!FriendManager.testPlayerEntity(getPlayerEntity(this))) {
                  if (!(mc.player.squaredDistanceTo(getPlayerEntity(this)) > this.computeDouble2() * this.computeDouble2())) {
                     if (this.testPlayerEntity2(getPlayerEntity(this))) {
                        label77:
                        if (intState52 != -1) {
                           if (this.equals3()) {
                              if (!this.testPlayerEntity(this.playerEntity)) {
                                 break label77;
                              }
                           } else {
                              ThreadLocalRandom.current().nextInt(3);
                           }

                           setIntState9(this, intState52);
                           setIntState(this, intState52);
                           this.intState5 = intState52;
                           if (this.checkCondition3()) {
                              Vec3d vec3d = this.computeVec3dForEntity(this.playerEntity);

                              this.updateStateForVec3d2(vec3d, ActionPriority.HIGH, true);
                           }

                           ThreadLocalRandom.current().nextInt(15);
                           setBooleanState(this, ((this.checkCondition9() && this.checkCondition13() ? 1 : 0) != 0));
                           return;
                        } else {
                           ThreadLocalRandom.current().nextInt(13);
                        }
                     }
                  }
               }
            }
         }

         this.updateState12();
      } else {
         this.updateState12();
      }
   }

   public static int getSelectedSlot2(AutoMaceModule autoMaceModule) {
      return autoMaceModule.selectedSlot2;
   }

   public static int getIntState(AutoMaceModule autoMaceModule) {
      return autoMaceModule.intState;
   }

   public static int getIntState7(AutoMaceModule autoMaceModule) {
      return autoMaceModule.intState7;
   }

   private void updateState5() {
      setIntState7(this, getIntState7(this) - 1);
      double doubleValue = this.computeDouble2();
      if (getPlayerEntity(this) != null && getPlayerEntity(this).isAlive()) {
         if ((double)mc.player.distanceTo(this.playerEntity) <= doubleValue) {
            if (this.checkCondition3()) {
               Vec3d vec3d = this.computeVec3dForEntity(getPlayerEntity(this));
               this.updateStateForVec3d(vec3d, ActionPriority.HIGH);
            }
         }
      }

      if (this.intState7 <= 0) {
         this.updateState18();
         this.updateState12();
      }
   }

   public static int getIntState9(AutoMaceModule autoMaceModule) {
      return autoMaceModule.intState9;
   }

   public static void setIntState9(AutoMaceModule autoMaceModule, int intState92) {
      autoMaceModule.intState9 = intState92;
   }

   private int computeInt() {
      return this.computeInt4(false);
   }

   private void updateState6() {
      if (MinecraftClientAccess38.getPlayer(mc) != null && mc.world != null) {
         if (!this.checkCondition12()) {
            RotationManager.updateState9(this);
         }

         if (!getBooleanState6(this)) {
            if (this.checkCondition()) {
               this.updateState12();
            } else {
               boolean onGround = mc.player.isOnGround();
               this.doubleState = onGround ? MinecraftClientAccess38.getPlayer(mc).getY() : Math.max(this.doubleState, MinecraftClientAccess38.getPlayer(mc).getY());
               setBooleanState8(this, onGround);
               int intState52 = this.computeInt5();
               boolean booleanValue = mc.player.getMainHandStack().getItem() instanceof MaceItem;
               int intValue2 = !booleanValue && intState52 == -1 ? 0 : 1;
               if (intValue2 == 0) {
                  this.updateState12();
               } else {
                  if (this.weaponOnlySetting.isOn()) {
                     if (!this.checkCondition6()) {
                        this.updateState12();
                        return;
                     }
                  }

                  if (this.booleanState7) {
                     this.updateState4(intState52, onGround);
                  } else if (getIntState7(this) > 0) {
                     this.updateState5();
                  } else if (this.intState3 > 0) {
                     this.updateState13();
                  } else if ((double)(System.currentTimeMillis() - getTimestampMillis(this)) < getCooldownMsSetting(this).getValue()) {
                  } else {
                     if (getPlayerEntity(this) == null || !getPlayerEntity(this).isAlive() || FriendManager.testPlayerEntity(getPlayerEntity(this)) || MinecraftClientAccess38.getPlayer(mc).squaredDistanceTo(getPlayerEntity(this)) > this.computeDouble2() * this.computeDouble2()) {
                        setPlayerEntity(this, this.computePlayerEntity());
                        getAttackRangeTimer(this).reset();
                     }

                     if (this.playerEntity == null) {
                        this.updateState12();
                     } else {
                        if (this.equals3()) {
                           if (!this.testPlayerEntity(getPlayerEntity(this))) {
                              this.updateState12();
                              return;
                           }

                           ThreadLocalRandom.current().nextInt(9);
                        }

                        if (!this.attackRangeTimer.advanceAndCheckLimit(getPlayerEntity(this), this.initialHitDelaySetting.getValue())) {
                           byte byteValue;
                           label199: {
                              if (!onGround) {
                                 double y = MinecraftClientAccess38.getY(mc.player.getVelocity());

                                 if (y < ((-1.0E-4))) {
                                    byteValue = 1;
                                    break label199;
                                 }
                              }

                              byteValue = 0;
                           }

                           byte byteValue2 = byteValue;
                           int intValue3 = byteValue2 != 0 && this.checkCondition2() && MinecraftClientAccess38.getPlayer(mc).fallDistance >= getMinFallDistSetting(this).getValue() ? 1 : 0;
                           if (intValue3 == 0 && getMinFallDistSetting(this).getValue() > 0.1) {
                              this.updateState12();
                           } else {
                              boolean booleanValue2 = this.testPlayerEntity3(getPlayerEntity(this));
                              if (!booleanValue2) {
                                 this.playerEntity2 = null;
                              } else {
                                 byteValue = 14;
                                 ThreadLocalRandom.current().nextInt(11);
                                 if (getPlayerEntity(this) != getPlayerEntity2(this)) {
                                    setPlayerEntity2(this, this.playerEntity);
                                    setBooleanState5(this, ((this.equals() && !this.humanizedRandom.checkCondition(getShieldSlamChanceSetting(this).getValue() / 100.0) ? 0 : 1) != 0));
                                 }
                              }

                              int intValue4 = booleanValue2 && getBooleanState5(this) ? 1 : 0;
                              MochiClient.INSTANCE.getMochiEventBus().post(new AutoMaceSyncEvent());
                              if (intValue4 != 0) {
                                 this.updateState10();
                              } else {
                                 this.updateState7();
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private void updateState7() {
      double doubleValue = this.computeDouble2();
      if (this.playerEntity != null && this.playerEntity.isAlive()) {
         if (!((double)mc.player.distanceTo(this.playerEntity) > doubleValue)) {
            Vec3d vec3d = this.computeVec3dForEntity(getPlayerEntity(this));
            if (this.checkCondition3()) {
               this.updateStateForVec3d(vec3d, ActionPriority.HIGH);
            }

            if (this.checkCondition9()) {
               if (this.checkCondition2()) {
                  if (this.checkCondition7()) {
                     int intState10;
                     int selectedSlot22 = intState10 = this.computeInt5();

                     if (selectedSlot22 != -1) {
                        selectedSlot22 = getSelectedSlot2(this);

                        if (selectedSlot22 == -1) {
                           this.selectedSlot2 = mc.player.getInventory().getSelectedSlot();
                        }

                        setBooleanState2(this, true);
                        this.intState = intState10;
                     }
                  }
               }
            }

            return;
         }
      }

      this.updateState12();
   }

   public static void setLongState2(AutoMaceModule autoMaceModule, long longState22) {
      autoMaceModule.longState2 = longState22;
   }

   private boolean testEntity(Entity entity, double doubleValue) {
      if (mc.player != null) {
         if (entity != null) {
            Vec3d eyePos = MinecraftClientAccess38.getPlayer(mc).getEyePos();
            Box boundingBox = entity.getBoundingBox();
            double doubleValue2 = MathHelper.clamp(MinecraftClientAccess38.getX(eyePos), MinecraftClientAccess38.getMinX(boundingBox), MinecraftClientAccess38.getMaxX(boundingBox));
            double doubleValue3 = MathHelper.clamp(MinecraftClientAccess38.getY(eyePos), MinecraftClientAccess38.getMinY(boundingBox), boundingBox.maxY);
            double doubleValue4 = MathHelper.clamp(eyePos.z, boundingBox.minZ, MinecraftClientAccess38.getMaxZ(boundingBox));

            double doubleValue5 = Math.max((0.0), doubleValue);
            return (eyePos.squaredDistanceTo(doubleValue2, doubleValue3, doubleValue4) <= doubleValue5 * doubleValue5);
         }

         ThreadLocalRandom.current().nextInt(12);
      }

      return false;
   }

   public static BooleanSetting getBooleanSetting(AutoMaceModule autoMaceModule) {
      return autoMaceModule.booleanSetting;
   }

   private void updateStateForVec3d2(Vec3d vec3d, ActionPriority actionPriority, boolean booleanValue) {
      if (MinecraftClientAccess38.getPlayer(mc) == null) {
      } else if (!this.checkCondition8()) {
         RotationManager.updateState(this);
      } else {
         ThreadLocalRandom.current().nextInt(8);
         if (!booleanValue) {
            if (getPlayerEntity(this) != null) {
               ThreadLocalRandom.current().nextInt(8);
               if (this.testEntity4(this.playerEntity, this.computeDouble())) {
                  RotationManager.updateState9(this);
                  return;
               }

               ThreadLocalRandom.current().nextInt(15);
            } else {
               ThreadLocalRandom.current().nextInt(3);
            }
         }

         if (this.equals3()) {
            Supplier supplier = () -> this.computeVec3d2();

            RotationManager.updateStateForActionPriority(this, actionPriority, supplier, this.computeRotationProfile(true));
         } else {
            Supplier supplier2 = () -> this.computeVec3d();

            RotationManager.updateStateForActionPriority(this, actionPriority, supplier2, this.computeRotationProfile(false));
         }
      }
   }

   public static boolean getBooleanState6(AutoMaceModule autoMaceModule) {
      return autoMaceModule.booleanState6;
   }

   private boolean testPlayerEntity2(PlayerEntity playerEntity3) {
      if (playerEntity3 != null) {
         if (playerEntity3.getMainHandStack().getItem() instanceof ShieldItem) {
            return true;
         }

         if (playerEntity3.getOffHandStack().getItem() instanceof ShieldItem) {
            return true;
         }

         ThreadLocalRandom.current().nextInt(17);
      }

      return false;
   }

   public static void setBooleanState7(AutoMaceModule autoMaceModule, boolean booleanState72) {
      autoMaceModule.booleanState7 = booleanState72;
   }

   private void updateState8() {
      if ((this.isEnabled())) {
         CombatActionCoordinator.updateState();
         ShieldDrainEvent shieldDrainEvent = new ShieldDrainEvent();
         MinecraftClientAccess38.getINSTANCE().getMochiEventBus().post(shieldDrainEvent);
         if (!shieldDrainEvent.isActive()) {
            label46: {
               setBooleanState2(this, false);
               this.booleanState = false;
               this.booleanState4 = false;
               this.intState = -1;
               this.updateState6();
               if (!getBooleanState2(this)) {
                  if (!this.booleanState) {
                     if (!this.booleanState4 && !this.checkCondition4()) {
                        break label46;
                     }
                  }
               }

               CombatActionCoordinator.checkCondition2();
            }
         }
      }
   }

   private boolean checkCondition4() {
      if (!this.booleanState6) {
         if (!this.booleanState3 && !getBooleanState7(this)) {
            ThreadLocalRandom.current().nextInt(4);
            if (this.intState3 <= 0) {
               if (getIntState7(this) <= 0) {
                  return false;
               }
            }
         }
      } else {
         ThreadLocalRandom.current().nextInt(4);
      }

      return true;
   }

   private int computeInt2() {
      int intValue = this.computeInt3();
      if (intValue != -1) {
         return intValue;
      } else {
         int intValue2 = 0;

         do {
            ItemStack stack = MinecraftClientAccess38.getPlayer(mc).getInventory().getStack(intValue2);
            if (stack.isIn(ItemTags.AXES)) {
               ThreadLocalRandom.current().nextInt(4);
               return intValue2;
            }
         } while (++intValue2 < 9);

         return -1;
      }
   }

   public static double getDoubleState(AutoMaceModule autoMaceModule) {
      return autoMaceModule.doubleState;
   }

   private boolean checkCondition5() {
      if (getIntState22(this) < 0) {
         ThreadLocalRandom.current().nextInt(16);

         if (!this.booleanState) {
            if (!getBooleanState4(this)) {
               if (getIntState32(this) <= 0) {
                  return false;
               }
            }
         }
      }

      return true;
   }

   public static void setBooleanState(AutoMaceModule autoMaceModule, boolean booleanState9) {
      autoMaceModule.booleanState = booleanState9;
   }

   public static boolean getBooleanState5(AutoMaceModule autoMaceModule) {
      return autoMaceModule.booleanState5;
   }

   public static ChoiceSetting getAimModeSetting(AutoMaceModule autoMaceModule) {
      return autoMaceModule.aimModeSetting;
   }

   private boolean checkCondition6() {
      if (mc.player == null) {
         ThreadLocalRandom.current().nextInt(6);
         return false;
      } else {
         ItemStack mainHandStack = MinecraftClientAccess38.getPlayer(mc).getMainHandStack();
         if (!(mainHandStack.getItem() instanceof MaceItem)) {
            ThreadLocalRandom.current().nextInt(15);
            if (!mainHandStack.isIn(MinecraftClientAccess38.getSPEARS())) {
               if (!mainHandStack.isIn(ItemTags.AXES)) {
                  if (!mainHandStack.isIn(MinecraftClientAccess38.getSWORDS())) {
                     return false;
                  }
               }
            }
         }

         return true;
      }
   }

   private double computeDouble() {
      if (this.checkCondition10()) {
         return (4.5);
      } else {
         return 3.0;
      }
   }

   private Vec3d computeVec3dForEntity(Entity entity) {
      if (entity != null) {
         if (mc.player != null) {
            Box boundingBox = entity.getBoundingBox();
            Vec3d center = boundingBox.getCenter();
            double doubleValue = boundingBox.minY + (double)entity.getHeight() * 0.65;
            return new Vec3d(center.x, doubleValue, MinecraftClientAccess38.getZ(center));
         }
      } else {
         ThreadLocalRandom.current().nextInt(3);
      }

      return MinecraftClientAccess38.getZERO();
   }

   private int computeIntForDoubleRangeSetting(DoubleRangeSetting doubleRangeSetting) {
      int intValue = (int)Math.round(doubleRangeSetting.getLowerValue2());
      int intValue2 = (int)Math.round(doubleRangeSetting.getUpperValue3());
      if (intValue2 <= 0) {
         return 0;
      } else {
         if (intValue == intValue2) {
         return intValue2;
      } else {
         return this.humanizedRandom.computeInt2(intValue, intValue2 + 1);
      }
      }
   }

   private void updateState9() {
      if (getPlayerEntity(this) != null) {
         if (!this.checkCondition14()) {
            ThreadLocalRandom.current().nextInt(12);
         } else {
            if (this.checkCondition7()) {
               boolean booleanValue = AttackActions.testMinecraftClient(mc, "combat.attack.automace");
               if (booleanValue) {
                  MinecraftClientAccess38.getINSTANCE().getMochiEventBus().post(new MaceHitEvent());
                  setIntState3(this, 1);
                  setLongState2(this, System.currentTimeMillis());
                  this.longState = 0L;
                  setIntState8(this, this.computeIntForDoubleRangeSetting(this.shieldSlamTicksSetting));
               } else {
                  this.updateState18();
                  this.intState5 = -1;
               }
            }
         }
      }
   }

   private void updateState10() {
      double doubleValue = this.computeDouble2();
      if ((double)mc.player.distanceTo(this.playerEntity) > doubleValue) {
         this.updateState12();
         this.playerEntity = null;

         setIntState3(this, 0);
         setIntState5(this, -1);
      } else {
         Vec3d vec3d = this.computeVec3dForEntity(this.playerEntity);
         if (this.checkCondition3()) {
            this.updateStateForVec3d(vec3d, ActionPriority.HIGH);
         }

         boolean booleanValue = this.equals2();
         if (this.checkCondition9()) {
            if (booleanValue) {
               if (!this.checkCondition13()) {
                  return;
               }
            } else {
               if (!this.checkCondition7()) {
                  return;
               }
            }

            if (booleanValue) {
               int intState53 = this.computeInt5();

               if (intState53 != -1) {
                  if (!mc.player.isOnGround()) {
                     if (getSelectedSlot2(this) == -1) {
                        this.selectedSlot2 = MinecraftClientAccess38.getPlayer(mc).getInventory().getSelectedSlot();
                        this.rateAccumulator.reset();
                     }

                     this.booleanState7 = true;
                     this.intState9 = intState53;

                     this.booleanState = true;
                     this.intState = intState53;
                     setIntState5(this, intState53);
                  }
               }

               return;
            }

            if (getAxeOnlySetting(this).isOn()) {
               if (!(MinecraftClientAccess38.getPlayer(mc).getMainHandStack().getItem() instanceof AxeItem)) {
                  return;
               }
            }

            int intState10 = this.computeInt2();
            int intState52 = this.computeInt();
            if (intState10 != -1 && intState52 != -1) {
               if (getSelectedSlot2(this) == -1) {
                  setSelectedSlot2(this, mc.player.getInventory().getSelectedSlot());
               }

               if (getIntState22(this) < 0) {
                  setIntState22(this, this.computeIntForDoubleRangeSetting(getShieldSlamTicksSetting(this)));
               }

               if (this.intState2 > 0) {
                  this.intState2--;
                  return;
               }

               setBooleanState(this, true);
               setIntState(this, intState10);
               this.intState5 = intState52;
            }
         }
      }
   }

   private boolean testEntity2(Entity entity) {
      HitResult crosshairTarget = mc.crosshairTarget;
      if (crosshairTarget instanceof EntityHitResult) {
         if (((EntityHitResult)crosshairTarget).getEntity() == entity) {
            return true;
         }
      }

      return false;
   }

   private int computeInt3() {
      int intValue = 0;

      while (true) {
         if (intValue >= 9) {
            return -1;
         }

         ThreadLocalRandom.current().nextInt(15);
         if (mc.player.getInventory().getStack(intValue).getItem() instanceof AxeItem) {
            return intValue;
         }

         intValue++;
      }
   }

   public static void setIntState6(AutoMaceModule autoMaceModule, int intState62) {
      autoMaceModule.intState6 = intState62;
   }

   private boolean equals2() {
      return getShieldBreakSetting(this).equals("Shield Drain");
   }

   private RotationProfile computeRotationProfile(boolean booleanState32) {
      boolean silentAim = getAimModeSetting(this).equals("Silent");
      double doubleValue = getAimSpeedSetting(this).getValue() * 60.0;
      double doubleValue2 = 0.45;
      if (silentAim) {
         ThreadLocalRandom.current().nextInt(17);
         doubleValue *= 1.5;

         doubleValue2 = Math.min((1.0), 0.75);
      }

      RotationProfile rotationProfile = RotationProfile.createRotationProfile().withMaxRotationSpeed(doubleValue).computeRotationProfile10(doubleValue2);

      return rotationProfile.computeRotationProfile3((0.3)).withSilentAim(silentAim).computeRotationProfile2(booleanState32);
   }

   public static void setBooleanState6(AutoMaceModule autoMaceModule, boolean booleanState62) {
      autoMaceModule.booleanState6 = booleanState62;
   }

   private boolean testEntity3(Entity entity, double doubleValue) {
      Vec3d eyePos = MinecraftClientAccess38.getPlayer(mc).getEyePos();
      Vec3d center = entity.getBoundingBox().getCenter();
      double doubleValue2 = MinecraftClientAccess38.getX(center) - eyePos.x;
      double doubleValue3 = center.z - MinecraftClientAccess38.getZ(eyePos);
      double doubleValue4 = doubleValue2 * doubleValue2 + doubleValue3 * doubleValue3;

      if (doubleValue4 <= (1.0E-6)) {
         return true;
      } else {
         float floatValue = (float)Math.toDegrees(Math.atan2(doubleValue3, doubleValue2)) - 90.0F;
         byte byteValue;
         if ((double)Math.abs(MathHelper.wrapDegrees(MinecraftClientAccess38.getPlayer(mc).getYaw() - floatValue)) <= doubleValue) {
            byteValue = 1;
         } else {
            ThreadLocalRandom.current().nextInt(13);

            byteValue = 0;
         }

         return (byteValue != 0);
      }
   }

   public static boolean getBooleanState7(AutoMaceModule autoMaceModule) {
      return autoMaceModule.booleanState7;
   }

   public static DoubleSetting getMinFallDistSetting(AutoMaceModule autoMaceModule) {
      return autoMaceModule.minFallDistSetting;
   }

   private boolean testEntity4(Entity entity, double doubleValue) {
      if (mc.player != null) {
         if (entity != null) {
            if ((double)MinecraftClientAccess38.getPlayer(mc).distanceTo(entity) > doubleValue) {
               return false;
            }

            String selected = this.stopAimSetting.getSelected();
            if (selected.equals("Exact Center")) {
               if (this.equals3()) {
                  if (!this.testEntity2(entity)) {
                     return false;
                  }
               }

               return this.testEntity5(entity);
            }

            return this.testEntity6(entity);
         }
      }

      return false;
   }

   private int computeInt4(boolean booleanValue) {
      double doubleValue = Math.max(Math.max(0.0, getDoubleState(this) - mc.player.getY()), MinecraftClientAccess38.getPlayer(mc).fallDistance);
      int intValue;
      if (doubleValue >= this.densityHeightSetting.getValue()) {
         intValue = (((byte)10));
         ThreadLocalRandom.current().nextInt(9);

         intValue = 1;
      } else {
         intValue = 0;
      }

      byte intValue10 = (byte)intValue;
      int intValue52 = -1;
      int intValue82 = -1;

      intValue = -848845724;

      int intValue92 = -1;

      int intValue5 = 0;

      while (true) {
         if (intValue5 >= 9) {
            return intValue52;
         }

         ItemStack stack = MinecraftClientAccess38.getPlayer(mc).getInventory().getStack(intValue5);
         label74:
         if (stack.getItem() instanceof MaceItem) {
            int intValue6 = this.computeIntForItemStack2(stack);
            int intValue7 = this.computeIntForItemStack(stack, "breach");
            if (!booleanValue) {
               if (intValue7 > 0) {
                  break label74;
               }
            }

            int intValue8 = intValue10 != 0 ? intValue6 : intValue7;
            int intValue9 = intValue10 != 0 ? intValue7 : intValue6;
            if (intValue8 > intValue82 || intValue8 == intValue82 && intValue9 > intValue92) {
               intValue82 = intValue8;
               intValue92 = intValue9;
               intValue52 = intValue5;
            }
         }

         intValue5++;
      }
   }

   public static CombatTargetTracker getCombatTargetTracker(AutoMaceModule autoMaceModule) {
      return autoMaceModule.combatTargetTracker;
   }

   private boolean equals3() {
      return getAimModeSetting(this).equals("Horizontal");
   }

   private double computeDouble2() {
      double doubleValue;
      if (this.checkCondition12()) {
         doubleValue = Math.max(this.aimRangeSetting.getValue(), this.computeDouble());

         ThreadLocalRandom.current().nextInt(9);
      } else {
         doubleValue = this.computeDouble();
      }

      return doubleValue;
   }

   public static int getIntState5(AutoMaceModule autoMaceModule) {
      return autoMaceModule.intState5;
   }

   public static void setIntState7(AutoMaceModule autoMaceModule, int intState72) {
      autoMaceModule.intState7 = intState72;
   }

   public static void setSelectedSlot2(AutoMaceModule autoMaceModule, int selectedSlot22) {
      autoMaceModule.selectedSlot2 = selectedSlot22;
   }

   private void updateState11() {
      if (mc.player == null) {
         setBooleanState6(this, false);
      } else {
         setIntState6(this, this.intState6 - 1);
         if (getIntState6(this) == 1) {
            ThreadLocalRandom.current().nextInt(3);
            KeyBindingAccessor useKey = (KeyBindingAccessor)MinecraftClientAccess38.getUseKey(MinecraftClientAccess38.getOptions(mc));
            useKey.setTimesPressed(useKey.getTimesPressed() + 1);
         }

         if (this.intState6 <= 0) {
            if (this.intState4 != -1) {
               MinecraftClientAccess38.getPlayer(mc).getInventory().setSelectedSlot(this.intState4);
            }

            setBooleanState6(this, false);

            this.intState4 = -1;
         }
      }
   }

   private int computeInt5() {
      return this.computeInt4(!this.densityOnlySetting.isOn());
   }

   @EventHandler
   private void onDisconnect(DisconnectEvent disconnectEvent) {
      this.updateState14();
   }

   public static void setPlayerEntity2(AutoMaceModule autoMaceModule, PlayerEntity playerEntity22) {
      autoMaceModule.playerEntity2 = playerEntity22;
   }

   public static void setIntState22(AutoMaceModule autoMaceModule, int intState22) {
      autoMaceModule.intState2 = intState22;
   }

   public static void setPlayerEntity(AutoMaceModule autoMaceModule, PlayerEntity playerEntity3) {
      autoMaceModule.playerEntity = playerEntity3;
   }

   private void updateState12() {
      if (getBooleanState7(this)) {
         byte byteValue;
         label49: {
            if (MinecraftClientAccess38.getPlayer(mc) != null && getIntState9(this) >= 0) {
               if (getIntState9(this) < 9) {
                  byteValue = 13;
                  ThreadLocalRandom.current().nextInt(9);

                  if (MinecraftClientAccess38.getPlayer(mc).getInventory().getSelectedSlot() == getIntState9(this)) {
                     byteValue = 1;
                     break label49;
                  }
               }
            }

            byteValue = 0;
         }

         byte byteValue2 = byteValue;
         this.booleanState7 = false;
         setIntState9(this, -1);
         if (byteValue2 != 0) {
            this.updateState18();
         } else {
            this.selectedSlot2 = -1;
         }
      } else {
         ThreadLocalRandom.current().nextInt(13);
      }

      RotationManager.updateState9(this);
      setPlayerEntity(this, null);
      this.intState3 = 0;
      setBooleanState2(this, false);
      setBooleanState(this, false);
      this.booleanState4 = false;

      setIntState(this, -1);
      this.intState5 = -1;
      this.booleanState3 = false;

      setLongState3(this, (0L));
      this.updateState15();
      getAttackRangeTimer(this).reset();
      setPlayerEntity2(this, null);
   }

   private boolean checkCondition7() {
      if (MinecraftClientAccess38.getPlayer(mc) != null) {
         if (this.playerEntity != null) {
            if (!AttackActions.testMinecraftClient3(mc)) {
               return false;
            }

            double doubleValue = this.computeDouble();
            if (MinecraftClientAccess38.getPlayer(mc).canSee(this.playerEntity)) {
               if (this.testEntity(this.playerEntity, doubleValue)) {
                  HitResult crosshairTarget2 = MinecraftClientAccess38.getCrosshairTarget(mc);
                  if (this.checkCondition10()) {
                     if (crosshairTarget2 == null || !(crosshairTarget2 instanceof EntityHitResult)) {
                        crosshairTarget2 = BlockInteractUtils.computeHitResult(RotationManager.computeFloat2(), RotationManager.computeFloat7(), doubleValue);
                     }
                  }

                  if (crosshairTarget2 instanceof EntityHitResult) {
                     if (((EntityHitResult)crosshairTarget2).getEntity() == this.playerEntity) {
                        return true;
                     }
                  }

                  return false;
               }
            }

            return false;
         }

         ThreadLocalRandom.current().nextInt(15);
      }

      return false;
   }

   public static DoubleSetting getShieldDrainMinCPSSetting(AutoMaceModule autoMaceModule) {
      return autoMaceModule.shieldDrainMinCPSSetting;
   }

   private void updateState13() {
      double doubleValue = this.computeDouble2();
      if (getPlayerEntity(this) != null && this.playerEntity.isAlive()) {
         if (!((double)MinecraftClientAccess38.getPlayer(mc).distanceTo(this.playerEntity) > doubleValue)) {
            Vec3d vec3d = this.computeVec3dForEntity(this.playerEntity);
            if (this.checkCondition3()) {
               this.updateStateForVec3d2(vec3d, ActionPriority.HIGHEST, true);
            }

            if (this.intState8 > 0) {
               this.intState8--;
               return;
            }

            long longState5 = System.currentTimeMillis();
            int intValue = this.checkCondition9() && this.checkCondition2() && this.checkCondition7() ? 1 : 0;
            if (intValue != 0) {
               this.longState = (0L);

               this.booleanState4 = true;
               setIntState(this, getIntState5(this));
               return;
            }

            long longState4 = getLongState(this);

            if (longState4 == (0L)) {
               setLongState(this, longState5);
            }

            longState4 = longState5 - getLongState(this);

            if (longState4 <= 150L) {
               longState4 = longState5 - this.longState2;

               if (longState4 <= 500L) {
                  return;
               }
            }

            this.updateState18();
            setIntState3(this, 0);
            setIntState5(this, -1);
            this.updateState12();

            return;
         }
      }

      this.updateState18();
      this.intState3 = 0;
      this.intState5 = -1;
      this.updateState12();
   }

   public static int getIntState22(AutoMaceModule autoMaceModule) {
      return autoMaceModule.intState2;
   }

   private boolean testPlayerEntity3(PlayerEntity playerEntity3) {
      if (playerEntity3 != null) {
         if (playerEntity3.isUsingItem()) {
            ThreadLocalRandom.current().nextInt(6);
            if (playerEntity3.getActiveItem().getItem() instanceof ShieldItem) {
               return true;
            }
         }
      }

      return false;
   }

   public static void setIntState8(AutoMaceModule autoMaceModule, int intState82) {
      autoMaceModule.intState8 = intState82;
   }

   private Vec3d computeVec3dForEntity2(Entity entity) {
      if (entity == null) {
         ThreadLocalRandom.current().nextInt(17);

         return MinecraftClientAccess38.getZERO();
      } else {
         if (getStopAimSetting(this).getSelected().equals("Exact Center")) {
            return entity.getBoundingBox().getCenter();
         } else {
            Box boundingBox = entity.getBoundingBox();
            Vec3d center = boundingBox.getCenter();
            Vec3d eyePos = mc.player.getEyePos();
            double doubleValue = Math.max(boundingBox.getLengthX() * 0.5, 0.001);
            double doubleValue2 = boundingBox.getLengthY();

            doubleValue2 *= (0.5);

            double doubleValue3 = Math.max(doubleValue2, (0.001));
            doubleValue2 = boundingBox.getLengthZ();

            double doubleValue4 = Math.max(doubleValue2 * (0.5), 0.001);
            double doubleValue5 = MinecraftClientAccess38.getX(eyePos) - center.x;
            if (this.equals3()) {
               doubleValue2 = 0.0;
            } else {
               doubleValue2 = MinecraftClientAccess38.getY(eyePos) - center.y;
            }

            double doubleValue22 = doubleValue2;
            double doubleValue7 = eyePos.z - MinecraftClientAccess38.getZ(center);
            double doubleValue8 = Math.max(Math.abs(doubleValue5) / doubleValue, Math.max(Math.abs(doubleValue22) / doubleValue3, Math.abs(doubleValue7) / doubleValue4));

            if (doubleValue8 < (0.001)) {
               return this.computeVec3dForEntity(entity);
            } else {
               return new Vec3d(MinecraftClientAccess38.getX(center) + doubleValue5 / doubleValue8 * 1.0, center.y + doubleValue22 / doubleValue8 * 1.0, MinecraftClientAccess38.getZ(center) + doubleValue7 / doubleValue8 * 1.0);
            }
         }
      }
   }

   private boolean testEntity5(Entity entity) {
      if (mc.player != null) {
         if (entity != null) {
            Vec3d center = entity.getBoundingBox().getCenter();
            float[] floatArray = RotationManager.computeFloatArrayForVec3d(center, RotationManager.computeFloat2());
            float floatValue = Math.abs(MathHelper.wrapDegrees(RotationManager.computeFloat2() - floatArray[0]));
            if (this.equals3()) {
               return (floatValue <= 1.0F);
            }

            float floatValue2 = Math.abs(MathHelper.wrapDegrees(RotationManager.computeFloat7() - floatArray[1]));
            if (floatValue <= 1.0F) {
               if (floatValue2 <= (1.0F)) {
                  return true;
               }
            }

            return false;
         }
      } else {
         ThreadLocalRandom.current().nextInt(4);
      }

      return false;
   }

   public static AttackRangeTimer getAttackRangeTimer(AutoMaceModule autoMaceModule) {
      return autoMaceModule.attackRangeTimer;
   }

   public static boolean getBooleanState2(AutoMaceModule autoMaceModule) {
      return autoMaceModule.booleanState2;
   }

   private void updateState14() {
      this.updateState12();
      setSelectedSlot2(this, -1);
      this.intState5 = -1;

      setIntState9(this, -1);
      setBooleanState7(this, false);
      this.updateState15();
   }

   public static void setBooleanState2(AutoMaceModule autoMaceModule, boolean booleanState22) {
      autoMaceModule.booleanState2 = booleanState22;
   }

   private void updateState15() {
      setIntState22(this, -1);
      setIntState8(this, 0);
      setLongState(this, 0L);
      this.rateAccumulator.reset();
   }

   public static void setBooleanState8(AutoMaceModule autoMaceModule, boolean booleanState82) {
      autoMaceModule.booleanState8 = booleanState82;
   }

   public static long getTimestampMillis(AutoMaceModule autoMaceModule) {
      return autoMaceModule.timestampMillis;
   }

   private boolean checkCondition8() {
      if (this.checkCondition12()) {
         if (!this.aimWhileGlidingSetting.isOn()) {
            if (this.checkCondition11()) {
               return false;
            }
         } else {
            ThreadLocalRandom.current().nextInt(13);
         }

         return true;
      } else {
         return false;
      }
   }

   public AutoMaceModule() {
      super("Auto Mace", "Automatically swaps maces for attacks.", ModuleCategory.COMBAT);

      this.aimRangeSetting = new DoubleSetting("Aim Range", (1.0), (10.0), (5.0), 0.1);

      this.densityOnlySetting = new BooleanSetting("Density Only", false);

      String[] stringArray = new String[4];

      stringArray[0] = "None";
      stringArray[1] = "Horizontal";

      stringArray[2] = "Horizontal + Vertical";
      stringArray[3] = "Silent";
      this.aimModeSetting = new ChoiceSetting("Aim Mode", "Horizontal + Vertical", stringArray);
      this.aimWhileGlidingSetting = new BooleanSetting("Aim while gliding", false);
      this.triggerWhileGlidingSetting = new BooleanSetting("Trigger while gliding", false);

      this.swapBackSetting = new BooleanSetting("Swap Back", true);

      this.aimSpeedSetting = new DoubleSetting("Aim Speed", (0.0), (50.0), (10.0), 0.1);

      this.minFallDistSetting = new DoubleSetting("Min Fall Dist", 0.0, (5.0), (3.0), 0.1);

      this.cooldownMsSetting = new DoubleSetting("Cooldown (ms)", 100.0, 2000.0, (505.0), 1.0);
      String[] stringArray2 = new String[2];

      stringArray2[0] = "Shield Slam";
      stringArray2[1] = "Shield Drain";
      this.shieldBreakSetting = new ChoiceSetting("Shield Break", "Shield Slam", stringArray2);
      this.weaponOnlySetting = new BooleanSetting("Weapon Only", true);
      String[] stringArray3 = new String[2];

      stringArray3[0] = "Hitbox Edge";

      stringArray3[1] = "Exact Center";
      this.stopAimSetting = new ChoiceSetting("Stop Aim", "Hitbox Edge", stringArray3);

      this.shieldSlamTicksSetting = new DoubleRangeSetting("Shield Slam Ticks", 0.0, 20.0, 2.0, (4.0), 1.0);

      this.shieldSlamChanceSetting = new DoubleSetting("Shield Slam Chance", 0.0, 100.0, (100.0), 1.0);

      this.axeOnlySetting = new BooleanSetting("Axe Only", false);

      this.shieldDrainMinCPSSetting = new DoubleSetting("Shield Drain Min CPS", 1.0, (50.0), (45.0), 1.0);

      this.shieldDrainMaxCPSSetting = new DoubleSetting("Shield Drain Max CPS", 1.0, 50.0, (50.0), (1.0));

      this.initialHitDelaySetting = new DoubleSetting("Initial Hit Delay", 0.0, 5.0, (0.0), 1.0);

      this.maceFOVSetting = new DoubleSetting("Mace FOV", (10.0), 360.0, (360.0), (1.0));

      this.densityHeightSetting = new DoubleSetting("Density Height", 1.0, 15.0, 6.0, (0.1));
      this.booleanSetting = CombatTargetTracker.createBooleanSetting();
      this.combatTargetTracker = new CombatTargetTracker();
      this.attackRangeTimer = new AttackRangeTimer();
      this.humanizedRandom = new HumanizedRandom();
      this.rateAccumulator = new RateAccumulator();
      this.intState2 = -1;
      this.intState8 = 0;
      this.playerEntity = null;
      this.playerEntity2 = null;
      this.booleanState5 = true;
      this.intState3 = 0;

      this.intState5 = -1;
      this.selectedSlot2 = -1;
      this.timestampMillis = 0L;

      this.longState2 = (0L);
      this.longState = 0L;

      this.intState7 = 0;

      this.doubleState = (0.0);
      this.booleanState8 = true;

      this.booleanState2 = false;

      this.booleanState = false;

      this.booleanState4 = false;
      this.booleanState7 = false;
      this.intState9 = -1;
      this.intState = -1;
      this.booleanState6 = false;

      this.intState6 = 0;

      this.intState4 = -1;
      this.booleanState3 = false;
      this.longState3 = 0L;
      this.addSetting(this.aimModeSetting);
      this.addSetting(this.aimWhileGlidingSetting);
      this.addSetting(this.triggerWhileGlidingSetting);
      this.addSetting(this.aimRangeSetting);
      this.addSetting(this.aimSpeedSetting);
      this.addSetting(this.stopAimSetting);
      this.addSetting(this.maceFOVSetting);
      this.addSetting(this.minFallDistSetting);
      this.addSetting(this.cooldownMsSetting);
      this.addSetting(this.initialHitDelaySetting);
      this.addSetting(this.swapBackSetting);
      this.addSetting(this.densityHeightSetting);
      this.addSetting(this.densityOnlySetting);
      this.addSetting(this.shieldBreakSetting);
      this.shieldSlamTicksSetting.setVisibility(() -> this.equals());
      this.addSetting(this.shieldSlamTicksSetting);
      this.shieldSlamChanceSetting.setVisibility(() -> this.equals());
      this.addSetting(this.shieldSlamChanceSetting);
      this.axeOnlySetting.setVisibility(() -> this.equals());
      this.addSetting(this.axeOnlySetting);
      this.shieldDrainMinCPSSetting.setVisibility(() -> this.equals2());
      this.shieldDrainMaxCPSSetting.setVisibility(() -> this.equals2());
      this.addSetting(this.shieldDrainMinCPSSetting);
      this.addSetting(this.shieldDrainMaxCPSSetting);
      this.addSetting(this.weaponOnlySetting);
      this.aimWhileGlidingSetting.setVisibility(() -> this.checkCondition12());
      this.aimRangeSetting.setVisibility(() -> this.checkCondition12());
      this.aimSpeedSetting.setVisibility(() -> this.checkCondition12());
      this.maceFOVSetting.setVisibility(() -> this.checkCondition12());
      this.stopAimSetting.setVisibility(() -> this.checkCondition12());
      this.addSetting(this.booleanSetting);
   }

   private boolean checkCondition9() {
      if (!this.triggerWhileGlidingSetting.isOn()) {
         if (this.checkCondition11()) {
            return false;
         }
      }

      ThreadLocalRandom.current().nextInt(13);
      return true;
   }

   @Override
   public void onDisable() {
      CombatActionCoordinator.updateState();
      this.rateAccumulator.reset();
      this.updateState12();
      this.combatTargetTracker.updateState();
      if (this.swapBackSetting.isOn()) {
         if (MinecraftClientAccess38.getPlayer(mc) != null) {
            if (this.selectedSlot2 >= 0) {
               if (getSelectedSlot2(this) < 9) {
                  ThreadLocalRandom.current().nextInt(7);

                  MinecraftClientAccess38.getPlayer(mc).getInventory().setSelectedSlot(getSelectedSlot2(this));
               } else {
                  ThreadLocalRandom.current().nextInt(11);
               }
            }
         } else {
            ThreadLocalRandom.current().nextInt(9);
         }
      }

      this.selectedSlot2 = -1;
   }

   public static void setLongState3(AutoMaceModule autoMaceModule, long longState32) {
      autoMaceModule.longState3 = longState32;
   }

   public boolean checkCondition10() {
      if (MinecraftClientAccess38.getPlayer(mc) != null) {
         if (!this.checkCondition5() && !this.testPlayerEntity3(getPlayerEntity(this))) {
            if (this.selectedSlot2 >= 0) {
               if (getSelectedSlot2(this) < 9) {
                  return MinecraftClientAccess38.getPlayer(mc).getInventory().getStack(this.selectedSlot2).isIn(MinecraftClientAccess38.getSPEARS());
               }
            }

            return mc.player.getMainHandStack().isIn(ItemTags.SPEARS);
         }
      }

      return false;
   }

   private boolean checkCondition11() {
      if (MinecraftClientAccess38.getPlayer(mc) != null) {
         if (mc.player.isGliding()) {
            return true;
         }
      }

      return false;
   }

   private void updateState16() {
      if (this.booleanState7) {
         if (mc.player != null) {
            if (!mc.player.isOnGround() && this.playerEntity != null) {
               if (this.playerEntity.isAlive()) {
                  if (this.testPlayerEntity2(getPlayerEntity(this))) {
                     if (!this.checkCondition14()) {
                        return;
                     }

                     double doubleValue22 = Math.min(this.shieldDrainMinCPSSetting.getValue(), getShieldDrainMaxCPSSetting(this).getValue());
                     double doubleValue32 = Math.max(getShieldDrainMinCPSSetting(this).getValue(), getShieldDrainMaxCPSSetting(this).getValue());
                     double doubleValue3 = doubleValue32 - doubleValue22 < 0.5 ? doubleValue32 : getHumanizedRandom(this).computeDouble5(doubleValue22, doubleValue32);
                     int intValue = this.rateAccumulator.accumulate(doubleValue3);
                     if (getBooleanState(this)) {
                        ThreadLocalRandom.current().nextInt(5);
                        if (this.checkCondition13()) {
                           for (int intValue2 = 0; intValue2 < intValue; intValue2++) {
                              InventorySynchronization.updateStateForMinecraftClient(mc);
                           }

                           return;
                        }

                        ThreadLocalRandom.current().nextInt(15);
                     }

                     return;
                  }
               }
            }
         } else {
            ThreadLocalRandom.current().nextInt(15);
         }
      }

      this.updateState12();
   }

   public static ChoiceSetting getStopAimSetting(AutoMaceModule autoMaceModule) {
      return autoMaceModule.stopAimSetting;
   }

   private boolean checkCondition12() {
      return (!this.aimModeSetting.equals("None"));
   }

   private void updateState17(int intValue) {
      if (mc.player != null) {
         if (intValue != -1) {
            if (getBooleanState6(this)) {
               return;
            }

            setIntState42(this, MinecraftClientAccess38.getPlayer(mc).getInventory().getSelectedSlot());
            MinecraftClientAccess38.getPlayer(mc).getInventory().setSelectedSlot(intValue);
            this.booleanState6 = true;

            setIntState6(this, 3);
            return;
         }
      } else {
         ThreadLocalRandom.current().nextInt(3);
      }
   }

   @EventHandler
   private void onRender2D(Render2DEvent render2DEvent) {
      this.updateState8();
   }

   private boolean checkCondition13() {
      if (MinecraftClientAccess38.getPlayer(mc) != null) {
         ThreadLocalRandom.current().nextInt(6);

         if (this.playerEntity != null) {
            if (this.playerEntity.isAlive()) {
               double doubleValue = this.computeDouble();
               if (mc.player.canSee(this.playerEntity)) {
                  if (this.testEntity(getPlayerEntity(this), doubleValue)) {
                     HitResult crosshairTarget = mc.crosshairTarget;
                     if (crosshairTarget instanceof EntityHitResult) {
                        if (((EntityHitResult)crosshairTarget).getEntity() == this.playerEntity) {
                           return true;
                        }
                     }

                     return false;
                  }

                  ThreadLocalRandom.current().nextInt(10);
               }

               return false;
            }
         }
      }

      return false;
   }

   public static void setLongState(AutoMaceModule autoMaceModule, long longState4) {
      autoMaceModule.longState = longState4;
   }

   public static DoubleSetting getShieldSlamChanceSetting(AutoMaceModule autoMaceModule) {
      return autoMaceModule.shieldSlamChanceSetting;
   }

   public static void setBooleanState32(AutoMaceModule autoMaceModule, boolean booleanState32) {
      autoMaceModule.booleanState3 = booleanState32;
   }

   private boolean checkCondition14() {
      if (mc.player == null) {
         return false;
      } else {
         if (getIntState(this) >= 0) {
            if (this.intState <= 8) {
               int selectedSlot = mc.player.getInventory().getSelectedSlot();
               if (selectedSlot != getIntState(this)) {
                  MinecraftClientAccess38.getPlayer(mc).getInventory().setSelectedSlot(getIntState(this));
               }

               return true;
            }
         }

         return true;
      }
   }

   private Vec3d computeVec3d2() {
      if (MinecraftClientAccess38.getPlayer(mc) != null) {
         if (getPlayerEntity(this) != null) {
            Vec3d vec3d = this.computeVec3dForEntity2(getPlayerEntity(this));
            return new Vec3d(MinecraftClientAccess38.getX(vec3d), mc.player.getEyeY(), MinecraftClientAccess38.getZ(vec3d));
         }
      }

      return null;
   }

   public static void setIntState42(AutoMaceModule autoMaceModule, int intState42) {
      autoMaceModule.intState4 = intState42;
   }

   public static BooleanSetting getAxeOnlySetting(AutoMaceModule autoMaceModule) {
      return autoMaceModule.axeOnlySetting;
   }

   @Override
   public boolean shouldBlockAttackInput() {
      return false;
   }

   public static DoubleRangeSetting getShieldSlamTicksSetting(AutoMaceModule autoMaceModule) {
      return autoMaceModule.shieldSlamTicksSetting;
   }

   public static void setBooleanState5(AutoMaceModule autoMaceModule, boolean booleanState52) {
      autoMaceModule.booleanState5 = booleanState52;
   }

   private boolean testEntity6(Entity entity) {
      return this.testEntity2(entity);
   }

   @EventHandler
   private void onWorldChange(WorldChangeEvent worldChangeEvent) {
      if (worldChangeEvent.getWorld() != MinecraftClientAccess38.getWorld(mc)) {
         ThreadLocalRandom.current().nextInt(16);
         this.updateState14();
      } else {
         ThreadLocalRandom.current().nextInt(14);
      }
   }

   public static DoubleSetting getMaceFOVSetting(AutoMaceModule autoMaceModule) {
      return autoMaceModule.maceFOVSetting;
   }

   private void updateState18() {
      if (this.swapBackSetting.isOn()) {
         if (this.selectedSlot2 >= 0) {
            int selectedSlot22 = getSelectedSlot2(this);

            if (selectedSlot22 <= 8) {
               mc.player.getInventory().setSelectedSlot(this.selectedSlot2);
               this.selectedSlot2 = -1;
               return;
            }
         }
      }

      this.selectedSlot2 = -1;
   }

   @EventHandler(
      priority = 100
   )
   private void onTickEvent(TickEvent tickEvent) {
      this.updateState8();
      if ((this.isEnabled())) {
         if (this.booleanState6) {
            this.updateState11();
         } else if (this.booleanState3) {
            ThreadLocalRandom.current().nextInt(16);

            if (System.currentTimeMillis() >= this.longState3) {
               setBooleanState32(this, false);
               this.updateState18();
               this.updateState12();
            }
         } else {
            if (this.booleanState7) {
               if (this.equals2()) {
                  this.updateState16();
                  return;
               }
            }

            if (getBooleanState(this)) {
               this.updateState2();
            } else {
               if (getBooleanState4(this)) {
                  this.updateState();
               } else {
                  if (getBooleanState2(this)) {
                     this.updateState3();
                  }
               }
            }
         }
      }
   }

   public static int getIntState32(AutoMaceModule autoMaceModule) {
      return autoMaceModule.intState3;
   }

   private int computeIntForItemStack2(ItemStack itemStack) {
      if (itemStack.isEmpty()) {
         return 0;
      } else {
         ItemEnchantmentsComponent itemEnchantmentsComponent = (ItemEnchantmentsComponent)itemStack.get(MinecraftClientAccess38.getENCHANTMENTS());
         if (itemEnchantmentsComponent == null) {
            return 0;
         } else {
            for (RegistryEntry registryEntry : itemEnchantmentsComponent.getEnchantments()) {
               if (registryEntry.getKey().isPresent()) {
                  if (((RegistryKey)registryEntry.getKey().get()).getValue().getPath().contains("density")) {
                     return itemEnchantmentsComponent.getLevel(registryEntry);
                  }
               }
            }

            return 0;
         }
      }
   }
}
