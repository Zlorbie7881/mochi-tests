package cc.mochi;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.util.math.Direction;

public class InteractionDirectionSwitchMap {
   static final int[] intArray3 = new int[Direction.values().length];

   static {
      label66: {
         try {
            int[] intArray = intArray3;
            int intValue = Direction.UP.ordinal();

            intArray[intValue] = 1;
         } catch (NoSuchFieldError failure) {
            break label66;
         }
      }

      try {
         intArray3[Direction.DOWN.ordinal()] = 2;
      } catch (NoSuchFieldError failure2) {
      }

      label61: {
         try {
            intArray3[Direction.NORTH.ordinal()] = 3;
         } catch (NoSuchFieldError failure3) {
            break label61;
         }
      }

      try {
         intArray3[Direction.SOUTH.ordinal()] = 4;
      } catch (NoSuchFieldError failure4) {
      }

      ThreadLocalRandom.current().nextInt(4);

      label56: {
         try {
            intArray3[Direction.WEST.ordinal()] = 5;
         } catch (NoSuchFieldError failure5) {
            break label56;
         }
      }

      try {
         int[] intArray2 = intArray3;
         int intValue2 = Direction.EAST.ordinal();

         intArray2[intValue2] = 6;
      } catch (NoSuchFieldError failure6) {
      }
   }
}
