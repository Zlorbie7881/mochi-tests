package cc.mochi;

import org.jetbrains.annotations.NotNull;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

record MatrixSnapshot(Matrix4f positionMatrix, Matrix3f normalMatrix) {
   @NotNull
   @Override
   public String toString() {
      return "Entry[positionMatrix=" + this.positionMatrix + ", normalMatrix=" + this.normalMatrix + "]";
   }

   public Matrix4f getPositionMatrix() {
      return this.positionMatrix;
   }

   public Matrix3f getNormalMatrix() {
      return this.normalMatrix;
   }
}
