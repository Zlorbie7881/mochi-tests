package cc.mochi;

import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.util.math.Direction.AxisDirection;

public class BoxAccess2 {
   public static Axis getX6() {
      return Axis.X;
   }

   public static double getMinZ(Box box) {
      return box.minZ;
   }

   public static double getMinX(Box box) {
      return box.minX;
   }

   public static double getMaxZ(Box box) {
      return box.maxZ;
   }

   public static double getX(Vec3d vec3d) {
      return vec3d.x;
   }

   public static AxisDirection getPOSITIVE() {
      return AxisDirection.POSITIVE;
   }

   public static double getZ(Vec3d vec3d) {
      return vec3d.z;
   }

   public static double getY(Vec3d vec3d) {
      return vec3d.y;
   }

   public static double getMaxY(Box box) {
      return box.maxY;
   }

   public static double getMinY(Box box) {
      return box.minY;
   }

   public static Axis getY5() {
      return Axis.Y;
   }

   public static double getMaxX(Box box) {
      return box.maxX;
   }

}
