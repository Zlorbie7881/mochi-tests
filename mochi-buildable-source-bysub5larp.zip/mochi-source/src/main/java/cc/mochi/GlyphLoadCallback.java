package cc.mochi;

interface GlyphLoadCallback {
   void loadGlyph(StbFontRenderer stbFontRenderer, int intValue, float floatValue);
}
