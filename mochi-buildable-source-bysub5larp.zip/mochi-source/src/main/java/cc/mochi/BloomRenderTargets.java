package cc.mochi;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.Std140Builder;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import java.nio.ByteBuffer;
import java.util.OptionalInt;
import net.minecraft.client.gl.GlBackend;
import net.minecraft.client.gl.GpuSampler;
import org.lwjgl.system.MemoryStack;
import org.slf4j.Logger;
import org.slf4j.helpers.NOPLogger;

final class BloomRenderTargets {
   private int intState;
   private boolean booleanState;

   private final GpuTextureView[] gpuTextureViewArray;

   private final GpuTexture[] gpuTextureArray = new GpuTexture[6];

   private int intState2;
   private boolean booleanState2;

   private final GpuBuffer[] gpuBufferArray;
   private static final Logger logger = NOPLogger.NOP_LOGGER;
   private static final float[] floatArray = new float[]{1.0F, 0.92F, 0.82F, 0.7F, 0.58F};

   private boolean booleanState3;

   private static String getStringConstant() {
      return "Mochi bloom uniforms";
   }

   BloomRenderTargets() {
      this.gpuTextureViewArray = new GpuTextureView[6];
      this.gpuBufferArray = new GpuBuffer[12];
      this.booleanState = true;
   }

   GpuTextureView computeGpuTextureView(int intValue, int intValue2) {
      int intState3 = Math.max(1, intValue / 2);
      int intState22 = Math.max(1, intValue2 / 2);
      if (this.gpuTextureViewArray[0] == null || intState3 != this.intState || intState22 != this.intState2 || this.gpuTextureViewArray[0].isClosed()) {
         this.updateState3(intState3, intState22);
      }

      return this.gpuTextureViewArray[0];
   }

   boolean getBooleanState3() {
      return this.booleanState3;
   }

   private static String computeString(String string) {
      return string;
   }

   void updateStateForGpuTextureView(GpuTextureView gpuTextureView, float floatValue) {
      if (this.booleanState3) {
         this.booleanState3 = false;
         if (!(floatValue <= 0.001F) && this.gpuTextureViewArray[0] != null) {
            GpuDevice device = RenderSystem.getDevice();
            CommandEncoder commandEncoder = device.createCommandEncoder();
            GpuSampler gpuSampler = RenderSystem.getSamplerCache().get(FilterMode.LINEAR);

            for (int intValue = 1; intValue < 6; intValue++) {
               GpuTexture gpuTexture = this.gpuTextureArray[intValue - 1];
               this.updateStateForCommandEncoder2(commandEncoder, intValue - 1, 1.0F / (float)gpuTexture.getWidth(0), 1.0F / (float)gpuTexture.getHeight(0), 1.0F, 1.0F, 0.0F, 0.35F, 24.0F, floatValue, 5);
            }

            for (int intValue2 = 4; intValue2 >= 1; intValue2--) {
               GpuTexture gpuTexture2 = this.gpuTextureArray[intValue2 + 1];
               this.updateStateForCommandEncoder2(commandEncoder, 5 + intValue2, 1.0F / (float)gpuTexture2.getWidth(0), 1.0F / (float)gpuTexture2.getHeight(0), 1.0F, floatArray[intValue2 - 1], 0.0F, 0.0F, 0.0F, floatValue, 5);
            }

            this.updateStateForCommandEncoder2(commandEncoder, 11, 1.0F / (float)this.gpuTextureArray[1].getWidth(0), 1.0F / (float)this.gpuTextureArray[1].getHeight(0), 1.0F, 1.0F, 0.0F, 0.0F, 0.0F, floatValue, 4);

            for (int intValue3 = 1; intValue3 < 6; intValue3++) {
               updateStateForCommandEncoder(commandEncoder, intValue3 == 1 ? UiRenderPipelines.BLOOM_PREFILTER : UiRenderPipelines.BLOOM_DOWNSAMPLE, this.gpuTextureViewArray[intValue3], this.gpuBufferArray[intValue3 - 1], this.gpuTextureViewArray[intValue3 - 1], null, gpuSampler, "Mochi bloom down " + intValue3);
            }

            for (int intValue4 = 4; intValue4 >= 1; intValue4--) {
               updateStateForCommandEncoder(commandEncoder, UiRenderPipelines.BLOOM_UPSAMPLE, this.gpuTextureViewArray[intValue4], this.gpuBufferArray[5 + intValue4], this.gpuTextureViewArray[intValue4 + 1], null, gpuSampler, "Mochi bloom up " + intValue4);
            }

            updateStateForCommandEncoder(commandEncoder, UiRenderPipelines.BLOOM_COMPOSITE, gpuTextureView, this.gpuBufferArray[11], this.gpuTextureViewArray[1], this.gpuTextureViewArray[0], gpuSampler, "Mochi bloom composite");
         }
      }
   }

   private static void updateStateForCommandEncoder(
      CommandEncoder commandEncoder, RenderPipeline renderPipeline, GpuTextureView gpuTextureView, GpuBuffer gpuBuffer, GpuTextureView gpuTextureView2, GpuTextureView gpuTextureView3, GpuSampler gpuSampler, String string
   ) {
      RenderPass renderPass = commandEncoder.createRenderPass(() -> computeString(string), gpuTextureView, OptionalInt.empty());

      try {
         renderPass.setPipeline(renderPipeline);
         renderPass.setUniform("MochiBloom", gpuBuffer);
         renderPass.bindTexture("Source", gpuTextureView2, gpuSampler);
         if (gpuTextureView3 != null) {
            renderPass.bindTexture("Core", gpuTextureView3, gpuSampler);
         }

         renderPass.draw(0, 3);
      } catch (Throwable failure) {
         if (renderPass != null) {
            try {
               renderPass.close();
            } catch (Throwable failure2) {
               failure.addSuppressed(failure2);
            }
         }

         throw failure;
      }

      if (renderPass != null) {
         renderPass.close();
      }
   }

   private GpuTexture computeGpuTexture(String string, int intValue, int intValue2) {
      if (this.booleanState && RenderSystem.getDevice() instanceof GlBackend) {
         try {
            return HdrGlTexture.computeHdrGlTexture(string, intValue, intValue2);
         } catch (RuntimeException failure) {
            this.booleanState = false;
            if (!this.booleanState2) {
               this.booleanState2 = true;
               logger.warn("Half-float bloom targets are unavailable, using RGBA8: {}", failure.getMessage());
            }
         }
      }

      return RenderSystem.getDevice().createTexture(string, 15, TextureFormat.RGBA8, intValue, intValue2, 1, 1);
   }

   void updateState() {
      this.updateState2();

      for (int intValue = 0; intValue < this.gpuBufferArray.length; intValue++) {
         if (this.gpuBufferArray[intValue] != null) {
            this.gpuBufferArray[intValue].close();
         }

         this.gpuBufferArray[intValue] = null;
      }

      this.intState = 0;
      this.intState2 = 0;
      this.booleanState3 = false;
   }

   float computeFloat(int intValue) {
      return intValue <= 0 ? 0.5F : (float)this.intState / (float)intValue;
   }

   boolean checkCondition() {
      boolean booleanValue = !this.booleanState3;
      this.booleanState3 = true;
      return booleanValue;
   }

   private void updateStateForCommandEncoder2(CommandEncoder commandEncoder, int intValue, float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5, float floatValue6, float floatValue7, float floatValue8, int intValue2) {
      GpuBuffer buffer = this.gpuBufferArray[intValue];
      if (buffer == null || buffer.isClosed()) {
         buffer = RenderSystem.getDevice().createBuffer(() -> getStringConstant(), 136, 48L);
         this.gpuBufferArray[intValue] = buffer;
      }

      MemoryStack memoryStack = MemoryStack.stackPush();

      try {
         ByteBuffer byteBuffer = Std140Builder.onStack(memoryStack, 48)
            .putVec4(floatValue, floatValue2, floatValue3, floatValue4)
            .putVec4(floatValue5, floatValue6, floatValue7, 0.0F)
            .putVec4(floatValue8, 0.35F, (float)intValue2, 0.003921569F)
            .get();
         commandEncoder.writeToBuffer(buffer.slice(), byteBuffer);
      } catch (Throwable failure) {
         if (memoryStack != null) {
            try {
               memoryStack.close();
            } catch (Throwable failure2) {
               failure.addSuppressed(failure2);
            }
         }

         throw failure;
      }

      if (memoryStack != null) {
         memoryStack.close();
      }
   }

   private void updateState2() {
      for (int intValue = 0; intValue < 6; intValue++) {
         if (this.gpuTextureViewArray[intValue] != null) {
            this.gpuTextureViewArray[intValue].close();
         }

         if (this.gpuTextureArray[intValue] != null) {
            this.gpuTextureArray[intValue].close();
         }

         this.gpuTextureViewArray[intValue] = null;
         this.gpuTextureArray[intValue] = null;
      }
   }

   private void updateState3(int intState3, int intState22) {
      this.updateState2();
      this.intState = intState3;
      this.intState2 = intState22;
      int intState32 = intState3;
      int intState222 = intState22;

      for (int intValue3 = 0; intValue3 < 6; intValue3++) {
         this.gpuTextureArray[intValue3] = this.computeGpuTexture("Mochi bloom " + intValue3, intState32, intState222);
         this.gpuTextureViewArray[intValue3] = RenderSystem.getDevice().createTextureView(this.gpuTextureArray[intValue3]);
         intState32 = Math.max(1, intState32 / 2);
         intState222 = Math.max(1, intState222 / 2);
      }

      this.booleanState3 = false;
   }

   void resetBooleanState3() {
      this.booleanState3 = false;
   }
}
