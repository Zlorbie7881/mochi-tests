package cc.mochi;

import java.util.Random;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class HumanizedAimController {
   private final double[] doubleArray;

   private boolean booleanState;
   private double doubleState;
   private double doubleState2;

   private boolean booleanState2;

   private double z;

   private boolean booleanState3;
   private double doubleState3;

   private double doubleState4;

   private double doubleState5;

   private double doubleState6;

   private double doubleState7;

   private double doubleState8;

   private final double[] doubleArray2;

   private double doubleState9;

   private boolean booleanState4;

   private double doubleState10;

   private long longState;

   private double z2;
   private double doubleState11;

   private double y;

   private static final double doubleState12 = Math.PI * 2;

   private double doubleState13;

   private double doubleState14;
   private int counter;

   private double doubleState15;

   private double y2;

   private double x;

   private int counter2;

   private double doubleState16;

   private double doubleState17;

   private boolean booleanState5;

   private final Random random;

   private double doubleState18;

   private boolean booleanState6;

   private double doubleState19;
   private int intState;

   private double x2;

   private final FractalNoise fractalNoise = new FractalNoise();

   private double doubleState20;

   private final FractalNoise fractalNoise2 = new FractalNoise();

   private double doubleState21;

   private void updateState(float[] floatArray) {
      this.doubleArray[0] = (double)floatArray[0];
      this.doubleArray[1] = (double)floatArray[1];
   }

   public double[] computeDoubleArrayForVec3d(double doubleValue, double doubleValue2, Vec3d vec3d, Vec3d vec3d2, float floatValue, float floatValue2, float floatValue3) {
      if (this.booleanState2 && vec3d2 != null) {
         float[] floatArray = RotationMath.computeFloatArrayForVec3d(vec3d, vec3d2, floatValue);
         if (this.booleanState6) {
            this.updateState5(doubleValue, doubleValue2, floatArray, floatValue, floatValue2, floatValue3);
         } else {
            this.doubleArray2[0] = this.computeDouble4(doubleValue, (double)floatValue, (double)floatArray[0], true, floatValue3);
            this.doubleArray2[1] = this.booleanState5 ? 0.0 : this.computeDouble4(doubleValue2, (double)floatValue2, (double)floatArray[1], false, floatValue3);
         }

         this.doubleState20 = this.doubleState4 = this.doubleState15 = this.doubleState5 = 0.0;
         return this.doubleArray2;
      } else {
         return this.computeDoubleArray();
      }
   }

   private double computeDouble(double doubleValue, double doubleValue2, boolean booleanValue, double doubleValue3, float floatValue) {
      double doubleValue4 = RotationMath.computeDouble(doubleValue, doubleValue2, booleanValue);
      double doubleValue5 = Math.abs(doubleValue4);
      double doubleValue6 = booleanValue ? this.doubleState20 : this.doubleState4;
      double doubleValue7 = this.doubleState9 * this.doubleState * (booleanValue ? 1.0 : 0.9);
      double doubleValue8 = Math.min(this.doubleState17, 0.5 / doubleValue3);
      double doubleValue9 = Math.signum(doubleValue4) * Math.min(doubleValue7, doubleValue8 * doubleValue5);
      double doubleValue10 = 1.0 - Math.exp(-doubleValue8 * doubleValue3);
      doubleValue6 += (doubleValue9 - doubleValue6) * doubleValue10;
      double doubleValue42 = doubleValue6 * doubleValue3;
      if (Math.abs(doubleValue42) > doubleValue5) {
         doubleValue42 = doubleValue4;
         doubleValue6 = doubleValue4 / doubleValue3 * 0.45;
      }

      if (doubleValue5 <= Math.max(0.012, (double)floatValue * 0.5) && Math.abs(doubleValue42) <= (double)floatValue) {
         doubleValue6 *= 0.35;
         doubleValue42 = 0.0;
      }

      doubleValue42 = this.computeDouble7(doubleValue42, booleanValue, floatValue);
      this.updateState7(booleanValue, doubleValue6);
      return doubleValue42;
   }

   private void updateState2(long longValue, double doubleValue, double doubleValue2, double doubleValue3) {
      if (this.doubleState8 <= 0.0) {
         this.doubleState6 = 0.0;
         this.doubleState19 = 0.0;
         this.doubleState18 = 0.0;
         this.doubleState16 = 0.0;
      } else {
         if (!this.booleanState3 && Math.max(Math.abs(doubleValue2), Math.abs(doubleValue3)) > 6.0) {
            this.booleanState3 = true;
            if (this.random.nextDouble() < 0.25) {
               double doubleValue4 = 0.15 * this.doubleState8 * (0.2 + this.random.nextDouble());
               if (Math.abs(doubleValue2) >= Math.abs(doubleValue3)) {
                  this.doubleState18 = Math.signum(doubleValue2) * doubleValue4;
               } else {
                  this.doubleState16 = Math.signum(doubleValue3) * doubleValue4;
               }
            }
         }

         double doubleValue5 = (double)longValue * 0.001;
         double doubleValue6 = this.fractalNoise.sampleOctaves(doubleValue5 * this.doubleState3, 3);
         double doubleValue7 = this.fractalNoise2.sampleOctaves(doubleValue5 * this.doubleState7, 3);
         double doubleValue8 = Math.sin(doubleValue5 * (Math.PI * 2) * this.doubleState2 + this.doubleState11);
         double doubleState82 = this.doubleState8;
         this.doubleState6 = doubleState82 * (0.3 * doubleValue6 + 0.1 * doubleValue8) + this.doubleState18;
         this.doubleState19 = doubleState82 * (0.24 * doubleValue7 + 0.06 * doubleValue8) + this.doubleState16;
         double doubleValue9 = Math.exp(-doubleValue / 0.22);
         this.doubleState18 *= doubleValue9;
         this.doubleState16 *= doubleValue9;
      }
   }

   private void updateStateForVec3d(Vec3d vec3d, long longState2) {
      double doubleValue = (double)(longState2 - this.longState) / 1000.0;
      double doubleValue2 = vec3d.x - this.x2;
      double doubleValue3 = vec3d.y - this.y2;
      double doubleValue4 = vec3d.z - this.z;
      double doubleValue5 = Math.sqrt(doubleValue2 * doubleValue2 + doubleValue3 * doubleValue3 + doubleValue4 * doubleValue4);
      if (this.booleanState && !(doubleValue > 0.5) && !(doubleValue5 > 4.0)) {
         if (doubleValue > 1.0E-4) {
            double doubleValue6 = 1.0 - Math.exp(-doubleValue / 0.04);
            this.x = this.x + (vec3d.x - this.x) * doubleValue6;
            this.y = this.y + (vec3d.y - this.y) * doubleValue6;
            this.z2 = this.z2 + (vec3d.z - this.z2) * doubleValue6;
            double doubleValue7 = (vec3d.x - this.x2) / doubleValue;
            double doubleValue8 = (vec3d.y - this.y2) / doubleValue;
            double doubleValue9 = (vec3d.z - this.z) / doubleValue;
            double doubleValue10 = this.counter2 <= 1 ? 1.0 : 0.28;
            this.doubleState21 = this.doubleState21 + (doubleValue7 - this.doubleState21) * doubleValue10;
            this.doubleState13 = this.doubleState13 + (doubleValue8 - this.doubleState13) * doubleValue10;
            this.doubleState10 = this.doubleState10 + (doubleValue9 - this.doubleState10) * doubleValue10;
            this.counter2++;
         }

         this.x2 = vec3d.x;
         this.y2 = vec3d.y;
         this.z = vec3d.z;
         this.longState = longState2;
      } else {
         this.x = vec3d.x;
         this.y = vec3d.y;
         this.z2 = vec3d.z;
         this.x2 = vec3d.x;
         this.y2 = vec3d.y;
         this.z = vec3d.z;
         this.doubleState21 = 0.0;
         this.doubleState13 = 0.0;
         this.doubleState10 = 0.0;
         this.counter2 = 1;
         this.longState = longState2;
         this.booleanState = true;
      }
   }

   public void updateState3(boolean booleanValue) {
      this.doubleState20 = 0.0;
      this.doubleState4 = 0.0;
      this.doubleState15 = 0.0;
      this.doubleState5 = 0.0;
      this.doubleState6 = 0.0;
      this.doubleState19 = 0.0;
      this.doubleState18 = 0.0;
      this.doubleState16 = 0.0;
      this.booleanState3 = false;
      this.doubleState = 1.0;
      this.updateState4();
      this.counter = 0;
      this.intState = 0;
      if (booleanValue) {
         this.booleanState = false;
         this.counter2 = 0;
         this.doubleState21 = 0.0;
         this.doubleState13 = 0.0;
         this.doubleState10 = 0.0;
      }
   }

   public void updateStateForRotationProfile(RotationProfile rotationProfile) {
      this.doubleState9 = rotationProfile.getMaxRotationSpeed();
      this.doubleState17 = 5.0 + 25.0 * rotationProfile.getDoubleState4();
      this.booleanState5 = rotationProfile.getBooleanState3();
      this.booleanState2 = rotationProfile.getBooleanState();
      this.booleanState4 = rotationProfile.getBooleanState2();
      this.booleanState6 = rotationProfile.getBooleanState4();
      this.doubleState14 = rotationProfile.getDoubleState2();
      if (Math.abs(rotationProfile.getDoubleState() - this.doubleState8) > 1.0E-6) {
         this.doubleState8 = rotationProfile.getDoubleState();
         this.updateState4();
      }
   }

   public HumanizedAimController(Random random2) {
      this.doubleState9 = 360.0;
      this.doubleState17 = 5.0;
      this.doubleState8 = 0.0;
      this.doubleState14 = 0.0;
      this.booleanState5 = false;
      this.booleanState2 = false;
      this.booleanState4 = true;
      this.booleanState6 = false;
      this.doubleState = 1.0;
      this.doubleArray2 = new double[2];
      this.doubleArray = new double[2];
      this.random = random2;
      this.updateState4();
   }

   public double[] computeDoubleArrayForVec3d2(
      double doubleValue,
      double doubleValue2,
      double doubleValue3,
      double doubleValue4,
      double doubleValue5,
      Vec3d vec3d,
      float floatValue,
      float floatValue2,
      boolean booleanValue,
      float floatValue3,
      long longState2,
      double doubleValue6
   ) {
      if (this.booleanState2 && !booleanValue) {
         return this.computeDoubleArray();
      } else {
         double doubleValue7 = Math.max(doubleValue6, 0.05) * 0.016666666666666666;
         double doubleValue8;
         double floatValue22;
         if (vec3d != null) {
            this.updateStateForVec3d2(doubleValue3, doubleValue4, doubleValue5, vec3d, doubleValue, doubleValue2, longState2);
            doubleValue8 = this.doubleArray[0];
            floatValue22 = this.doubleArray[1];
         } else {
            if (!booleanValue) {
               return this.computeDoubleArray();
            }

            doubleValue8 = (double)RotationMath.computeFloat(floatValue, (float)doubleValue);
            floatValue22 = (double)floatValue2;
         }

         double doubleValue10 = RotationMath.computeDouble(doubleValue, doubleValue8, true);
         double doubleValue11 = RotationMath.computeDouble(doubleValue2, floatValue22, false);
         this.updateState6(doubleValue7);
         this.updateState2(longState2, doubleValue7, doubleValue10, doubleValue11);
         doubleValue8 += this.doubleState6;
         floatValue22 += this.doubleState19;
         this.doubleArray2[0] = this.computeDouble(doubleValue, doubleValue8, true, doubleValue7, floatValue3);
         this.doubleArray2[1] = this.booleanState5 ? 0.0 : this.computeDouble(doubleValue2, floatValue22, false, doubleValue7, floatValue3);
         return this.doubleArray2;
      }
   }

   private void updateStateForVec3d2(double doubleValue, double doubleValue2, double doubleValue3, Vec3d vec3d, double doubleValue4, double doubleValue5, long longState2) {
      if (!this.booleanState4) {
         this.updateState(RotationMath.computeFloatArray(doubleValue, doubleValue2, doubleValue3, vec3d.x, vec3d.y, vec3d.z, (float)doubleValue4));
      } else {
         this.updateStateForVec3d(vec3d, longState2);
         double x3 = this.x;
         double y3 = this.y;
         double z22 = this.z2;
         this.updateState(RotationMath.computeFloatArray(doubleValue, doubleValue2, doubleValue3, x3, y3, z22, (float)doubleValue4));
         if (!(this.doubleState14 <= 0.0) && this.counter2 >= 3) {
            double doubleValue6 = Math.sqrt(this.doubleState21 * this.doubleState21 + this.doubleState13 * this.doubleState13 + this.doubleState10 * this.doubleState10);
            if (!(doubleValue6 < 0.35)) {
               double doubleValue7 = 0.08 * this.doubleState14;
               double doubleValue8 = this.doubleState21 * doubleValue7;
               double doubleValue9 = this.doubleState13 * doubleValue7 * 0.5;
               double doubleValue10 = this.doubleState10 * doubleValue7;
               double doubleValue11 = Math.sqrt(doubleValue8 * doubleValue8 + doubleValue9 * doubleValue9 + doubleValue10 * doubleValue10);
               if (doubleValue11 > 1.0) {
                  double doubleValue12 = 1.0 / doubleValue11;
                  doubleValue8 *= doubleValue12;
                  doubleValue9 *= doubleValue12;
                  doubleValue10 *= doubleValue12;
               }

               this.updateState(RotationMath.computeFloatArray(doubleValue, doubleValue2, doubleValue3, x3 + doubleValue8, y3 + doubleValue9, z22 + doubleValue10, (float)doubleValue4));
            }
         }
      }
   }

   private static double computeDouble2(double doubleValue, float floatValue) {
      return floatValue > 0.0F ? Math.floor(doubleValue / (double)floatValue) * (double)floatValue : doubleValue;
   }

   private void updateState4() {
      this.doubleState3 = 0.1 + this.random.nextDouble() * 0.15;
      this.doubleState7 = 0.1 + this.random.nextDouble() * 0.15;
      this.doubleState2 = 0.6 + this.random.nextDouble();
      this.doubleState11 = this.random.nextDouble() * (Math.PI * 2);
   }

   private void updateState5(double doubleValue, double doubleValue2, float[] floatArray, float floatValue, float floatValue2, float floatValue3) {
      double doubleValue3 = computeDouble2(this.doubleState9 * 0.05, floatValue3);
      double doubleValue4 = computeDouble2(this.doubleState9 * 0.05 * 0.9, floatValue3);
      double doubleValue5 = RotationMath.computeDouble((double)floatValue, (double)floatArray[0], true);
      double doubleValue6 = this.booleanState5 ? 0.0 : RotationMath.computeDouble((double)floatValue2, (double)floatArray[1], false);
      int intState2 = Math.max(computeInt(doubleValue5, doubleValue3, floatValue3), computeInt(doubleValue6, doubleValue4, floatValue3));
      if (intState2 > 1 && intState2 <= this.intState - 1) {
         this.counter++;
      } else {
         this.counter = 0;
      }

      this.intState = intState2;
      double doubleValue7 = intState2 <= 1 ? 1.0 : computeDouble8(this.counter, this.counter + intState2);
      this.doubleArray2[0] = this.computeDouble6(doubleValue, (double)floatValue, doubleValue5, doubleValue3, doubleValue7, intState2, true, floatValue3);
      this.doubleArray2[1] = this.booleanState5 ? 0.0 : this.computeDouble6(doubleValue2, (double)floatValue2, doubleValue6, doubleValue4, doubleValue7, intState2, false, floatValue3);
   }

   private void updateState6(double doubleValue) {
      double doubleValue2 = 0.012 + 0.02 * this.doubleState8;
      this.doubleState = MathHelper.clamp(this.doubleState + this.random.nextGaussian() * doubleValue2 * Math.sqrt(doubleValue), 0.9, 1.1);
   }

   private static double computeDouble3(double doubleValue) {
      doubleValue = MathHelper.clamp(doubleValue, 0.0, 1.0);
      return doubleValue * doubleValue * (3.0 - 2.0 * doubleValue);
   }

   private double computeDouble4(double doubleValue, double doubleValue2, double doubleValue3, boolean booleanValue, float floatValue) {
      double doubleValue4 = this.doubleState9 * 0.05 * (booleanValue ? 1.0 : 0.9);
      double doubleValue5 = RotationMath.computeDouble(doubleValue2, doubleValue3, booleanValue);
      double doubleValue6 = MathHelper.clamp(doubleValue5, -doubleValue4, doubleValue4);
      if (floatValue > 0.0F) {
         long longValue = (long)Math.floor(doubleValue4 / (double)floatValue);
         long longValue2 = Math.max(-longValue, Math.min(longValue, Math.round(doubleValue6 / (double)floatValue)));
         doubleValue6 = (double)longValue2 * (double)floatValue;
      }

      return RotationMath.computeDouble(doubleValue, doubleValue2 + doubleValue6, booleanValue);
   }

   private double computeDouble5(double doubleValue, double doubleValue2, double doubleValue3, double doubleValue72, double doubleValue73, boolean booleanValue, int intValue, double doubleValue6) {
      for (int intValue2 = 0; intValue2 < 32; intValue2++) {
         double doubleValue7 = (doubleValue72 + doubleValue73) * 0.5;
         double doubleValue4 = doubleValue;
         double doubleValue32 = doubleValue3;
         double doubleValue10 = Math.min(this.doubleState17, 0.5 / doubleValue6);
         double doubleValue11 = 1.0 - Math.exp(-doubleValue10 * doubleValue6);
         double doubleValue12 = this.doubleState9 * this.doubleState * (booleanValue ? 1.0 : 0.9);

         for (int intValue3 = 0; intValue3 < intValue; intValue3++) {
            double doubleValue13 = doubleValue7 - doubleValue4;
            double doubleValue14 = Math.signum(doubleValue13) * Math.min(doubleValue12, doubleValue10 * Math.abs(doubleValue13));
            doubleValue32 += (doubleValue14 - doubleValue32) * doubleValue11;
            double doubleValue132 = doubleValue32 * doubleValue6;
            if (Math.abs(doubleValue132) > Math.abs(doubleValue13)) {
               doubleValue132 = doubleValue13;
               doubleValue32 = doubleValue13 / doubleValue6 * 0.45;
            }

            doubleValue4 += doubleValue132;
         }

         if (doubleValue4 < doubleValue2) {
            doubleValue72 = doubleValue7;
         } else {
            doubleValue73 = doubleValue7;
         }
      }

      return (doubleValue72 + doubleValue73) * 0.5;
   }

   private double computeDouble6(double doubleValue, double doubleValue2, double doubleValue3, double doubleValue4, double doubleValue5, int intValue, boolean booleanValue, float floatValue) {
      double doubleValue6 = Math.abs(doubleValue3);
      if (!(doubleValue6 <= 0.0) && !(doubleValue4 <= 0.0)) {
         double doubleValue7 = Math.max(0.0, doubleValue6 - (double)(intValue - 1) * doubleValue4 - (floatValue > 0.0F ? (double)floatValue * 0.5 : 0.0));
         double doubleValue8 = Math.min(Math.min(doubleValue4, doubleValue6), Math.max(doubleValue6 * doubleValue5, doubleValue7));
         double doubleValue9;
         if (floatValue > 0.0F) {
            long longValue = Math.round(doubleValue4 / (double)floatValue);
            long longValue2 = Math.round(doubleValue6 / (double)floatValue);
            long longValue22;
            if (intValue <= 1) {
               longValue22 = longValue2;
            } else {
               long longValue4 = (long)Math.ceil(doubleValue7 / (double)floatValue - 1.0E-9);
               longValue22 = Math.min(longValue2, Math.max(Math.round(doubleValue8 / (double)floatValue), longValue4));
            }

            longValue22 = Math.max(0L, Math.min(longValue, longValue22));
            doubleValue9 = Math.copySign((double)longValue22 * (double)floatValue, doubleValue3);
         } else {
            doubleValue9 = Math.copySign(doubleValue8, doubleValue3);
         }

         return RotationMath.computeDouble(doubleValue, doubleValue2 + doubleValue9, booleanValue);
      } else {
         return RotationMath.computeDouble(doubleValue, doubleValue2, booleanValue);
      }
   }

   private static int computeInt(double doubleValue, double doubleValue2, float floatValue) {
      double doubleValue3 = Math.abs(doubleValue);
      double doubleValue4 = floatValue > 0.0F ? (double)floatValue * 0.5 : 0.0;
      return !(doubleValue3 <= Math.max(doubleValue4, 1.0E-4)) && !(doubleValue2 <= 0.0) ? Math.max(1, (int)Math.ceil((doubleValue3 - doubleValue4) / doubleValue2 - 1.0E-6)) : 0;
   }

   private double[] computeDoubleArray() {
      this.doubleArray2[0] = 0.0;
      this.doubleArray2[1] = 0.0;
      return this.doubleArray2;
   }

   public float[] computeFloatArray(float floatValue, float floatValue2, float floatValue3, float floatValue4, double doubleValue, double doubleValue2) {
      double doubleValue3 = MathHelper.clamp(doubleValue2, 8.333333333333334E-4, 0.05);
      int intValue = Math.max(1, Math.min(120, (int)Math.round(doubleValue / doubleValue3)));
      return new float[]{
         (float)this.computeDouble5((double)floatValue, (double)RotationMath.computeFloat(floatValue3, floatValue), this.doubleState20, (double)floatValue - 179.9, (double)floatValue + 179.9, true, intValue, doubleValue3),
         (float)this.computeDouble5((double)floatValue2, (double)floatValue4, this.doubleState4, ((-90.0)), 90.0, false, intValue, doubleValue3)
      };
   }

   private double computeDouble7(double doubleValue, boolean booleanValue, float floatValue) {
      if (floatValue <= 0.0F) {
         return doubleValue;
      } else {
         double doubleValue2 = booleanValue ? (this.doubleState15 += doubleValue) : (this.doubleState5 += doubleValue);
         if (Math.abs(doubleValue2) < 1.0E-5) {
            return 0.0;
         } else {
            long longValue = Math.round(doubleValue2 / (double)floatValue);
            if (longValue != 0L) {
               double doubleValue3 = (booleanValue ? 0.05 : 0.03) + (booleanValue ? 0.45 : 0.3) * this.doubleState8;
               if (this.random.nextDouble() < doubleValue3) {
                  longValue += this.random.nextBoolean() ? 1L : -1L;
               }
            }

            double doubleValue4 = (double)longValue * (double)floatValue;
            if (booleanValue) {
               this.doubleState15 = doubleValue2 - doubleValue4;
            } else {
               this.doubleState5 = doubleValue2 - doubleValue4;
            }

            return doubleValue4;
         }
      }
   }

   private void updateState7(boolean booleanValue, double doubleValue) {
      if (booleanValue) {
         this.doubleState20 = doubleValue;
      } else {
         this.doubleState4 = doubleValue;
      }
   }

   private static double computeDouble8(int intValue, int intValue2) {
      double doubleValue = computeDouble3((double)intValue / (double)intValue2);
      double doubleValue2 = computeDouble3((double)(intValue + 1) / (double)intValue2);
      return doubleValue >= 1.0 ? 1.0 : (doubleValue2 - doubleValue) / (1.0 - doubleValue);
   }
}
