package cc.mochi;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public record BlockPlacementPlan(BlockPos cell, BlockPos support, Direction face, boolean plannedSupport) {
   public boolean getPlannedSupport2() {
      return getPlannedSupport(this);
   }

   public static boolean getPlannedSupport(BlockPlacementPlan blockPlacementPlan) {
      return blockPlacementPlan.plannedSupport;
   }

   public static BlockPos getSupport(BlockPlacementPlan blockPlacementPlan) {
      return blockPlacementPlan.support;
   }

   public Direction getFace() {
      return this.face;
   }

   public static BlockPos getCell(BlockPlacementPlan blockPlacementPlan) {
      return blockPlacementPlan.cell;
   }

   public BlockPos getSupport2() {
      return getSupport(this);
   }

   public BlockPos getCell2() {
      return getCell(this);
   }
}
