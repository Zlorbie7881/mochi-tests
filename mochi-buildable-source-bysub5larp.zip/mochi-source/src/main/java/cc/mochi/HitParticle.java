package cc.mochi;

import net.minecraft.util.math.Vec3d;

public final class HitParticle {
   final float floatState;

   Vec3d vec3d;

   final long longState;
   Vec3d vec3d2;
   final float floatState2;
   final float floatState3;

   HitParticle(Vec3d vec3d22, Vec3d vec3d3, long longState2, float floatState4, float floatState22, float floatState32) {
      this.vec3d2 = vec3d22;
      this.vec3d = vec3d3;
      this.longState = longState2;
      this.floatState = floatState4;
      this.floatState2 = floatState22;
      this.floatState3 = floatState32;
   }
}
