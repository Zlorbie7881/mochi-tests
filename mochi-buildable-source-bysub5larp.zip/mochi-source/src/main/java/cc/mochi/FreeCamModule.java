package cc.mochi;

import cc.mochi.event.impl.network.DisconnectEvent;
import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.event.impl.world.WorldChangeEvent;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.option.Perspective;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class FreeCamModule extends Module {
   private double doubleState;
   private static FreeCamModule freeCamModule;

   private Perspective perspective;

   private boolean booleanState;
   private final DoubleSetting speedSetting;

   private double doubleState2;

   private final BooleanSetting holdModeSetting;

   private double z;

   private double doubleState3;

   private float pitch;

   private double doubleState4;

   private float yaw;

   private double doubleState5;

   public static boolean getBooleanState(FreeCamModule freeCamModule2) {
      return freeCamModule2.booleanState;
   }

   public static double getDoubleState5(FreeCamModule freeCamModule2) {
      return freeCamModule2.doubleState5;
   }

   public static double getDoubleState3(FreeCamModule freeCamModule2) {
      return freeCamModule2.doubleState3;
   }

   public static float getPitch(FreeCamModule freeCamModule2) {
      return freeCamModule2.pitch;
   }

   @Override
   public void onEnable() {
      if (!(this.isWorldUnavailable())) {
         Vec3d eyePos = PerspectiveAccess.getPlayer(mc).getEyePos();
         setDoubleState(this, eyePos.x);
         setDoubleState3(this, eyePos.y);
         this.z = PerspectiveAccess.getZ(eyePos);
         this.doubleState5 = this.doubleState;
         this.doubleState2 = getDoubleState3(this);
         setDoubleState4(this, this.z);
         this.yaw = mc.player.getYaw();
         this.pitch = mc.player.getPitch();
         PerspectiveAccess.getPlayer(mc).setVelocity(PerspectiveAccess.getZERO());
         this.perspective = PerspectiveAccess.getOptions(mc).getPerspective();
         if (this.perspective != PerspectiveAccess.getFIRST_PERSON()) {
            mc.options.setPerspective(PerspectiveAccess.getFIRST_PERSON());
         }

         this.booleanState = true;
      }
   }

   public double computeDouble(float floatValue) {
      return getDoubleState5(this) + (getDoubleState(this) - getDoubleState5(this)) * (double)floatValue;
   }

   public static double getDoubleState4(FreeCamModule freeCamModule2) {
      return freeCamModule2.doubleState4;
   }

   public double computeDouble2(float floatValue) {
      return getDoubleState4(this) + (this.z - getDoubleState4(this)) * (double)floatValue;
   }

   private static double computeDouble3(boolean booleanValue, boolean booleanValue2) {
      double doubleValue;
      if (booleanValue) {
         doubleValue = (1.0);

         ThreadLocalRandom.current().nextInt(7);
      } else {
         doubleValue = 0.0;
      }

      double doubleValue2;
      if (booleanValue2) {
         doubleValue2 = (1.0);
      } else {
         doubleValue2 = 0.0;
      }

      return doubleValue - doubleValue2;
   }

   public static float getYaw(FreeCamModule freeCamModule2) {
      return freeCamModule2.yaw;
   }

   public static void setBooleanState(FreeCamModule freeCamModule2, boolean booleanState2) {
      freeCamModule2.booleanState = booleanState2;
   }

   public static FreeCamModule getFreeCamModule() {
      return freeCamModule;
   }

   public static void setDoubleState4(FreeCamModule freeCamModule2, double doubleState42) {
      freeCamModule2.doubleState4 = doubleState42;
   }

   public static void setDoubleState2(FreeCamModule freeCamModule2, double doubleState22) {
      freeCamModule2.doubleState2 = doubleState22;
   }

   private boolean checkCondition(int intValue) {
      return (GLFW.glfwGetKey(mc.getWindow().getHandle(), intValue) == 1);
   }

   public static double getDoubleState(FreeCamModule freeCamModule2) {
      return freeCamModule2.doubleState;
   }

   @EventHandler
   private void onDisconnect(DisconnectEvent disconnectEvent) {
      this.setEnabled(false);
   }

   public static double getZ(FreeCamModule freeCamModule2) {
      return freeCamModule2.z;
   }

   public static double getDoubleState2(FreeCamModule freeCamModule2) {
      return freeCamModule2.doubleState2;
   }

   public static void setDoubleState5(FreeCamModule freeCamModule2, double doubleState52) {
      freeCamModule2.doubleState5 = doubleState52;
   }

   public boolean testEntity(Entity entity) {
      byte byteValue;
      label29: {
         if (getBooleanState(this)) {
            if (entity == mc.player) {
               byteValue = 1;
               break label29;
            }
         }

         byteValue = 0;
      }

      ThreadLocalRandom.current().nextInt(15);
      return (byteValue != 0);
   }

   private boolean checkCondition2() {
      int keyCode = this.getKeybind().getKeyCode();
      if (keyCode > 0) {
         int intValue = GLFW.glfwGetKey(mc.getWindow().getHandle(), keyCode);

         if (intValue == 1) {
            return true;
         }
      } else {
         ThreadLocalRandom.current().nextInt(9);
      }

      return false;
   }

   public float getYaw22() {
      return getYaw(this);
   }

   public static boolean checkCondition3(double doubleValue, double doubleValue2) {
      FreeCamModule freeCamModule2 = freeCamModule;
      if (freeCamModule2 != null) {
         ThreadLocalRandom.current().nextInt(11);
         if (getBooleanState(freeCamModule2)) {
            setPitch(freeCamModule2, MathHelper.clamp(getPitch(freeCamModule2) + (float)(doubleValue2 * 0.15), ((-90.0F)), (90.0F)));
            freeCamModule2.yaw = MathHelper.wrapDegrees(getYaw(freeCamModule2) + (float)(doubleValue * 0.15));
            return true;
         }
      }

      ThreadLocalRandom.current().nextInt(13);
      return false;
   }

   public static void setDoubleState3(FreeCamModule freeCamModule2, double doubleState32) {
      freeCamModule2.doubleState3 = doubleState32;
   }

   public static FreeCamModule getFreeCamModule3() {
      return getFreeCamModule();
   }

   public static void setPitch(FreeCamModule freeCamModule2, float pitch2) {
      freeCamModule2.pitch = pitch2;
   }

   public static void setDoubleState(FreeCamModule freeCamModule2, double doubleState6) {
      freeCamModule2.doubleState = doubleState6;
   }

   @EventHandler
   private void onTickEvent(TickEvent tickEvent) {
      if (this.booleanState) {
         if (this.isWorldUnavailable()) {
            this.setEnabled(false);
         } else {
            if (this.holdModeSetting.isOn()) {
               if (!this.checkCondition2()) {
                  ThreadLocalRandom.current().nextInt(10);
                  this.setEnabled(false);
                  return;
               }
            }

            setDoubleState5(this, this.doubleState);
            setDoubleState2(this, this.doubleState3);
            this.doubleState4 = getZ(this);
            if (mc.currentScreen == null) {
               int intValue = (this.checkCondition(87)) ? 1 : 0;

               double doubleValue = computeDouble3((intValue != 0), this.checkCondition(83));

               double doubleValue2 = computeDouble3(this.checkCondition(68), this.checkCondition(65));

               double doubleValue3 = computeDouble3(this.checkCondition(32), this.checkCondition(340));

               if (doubleValue == (0.0)) {
                  if (doubleValue2 == 0.0) {
                     if (doubleValue3 == 0.0) {
                        return;
                     }
                  }
               }

               double doubleValue4 = 0.5 * this.speedSetting.getValue() * (this.checkCondition(341) ? 2.0 : 1.0);
               double doubleValue5 = Math.toRadians((double)this.yaw);
               double doubleValue6 = Math.sin(doubleValue5);
               double doubleValue7 = Math.cos(doubleValue5);
               double doubleValue8 = doubleValue * -doubleValue6 - doubleValue2 * doubleValue7;
               double doubleValue9 = doubleValue * doubleValue7 - doubleValue2 * doubleValue6;
               if (doubleValue != 0.0) {
                  if (doubleValue2 != 0.0) {
                     intValue = 22;
                     ThreadLocalRandom.current().nextInt(16);

                     double doubleValue10 = (1.0) / Math.sqrt(2.0);
                     doubleValue8 *= doubleValue10;
                     doubleValue9 *= doubleValue10;
                  }
               }

               this.doubleState = getDoubleState(this) + doubleValue8 * doubleValue4;
               this.doubleState3 = getDoubleState3(this) + doubleValue3 * doubleValue4;
               setZ(this, this.z + doubleValue9 * doubleValue4);
            }
         }
      }
   }

   public double computeDouble4(float floatValue) {
      return getDoubleState2(this) + (getDoubleState3(this) - getDoubleState2(this)) * (double)floatValue;
   }

   @Override
   public void onDisable() {
      setBooleanState(this, false);
      if (this.perspective != null) {
         mc.options.setPerspective(this.perspective);
         this.perspective = null;
      } else {
         ThreadLocalRandom.current().nextInt(9);
      }
   }

   public FreeCamModule() {
      super("Free Cam", "Spectate freely while your body stays in place.", ModuleCategory.PLAYER);

      this.speedSetting = new DoubleSetting("Speed", 0.1, 10.0, 2.0, (0.1));

      this.holdModeSetting = new BooleanSetting("Hold Mode", false);
      freeCamModule = this;
      this.addSetting(this.speedSetting);
      this.addSetting(this.holdModeSetting);
   }

   public static boolean checkCondition4() {
      FreeCamModule freeCamModule2 = getFreeCamModule();
      if (freeCamModule2 != null) {
         if (getBooleanState(freeCamModule2)) {
            ThreadLocalRandom.current().nextInt(12);

            return true;
         }
      }

      return false;
   }

   public static void setZ(FreeCamModule freeCamModule2, double z2) {
      freeCamModule2.z = z2;
   }

   @EventHandler
   private void onWorldChange(WorldChangeEvent worldChangeEvent) {
      if (worldChangeEvent.getWorld() != mc.world) {
         this.setEnabled(false);
      }
   }

   public float getPitch3() {
      return getPitch(this);
   }
}
