package cc.mochi;

public record InstaCartPlan(RailPlacementCandidate candidate, int railOffset, int cartOffset, int lastOffset, int hits, CoverPlacementPlan cover, int coverSteps, double distance) {
   public static CoverPlacementPlan getCover(InstaCartPlan instaCartPlan) {
      return instaCartPlan.cover;
   }

   public int getCoverSteps() {
      return this.coverSteps;
   }

   public int getRailOffset2() {
      return getRailOffset(this);
   }

   public int getCartOffset() {
      return this.cartOffset;
   }

   public static RailPlacementCandidate getCandidate(InstaCartPlan instaCartPlan) {
      return instaCartPlan.candidate;
   }

   public int getLastOffset() {
      return this.lastOffset;
   }

   public int getHits2() {
      return getHits(this);
   }

   public static int getHits(InstaCartPlan instaCartPlan) {
      return instaCartPlan.hits;
   }

   public CoverPlacementPlan getCover2() {
      return getCover(this);
   }

   public double getDistance() {
      return this.distance;
   }

   public static int getRailOffset(InstaCartPlan instaCartPlan) {
      return instaCartPlan.railOffset;
   }

   public RailPlacementCandidate getCandidate2() {
      return getCandidate(this);
   }
}
