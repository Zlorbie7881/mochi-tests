package cc.mochi;

public class DoubleRangeSetting extends Setting {
   private double maximum;
   private double lowerValue;
   private double step;
   private double upperValue;
   private double minimum;

   private final double defaultLowerValue;
   private final double defaultUpperValue;

   public double getStep2() {
      return getStep(this);
   }

   public static double getDefaultUpperValue(DoubleRangeSetting doubleRangeSetting) {
      return doubleRangeSetting.defaultUpperValue;
   }

   public void setLowerValue(double doubleValue) {
      this.lowerValue = this.clampAndSnap(doubleValue, getMinimum(this), getUpperValue(this));
   }

   public static void setUpperValue2(DoubleRangeSetting doubleRangeSetting, double upperValue2) {
      doubleRangeSetting.upperValue = upperValue2;
   }

   @Override
   public boolean isDefault() {
      if (this.lowerValue == this.defaultLowerValue) {
         if (getUpperValue(this) == this.defaultUpperValue) {
            return true;
         }
      }

      return false;
   }

   public static double getUpperValue(DoubleRangeSetting doubleRangeSetting) {
      return doubleRangeSetting.upperValue;
   }

   public double getDefaultUpperValue2() {
      return this.defaultUpperValue;
   }

   public void setRange(double doubleValue2, double doubleValue3) {
      if (doubleValue2 > doubleValue3) {
         double doubleValue = doubleValue2;
         doubleValue2 = doubleValue3;
         doubleValue3 = doubleValue;
      }

      setLowerValue2(this, this.clampAndSnap(doubleValue2, this.minimum, this.maximum));
      this.upperValue = this.clampAndSnap(doubleValue3, getMinimum(this), this.maximum);
   }

   public static double getMinimum(DoubleRangeSetting doubleRangeSetting) {
      return doubleRangeSetting.minimum;
   }

   public double getMaximum() {
      return this.maximum;
   }

   public DoubleRangeSetting(String name, double minimum2, double maximum2, double doubleValue2, double doubleValue3, double step2) {
      super(name);
      this.minimum = minimum2;
      this.maximum = maximum2;
      this.step = step2;
      if (doubleValue2 > doubleValue3) {
         double doubleValue = doubleValue2;
         doubleValue2 = doubleValue3;
         doubleValue3 = doubleValue;
      }

      this.lowerValue = this.clampAndSnap(doubleValue2, minimum2, maximum2);
      this.upperValue = this.clampAndSnap(doubleValue3, minimum2, maximum2);
      this.defaultLowerValue = this.lowerValue;
      this.defaultUpperValue = this.upperValue;
   }

   public static double getLowerValue(DoubleRangeSetting doubleRangeSetting) {
      return doubleRangeSetting.lowerValue;
   }

   private double clampAndSnap(double doubleValue, double doubleValue2, double doubleValue3) {
      double doubleValue4 = 1.0 / this.step;
      double doubleValue5 = (double)Math.round(doubleValue * doubleValue4) / doubleValue4;
      return Math.max(doubleValue2, Math.min(doubleValue3, doubleValue5));
   }

   public static double getDefaultLowerValue(DoubleRangeSetting doubleRangeSetting) {
      return doubleRangeSetting.defaultLowerValue;
   }

   public static void setLowerValue2(DoubleRangeSetting doubleRangeSetting, double lowerValue2) {
      doubleRangeSetting.lowerValue = lowerValue2;
   }

   public static double getMaximum2(DoubleRangeSetting doubleRangeSetting) {
      return doubleRangeSetting.maximum;
   }

   public static double getStep(DoubleRangeSetting doubleRangeSetting) {
      return doubleRangeSetting.step;
   }

   public double getDefaultLowerValue2() {
      return this.defaultLowerValue;
   }

   public void setMinimum(double minimum2) {
      this.minimum = minimum2;
   }

   @Override
   public void reset() {
      this.setRange(getDefaultLowerValue(this), getDefaultUpperValue(this));
   }

   public void setMaximum(double maximum2) {
      setMaximum2(this, maximum2);
   }

   public double getMinimum3() {
      return this.minimum;
   }

   public void setUpperValue(double doubleValue) {
      setUpperValue2(this, this.clampAndSnap(doubleValue, this.lowerValue, getMaximum2(this)));
   }

   public double getUpperValue3() {
      return this.upperValue;
   }

   public double getLowerValue2() {
      return getLowerValue(this);
   }

   public static void setMaximum2(DoubleRangeSetting doubleRangeSetting, double maximum2) {
      doubleRangeSetting.maximum = maximum2;
   }

   public void setStep(double step2) {
      this.step = step2;
   }
}
