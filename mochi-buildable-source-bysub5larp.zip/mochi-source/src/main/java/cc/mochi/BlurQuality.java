package cc.mochi;

import java.util.Locale;

public enum BlurQuality {
   PERFORMANCE(2),
   BALANCED(3),
   QUALITY(4);

   private final int passes;

   private static BlurQuality[] createValues() {
      return new BlurQuality[]{PERFORMANCE, BALANCED, QUALITY};
   }

   public int getPasses() {
      return this.passes;
   }

   private BlurQuality(int passes2) {
      this.passes = passes2;
   }

   public static BlurQuality computeBlurQuality(String string) {
      if (string == null) {
         return BALANCED;
      } else {
         try {
            return valueOf(string.trim().toUpperCase(Locale.ROOT));
         } catch (IllegalArgumentException failure) {
            return BALANCED;
         }
      }
   }
}
