package cc.mochi;

import cc.mochi.event.impl.input.MouseClickEvent;
import cc.mochi.event.impl.render.Render2DEvent;
import java.awt.Color;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.util.math.MathHelper;

public class KeystrokesModule extends Module implements HudElement {
   private final BooleanSetting mouseSetting = new BooleanSetting("Mouse", true);

   private final DoubleSetting paddingSetting;

   private final Deque<Long> longDeque;

   private static final FontFace fontFace2 = FontFace.SEMIBOLD;

   private float floatState;

   private final BooleanSetting spaceSetting = new BooleanSetting("Space", true);

   private static final FontFace fontFace = FontFace.MEDIUM;

   private final DoubleSetting scaleSetting;

   private float floatState2;
   private long timestampNanos;
   private final Map<String, Float> floatByString;
   private final DoubleSetting bGAlphaSetting;

   private final BooleanSetting shadowSetting;

   private final BooleanSetting arrowKeysSetting;
   private final Deque<Long> longDeque2;
   private final HudLayout hudLayout;

   private final BooleanSetting cPSSetting = new BooleanSetting("CPS", true);
   private final BooleanSetting camoSetting;

   private String computeString2() {
      return this.arrowKeysSetting.getValue() ? "←" : "A";
   }

   private String computeString3() {
      return this.arrowKeysSetting.getValue() ? "↓" : "S";
   }

   @Override
   public void updateState() {
      this.hudLayout.setAlignmentAndInsets(HudHorizontalAlignment.LEFT, HudVerticalAlignment.BOTTOM, HudLayoutMetrics.computeFloat3(4.0F, CoordinatesModule.class, ArmorModule.class), 4.0F);
   }

   @Override
   public boolean checkCondition() {
      return false;
   }

   private void updateStateForColor(boolean booleanValue, String text, String text2, float x, float y, float width, float height, float size, float size2, Color color) {
      float floatValue = this.computeFloat(text, booleanValue);
      updateStateForColor2(x, y, width, height, floatValue, color);
      Color color2 = LegacyUiTheme.computeColorForColor(LegacyUiTheme.color3, Color.WHITE, floatValue);
      if (text2 != null && !text2.isBlank()) {
         float floatValue2 = LegacyUiTheme.measureFontHeight(size, fontFace2);
         float floatValue3 = LegacyUiTheme.measureFontHeight(size2, fontFace);
         float floatValue4 = y + (height - floatValue2 - floatValue3) / 2.0F;
         LegacyUiTheme.drawText22(text, x + width / 2.0F, floatValue4 + floatValue2 / 2.0F, size, color2, fontFace2);
         LegacyUiTheme.drawText22(text2, x + width / 2.0F, floatValue4 + floatValue2 + floatValue3 / 2.0F, size2, LegacyUiTheme.computeColorForColor(LegacyUiTheme.color5, Color.WHITE, floatValue), fontFace);
      } else {
         LegacyUiTheme.drawText22(text, x + width / 2.0F, y + height / 2.0F, size, color2, fontFace2);
      }
   }

   private static void fillRoundedRect(float x, float y, float width, float height, Color color, float floatValue) {
      HudBloomRenderer.fillRoundedRect(x, y, width, height, 4.0F, LegacyUiTheme.createColor(color, 0.9F * floatValue));
   }

   private static void updateStateForColor2(float x, float y, float width, float height, float floatValue, Color color) {
      HudBloomRenderer.fillRoundedRect(x, y, width, height, 4.0F, LegacyUiTheme.createColor(Color.WHITE, 0.055F * (1.0F - floatValue)));
      if (floatValue > 0.01F) {
         LegacyUiTheme.updateStateForRunnable(0.7F * floatValue, () -> fillRoundedRect(x, y, width, height, color, floatValue));
      }
   }

   @Override
   public String computeString() {
      return this.getName();
   }

   private String computeString4() {
      return this.arrowKeysSetting.getValue() ? "→" : "D";
   }

   private String computeString5() {
      return this.arrowKeysSetting.getValue() ? "↑" : "W";
   }

   @Override
   public HudLayout computeHudLayout() {
      return this.hudLayout;
   }

   @EventHandler
   private void onRender2D(Render2DEvent render2DEvent) {
      if (mc.player != null && mc.world != null) {
         if (mc.currentScreen == null || mc.currentScreen instanceof ChatScreen) {
            if (!GlCapabilities.checkCondition3()) {
               ThemeSnapshot themeSnapshot = ClickGuiModule.computeThemeSnapshot();
               Color color = LegacyUiTheme.computeColorForThemeSnapshot2(themeSnapshot);
               float value = (float)this.scaleSetting.getValue();
               float value2 = (float)this.paddingSetting.getValue();
               float floatValue = 15.0F * value;
               float floatValue2 = 3.0F * value;
               float size = 7.2F * value;
               float size2 = 5.2F * value;
               boolean value3 = this.mouseSetting.getValue();
               boolean value4 = this.spaceSetting.getValue();
               long timestampNanos2 = System.nanoTime();
               this.updateState2(timestampNanos2);
               float floatValue3 = this.timestampNanos == 0L ? 0.016F : MathHelper.clamp((float)(timestampNanos2 - this.timestampNanos) / 1.0E9F, 0.0F, 0.1F);
               this.timestampNanos = timestampNanos2;
               this.floatState = LegacyUiTheme.computeFloat2(floatValue3, 34.0F);
               this.floatState2 = LegacyUiTheme.computeFloat2(floatValue3, 12.0F);
               int intValue = this.longDeque2.size();
               int intValue2 = this.longDeque.size();

               try (UiRenderBackend uiRenderBackend = HudBloomRenderer.computeUiRenderBackendForRender2DEvent(render2DEvent)) {
                  float width2 = floatValue * 3.0F + floatValue2 * 2.0F;
                  float width3 = width2 + value2 * 2.0F;
                  float height = value2 * 2.0F + floatValue * 2.0F + floatValue2;
                  if (value3) {
                     height += floatValue + floatValue2;
                  }

                  if (value4) {
                     height += floatValue * 0.6F + floatValue2;
                  }

                  this.updateState4(width3, height);
                  float x = this.hudLayout.getX();
                  float y = this.hudLayout.getY();
                  LegacyUiTheme.updateStateForThemeSnapshot(x, y, width3, height, (int)this.bGAlphaSetting.getValue(), true, this.shadowSetting.getValue(), this.camoSetting.getValue(), false, themeSnapshot);
                  float x2 = x + value2;
                  float y2 = y + value2;
                  this.updateStateForColor(mc.options.forwardKey.isPressed(), this.computeString5(), null, x2 + floatValue + floatValue2, y2, floatValue, floatValue, size, size2, color);
                  y2 += floatValue + floatValue2;
                  this.updateStateForColor(mc.options.leftKey.isPressed(), this.computeString2(), null, x2, y2, floatValue, floatValue, size, size2, color);
                  this.updateStateForColor(mc.options.backKey.isPressed(), this.computeString3(), null, x2 + floatValue + floatValue2, y2, floatValue, floatValue, size, size2, color);
                  this.updateStateForColor(mc.options.rightKey.isPressed(), this.computeString4(), null, x2 + (floatValue + floatValue2) * 2.0F, y2, floatValue, floatValue, size, size2, color);
                  y2 += floatValue + floatValue2;
                  if (value3) {
                     float width4 = (width2 - floatValue2) / 2.0F;
                     this.updateStateForColor(mc.options.attackKey.isPressed(), "LMB", this.cPSSetting.getValue() ? intValue + " CPS" : null, x2, y2, width4, floatValue, size, size2, color);
                     this.updateStateForColor(
                        mc.options.useKey.isPressed(), "RMB", this.cPSSetting.getValue() ? intValue2 + " CPS" : null, x2 + width4 + floatValue2, y2, width4, floatValue, size, size2, color
                     );
                     y2 += floatValue + floatValue2;
                  }

                  if (value4) {
                     float height2 = floatValue * 0.6F;
                     float floatValue4 = this.computeFloat("Space", mc.options.jumpKey.isPressed());
                     updateStateForColor2(x2, y2, width2, height2, floatValue4, color);
                     float width = width2 * 0.3F;
                     HudBloomRenderer.fillRoundedRect(x2 + (width2 - width) / 2.0F, y2 + height2 / 2.0F - 0.7F, width, 1.4F, 0.7F, LegacyUiTheme.computeColorForColor(LegacyUiTheme.color5, Color.WHITE, floatValue4));
                  }
               }
            }
         }
      }
   }

   @EventHandler
   private void onMouseClick(MouseClickEvent mouseClickEvent) {
      if (mouseClickEvent.action() == 1 && mc.currentScreen == null) {
         long longValue = System.nanoTime();
         if (mouseClickEvent.button() == 0) {
            this.longDeque2.addLast(longValue);
         } else if (mouseClickEvent.button() == 1) {
            this.longDeque.addLast(longValue);
         }

         this.updateState2(longValue);
      }
   }

   private void updateState2(long longValue) {
      while (!this.longDeque2.isEmpty()) {
         long longValue2 = longValue - this.longDeque2.peekFirst();

         if (longValue2 > 1000000000L) {
            this.longDeque2.removeFirst();
            continue;
         }
         break;
      }

      while (!this.longDeque.isEmpty()) {
         long longValue3 = longValue - this.longDeque.peekFirst();

         if (longValue3 <= 1000000000L) {
            break;
         }

         this.longDeque.removeFirst();
      }
   }

   @Override
   public float getFloatConstant2() {
      return 72.0F;
   }

   @Override
   public float getFloatConstant() {
      return 72.0F;
   }

   public KeystrokesModule() {
      super("Keystrokes", "Movement keys and mouse buttons as they are pressed", -1, ModuleCategory.RENDER);
      this.arrowKeysSetting = new BooleanSetting("Arrow Keys", false);
      this.scaleSetting = new DoubleSetting("Scale", 0.6, 2.6, 1.4, 0.05);
      this.paddingSetting = new DoubleSetting("Padding", 1.0, 10.0, 5.0, 1.0);
      this.bGAlphaSetting = new DoubleSetting("BG Alpha", 0.0, 255.0, 150.0, 5.0);
      this.shadowSetting = new BooleanSetting("Shadow", true);
      this.camoSetting = new BooleanSetting("Camo", false);
      this.hudLayout = new HudLayout(4.0F, 4.0F, 72.0F, 72.0F);
      this.longDeque2 = new ArrayDeque<>();
      this.longDeque = new ArrayDeque<>();
      this.floatByString = new HashMap<>();
      this.addSettings(new Setting[]{this.mouseSetting, this.spaceSetting, this.cPSSetting, this.arrowKeysSetting, this.scaleSetting, this.paddingSetting, this.bGAlphaSetting, this.shadowSetting, this.camoSetting});
   }

   private float computeFloat(String string, boolean booleanValue) {
      float floatValue = this.floatByString.getOrDefault(string, 0.0F);
      float floatValue2 = floatValue + ((booleanValue ? 1.0F : 0.0F) - floatValue) * (booleanValue ? this.floatState : this.floatState2);
      this.floatByString.put(string, floatValue2);
      return floatValue2;
   }
}
