package cc.mochi;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public record BlockFaceCandidate(BlockPos block, Direction side, Vec3d point, double score) {
   public Direction getSide2() {
      return getSide(this);
   }

   public BlockPos getBlock2() {
      return getBlock(this);
   }

   public static BlockPos getBlock(BlockFaceCandidate blockFaceCandidate) {
      return blockFaceCandidate.block;
   }

   public double getScore() {
      return this.score;
   }

   public Vec3d getPoint2() {
      return getPoint(this);
   }

   public static Direction getSide(BlockFaceCandidate blockFaceCandidate) {
      return blockFaceCandidate.side;
   }

   public static Vec3d getPoint(BlockFaceCandidate blockFaceCandidate) {
      return blockFaceCandidate.point;
   }
}
