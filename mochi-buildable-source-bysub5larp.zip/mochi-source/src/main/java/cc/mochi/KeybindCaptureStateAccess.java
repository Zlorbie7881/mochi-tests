package cc.mochi;

public class KeybindCaptureStateAccess {
   public static KeybindCaptureState getEMPTY() {
      return KeybindCaptureState.EMPTY;
   }

   public static KeybindCaptureState getCAPTURING() {
      return KeybindCaptureState.CAPTURING;
   }
}
