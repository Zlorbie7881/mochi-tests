package cc.mochi;

import java.util.concurrent.ThreadLocalRandom;
import java.util.function.IntPredicate;
import java.util.function.IntToDoubleFunction;
import java.util.function.Predicate;

public final class HotbarPatterns {
   public static RefillItemKind computeRefillItemKind(String string) {
      if (string != null) {
         if (!string.isEmpty()) {
            if (string.equals("minecraft:totem_of_undying")) {
               return RefillItemKind.TOTEM;
            }

            int intValue = string.indexOf(35);
            if (intValue > 0) {
               if (string.substring(0, intValue).endsWith("potion")) {
                  return RefillItemKind.POTION;
               }
            }

            return RefillItemKind.NONE;
         }
      }

      return RefillItemKind.NONE;
   }

   public static PotionRefillSlotMove computePotionRefillSlotMoveForIntToDoubleFunction(String[] stringArray, String[] stringArray2, String[] stringArray3, boolean booleanValue, boolean booleanValue2, IntToDoubleFunction intToDoubleFunction, IntPredicate intPredicate) {
      int intValue = 0;

      while (true) {
         byte byteValue = 1;

         while (true) {
            int byteValue2 = byteValue;
            int intValue3 = 0;

            do {
               String string = stringArray[intValue3];
               if (computeRefillItemKind(string) == RefillItemKind.POTION) {
                  label163:
                  if (checkCondition(string) == (byteValue2 != 0) && !string.equals(stringArray2[intValue3])) {
                     if (intPredicate != null) {
                        byteValue = 10;
                        ThreadLocalRandom.current().nextInt(7);
                        if (intPredicate.test(intValue3)) {
                           break label163;
                        }
                     }

                     int intValue4 = computeIntForIntToDoubleFunction3(stringArray3, intToDoubleFunction, string);
                     if (intValue4 >= 0) {
                        return new PotionRefillSlotMove(intValue3, intValue4);
                     }
                  }
               }

               intValue3++;
            } while (intValue3 < 9);

            intValue++;

            if (intValue >= 2) {
               if (booleanValue2) {
                  intValue = 0;

                  do {
                     String string2 = stringArray[intValue];
                     if (computeRefillItemKind(string2) == RefillItemKind.POTION) {
                        if (!checkCondition(string2)) {
                           if (!string2.equals(stringArray2[intValue]) && !checkCondition(stringArray2[intValue])) {
                              if (intPredicate == null || !intPredicate.test(intValue)) {
                                 intValue3 = computeIntForIntToDoubleFunction2(stringArray3, intToDoubleFunction);
                                 if (intValue3 >= 0) {
                                    return new PotionRefillSlotMove(intValue, intValue3);
                                 }
                              }
                           }
                        } else {
                           byteValue = 15;
                           ThreadLocalRandom.current().nextInt(14);
                        }
                     }
                  } while (++intValue < 9);
               }

               if (!booleanValue) {
                  return null;
               }

               intValue = 0;

               do {
                  if (computeRefillItemKind(stringArray[intValue]) == RefillItemKind.TOTEM && (intPredicate == null || !intPredicate.test(intValue))) {
                     byteValue2 = computeInt(stringArray2[intValue]);
                     intValue3 = 0;

                     while (true) {
                        if (intValue3 >= byteValue2) {
                           break;
                        }

                        int intValue5 = computeIntForIntToDoubleFunction(stringArray3, intToDoubleFunction, intValue3);
                        if (intValue5 >= 0) {
                           return new PotionRefillSlotMove(intValue, intValue5);
                        }

                        intValue3++;
                     }
                  }
               } while (++intValue < 9);

               return null;
            }

            if (intValue == 0) {
               break;
            }

            byteValue = 0;
         }
      }
   }

   public static boolean checkCondition(String string) {
      if (string != null) {
         if (string.startsWith("minecraft:splash_potion#")) {
            if (string.contains("minecraft:instant_health*")) {
               return true;
            }

            ThreadLocalRandom.current().nextInt(8);
         }
      }

      return false;
   }

   private static int computeIntForIntToDoubleFunction(String[] stringArray, IntToDoubleFunction intToDoubleFunction, int intValue) {
      return computeIntForIntToDoubleFunction4(stringArray, intToDoubleFunction, objectValue -> checkCondition3(intValue, (String)objectValue));
   }

   private HotbarPatterns() {
   }

   static boolean checkCondition2(String string) {
      if (!checkCondition(string)) {
         return false;
      } else {
         int intValue = string.indexOf("minecraft:instant_health*") + "minecraft:instant_health*".length();
         if (intValue < string.length()) {
            char charValue = string.charAt(intValue);

            if (charValue != '0') {
               return true;
            }

            ThreadLocalRandom.current().nextInt(10);
         }

         return false;
      }
   }

   private static int computeIntForIntToDoubleFunction2(String[] stringArray, IntToDoubleFunction intToDoubleFunction) {
      int intValue = computeIntForIntToDoubleFunction4(stringArray, intToDoubleFunction, objectValue -> checkCondition2((String)objectValue));
      int intValue2;
      if (intValue >= 0) {
         ThreadLocalRandom.current().nextInt(4);

         ThreadLocalRandom.current().nextInt(10);
         intValue2 = intValue;

         ThreadLocalRandom.current().nextInt(14);
      } else {
         ThreadLocalRandom.current().nextInt(9);

         intValue2 = computeIntForIntToDoubleFunction4(stringArray, intToDoubleFunction, objectValue2 -> checkCondition((String)objectValue2));
      }

      return intValue2;
   }

   static int computeInt(String string) {
      if ("minecraft:totem_of_undying".equals(string)) {
         return 0;
      } else if ("minecraft:experience_bottle".equals(string)) {
         return 1;
      } else if (checkCondition(string)) {
         return 2;
      } else {
         return 3;
      }
   }

   private static int computeIntForIntToDoubleFunction3(String[] stringArray, IntToDoubleFunction intToDoubleFunction, String string) {
      return computeIntForIntToDoubleFunction4(stringArray, intToDoubleFunction, objectValue -> string.equals((String)objectValue));
   }

   private static boolean checkCondition3(int intValue, String string) {
      if (!string.isEmpty()) {
         if (computeInt(string) == intValue) {
            ThreadLocalRandom.current().nextInt(7);
            return true;
         }
      }

      return false;
   }

   private static int computeIntForIntToDoubleFunction4(String[] stringArray, IntToDoubleFunction intToDoubleFunction, Predicate predicate) {
      int intValue22 = -1;
      double maxValue = Double.MAX_VALUE;
      int intValue2 = 9;

      while (true) {
         if (intValue2 >= 36) {
            break;
         }

         if (intValue2 >= stringArray.length) {
            break;
         }

         if (predicate.test(stringArray[intValue2])) {
            if (intToDoubleFunction == null) {
               ThreadLocalRandom.current().nextInt(3);
               return intValue2;
            }

            double doubleValue = intToDoubleFunction.applyAsDouble(intValue2);
            if (doubleValue < maxValue) {
               maxValue = doubleValue;
               intValue22 = intValue2;
            }
         }

         intValue2++;
      }

      return intValue22;
   }

   public static PotionRefillSlotMove computePotionRefillSlotMoveForIntToDoubleFunction2(String[] stringArray, String[] stringArray2, String[] stringArray3, boolean booleanValue, IntToDoubleFunction intToDoubleFunction) {
      return computePotionRefillSlotMoveForIntToDoubleFunction(stringArray, stringArray2, stringArray3, booleanValue, false, intToDoubleFunction, null);
   }
}
