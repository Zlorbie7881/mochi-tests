package cc.mochi;

public class FontFaceAccess {
   public static FontFace getMEDIUM() {
      return FontFace.MEDIUM;
   }
}
