package cc.mochi;

import com.mojang.blaze3d.opengl.GlStateManager;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public final class LegacyWidgets {
   private static final Map<String, WidgetAnimation> widgetAnimationByString = new HashMap<>();

   public static void updateStateForDrawContext(DrawContext drawContext, int intValue, int intValue2, int intValue3, int intValue4, int intValue5, int intValue6, Color color) {
      RenderUtils.updateStateForDrawContext10(drawContext, intValue, intValue2, intValue3, intValue6, intValue5, color.getRGB());
      RenderUtils.updateStateForDrawContext10(drawContext, intValue, intValue2 + intValue4 - intValue6, intValue3, intValue6, intValue5, color.getRGB());
      RenderUtils.updateStateForDrawContext10(drawContext, intValue, intValue2, intValue6, intValue4, intValue5, color.getRGB());
      RenderUtils.updateStateForDrawContext10(drawContext, intValue + intValue3 - intValue6, intValue2, intValue6, intValue4, intValue5, color.getRGB());
   }

   public static void updateStateForDrawContext2(DrawContext drawContext, int intValue, int intValue2, int intValue3, String string, String string2, NotificationSeverity notificationSeverity, float floatValue) {
      Color color = computeColorForNotificationSeverity(notificationSeverity);
      RenderUtils.updateStateForDrawContext10(drawContext, intValue, intValue2, intValue3, 60, 8, LegacyUiColors.color10.getRGB());
      RenderUtils.updateStateForDrawContext10(drawContext, intValue, intValue2, 4, 60, 2, color.getRGB());
      if (floatValue > 0.0F) {
         int intValue4 = (int)((float)intValue3 * floatValue);
         Color color2 = new Color(color.getRed(), color.getGreen(), color.getBlue(), 60);
         RenderUtils.updateStateForDrawContext10(drawContext, intValue, intValue2 + 56, intValue4, 4, 2, color2.getRGB());
      }

      updateStateForDrawContext11(drawContext, intValue + 12, intValue2 + 12, notificationSeverity);
      drawText(drawContext, string, intValue + 40, intValue2 + 12, LegacyUiColors.color3);
      drawText(drawContext, string2, intValue + 40, intValue2 + 32, LegacyUiColors.color4);
   }

   public static int getIntConstant() {
      return 9;
   }

   public static void drawText(DrawContext drawContext, String string, int intValue, int intValue2, Color color) {
      drawContext.drawText(MinecraftClient.getInstance().textRenderer, string, intValue, intValue2, color.getRGB(), false);
   }

   public static void updateStateForDrawContext3(DrawContext drawContext, int intValue, int intValue2, int intValue3, int intValue4, String string, boolean booleanValue, boolean booleanValue2) {
      Color color = booleanValue2 ? LegacyUiColors.color : LegacyUiColors.color10;
      RenderUtils.updateStateForDrawContext10(drawContext, intValue, intValue2, intValue3, intValue4, 4, color.getRGB());
      drawText(drawContext, string, intValue + 8, intValue2 + intValue4 / 2 - 4, LegacyUiColors.color3);
      updateStateForDrawContext12(drawContext, intValue + intValue3 - 16, intValue2 + intValue4 / 2 - 3, 6, booleanValue, LegacyUiColors.color4);
   }

   public static void updateStateForDrawContext4(DrawContext drawContext, int intValue, int intValue2, int intValue3, int intValue4, Color color, Color color2) {
      GlStateManager._enableBlend();
      GlStateManager._blendFuncSeparate(770, 771, 1, 0);
      RenderSystemAccess.updateState();
      drawContext.fillGradient(intValue, intValue2, intValue + intValue3, intValue2 + intValue4, color.getRGB(), color2.getRGB());
      GlStateManager._disableBlend();
   }

   public static void updateStateForDrawContext5(DrawContext drawContext, int intValue, int intValue2, int intValue3, int intValue4, boolean booleanValue, boolean booleanValue2) {
      Color color = booleanValue ? LegacyUiColors.color12 : LegacyUiColors.color10;
      Color color2 = booleanValue2 ? LegacyUiColors.color12.brighter() : (booleanValue ? LegacyUiColors.color12 : LegacyUiColors.color15);
      RenderUtils.updateStateForDrawContext10(drawContext, intValue, intValue2, intValue3, intValue4, intValue4 / 2, color.getRGB());
      updateStateForDrawContext(drawContext, intValue, intValue2, intValue3, intValue4, intValue4 / 2, 1, color2);
      int intValue5 = intValue4 - 4;
      int intValue6 = booleanValue ? intValue + intValue3 - intValue5 - 2 : intValue + 2;
      Color color3 = LegacyUiColors.color3;
      RenderUtils.updateStateForDrawContext10(drawContext, intValue6, intValue2 + 2, intValue5, intValue5, intValue5 / 2, color3.getRGB());
   }

   private static Color computeColorForNotificationSeverity(NotificationSeverity notificationSeverity) {
      switch (notificationSeverity) {
         case SUCCESS:
            return LegacyUiColors.color6;
         case WARNING:
            return LegacyUiColors.color14;
         case ERROR:
            return LegacyUiColors.color8;
         default:
            return LegacyUiColors.color11;
      }
   }

   private static boolean testEntry(long longValue, Entry entry) {
      WidgetAnimation value = (WidgetAnimation)entry.getValue();
      return longValue - value.startedAtMillis > 5000L && Math.abs(value.current - value.start) < 0.01F;
   }

   public static Color computeColorForColor(Color color, Color color2, float floatValue) {
      floatValue = Math.max(0.0F, Math.min(1.0F, floatValue));
      int intValue = (int)((float)color.getRed() + (float)(color2.getRed() - color.getRed()) * floatValue);
      int intValue2 = (int)((float)color.getGreen() + (float)(color2.getGreen() - color.getGreen()) * floatValue);
      int intValue3 = (int)((float)color.getBlue() + (float)(color2.getBlue() - color.getBlue()) * floatValue);
      int intValue4 = (int)((float)color.getAlpha() + (float)(color2.getAlpha() - color.getAlpha()) * floatValue);
      return new Color(intValue, intValue2, intValue3, intValue4);
   }

   private static float computeFloatForEasingType(float floatValue, EasingType easingType) {
      float floatValue2;
      switch (easingType) {
         case LINEAR:
            floatValue2 = floatValue;
            break;
         case EASE_IN:
            floatValue2 = floatValue * floatValue;
            break;
         case EASE_OUT:
            floatValue2 = 1.0F - (1.0F - floatValue) * (1.0F - floatValue);
            break;
         case EASE_IN_OUT:
            floatValue2 = floatValue < 0.5F ? 2.0F * floatValue * floatValue : 1.0F - 2.0F * (1.0F - floatValue) * (1.0F - floatValue);
            break;
         case BOUNCE:
            floatValue2 = computeFloat2(floatValue);
            break;
         case ELASTIC:
            floatValue2 = computeFloat(floatValue);
            break;
         default:
            throw new MatchException(null, null);
      }

      return floatValue2;
   }

   public static void updateStateForDrawContext6(DrawContext drawContext, int intValue, int intValue2, int intValue3, int intValue4, String string, boolean booleanValue, boolean booleanValue2) {
      Color color = booleanValue2 ? LegacyUiColors.color : (booleanValue ? LegacyUiColors.color : LegacyUiColors.color10);
      RenderUtils.updateStateForDrawContext10(drawContext, intValue, intValue2, intValue3, intValue4, 6, color.getRGB());
      Color color2 = booleanValue ? LegacyUiColors.color16 : LegacyUiColors.color15;
      updateStateForDrawContext(drawContext, intValue, intValue2, intValue3, intValue4, 6, 1, color2);
      updateStateForDrawContext13(drawContext, string, intValue + intValue3 / 2, intValue2 + intValue4 / 2, LegacyUiColors.color3);
   }

   public static Color createColor(Color color, int intValue) {
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), Math.max(0, Math.min(255, intValue)));
   }

   public static void updateStateForDrawContext7(DrawContext drawContext, int intValue, int intValue2, int intValue3, boolean booleanValue, boolean booleanValue2) {
      Color color = booleanValue ? LegacyUiColors.color12 : LegacyUiColors.color10;
      Color color2 = booleanValue2 ? LegacyUiColors.color12 : LegacyUiColors.color15;
      RenderUtils.updateStateForDrawContext10(drawContext, intValue, intValue2, intValue3, intValue3, 3, color.getRGB());
      updateStateForDrawContext(drawContext, intValue, intValue2, intValue3, intValue3, 3, 1, color2);
      if (booleanValue) {
         updateStateForDrawContext9(drawContext, intValue + 2, intValue2 + 2, intValue3 - 4, LegacyUiColors.color3);
      }
   }

   public static void updateState() {
      long longValue = System.currentTimeMillis();
      widgetAnimationByString.entrySet().removeIf(entry -> testEntry(longValue, entry));
   }

   public static void updateStateForDrawContext8(DrawContext drawContext, int intValue, int intValue2, int intValue3, int intValue4, float floatValue, boolean booleanValue) {
      floatValue = Math.max(0.0F, Math.min(1.0F, floatValue));
      Color color = new Color(40, 40, 40);
      RenderUtils.updateStateForDrawContext10(drawContext, intValue, intValue2 + intValue4 / 4, intValue3, intValue4 / 2, intValue4 / 4, color.getRGB());
      if (floatValue > 0.0F) {
         int intValue5 = (int)((float)intValue3 * floatValue);
         RenderUtils.updateStateForDrawContext10(drawContext, intValue, intValue2 + intValue4 / 4, intValue5, intValue4 / 2, intValue4 / 4, LegacyUiColors.color12.getRGB());
      }

      int intValue6 = intValue + (int)((float)intValue3 * floatValue) - intValue4 / 2;
      intValue6 = Math.max(intValue, Math.min(intValue + intValue3 - intValue4, intValue6));
      Color color2 = booleanValue ? LegacyUiColors.color12.brighter() : LegacyUiColors.color12;
      Color color3 = new Color(0, 0, 0, 60);
      RenderUtils.updateStateForDrawContext10(drawContext, intValue6 + 1, intValue2 + 1, intValue4, intValue4, intValue4 / 2, color3.getRGB());
      RenderUtils.updateStateForDrawContext10(drawContext, intValue6, intValue2, intValue4, intValue4, intValue4 / 2, color2.getRGB());
   }

   public static void updateStateForDrawContext9(DrawContext drawContext, int intValue, int intValue2, int intValue3, Color color) {
      int intValue4 = intValue + intValue3 / 2;
      int intValue5 = intValue2 + intValue3 / 2;
      drawContext.fill(intValue4 - 2, intValue5, intValue4, intValue5 + 2, color.getRGB());
      drawContext.fill(intValue4, intValue5 + 2, intValue4 + 4, intValue5 - 2, color.getRGB());
   }

   public static void updateStateForDrawContext10(DrawContext drawContext, int intValue, int intValue2, String string) {
      int width = getWidth(string);
      int intConstant = getIntConstant();
      int intValue3 = width + 12;
      int intValue4 = intConstant + 12;
      Color color = new Color(0, 0, 0, 100);
      RenderUtils.updateStateForDrawContext10(drawContext, intValue + 2, intValue2 + 2, intValue3, intValue4, 4, color.getRGB());
      Color color2 = new Color(25, 25, 25, 240);
      RenderUtils.updateStateForDrawContext10(drawContext, intValue, intValue2, intValue3, intValue4, 4, color2.getRGB());
      drawText(drawContext, string, intValue + 6, intValue2 + 6, LegacyUiColors.color3);
   }

   private static float computeFloat(float floatValue) {
      return (float)(Math.pow(2.0, (double)(((-10.0F)) * floatValue)) * Math.sin(((double)floatValue - 0.1) * (Math.PI * 2) / 0.4) + 1.0);
   }

   public static float computeFloatForEasingType2(String string, float start, float floatValue, EasingType easingType) {
      WidgetAnimation widgetAnimation = widgetAnimationByString.computeIfAbsent(string, string2 -> createWidgetAnimation(start, floatValue, easingType, string2));
      widgetAnimation.start = start;
      long startedAtMillis = System.currentTimeMillis();
      float floatValue2 = (float)(startedAtMillis - widgetAnimation.startedAtMillis) / 1000.0F;
      widgetAnimation.startedAtMillis = startedAtMillis;
      if (Math.abs(widgetAnimation.current - widgetAnimation.start) > 0.01F) {
         float floatValue3 = widgetAnimation.start - widgetAnimation.current;
         float floatValue4 = floatValue3 * widgetAnimation.target * floatValue2;
         floatValue4 = computeFloatForEasingType(floatValue4, widgetAnimation.easing);
         widgetAnimation.current += floatValue4;
         if (Math.abs(widgetAnimation.current - widgetAnimation.start) < 0.01F) {
            widgetAnimation.current = widgetAnimation.start;
         }
      }

      return widgetAnimation.current;
   }

   public static int getWidth(String string) {
      return MinecraftClient.getInstance().textRenderer.getWidth(string);
   }

   public static Color computeColor(float floatValue, float floatValue2, float floatValue3) {
      float floatValue4 = ((float)System.currentTimeMillis() * 0.001F + floatValue) % 1.0F;
      return Color.getHSBColor(floatValue4, floatValue2, floatValue3);
   }

   public static void updateStateForDrawContext11(DrawContext drawContext, int intValue, int intValue2, NotificationSeverity notificationSeverity) {
      Color color = computeColorForNotificationSeverity(notificationSeverity);
      switch (notificationSeverity) {
         case INFO:
            RenderUtils.updateStateForDrawContext2(drawContext, intValue + 8, intValue2 + 8, 8, color.getRGB());
            drawText(drawContext, "i", intValue + 6, intValue2 + 4, LegacyUiColors.color3);
            break;
         case SUCCESS:
            RenderUtils.updateStateForDrawContext2(drawContext, intValue + 8, intValue2 + 8, 8, color.getRGB());
            updateStateForDrawContext9(drawContext, intValue + 4, intValue2 + 4, 8, LegacyUiColors.color3);
            break;
         case WARNING:
            drawText(drawContext, "!", intValue + 6, intValue2 + 2, color);
            break;
         case ERROR:
            drawText(drawContext, "X", intValue + 4, intValue2 + 4, color);
      }
   }

   public static void updateStateForDrawContext12(DrawContext drawContext, int intValue, int intValue2, int intValue3, boolean booleanValue, Color color) {
      int intValue4 = intValue + intValue3 / 2;
      int intValue5 = intValue2 + intValue3 / 2;
      if (booleanValue) {
         for (int intValue6 = 0; intValue6 < intValue3 / 2; intValue6++) {
            drawContext.fill(intValue4 - intValue6, intValue5 - intValue3 / 4 + intValue6, intValue4 + intValue6 + 1, intValue5 - intValue3 / 4 + intValue6 + 1, color.getRGB());
         }
      } else {
         for (int intValue7 = 0; intValue7 < intValue3 / 2; intValue7++) {
            drawContext.fill(intValue4 - intValue7, intValue5 + intValue3 / 4 - intValue7, intValue4 + intValue7 + 1, intValue5 + intValue3 / 4 - intValue7 + 1, color.getRGB());
         }
      }
   }

   private static float computeFloat2(float floatValue) {
      if (floatValue < 0.36363637F) {
         return 7.5625F * floatValue * floatValue;
      } else if (floatValue < 0.72727275F) {
         float floatValue2;
         return 7.5625F * (floatValue2 = floatValue - 0.54545456F) * floatValue2 + 0.75F;
      } else {
         float floatValue3;
         float floatValue4;
         return (double)floatValue < 0.9090909090909091
            ? 7.5625F * (floatValue3 = floatValue - 0.8181818F) * floatValue3 + 0.9375F
            : 7.5625F * (floatValue4 = floatValue - 0.95454544F) * floatValue4 + 0.984375F;
      }
   }

   public static void updateStateForDrawContext13(DrawContext drawContext, String string, int intValue, int intValue2, Color color) {
      int width = getWidth(string);
      int intConstant = getIntConstant();
      drawText(drawContext, string, intValue - width / 2, intValue2 - intConstant / 2, color);
   }

   public static void updateStateForDrawContext14(DrawContext drawContext, int intValue, int intValue2, int intValue3, int intValue4, float floatValue, Color color, Color color2) {
      floatValue = Math.max(0.0F, Math.min(1.0F, floatValue));
      RenderUtils.updateStateForDrawContext10(drawContext, intValue, intValue2, intValue3, intValue4, intValue4 / 2, color.getRGB());
      if (floatValue > 0.0F) {
         int intValue5 = (int)((float)intValue3 * floatValue);
         RenderUtils.updateStateForDrawContext10(drawContext, intValue, intValue2, intValue5, intValue4, intValue4 / 2, color2.getRGB());
      }

      Color color3 = new Color(255, 255, 255, 30);
      RenderUtils.updateStateForDrawContext10(drawContext, intValue, intValue2, intValue3, 1, intValue4 / 2, color3.getRGB());
   }

   private static WidgetAnimation createWidgetAnimation(float floatValue, float floatValue2, EasingType easingType, String string) {
      return new WidgetAnimation(floatValue, floatValue2, easingType);
   }
}
