package cc.mochi;

import cc.mochi.event.impl.combat.ShieldDrainEvent;
import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.mixin.KeyBindingAccessor;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class AutoComboModule extends Module {
   private final BooleanSetting onlyOnGroundSetting;

   private boolean booleanState;
   private final DoubleRangeSetting sTapDurationMsSetting;

   private final DoubleRangeSetting wTapDurationMsSetting;

   private long longState;
   private final DoubleRangeSetting smartBandBlocksSetting;

   private final ChoiceSetting modeSetting;

   private boolean booleanState2;
   private boolean booleanState3;

   private long deadlineMillis;
   private boolean booleanState4;

   private double computeDoubleForEntity(Entity entity) {
      Vec3d vec3d = entity.getEntityPos().subtract(MinecraftClientAccess2.getPlayer(mc).getEntityPos());
      double doubleValue = Math.sqrt(vec3d.x * vec3d.x + vec3d.z * MinecraftClientAccess2.getZ(vec3d));

      if (doubleValue < (1.0E-4)) {
         return (0.0);
      } else {
         double doubleValue2 = vec3d.x / doubleValue;
         double doubleValue3 = MinecraftClientAccess2.getZ(vec3d) / doubleValue;
         Vec3d vec3d2 = MinecraftClientAccess2.getPlayer(mc).getVelocity().subtract(entity.getVelocity());
         return -(vec3d2.x * doubleValue2 + MinecraftClientAccess2.getZ(vec3d2) * doubleValue3);
      }
   }

   private long computeLongForDoubleRangeSetting(DoubleRangeSetting doubleRangeSetting) {
      double lowerValue2 = doubleRangeSetting.getLowerValue2();
      double upperValue3 = doubleRangeSetting.getUpperValue3();
      if (lowerValue2 >= upperValue3) {
         return Math.max((1L), Math.round(lowerValue2));
      } else {
         return Math.max(1L, Math.round(ThreadLocalRandom.current().nextDouble(lowerValue2, upperValue3)));
      }
   }

   @EventHandler
   private void onTickEvent(TickEvent tickEvent) {
      if ((this.booleanState4)) {
         ShieldDrainEvent shieldDrainEvent = new ShieldDrainEvent();
         MochiClient.INSTANCE.getMochiEventBus().post(shieldDrainEvent);
         if (!shieldDrainEvent.isActive()) {
            long longValue = System.currentTimeMillis();
            if (longValue >= this.deadlineMillis) {
               if (this.booleanState2 && this.checkCondition2()) {
                  MinecraftClientAccess2.getOptions(mc).forwardKey.setPressed(true);
               }

               label53: {
                  if (this.booleanState) {
                     if (this.checkCondition5()) {
                        MinecraftClientAccess2.getBackKey(MinecraftClientAccess2.getOptions(mc)).setPressed(true);
                        break label53;
                     }
                  }

                  MinecraftClientAccess2.getBackKey(MinecraftClientAccess2.getOptions(mc)).setPressed(false);
               }

               this.booleanState4 = false;
               this.setDisplaySuffix(null);
            }
         }
      }
   }

   public static ChoiceSetting getModeSetting(AutoComboModule autoComboModule) {
      return autoComboModule.modeSetting;
   }

   public boolean checkCondition() {
      if (this.isEnabled()) {
         if (getBooleanState4(this)) {
            return true;
         }

         ThreadLocalRandom.current().nextInt(12);
      }

      return false;
   }

   private long computeLongForDoubleRangeSetting2(DoubleRangeSetting doubleRangeSetting, double doubleValue) {
      double lowerValue2 = doubleRangeSetting.getLowerValue2();
      double upperValue3 = doubleRangeSetting.getUpperValue3();
      if (lowerValue2 >= upperValue3) {
         return Math.max(1L, Math.round(lowerValue2));
      } else {
         double doubleValue2 = doubleValue / 1.5;

         double doubleValue3 = MathHelper.clamp(doubleValue2, (0.0), 1.0);
         double doubleValue4 = lowerValue2 + doubleValue3 * (upperValue3 - lowerValue2);
         ThreadLocalRandom threadLocalRandom = ThreadLocalRandom.current();

         double doubleValue5 = threadLocalRandom.nextDouble(((-0.15)), 0.15) * (upperValue3 - lowerValue2);

         return Math.max((1L), Math.round(MathHelper.clamp(doubleValue4 + doubleValue5, lowerValue2, upperValue3)));
      }
   }

   public static void setBooleanState3(AutoComboModule autoComboModule, boolean booleanState32) {
      autoComboModule.booleanState3 = booleanState32;
   }

   public static boolean getBooleanState3(AutoComboModule autoComboModule) {
      return autoComboModule.booleanState3;
   }

   public static boolean getBooleanState(AutoComboModule autoComboModule) {
      return autoComboModule.booleanState;
   }

   private boolean checkCondition2() {
      int code = ((KeyBindingAccessor)MinecraftClientAccess2.getForwardKey(MinecraftClientAccess2.getOptions(mc))).getBoundKey().getCode();
      return (GLFW.glfwGetKey(mc.getWindow().getHandle(), code) == 1);
   }

   public void updateStateForEntity(Entity entity) {
      if (this.isEnabled()) {
         if (mc.player != null) {
            if (!this.booleanState4) {
               if (System.currentTimeMillis() < getLongState(this)) {
                  return;
               }

               ShieldDrainEvent shieldDrainEvent = new ShieldDrainEvent();
               MochiClient.INSTANCE.getMochiEventBus().post(shieldDrainEvent);
               if (shieldDrainEvent.isActive()) {
                  return;
               }

               if (getOnlyOnGroundSetting(this).isOn()) {
                  if (!mc.player.isOnGround()) {
                     return;
                  }
               }

               if (!this.checkCondition2()) {
                  return;
               }

               long deadlineMillis2;
               this.booleanState4 = true;
               setBooleanState2(this, this.checkCondition2());
               setBooleanState(this, this.checkCondition5());
               SprintResetPlan sprintResetPlan = this.computeSprintResetPlanForEntity2(entity);
               setBooleanState3(this, sprintResetPlan.getStap2());
               this.setDisplaySuffix(sprintResetPlan.getStap2() ? "STap" : "WTap");
               this.deadlineMillis = System.currentTimeMillis() + sprintResetPlan.getDurationMs2();
               deadlineMillis2 = getDeadlineMillis(this);

               this.longState = deadlineMillis2 + (120L);
               MinecraftClientAccess2.getForwardKey(MinecraftClientAccess2.getOptions(mc)).setPressed(false);
               mc.options.backKey.setPressed(sprintResetPlan.getStap2());
               return;
            }
         }
      }
   }

   public static DoubleRangeSetting getSTapDurationMsSetting(AutoComboModule autoComboModule) {
      return autoComboModule.sTapDurationMsSetting;
   }

   public boolean checkCondition3() {
      if (this.isEnabled()) {
         if (getBooleanState4(this)) {
            return true;
         }
      }

      return false;
   }

   public static DoubleRangeSetting getWTapDurationMsSetting(AutoComboModule autoComboModule) {
      return autoComboModule.wTapDurationMsSetting;
   }

   public AutoComboModule() {
      super("Auto Combo", "Automatically resets your sprint by tapping the appropriate key.", ModuleCategory.COMBAT);
      String[] stringArray = new String[]{"WTap", null, null, null};

      stringArray[1] = "STap";

      stringArray[2] = "Both";

      stringArray[3] = "Smart (Beta)";
      this.modeSetting = new ChoiceSetting("Mode", "WTap", stringArray);

      this.wTapDurationMsSetting = new DoubleRangeSetting("WTap Duration (ms)", 10.0, 300.0, (40.0), 60.0, (1.0));

      this.sTapDurationMsSetting = new DoubleRangeSetting("STap Duration (ms)", 10.0, (300.0), 40.0, 60.0, (1.0));

      this.smartBandBlocksSetting = new DoubleRangeSetting("Smart Band (Blocks)", 1.0, (5.0), (2.7), (3.0), 0.05);
      this.onlyOnGroundSetting = new BooleanSetting("Only On Ground", false);
      this.booleanState4 = false;
      this.booleanState3 = false;

      this.deadlineMillis = (0L);
      this.longState = 0L;

      this.booleanState2 = false;

      this.booleanState = false;
      this.addSetting(this.modeSetting);
      this.addSetting(this.wTapDurationMsSetting);
      this.addSetting(this.sTapDurationMsSetting);
      this.addSetting(this.smartBandBlocksSetting);
      this.addSetting(this.onlyOnGroundSetting);
      this.smartBandBlocksSetting.setVisibility(() -> this.checkCondition4());
   }

   public static boolean getBooleanState4(AutoComboModule autoComboModule) {
      return autoComboModule.booleanState4;
   }

   public static void setBooleanState2(AutoComboModule autoComboModule, boolean booleanState22) {
      autoComboModule.booleanState2 = booleanState22;
   }

   public static long getLongState(AutoComboModule autoComboModule) {
      return autoComboModule.longState;
   }

   public boolean getBooleanState322() {
      return getBooleanState3(this);
   }

   public static BooleanSetting getOnlyOnGroundSetting(AutoComboModule autoComboModule) {
      return autoComboModule.onlyOnGroundSetting;
   }

   private SprintResetPlan computeSprintResetPlanForEntity(Entity entity) {
      int intValue;
      double doubleValue;
      label45: {
         double doubleValue2 = (double)mc.player.distanceTo(entity);
         double lowerValue2 = this.smartBandBlocksSetting.getLowerValue2();
         double upperValue3 = this.smartBandBlocksSetting.getUpperValue3();
         double doubleValue3 = doubleValue2 + this.computeDoubleForEntity(entity) * 3.0;
         if (doubleValue3 < lowerValue2 - 0.15) {
            intValue = 1;
         } else {
            label44: {
               if (doubleValue3 > upperValue3 + 0.15) {
                  intValue = 0;
               } else {
                  intValue = (getBooleanState3(this)) ? 1 : 0;

                  if (intValue != 0) {
                     break label44;
                  }
               }

               doubleValue = Math.max((0.0), upperValue3 - doubleValue2);
               break label45;
            }
         }

         double doubleValue4 = Math.max((0.0), lowerValue2 - doubleValue3);
         double doubleValue5 = Math.max(0.0, doubleValue2 - upperValue3);
         doubleValue = Math.max(doubleValue4, doubleValue5);
      }

      return new SprintResetPlan((intValue != 0), this.computeLongForDoubleRangeSetting2(intValue != 0 ? this.sTapDurationMsSetting : getWTapDurationMsSetting(this), doubleValue));
   }

   @Override
   public void onDisable() {
      if (this.booleanState4) {
         if (this.booleanState2) {
            if (this.checkCondition2()) {
               MinecraftClientAccess2.getOptions(mc).forwardKey.setPressed(true);
            }
         } else {
            ThreadLocalRandom.current().nextInt(9);
         }
      }

      if (getBooleanState4(this) && getBooleanState(this)) {
         if (this.checkCondition5()) {
            ThreadLocalRandom.current().nextInt(17);

            MinecraftClientAccess2.getOptions(mc).backKey.setPressed(true);
         }
      }

      this.booleanState4 = false;
      this.longState = 0L;
      this.setDisplaySuffix(null);
   }

   private boolean checkCondition4() {
      if (!this.modeSetting.equals("Both")) {
         if (!getModeSetting(this).equals("Smart (Beta)")) {
            return false;
         }
      }

      return true;
   }

   public static void setBooleanState(AutoComboModule autoComboModule, boolean booleanState5) {
      autoComboModule.booleanState = booleanState5;
   }

   private SprintResetPlan computeSprintResetPlanForEntity2(Entity entity) {
      String selected = this.modeSetting.getSelected();
      if (selected.equals("Smart (Beta)")) {
         if (entity != null && MinecraftClientAccess2.getPlayer(mc) != null) {
            return this.computeSprintResetPlanForEntity(entity);
         }
      }

      int byteValue2;
      if (selected.equals("Both")) {
         if (entity == null) {
            byteValue2 = 1;
         } else {
            byte byteValue;
            label58: {
               double doubleValue = (double)MinecraftClientAccess2.getPlayer(mc).distanceTo(entity);
               if (!(doubleValue < this.smartBandBlocksSetting.getLowerValue2())) {
                  if (!(doubleValue > this.smartBandBlocksSetting.getUpperValue3())) {
                     byteValue = 0;
                     break label58;
                  }
               }

               byteValue = 1;
            }

            byteValue2 = byteValue;
         }
      } else {
         byteValue2 = (selected.equals("STap")) ? 1 : 0;
      }

      return new SprintResetPlan((byteValue2 != 0), this.computeLongForDoubleRangeSetting(byteValue2 != 0 ? getSTapDurationMsSetting(this) : getWTapDurationMsSetting(this)));
   }

   public static long getDeadlineMillis(AutoComboModule autoComboModule) {
      return autoComboModule.deadlineMillis;
   }

   private boolean checkCondition5() {
      int code = ((KeyBindingAccessor)mc.options.backKey).getBoundKey().getCode();
      return (GLFW.glfwGetKey(mc.getWindow().getHandle(), code) == 1);
   }
}
