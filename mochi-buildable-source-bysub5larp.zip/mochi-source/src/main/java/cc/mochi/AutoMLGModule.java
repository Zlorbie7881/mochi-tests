package cc.mochi;

import cc.mochi.event.impl.network.DisconnectEvent;
import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.event.impl.world.WorldChangeEvent;
import cc.mochi.mixin.MinecraftClientAccessor;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;

public final class AutoMLGModule extends Module {
   private boolean booleanState;
   private ClientPlayerEntity clientPlayerEntity;
   private int intState;
   private float pitch;

   private final BooleanSetting pickUpSetting;
   private final DoubleSetting fallDistanceSetting;
   private int intState2;
   private int intState3;

   private int counter;

   @EventHandler
   private void onDisconnect(DisconnectEvent disconnectEvent) {
      this.updateState();
   }

   private void updateState() {
      if (getClientPlayerEntity(this) != null) {
         if (this.clientPlayerEntity == mc.player) {
            if (getIntState2(this) >= 0) {
               ThreadLocalRandom.current().nextInt(12);
               if (this.intState3 >= 0) {
                  if (mc.player.getInventory().getSelectedSlot() == getIntState32(this)) {
                     MinecraftClientAccess5.getPlayer(mc).getInventory().setSelectedSlot(this.intState2);
                  }
               }
            }

            if (getBooleanState(this)) {
               mc.player.setPitch(getPitch(this));
            }
         }
      }

      this.intState = 0;
      setCounter(this, 0);
      this.intState2 = -1;

      this.intState3 = -1;
      this.clientPlayerEntity = null;
      setBooleanState(this, false);
   }

   public static int getIntState2(AutoMLGModule autoMLGModule) {
      return autoMLGModule.intState2;
   }

   private void updateState2() {
      this.counter++;
      if (!mc.player.isOnGround()) {
         if (!mc.player.isTouchingWater()) {
            return;
         }
      }

      int counter2 = getCounter(this);

      if (counter2 >= 3) {
         InventoryUtils.updateStateForItem(MinecraftClientAccess5.getBUCKET());
         int selectedSlot = MinecraftClientAccess5.getPlayer(mc).getInventory().getSelectedSlot();
         int selectedSlot2;
         if (selectedSlot != this.intState2 && mc.player.getInventory().getStack(selectedSlot).isOf(Items.BUCKET)) {
            ThreadLocalRandom.current().nextInt(14);
            selectedSlot2 = selectedSlot;
         } else {
            selectedSlot2 = -1;
         }

         this.intState3 = selectedSlot2;
         ((MinecraftClientAccessor)mc).invokeDoItemUse();
         this.intState = 3;
      }
   }

   public static float getPitch(AutoMLGModule autoMLGModule) {
      return autoMLGModule.pitch;
   }

   public static void setIntState2(AutoMLGModule autoMLGModule, int intState22) {
      autoMLGModule.intState2 = intState22;
   }

   public static ClientPlayerEntity getClientPlayerEntity(AutoMLGModule autoMLGModule) {
      return autoMLGModule.clientPlayerEntity;
   }

   public static BooleanSetting getPickUpSetting(AutoMLGModule autoMLGModule) {
      return autoMLGModule.pickUpSetting;
   }

   public static void setCounter(AutoMLGModule autoMLGModule, int counter2) {
      autoMLGModule.counter = counter2;
   }

   private void updateState3() {
      if (!this.booleanState) {
         mc.player.setPitch(89.5F);
         setBooleanState(this, true);
      } else if (MinecraftClientAccess5.getPlayer(mc).isOnGround()) {
         setIntState(this, 3);
      } else {
         int intValue = this.computeInt();
         setCounter(this, this.counter + 1);

         if (!(intValue > 2)) {
            if (this.counter % 2 == 0) {
               InventoryUtils.updateStateForItem(Items.WATER_BUCKET);
               int selectedSlot = mc.player.getInventory().getSelectedSlot();
               this.intState3 = selectedSlot != getIntState2(this) && mc.player.getInventory().getStack(selectedSlot).isOf(MinecraftClientAccess5.getWATER_BUCKET()) ? selectedSlot : -1;
               ((MinecraftClientAccessor)mc).invokeDoItemUse();
               this.intState = getPickUpSetting(this).getValue() ? 2 : 3;
               this.counter = 0;
            }
         }
      }
   }

   public static void setIntState3(AutoMLGModule autoMLGModule, int intState32) {
      autoMLGModule.intState3 = intState32;
   }

   public static int getIntState(AutoMLGModule autoMLGModule) {
      return autoMLGModule.intState;
   }

   public static int getCounter(AutoMLGModule autoMLGModule) {
      return autoMLGModule.counter;
   }

   public static void setBooleanState(AutoMLGModule autoMLGModule, boolean booleanState2) {
      autoMLGModule.booleanState = booleanState2;
   }

   @EventHandler
   private void onWorldChange(WorldChangeEvent worldChangeEvent) {
      if (worldChangeEvent.getWorld() != MinecraftClientAccess5.getWorld(mc)) {
         this.updateState();
      }
   }

   @Override
   public void onDisable() {
      this.updateState();
      super.onDisable();
   }

   private int computeInt() {
      if (this.isWorldUnavailable()) {
         return 6;
      } else {
         BlockPos blockPos = MinecraftClientAccess5.getPlayer(mc).getBlockPos();
         int intValue = 1;

         do {
            BlockPos blockPos2 = blockPos.down(intValue);
            if (!MinecraftClientAccess5.getWorld(mc).getBlockState(blockPos2).isAir()) {
               return intValue;
            }

            intValue++;
         } while (intValue <= 6);

         ThreadLocalRandom.current().nextInt(14);
         return 7;
      }
   }

   public static int getIntState32(AutoMLGModule autoMLGModule) {
      return autoMLGModule.intState3;
   }

   public AutoMLGModule() {
      super("Auto MLG", "Places water before landing", -1, ModuleCategory.MOVEMENT);

      this.fallDistanceSetting = new DoubleSetting("Fall Distance", (3.0), 40.0, (8.0), (1.0));
      this.pickUpSetting = new BooleanSetting("Pick Up", true);

      this.intState2 = -1;
      this.intState3 = -1;

      Setting[] settingArray = new Setting[2];

      settingArray[0] = this.fallDistanceSetting;

      settingArray[1] = this.pickUpSetting;
      this.addSettings(settingArray);
   }

   public static void setIntState(AutoMLGModule autoMLGModule, int intState4) {
      autoMLGModule.intState = intState4;
   }

   @EventHandler
   private void onTick(TickEvent tickEvent) {
      label56:
      if (!this.isWorldUnavailable()) {
         if (getClientPlayerEntity(this) != null) {
            ThreadLocalRandom.current().nextInt(12);
            if (getClientPlayerEntity(this) != mc.player) {
               break label56;
            }

            ThreadLocalRandom.current().nextInt(13);
         }

         if (getIntState(this) == 0) {
            ThreadLocalRandom.current().nextInt(8);
            this.updateState4();
         } else {
            int intState4 = getIntState(this);

            if (intState4 == 1) {
               this.updateState3();
            } else if (this.intState == 2) {
               this.updateState2();
            } else {
               if (this.intState == 3) {
                  this.updateState();
               }
            }
         }

         return;
      }

      this.updateState();
   }

   public static boolean getBooleanState(AutoMLGModule autoMLGModule) {
      return autoMLGModule.booleanState;
   }

   private void updateState4() {
      if (!MinecraftClientAccess5.getPlayer(mc).isOnGround()) {
         if (!(MinecraftClientAccess5.getPlayer(mc).isTouchingWater())) {
            if (!(mc.player.fallDistance < this.fallDistanceSetting.getValue())) {
               double y = MinecraftClientAccess5.getPlayer(mc).getVelocity().y;

               if (y >= ((-0.6))) {
               } else if (!InventoryUtils.testItem4(Items.WATER_BUCKET)) {
               } else {
                  this.clientPlayerEntity = mc.player;
                  setIntState2(this, mc.player.getInventory().getSelectedSlot());
                  this.pitch = mc.player.getPitch();
                  InventoryUtils.updateStateForItem(Items.WATER_BUCKET);
                  int selectedSlot = mc.player.getInventory().getSelectedSlot();
                  setIntState3(this, selectedSlot != getIntState2(this) && mc.player.getInventory().getStack(selectedSlot).isOf(MinecraftClientAccess5.getWATER_BUCKET()) ? selectedSlot : -1);

                  this.intState = 1;
                  setCounter(this, 0);

                  this.booleanState = false;
               }
            }
         }
      }
   }

}
