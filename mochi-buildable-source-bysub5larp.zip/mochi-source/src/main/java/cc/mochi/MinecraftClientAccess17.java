package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public class MinecraftClientAccess17 {
   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static ClientWorld getWorld(MinecraftClient minecraftClient) {
      return minecraftClient.world;
   }

   public static ClientPlayerInteractionManager getInteractionManager(MinecraftClient minecraftClient) {
      return minecraftClient.interactionManager;
   }

   public static int getHurtTime(LivingEntity livingEntity) {
      return livingEntity.hurtTime;
   }

   public static void setCrosshairTarget(MinecraftClient minecraftClient, HitResult crosshairTarget) {
      minecraftClient.crosshairTarget = crosshairTarget;
   }

   public static Screen getCurrentScreen(MinecraftClient minecraftClient) {
      return minecraftClient.currentScreen;
   }

   public static GameOptions getOptions(MinecraftClient minecraftClient) {
      return minecraftClient.options;
   }

   public static KeyBinding getForwardKey(GameOptions gameOptions) {
      return gameOptions.forwardKey;
   }

   public static double getMinZ(Box box) {
      return box.minZ;
   }

   public static double getMinY(Box box) {
      return box.minY;
   }

   public static double getY(Vec3d vec3d) {
      return vec3d.y;
   }

   public static KeyBinding getUseKey(GameOptions gameOptions) {
      return gameOptions.useKey;
   }

   public static AttackWaitState getRELEASE_AND_WAIT() {
      return AttackWaitState.RELEASE_AND_WAIT;
   }

   public static double getX(Vec3d vec3d) {
      return vec3d.x;
   }

   public static boolean getBooleanState() {
      return AutoStunModule.booleanState;
   }

}
