package cc.mochi;

public class CombatActionOwnerAccess2 {
   public static CombatActionOwner getAUTOMACE() {
      return CombatActionOwner.AUTOMACE;
   }

}
