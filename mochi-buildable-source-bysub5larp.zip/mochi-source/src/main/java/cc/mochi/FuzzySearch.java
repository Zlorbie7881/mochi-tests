package cc.mochi;

import java.util.Locale;

public final class FuzzySearch {
   public static int computeInt(String string, String string2) {
      if (string != null && !string.isBlank()) {
         if (string2 != null && !string2.isEmpty()) {
            String string3 = string.toLowerCase(Locale.ROOT).trim();
            String string4 = string2.toLowerCase(Locale.ROOT);
            if (string4.equals(string3)) {
               return 10000;
            } else if (string4.startsWith(string3)) {
               return 5000 - string4.length();
            } else {
               int intValue = string4.indexOf(string3);
               if (intValue >= 0) {
                  boolean booleanValue = intValue == 0 || !Character.isLetterOrDigit(string4.charAt(intValue - 1));
                  return (booleanValue ? 3000 : 2000) - intValue - string4.length();
               } else {
                  int intValue2 = computeInt3(string3, string4);
                  if (intValue2 >= 0) {
                     return intValue2;
                  } else {
                     int intValue3 = 0;
                     int intValue4 = 0;
                     int intValue5 = 0;

                     label77:
                     for (int intValue6 = 0; intValue6 < string3.length(); intValue6++) {
                        char charValue = string3.charAt(intValue6);
                        if (charValue != ' ') {
                           while (intValue5 < string4.length()) {
                              char charValue2 = string4.charAt(intValue5);
                              boolean booleanValue2 = intValue5 == 0 || !Character.isLetterOrDigit(string4.charAt(intValue5 - 1));
                              intValue5++;
                              if (charValue2 == charValue) {
                                 intValue3 += 10 + ++intValue4 * 6 + (booleanValue2 ? 25 : 0);
                                 continue label77;
                              }

                              intValue4 = 0;
                           }

                           return -1;
                        }
                     }

                     return intValue3 - string4.length();
                  }
               }
            }
         } else {
            return -1;
         }
      } else {
         return 0;
      }
   }

   public static int computeInt2(String string, String... stringArray) {
      int intValue = -1;

      for (String string2 : stringArray) {
         intValue = Math.max(intValue, computeInt(string, string2));
      }

      return intValue;
   }

   private FuzzySearch() {
   }

   private static int computeInt3(String string, String string2) {
      int intValue = 0;

      label37:
      for (int intValue2 = 0; intValue2 < string.length(); intValue2++) {
         char charValue = string.charAt(intValue2);
         if (charValue != ' ') {
            while (intValue < string2.length()) {
               boolean booleanValue = intValue == 0 || !Character.isLetterOrDigit(string2.charAt(intValue - 1));
               char charValue2 = string2.charAt(intValue++);
               if (booleanValue && charValue2 == charValue) {
                  continue label37;
               }
            }

            return -1;
         }
      }

      return 1500 + string.length() * 10 - string2.length();
   }
}
