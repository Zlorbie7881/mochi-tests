package cc.mochi;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public final class HeldItemPredicates implements MinecraftAccess {
   public static boolean testItem(Item item) {
      int intValue = 0;

      while (true) {
         if (intValue >= 9) {
            return false;
         }

         ItemStack stack = MinecraftClientAccess36.getPlayer(mc).getInventory().getStack(intValue);
         if (!stack.isEmpty()) {
            if (stack.getItem() == item) {
               ThreadLocalRandom.current().nextInt(11);

               mc.player.getInventory().setSelectedSlot(intValue);
               return true;
            }
         }

         intValue++;
      }
   }
}
