package cc.mochi;

import cc.mochi.event.impl.network.DisconnectEvent;
import cc.mochi.event.impl.player.ItemUseEvent;
import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.event.impl.world.WorldChangeEvent;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class AutoWindChargeModule extends Module {
   private final KeybindSetting activationKeySetting;

   private final ChoiceSetting modeSetting;
   private final BooleanSetting swapBackSetting;

   private long deadlineMillis;
   private long longState;

   private float yaw;

   private ClientPlayerEntity clientPlayerEntity;

   private long deadlineMillis2;
   private final DoubleSetting speedSetting;

   private float pitch;

   private int intState;
   private long timestampMillis;

   private boolean booleanState;

   private boolean booleanState2;
   private WindChargeState windChargeState;

   private int intState2;

   private boolean booleanState3;

   private final ChoiceSetting aimSetting;

   private boolean booleanState4;

   public static WindChargeState getWindChargeState(AutoWindChargeModule autoWindChargeModule) {
      return autoWindChargeModule.windChargeState;
   }

   private void updateState() {
      if (mc.player != null) {
         if (MinecraftClientAccess43.getPlayer(mc) == this.clientPlayerEntity) {
            ThreadLocalRandom.current().nextInt(14);
            if (this.swapBackSetting.isOn()) {
               if (this.booleanState) {
                  if (getIntState2(this) != -1) {
                     if (MinecraftClientAccess43.getPlayer(mc).getInventory().getSelectedSlot() == getIntState(this)) {
                        mc.player.getInventory().setSelectedSlot(this.intState2);
                        this.booleanState = false;
                        return;
                     }
                  }
               }
            }
         }
      }
   }

   public static void setBooleanState3(AutoWindChargeModule autoWindChargeModule, boolean booleanState32) {
      autoWindChargeModule.booleanState3 = booleanState32;
   }

   public static void setIntState2(AutoWindChargeModule autoWindChargeModule, int intState22) {
      autoWindChargeModule.intState2 = intState22;
   }

   public static KeybindSetting getActivationKeySetting(AutoWindChargeModule autoWindChargeModule) {
      return autoWindChargeModule.activationKeySetting;
   }

   public static void setBooleanState(AutoWindChargeModule autoWindChargeModule, boolean booleanState5) {
      autoWindChargeModule.booleanState = booleanState5;
   }

   public static void setBooleanState4(AutoWindChargeModule autoWindChargeModule, boolean booleanState42) {
      autoWindChargeModule.booleanState4 = booleanState42;
   }

   public AutoWindChargeModule() {
      super("Auto Wind Charge", "Flicks down, throws a wind charge and jumps with it", -1, ModuleCategory.MOVEMENT);
      String[] stringArray = new String[3];

      stringArray[0] = "Legit";
      stringArray[1] = "Silent";

      stringArray[2] = "None";
      this.aimSetting = new ChoiceSetting("Aim", "Legit", stringArray);
      this.modeSetting = new ChoiceSetting("Mode", "On Key", "On Key", "On Throw");
      this.activationKeySetting = new KeybindSetting("Activation Key", 71, false);

      this.speedSetting = new DoubleSetting("Speed", (1.0), (10.0), 5.0, 0.5);

      this.swapBackSetting = new BooleanSetting("Swap Back", true);
      this.windChargeState = WindChargeState.IDLE;

      this.timestampMillis = (0L);

      this.longState = 120L;

      this.deadlineMillis2 = (0L);

      this.deadlineMillis = (0L);

      this.booleanState2 = true;
      this.intState = -1;

      this.intState2 = -1;

      this.booleanState4 = false;

      this.booleanState3 = false;

      Setting[] settingArray = new Setting[]{this.aimSetting, this.modeSetting, this.activationKeySetting, null, null};

      settingArray[3] = this.speedSetting;

      settingArray[4] = this.swapBackSetting;
      this.addSettings(settingArray);
      this.getSettings().removeIf(objectValue -> this.testSetting((Setting)objectValue));
      this.activationKeySetting.setVisibility(() -> this.equals());
   }

   private void updateState2() {
      if (mc.options != null) {
         KeybindUtils.updateStateForKeyBinding(MinecraftClientAccess43.getJumpKey(mc.options));
      } else {
         ThreadLocalRandom.current().nextInt(3);
      }
   }

   public static boolean getBooleanState2(AutoWindChargeModule autoWindChargeModule) {
      return autoWindChargeModule.booleanState2;
   }

   public static void setIntState(AutoWindChargeModule autoWindChargeModule, int intState3) {
      autoWindChargeModule.intState = intState3;
   }

   @Override
   public int getKeyCode() {
      return -1;
   }

   public static void setWindChargeState(AutoWindChargeModule autoWindChargeModule, WindChargeState windChargeState2) {
      autoWindChargeModule.windChargeState = windChargeState2;
   }

   public static ChoiceSetting getModeSetting(AutoWindChargeModule autoWindChargeModule) {
      return autoWindChargeModule.modeSetting;
   }

   public static void setLongState(AutoWindChargeModule autoWindChargeModule, long longState2) {
      autoWindChargeModule.longState = longState2;
   }

   @EventHandler
   private void onTick(TickEvent tickEvent) {
      KeybindUtils.updateState2();
      if (!this.isWorldUnavailable()) {
         if (getClientPlayerEntity(this) == null || getClientPlayerEntity(this) == mc.player) {
            if (getModeSetting(this).equals("On Key")) {
               boolean booleanState42 = KeybindUtils.checkCondition(getActivationKeySetting(this).getKeyCode());
               if (booleanState42) {
                  if (!getBooleanState4(this)) {
                     ThreadLocalRandom.current().nextInt(17);
                     setBooleanState3(this, true);
                  }
               }

               setBooleanState4(this, booleanState42);
            }

            if (this.booleanState3) {
               if (getWindChargeState(this) == WindChargeState.IDLE) {
                  this.booleanState3 = false;
                  this.updateState3();
               }
            }

            if (getWindChargeState(this) != WindChargeState.IDLE) {
               this.updateState8();
            }

            return;
         }
      }

      this.updateState10();
   }

   public static int getIntState2(AutoWindChargeModule autoWindChargeModule) {
      return autoWindChargeModule.intState2;
   }

   @EventHandler
   private void onWorldChange(WorldChangeEvent worldChangeEvent) {
      if (worldChangeEvent.getWorld() != MinecraftClientAccess43.getWorld(mc)) {
         this.updateState10();
      }
   }

   public static void setClientPlayerEntity(AutoWindChargeModule autoWindChargeModule, ClientPlayerEntity clientPlayerEntity2) {
      autoWindChargeModule.clientPlayerEntity = clientPlayerEntity2;
   }

   public static int getIntState(AutoWindChargeModule autoWindChargeModule) {
      return autoWindChargeModule.intState;
   }

   public static boolean getBooleanState4(AutoWindChargeModule autoWindChargeModule) {
      return autoWindChargeModule.booleanState4;
   }

   private void updateState3() {
      setIntState(this, this.computeInt());
      if ((getIntState(this) != -1)) {
         setClientPlayerEntity(this, MinecraftClientAccess43.getPlayer(mc));
         setIntState2(this, MinecraftClientAccess43.getPlayer(mc).getInventory().getSelectedSlot());
         this.yaw = mc.player.getYaw();
         this.pitch = MinecraftClientAccess43.getPlayer(mc).getPitch();
         this.windChargeState = WindChargeState.FLICK;
         this.timestampMillis = System.currentTimeMillis();
         float pitch2 = getPitch(this);

         this.longState = this.computeLong(pitch2, (89.0F));
         this.updateState7(89.0F);
      }
   }

   public static WindChargeState getIDLE() {
      return WindChargeState.IDLE;
   }

   public static void setTimestampMillis(AutoWindChargeModule autoWindChargeModule, long timestampMillis2) {
      autoWindChargeModule.timestampMillis = timestampMillis2;
   }

   public static ClientPlayerEntity getClientPlayerEntity(AutoWindChargeModule autoWindChargeModule) {
      return autoWindChargeModule.clientPlayerEntity;
   }

   private Vec3d computeVec3d(float floatValue, float floatValue2) {
      return this.computeVec3d2(floatValue, floatValue2);
   }

   private void updateState4() {
      RotationManager.updateState(this);
      if (this.aimSetting.equals("Legit")) {
         if (MinecraftClientAccess43.getPlayer(mc) == this.clientPlayerEntity) {
            mc.player.setYaw(this.yaw);
            mc.player.setPitch(this.pitch);
         }
      } else {
         ThreadLocalRandom.current().nextInt(11);
      }

      this.updateState5();
   }

   private void updateState5() {
      setWindChargeState(this, WindChargeState.IDLE);

      setTimestampMillis(this, (0L));

      setLongState(this, (120L));

      setDeadlineMillis2(this, (0L));

      this.deadlineMillis = (0L);

      setBooleanState22(this, true);
      this.intState = -1;
      this.intState2 = -1;
      setClientPlayerEntity(this, null);
      setBooleanState(this, false);
   }

   private double computeDouble() {
      return 90.0 * Math.pow(this.speedSetting.getValue(), 1.8);
   }

   private int computeInt() {
      ThreadLocalRandom.current().nextInt(8);
      int intValue = 0;

      do {
         if (this.testItemStack(mc.player.getInventory().getStack(intValue))) {
            ThreadLocalRandom.current().nextInt(5);

            return intValue;
         }

         intValue++;
      } while (intValue < 9);

      ThreadLocalRandom.current().nextInt(17);
      return -1;
   }

   private boolean checkCondition(long longValue) {
      if (this.aimSetting.equals("None")) {
         return true;
      } else {
         if (!RotationManager.checkCondition3((2.0F))) {
            if (longValue - this.timestampMillis < getLongState(this)) {
               return false;
            }
         }

         return true;
      }
   }

   public static void setDeadlineMillis2(AutoWindChargeModule autoWindChargeModule, long deadlineMillis22) {
      autoWindChargeModule.deadlineMillis2 = deadlineMillis22;
   }

   private Boolean equals() {
      return this.modeSetting.equals("On Key");
   }

   @Override
   public void onDisable() {
      this.updateState10();
   }

   private void updateState6() {
      if (getIntState(this) >= 0) {
         setBooleanState(this, ((MinecraftClientAccess43.getPlayer(mc).getInventory().getSelectedSlot() != getIntState(this) ? 1 : 0) != 0));
         mc.player.getInventory().setSelectedSlot(getIntState(this));
      }
   }

   private void updateState7(float floatValue) {
      if (!(this.aimSetting.equals("None"))) {
         floatValue = MathHelper.clamp(floatValue, ((-89.9F)), 89.9F);
         float yaw2 = getYaw(this);
         float capturedPitch = floatValue;
         RotationManager.updateStateForActionPriority(this, ActionPriority.HIGH, () -> this.computeVec3d(yaw2, capturedPitch), RotationProfile.createRotationProfile().withMaxRotationSpeed(this.computeDouble()).computeRotationProfile10(0.85).withSilentAim(this.aimSetting.equals("Silent")));
      }
   }

   @EventHandler
   private void onDisconnect(DisconnectEvent disconnectEvent) {
      this.updateState10();
   }

   @EventHandler
   private void onItemUse(ItemUseEvent itemUseEvent) {
      if (this.isEnabled()) {
         if (!this.isWorldUnavailable()) {
            if (this.modeSetting.equals("On Throw")) {
               if (this.windChargeState != WindChargeState.IDLE) {
                  return;
               }

               if (this.testItemStack(MinecraftClientAccess43.getPlayer(mc).getMainHandStack())) {
                  setBooleanState3(this, true);
               }

               return;
            }
         }
      }
   }

   private Vec3d computeVec3d2(float floatValue, float floatValue2) {
      ThreadLocalRandom.current().nextInt(6);

      if (MinecraftClientAccess43.getPlayer(mc) == null) {
         return null;
      } else {
         ThreadLocalRandom.current().nextInt(6);
         Vec3d eyePos = MinecraftClientAccess43.getPlayer(mc).getEyePos();
         Vec3d vec3d = RotationMath.computeVec3d(floatValue, floatValue2);

         return eyePos.add(vec3d.multiply((10.0)));
      }
   }

   public static void setBooleanState22(AutoWindChargeModule autoWindChargeModule, boolean booleanState22) {
      autoWindChargeModule.booleanState2 = booleanState22;
   }

   public static long getLongState(AutoWindChargeModule autoWindChargeModule) {
      return autoWindChargeModule.longState;
   }

   private void updateState8() {
      long timestampMillis2 = System.currentTimeMillis();
      switch (getWindChargeState(this)) {
         case FLICK:

            if (!this.checkCondition(timestampMillis2)) {
               return;
            }

            this.updateState6();
            ThreadLocalRandom threadLocalRandom = ThreadLocalRandom.current();
            long longValue = 5187255321411507505L;
            longValue = 5187255321411507505L;
            long longValue2 = 10L;
            longValue = (-4716431465026475094L);
            long longValue3 = -470894813539729758L;
            longValue3 = -470894813539729758L;
            long longValue4 = 1067395993L;
            this.deadlineMillis2 = timestampMillis2 + threadLocalRandom.nextLong(10L, (51L));
            setWindChargeState(this, WindChargeState.THROW);

            break;
         case THROW:
            if (timestampMillis2 < this.deadlineMillis2) {
               return;
            }

            this.updateState9();
            this.updateState2();
            if (this.aimSetting.equals("Legit")) {
               setLongState(this, this.computeLong(89.0F, this.pitch));
               this.updateState7(this.pitch);
            }

            this.timestampMillis = timestampMillis2;
            long longValue5 = (-7969398455962076471L);
            long longValue6 = 3384523436948342492L;
            longValue6 = 3384523436948342492L;
            long longValue7 = 4141185709L;
            this.deadlineMillis = timestampMillis2 + (100L);
            setBooleanState22(this, false);
            setWindChargeState(this, WindChargeState.RECOVER);

            break;
         case RECOVER:
            if (!getBooleanState2(this) && timestampMillis2 >= this.deadlineMillis) {
               this.updateState();

               this.booleanState2 = true;
            }

            if (getBooleanState2(this) && this.checkCondition(timestampMillis2)) {
               this.updateState4();

               ThreadLocalRandom.current().nextInt(14);
            }
      }
   }

   @Override
   public void onEnable() {
      this.updateState5();
      this.booleanState4 = false;

      this.booleanState3 = false;
   }

   private boolean testItemStack(ItemStack itemStack) {
      if (itemStack != null) {
         if (!itemStack.isEmpty() && itemStack.getItem() == MinecraftClientAccess43.getWIND_CHARGE()) {
            return true;
         }
      }

      return false;
   }

   private void updateState9() {
      label28: {
         ActionResult actionResult = MinecraftClientAccess43.getInteractionManager(mc).interactItem(MinecraftClientAccess43.getPlayer(mc), MinecraftClientAccess43.getMAIN_HAND());
         if (actionResult != ActionResult.SUCCESS) {
            if (actionResult != ActionResult.SUCCESS_SERVER) {
               break label28;
            }
         }

         MinecraftClientAccess43.getPlayer(mc).swingHand(Hand.MAIN_HAND);
      }
   }

   public static WindChargeState getTHROW() {
      return WindChargeState.THROW;
   }

   public static WindChargeState getRECOVER() {
      return WindChargeState.RECOVER;
   }

   private void updateState10() {
      RotationManager.updateState(this);
      if (getWindChargeState(this) == WindChargeState.RECOVER) {
         ThreadLocalRandom.current().nextInt(8);
         KeybindUtils.updateState();
      } else {
         ThreadLocalRandom.current().nextInt(16);
      }

      this.updateState();
      if (this.windChargeState != WindChargeState.IDLE) {
         if (this.aimSetting.equals("Legit")) {
            if (mc.player == this.clientPlayerEntity) {
               mc.player.setYaw(this.yaw);
               mc.player.setPitch(this.pitch);
            }
         }
      }

      this.updateState5();

      this.booleanState3 = false;

      this.booleanState4 = false;
   }

   public static float getYaw(AutoWindChargeModule autoWindChargeModule) {
      return autoWindChargeModule.yaw;
   }

   private boolean testSetting(Setting setting) {
      if (setting instanceof KeybindSetting) {
         if (!setting.equals(this.activationKeySetting)) {
            return true;
         }
      }

      return false;
   }

   public static float getPitch(AutoWindChargeModule autoWindChargeModule) {
      return autoWindChargeModule.pitch;
   }

   private long computeLong(float floatValue, float floatValue2) {
      double doubleValue = (double)Math.abs(MathHelper.wrapDegrees(floatValue2 - floatValue));
      double doubleValue2 = doubleValue / this.computeDouble();

      long longValue = Math.round(doubleValue2 * (1000.0) + 160.0);

      return MathHelper.clamp(longValue, (120L), 2200L);
   }

}
