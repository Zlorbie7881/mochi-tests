package cc.mochi;

import org.jetbrains.annotations.NotNull;

record Glyph(int u, int v, int width, int height, char value, GlyphPage owner) {
   public char getValue() {
      return this.value;
   }

   public GlyphPage getOwner() {
      return this.owner;
   }

   public int getU() {
      return this.u;
   }

   public int getHeight() {
      return this.height;
   }

   @NotNull
   @Override
   public String toString() {
      return "Glyph[u="
         + this.u
         + ", v="
         + this.v
         + ", width="
         + this.width
         + ", height="
         + this.height
         + ", value="
         + this.value
         + ", owner="
         + this.owner
         + "]";
   }

   public int getWidth() {
      return this.width;
   }

   public int getV() {
      return this.v;
   }
}
