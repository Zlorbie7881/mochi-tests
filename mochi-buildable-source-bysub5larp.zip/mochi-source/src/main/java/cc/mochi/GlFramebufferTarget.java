package cc.mochi;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

final class GlFramebufferTarget {
   private int vertexArrayId;
   private static final float[] QUAD_VERTICES = new float[]{((-1.0F)), ((-1.0F)), 1.0F, ((-1.0F)), 1.0F, 1.0F, ((-1.0F)), 1.0F};

   private static final int[] QUAD_INDICES = new int[]{0, 1, 2, 2, 3, 0};
   private int indexBufferId;
   private int vertexBufferId;

   void destroy() {
      if (this.vertexArrayId != 0 && GL30.glIsVertexArray(this.vertexArrayId)) {
         GL30.glDeleteVertexArrays(this.vertexArrayId);
      }

      if (this.vertexBufferId != 0 && GL15.glIsBuffer(this.vertexBufferId)) {
         GL15.glDeleteBuffers(this.vertexBufferId);
      }

      if (this.indexBufferId != 0 && GL15.glIsBuffer(this.indexBufferId)) {
         GL15.glDeleteBuffers(this.indexBufferId);
      }

      this.vertexArrayId = 0;
      this.vertexBufferId = 0;
      this.indexBufferId = 0;
   }

   boolean isValid() {
      return this.vertexArrayId != 0 && this.vertexBufferId != 0 && this.indexBufferId != 0 && GL30.glIsVertexArray(this.vertexArrayId) && GL15.glIsBuffer(this.vertexBufferId) && GL15.glIsBuffer(this.indexBufferId);
   }

   boolean ensureInitialized() {
      if (this.isValid()) {
         return true;
      } else {
         this.vertexArrayId = GL30.glGenVertexArrays();
         this.vertexBufferId = GL15.glGenBuffers();
         this.indexBufferId = GL15.glGenBuffers();
         if (this.vertexArrayId != 0 && this.vertexBufferId != 0 && this.indexBufferId != 0) {
            GL30.glBindVertexArray(this.vertexArrayId);
            GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, this.vertexBufferId);
            GL15.glBufferData(GL15.GL_ARRAY_BUFFER, QUAD_VERTICES, GL15.GL_STATIC_DRAW);
            GL15.glBindBuffer(GL15.GL_ELEMENT_ARRAY_BUFFER, this.indexBufferId);
            GL15.glBufferData(GL15.GL_ELEMENT_ARRAY_BUFFER, QUAD_INDICES, GL15.GL_STATIC_DRAW);
            GL20.glVertexAttribPointer(0, 2, GL11.GL_FLOAT, false, 8, 0L);
            GL20.glEnableVertexAttribArray(0);
            return true;
         } else {
            this.destroy();
            return false;
         }
      }
   }

   void draw() {
      GL30.glBindVertexArray(this.vertexArrayId);
      GL11.glDrawElements(GL11.GL_TRIANGLES, 6, GL11.GL_UNSIGNED_INT, 0L);
   }
}
