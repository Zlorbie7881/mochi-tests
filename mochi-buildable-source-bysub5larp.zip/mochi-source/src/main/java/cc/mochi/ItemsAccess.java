package cc.mochi;

import net.minecraft.item.Item;
import net.minecraft.item.Items;

public class ItemsAccess {
   public static Item getCHORUS_FRUIT() {
      return Items.CHORUS_FRUIT;
   }

   public static Item getENCHANTED_GOLDEN_APPLE() {
      return Items.ENCHANTED_GOLDEN_APPLE;
   }

   public static Item computeItem() {
      return Items.APPLE;
   }

   public static Item getCOOKED_PORKCHOP() {
      return Items.COOKED_PORKCHOP;
   }

   public static Item getSWEET_BERRIES() {
      return Items.SWEET_BERRIES;
   }

   public static Item getDRIED_KELP() {
      return Items.DRIED_KELP;
   }

   public static Item getPUMPKIN_PIE() {
      return Items.PUMPKIN_PIE;
   }

   public static Item getPOTATO() {
      return Items.POTATO;
   }

   public static Item getCOOKED_BEEF() {
      return Items.COOKED_BEEF;
   }
}
