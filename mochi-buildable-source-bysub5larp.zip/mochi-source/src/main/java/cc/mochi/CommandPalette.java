package cc.mochi;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Supplier;

public final class CommandPalette {
   private boolean booleanState;

   private final Supplier<List<PaletteCommand>> supplier;
   private double doubleState;

   private final ScrollModel scrollModel;
   private int intState;
   private long longState;

   private String string;

   private final TextInputModel textInputModel = new TextInputModel(48);

   private List<PaletteCommand> paletteCommandList;

   private double doubleState2;

   private void updateState(int intValue) {
      if (!getPaletteCommandList(this).isEmpty()) {
         this.intState = Math.floorMod(getIntState(this) + intValue, this.paletteCommandList.size());
         this.scrollModel.ensureVisible((float)getIntState(this) * 30.0F, (float)(getIntState(this) + 1) * 30.0F, 244.0F);
         ClientSounds.updateState();
      }
   }

   public static List<PaletteCommand> getPaletteCommandList(CommandPalette commandPalette) {
      return commandPalette.paletteCommandList;
   }

   public void updateStateForUiContext(UiContext uiContext, float floatValue, float floatValue2, float floatValue3) {
      float floatValue4 = uiContext.getAnimations().exponential("palette." + this.longState, 0.0F, this.booleanState ? 1.0F : 0.0F, 0.04F);
      if (!(floatValue4 <= 0.01F)) {
         this.updateState2();
         ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
         float floatValue5 = floatValue3 * floatValue4;
         uiContext.getUiRenderContext().flushBloom();
         PanelRenderer.updateStateForUiContext6(uiContext, floatValue, floatValue2, 0.6F * floatValue5);
         if (getBooleanState(this)) {
            uiContext.getInputRouter().addModalCatcher(UiLayer.SYSTEM, () -> this.updateState9());
         }

         int intValue = Math.min(8, getPaletteCommandList(this).size());
         float floatValue6 = getPaletteCommandList(this).isEmpty() ? 54.0F : (float)intValue * 30.0F + 8.0F;
         float floatValue7 = 34.0F + floatValue6 + 24.0F;
         float floatValue8 = Math.max(20.0F, floatValue2 * 0.18F) - 10.0F * (1.0F - floatValue4);
         Rect rect = new Rect(floatValue / 2.0F - 195.0F, floatValue8, 390.0F, floatValue7);
         uiContext.getUiRenderContext().pushTransform();
         uiContext.getUiRenderContext().scaleAroundPoint(0.97F + 0.03F * floatValue4, rect.centerX(), rect.getY());
         PanelRenderer.drawCard(uiContext, rect, floatValue5);
         if (getBooleanState(this)) {
            uiContext.getInputRouter().addPressRegion(rect, UiLayer.SYSTEM, (intValue2, doubleValue, doubleValue2) -> updateState6(intValue2, doubleValue, doubleValue2));
         }

         float floatValue9 = rect.getY() + 17.0F + 2.0F;
         UiShapeRenderer.updateStateForUiRenderContext3(uiContext.getUiRenderContext(), Icon.SEARCH, rect.getX() + 18.0F, floatValue9, 11.0F, UiContext.multiplyAlpha(themeSnapshot2.getAccentText2(), floatValue5));
         String text = this.textInputModel.toString();
         float x2 = rect.getX() + 32.0F;
         if (text.isEmpty()) {
            uiContext.drawVerticallyCenteredText("Search modules, tools and themes", x2, floatValue9, TextStyle.BODY, UiContext.multiplyAlpha(themeSnapshot2.getDisabledText2(), floatValue5));
         } else {
            uiContext.drawVerticallyCenteredText(text, x2, floatValue9, TextStyle.BODY, UiContext.multiplyAlpha(themeSnapshot2.getPrimaryText(), floatValue5));
         }

         if (this.textInputModel.checkCondition2(uiContext.getDeltaSeconds())) {
            float x = x2 + uiContext.measureText(text.substring(0, Math.min(text.length(), getTextInputModel(this).getCounter9())), TextStyle.BODY) + 0.5F;
            float height = uiContext.measureFontHeight(TextStyle.BODY);
            uiContext.getUiRenderContext().pushBloom(themeSnapshot2.computeFloat3(0.6F) * floatValue5);
            uiContext.getUiRenderContext().fillRect(x, floatValue9 - height / 2.0F, 1.0F, height, UiContext.multiplyAlpha(themeSnapshot2.getAccent2(), floatValue5));
            uiContext.getUiRenderContext().popBloom();
         }

         LabelWidgets.computeFloatForUiContext5(uiContext, rect.right() - 14.0F, floatValue9, "Esc", floatValue5);
         PanelRenderer.updateStateForUiContext3(uiContext, rect.getX() + 10.0F, rect.getY() + 34.0F + 2.0F, rect.right() - 10.0F, floatValue5);
         Rect rect2 = new Rect(rect.getX() + 6.0F, rect.getY() + 34.0F + 6.0F, rect.getWidth() - 12.0F, floatValue6 - 4.0F);
         if (getPaletteCommandList(this).isEmpty()) {
            uiContext.drawCenteredText("Nothing matches “" + uiContext.ellipsize(text, TextStyle.BODY, 200.0F) + "”", rect2.centerX(), rect2.centerY() - 4.0F, TextStyle.BODY, UiContext.multiplyAlpha(themeSnapshot2.getSecondaryText2(), floatValue5));
            uiContext.drawCenteredText("Try a module name, “theme” or “config”", rect2.centerX(), rect2.centerY() + 8.0F, TextStyle.CAPTION, UiContext.multiplyAlpha(themeSnapshot2.getDisabledText2(), floatValue5));
         } else {
            float floatValue13 = getScrollModel(this).update(uiContext, (float)getPaletteCommandList(this).size() * 30.0F, rect2.getHeight());
            uiContext.getInputRouter().addScrollRegion(rect2, UiLayer.SYSTEM, getScrollModel(this)::scroll);
            uiContext.getUiRenderContext().pushClip(rect2.getX(), rect2.getY(), rect2.getWidth(), rect2.getHeight());

            for (int intState2 = 0; intState2 < this.paletteCommandList.size(); intState2++) {
               float floatValue14 = rect2.getY() + (float)intState2 * 30.0F - floatValue13;
               if (!(floatValue14 + 30.0F < rect2.getY()) && !(floatValue14 > rect2.bottom())) {
                  PaletteCommand paletteCommand = getPaletteCommandList(this).get(intState2);
                  Rect rect3 = new Rect(rect2.getX(), floatValue14, rect2.getWidth(), 30.0F);
                  boolean booleanValue = this.booleanState && uiContext.isHovered(rect3.intersection(rect2), UiLayer.SYSTEM);
                  if (booleanValue && (uiContext.getMouseX() != this.doubleState2 || uiContext.getMouseY() != this.doubleState)) {
                     setIntState(this, intState2);
                  }

                  float progress = uiContext.animateToggle("palette.row." + intState2, intState2 == getIntState(this), 0.035F);
                  PanelRenderer.updateStateForUiContext4(uiContext, rect3.inset(0.0F, 1.0F), 7.0F, progress, floatValue5);
                  boolean booleanValue2 = paletteCommand.getActive2() != null && paletteCommand.getActive2().getAsBoolean();
                  Rect rect4 = new Rect(rect3.getX() + 6.0F, rect3.centerY() - 10.0F, 20.0F, 20.0F);
                  uiContext.getUiRenderContext().fillRoundedRect(rect4.getX(), rect4.getY(), 20.0F, 20.0F, 6.0F, UiContext.multiplyAlpha(booleanValue2 ? themeSnapshot2.getAccent2() : UiContext.blendColors(themeSnapshot2.getSurfaceRaised(), themeSnapshot2.getAccentSoft2(), progress), floatValue5));
                  UiShapeRenderer.updateStateForUiRenderContext3(
                     uiContext.getUiRenderContext(),
                     paletteCommand.getIcon() == null ? Icon.ARROW_RIGHT : paletteCommand.getIcon(),
                     rect4.centerX(),
                     rect4.centerY(),
                     10.0F,
                     UiContext.multiplyAlpha(booleanValue2 ? themeSnapshot2.getOnAccent() : UiContext.blendColors(themeSnapshot2.getSecondaryText2(), themeSnapshot2.getAccentText2(), progress), floatValue5)
                  );
                  String text2 = paletteCommand.getState() == null ? null : (String)paletteCommand.getState().get();
                  float floatValue16 = rect3.right() - 8.0F;
                  float floatValue17 = LabelWidgets.computeFloatForUiContext4(uiContext, paletteCommand.getGroup());
                  LabelWidgets.computeFloatForUiContext7(uiContext, floatValue16 - floatValue17, rect3.centerY(), paletteCommand.getGroup(), ControlTone.NEUTRAL, floatValue5);
                  floatValue16 -= floatValue17 + 6.0F;
                  float x3 = rect4.right() + 9.0F;
                  if (text2 != null && !text2.isEmpty()) {
                     float floatValue19 = uiContext.measureText(text2, TextStyle.CAPTION);
                     uiContext.drawVerticallyCenteredText(text2, floatValue16 - floatValue19, rect3.centerY(), TextStyle.CAPTION, UiContext.multiplyAlpha(booleanValue2 ? themeSnapshot2.getAccentText2() : themeSnapshot2.getDisabledText2(), floatValue5));
                     floatValue16 -= floatValue19 + 8.0F;
                  }

                  uiContext.drawVerticallyCenteredText(
                     uiContext.ellipsize(paletteCommand.getTitle2(), TextStyle.STRONG, floatValue16 - x3), x3, rect3.centerY(), TextStyle.STRONG, UiContext.multiplyAlpha(UiContext.blendColors(themeSnapshot2.getPrimaryText(), themeSnapshot2.getAccentText2(), progress * 0.3F), floatValue5)
                  );
                  int intState3 = intState2;
                  if (this.booleanState) {
                     uiContext.getInputRouter().addClickRegion(rect3.intersection(rect2), UiLayer.SYSTEM, () -> this.updateState8(intState3));
                  }
               }
            }

            uiContext.getUiRenderContext().popClip();
         }

         setDoubleState2(this, uiContext.getMouseX());
         setDoubleState(this, uiContext.getMouseY());
         float y = rect.bottom() - 12.0F;
         float x4 = rect.getX() + 14.0F;
         x4 += LabelWidgets.computeFloatForUiContext6(uiContext, x4, y, floatValue5, "↑", "↓") + 5.0F;
         uiContext.drawVerticallyCenteredText("Move", x4, y, TextStyle.CAPTION, UiContext.multiplyAlpha(themeSnapshot2.getDisabledText2(), floatValue5));
         x4 += uiContext.measureText("Move", TextStyle.CAPTION) + 12.0F;
         x4 += LabelWidgets.computeFloatForUiContext2(uiContext, x4, y, "Enter", floatValue5) + 5.0F;
         uiContext.drawVerticallyCenteredText("Run", x4, y, TextStyle.CAPTION, UiContext.multiplyAlpha(themeSnapshot2.getDisabledText2(), floatValue5));
         x4 += uiContext.measureText("Run", TextStyle.CAPTION) + 12.0F;
         PaletteCommand paletteCommand2 = this.paletteCommandList.isEmpty() ? null : this.paletteCommandList.get(Math.max(0, Math.min(getPaletteCommandList(this).size() - 1, getIntState(this))));
         if (paletteCommand2 != null && paletteCommand2.getAlternate() != null) {
            x4 += LabelWidgets.computeFloatForUiContext6(uiContext, x4, y, floatValue5, "Shift", "Enter") + 5.0F;
            uiContext.drawVerticallyCenteredText("Open settings", x4, y, TextStyle.CAPTION, UiContext.multiplyAlpha(themeSnapshot2.getDisabledText2(), floatValue5));
         }

         String text3 = this.paletteCommandList.size() == 1 ? "1 result" : this.paletteCommandList.size() + " results";
         uiContext.drawRightAlignedText(text3, rect.right() - 14.0F, y, TextStyle.CAPTION, UiContext.multiplyAlpha(themeSnapshot2.getDisabledText2(), floatValue5));
         uiContext.getUiRenderContext().popTransform();
      }
   }

   public static void setPaletteCommandList(CommandPalette commandPalette, List paletteCommandList2) {
      commandPalette.paletteCommandList = paletteCommandList2;
   }

   public static ScrollModel getScrollModel(CommandPalette commandPalette) {
      return commandPalette.scrollModel;
   }

   public static TextInputModel getTextInputModel(CommandPalette commandPalette) {
      return commandPalette.textInputModel;
   }

   private void updateState2() {
      String string2 = getTextInputModel(this).toString().trim();
      if (!string2.equals(this.string)) {
         setString(this, string2);
         List list = getSupplier(this).get();
         if (string2.isEmpty()) {
            setPaletteCommandList(this, list.size() > 50 ? list.subList(0, 50) : list);
         } else {
            ArrayList arrayList = new ArrayList();

            for (PaletteCommand paletteCommand : (java.lang.Iterable<PaletteCommand>)(java.lang.Iterable<?>)(list)) {
               int intValue = FuzzySearch.computeInt2(string2, paletteCommand.getTitle2(), paletteCommand.getGroup() + " " + paletteCommand.getTitle2(), paletteCommand.getKeywords2() == null ? "" : paletteCommand.getKeywords2());
               if (intValue >= 0) {
                  arrayList.add(new CommandSearchResult(paletteCommand, intValue));
               }
            }

            arrayList.sort(Comparator.<Object>comparingInt(objectValue -> ((CommandSearchResult)objectValue).getScore()).reversed());
            ArrayList paletteCommandList2 = new ArrayList();

            for (int intValue2 = 0; intValue2 < Math.min(50, arrayList.size()); intValue2++) {
               paletteCommandList2.add(((CommandSearchResult)arrayList.get(intValue2)).getCommand());
            }

            this.paletteCommandList = paletteCommandList2;
         }

         setIntState(this, 0);
         this.scrollModel.reset();
      }
   }

   public boolean checkCondition(char charValue) {
      if (!getBooleanState(this)) {
         return false;
      } else {
         getTextInputModel(this).checkCondition3(charValue);
         return true;
      }
   }

   private void updateState3() {
      this.updateState7(false);
   }

   public static void setString(CommandPalette commandPalette, String string2) {
      commandPalette.string = string2;
   }

   public static long getLongState(CommandPalette commandPalette) {
      return commandPalette.longState;
   }

   public static boolean getBooleanState(CommandPalette commandPalette) {
      return commandPalette.booleanState;
   }

   public static void setDoubleState2(CommandPalette commandPalette, double doubleState22) {
      commandPalette.doubleState2 = doubleState22;
   }

   public static void setDoubleState(CommandPalette commandPalette, double doubleState3) {
      commandPalette.doubleState = doubleState3;
   }

   public static void setIntState(CommandPalette commandPalette, int intState2) {
      commandPalette.intState = intState2;
   }

   public void updateState4() {
      if (this.booleanState) {
         this.updateState9();
      } else {
         this.updateState5();
      }
   }

   public void updateState5() {
      this.booleanState = true;
      setLongState(this, getLongState(this) + 1L);
      getTextInputModel(this).updateState2();
      this.textInputModel.updateState3(true);
      this.intState = 0;
      this.scrollModel.reset();
      this.string = null;
      ClientSounds.updateState5();
   }

   private static void updateState6(int intValue, double doubleValue, double doubleValue2) {
   }

   public CommandPalette(Supplier supplier2) {
      this.scrollModel = new ScrollModel();
      this.paletteCommandList = List.of();
      this.doubleState2 = Double.NaN;
      this.doubleState = Double.NaN;
      this.supplier = supplier2;
   }

   private void updateState7(boolean booleanValue) {
      if (!getPaletteCommandList(this).isEmpty()) {
         PaletteCommand paletteCommand = getPaletteCommandList(this).get(Math.max(0, Math.min(this.paletteCommandList.size() - 1, this.intState)));
         ClientSounds.updateState4();
         if (booleanValue && paletteCommand.getAlternate() != null) {
            this.updateState9();
            paletteCommand.getAlternate().run();
         } else {
            if (!paletteCommand.getKeepOpen()) {
               this.updateState9();
            }

            paletteCommand.getAction2().run();
            setString(this, null);
         }
      }
   }

   public static void setBooleanState(CommandPalette commandPalette, boolean booleanState2) {
      commandPalette.booleanState = booleanState2;
   }

   public static int getIntState(CommandPalette commandPalette) {
      return commandPalette.intState;
   }

   public boolean checkCondition2(int intValue, boolean booleanValue, boolean booleanValue2) {
      if (!this.booleanState) {
         return false;
      } else {
         switch (intValue) {
            case 256:
               this.updateState9();
               break;
            case 257:
            case 335:
               this.updateState7(booleanValue2);
               break;
            case 258:
            case 264:
               this.updateState(1);
               break;
            case 265:
               this.updateState(-1);
               break;
            case 266:
               this.updateState(-8);
               break;
            case 267:
               this.updateState(8);
               break;
            default:
               getTextInputModel(this).checkCondition(intValue, booleanValue);
         }

         return true;
      }
   }

   private void updateState8(int intState2) {
      setIntState(this, intState2);
      this.updateState3();
   }

   public void updateState9() {
      if (this.booleanState) {
         ClientSounds.updateState5();
      }

      setBooleanState(this, false);
      this.textInputModel.updateState3(false);
   }

   public static Supplier<List<PaletteCommand>> getSupplier(CommandPalette commandPalette) {
      return commandPalette.supplier;
   }

   public static void setLongState(CommandPalette commandPalette, long longState2) {
      commandPalette.longState = longState2;
   }

   public boolean getBooleanState4() {
      return this.booleanState;
   }

}
