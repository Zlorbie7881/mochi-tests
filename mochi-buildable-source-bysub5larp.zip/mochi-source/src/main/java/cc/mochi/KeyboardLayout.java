package cc.mochi;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class KeyboardLayout {
   static final List<List<KeyboardKey>> listList;

   private static KeyboardKey computeKeyboardKey(float floatValue) {
      int minValue = Integer.MIN_VALUE;

      return new KeyboardKey(Integer.MIN_VALUE, "", floatValue, true);
   }

   static List computeList() {
      ArrayList arrayList = new ArrayList(computeList3());

      arrayList.remove(0);
      int intValue = 0;

      while (intValue < arrayList.size()) {
         List list = (List)arrayList.get(intValue);
         ArrayList arrayList2 = new ArrayList();
         byte byteValue = 0;
         Iterator iterator = list.iterator();

         while (iterator.hasNext()) {
            KeyboardKey keyboardKey = (KeyboardKey)iterator.next();
            if (keyboardKey.getSpacer2()) {
               float units = keyboardKey.getUnits();

               if (units >= (0.6F)) {
                  byteValue = 1;

                  continue;
               }
            }

            if (byteValue != 0) {
               if (!keyboardKey.getSpacer2()) {
                  continue;
               }
            }

            arrayList2.add(keyboardKey);
         }

         arrayList.set(intValue, List.copyOf(arrayList2));
         intValue++;
      }

      return List.copyOf(arrayList);
   }

   static float computeFloatForList(List list) {
      float floatValue = 0.0F;
      Iterator iterator = list.iterator();

      while (true) {
         if (!iterator.hasNext()) {
            return floatValue;
         }

         KeyboardKey keyboardKey = (KeyboardKey)iterator.next();
         floatValue += keyboardKey.getUnits();
      }
   }

   static List computeList2() {
      return computeList3();
   }

   private static KeyboardKey createKeyboardKey(int intValue, String string) {
      return new KeyboardKey(intValue, string, (1.0F), false);
   }

   static List computeList3() {
      KeyboardKey[] keyboardKeyArray = new KeyboardKey[]{createKeyboardKey(256, "Esc"), null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null};

      keyboardKeyArray[1] = computeKeyboardKey((0.4F));

      keyboardKeyArray[2] = createKeyboardKey(290, "F1");
      keyboardKeyArray[3] = createKeyboardKey(291, "F2");
      keyboardKeyArray[4] = createKeyboardKey(292, "F3");

      keyboardKeyArray[5] = createKeyboardKey(293, "F4");

      keyboardKeyArray[6] = computeKeyboardKey((0.4F));
      keyboardKeyArray[7] = createKeyboardKey(294, "F5");

      keyboardKeyArray[8] = createKeyboardKey(295, "F6");

      keyboardKeyArray[9] = createKeyboardKey(296, "F7");

      keyboardKeyArray[10] = createKeyboardKey(297, "F8");
      keyboardKeyArray[11] = computeKeyboardKey((0.4F));

      keyboardKeyArray[12] = createKeyboardKey(298, "F9");

      keyboardKeyArray[13] = createKeyboardKey(299, "F10");

      keyboardKeyArray[14] = createKeyboardKey(300, "F11");

      keyboardKeyArray[15] = createKeyboardKey(301, "F12");

      keyboardKeyArray[16] = computeKeyboardKey(0.6F);

      keyboardKeyArray[17] = createKeyboardKey(283, "Prt");

      keyboardKeyArray[18] = createKeyboardKey(281, "Scr");
      keyboardKeyArray[19] = createKeyboardKey(284, "Pau");
      List list = List.of(keyboardKeyArray);
      KeyboardKey[] keyboardKeyArray2 = new KeyboardKey[]{createKeyboardKey(96, "`"), null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null};

      keyboardKeyArray2[1] = createKeyboardKey(49, "1");
      keyboardKeyArray2[2] = createKeyboardKey(50, "2");

      keyboardKeyArray2[3] = createKeyboardKey(51, "3");
      keyboardKeyArray2[4] = createKeyboardKey(52, "4");
      keyboardKeyArray2[5] = createKeyboardKey(53, "5");

      keyboardKeyArray2[6] = createKeyboardKey(54, "6");

      keyboardKeyArray2[7] = createKeyboardKey(55, "7");
      keyboardKeyArray2[8] = createKeyboardKey(56, "8");

      keyboardKeyArray2[9] = createKeyboardKey(57, "9");
      keyboardKeyArray2[10] = createKeyboardKey(48, "0");

      keyboardKeyArray2[11] = createKeyboardKey(45, "-");

      keyboardKeyArray2[12] = createKeyboardKey(61, "=");

      keyboardKeyArray2[13] = createKeyboardKey2(259, "Bksp", (2.0F));

      keyboardKeyArray2[14] = computeKeyboardKey(0.6F);
      keyboardKeyArray2[15] = createKeyboardKey(260, "Ins");

      keyboardKeyArray2[16] = createKeyboardKey(268, "Home");

      keyboardKeyArray2[17] = createKeyboardKey(266, "PgUp");
      List list2 = List.of(keyboardKeyArray2);
      KeyboardKey[] keyboardKeyArray3 = new KeyboardKey[18];

      keyboardKeyArray3[0] = createKeyboardKey2(258, "Tab", (1.5F));

      keyboardKeyArray3[1] = createKeyboardKey(81, "Q");

      keyboardKeyArray3[2] = createKeyboardKey(87, "W");

      keyboardKeyArray3[3] = createKeyboardKey(69, "E");
      keyboardKeyArray3[4] = createKeyboardKey(82, "R");
      keyboardKeyArray3[5] = createKeyboardKey(84, "T");

      keyboardKeyArray3[6] = createKeyboardKey(89, "Y");

      keyboardKeyArray3[7] = createKeyboardKey(85, "U");

      keyboardKeyArray3[8] = createKeyboardKey(73, "I");

      keyboardKeyArray3[9] = createKeyboardKey(79, "O");

      keyboardKeyArray3[10] = createKeyboardKey(80, "P");

      keyboardKeyArray3[11] = createKeyboardKey(91, "[");

      keyboardKeyArray3[12] = createKeyboardKey(93, "]");

      keyboardKeyArray3[13] = createKeyboardKey2(92, "\\", 1.5F);
      keyboardKeyArray3[14] = computeKeyboardKey((0.6F));
      keyboardKeyArray3[15] = createKeyboardKey(261, "Del");
      keyboardKeyArray3[16] = createKeyboardKey(269, "End");
      keyboardKeyArray3[17] = createKeyboardKey(267, "PgDn");
      List list3 = List.of(keyboardKeyArray3);

      KeyboardKey[] keyboardKeyArray4 = new KeyboardKey[13];

      keyboardKeyArray4[0] = createKeyboardKey2(280, "Caps", 1.75F);

      keyboardKeyArray4[1] = createKeyboardKey(65, "A");
      keyboardKeyArray4[2] = createKeyboardKey(83, "S");
      keyboardKeyArray4[3] = createKeyboardKey(68, "D");

      keyboardKeyArray4[4] = createKeyboardKey(70, "F");
      keyboardKeyArray4[5] = createKeyboardKey(71, "G");

      keyboardKeyArray4[6] = createKeyboardKey(72, "H");

      keyboardKeyArray4[7] = createKeyboardKey(74, "J");

      keyboardKeyArray4[8] = createKeyboardKey(75, "K");

      keyboardKeyArray4[9] = createKeyboardKey(76, "L");
      keyboardKeyArray4[10] = createKeyboardKey(59, ";");
      keyboardKeyArray4[11] = createKeyboardKey(39, "'");
      keyboardKeyArray4[12] = createKeyboardKey2(257, "Enter", 2.25F);
      List list4 = List.of(keyboardKeyArray4);

      KeyboardKey[] keyboardKeyArray5 = new KeyboardKey[14];

      keyboardKeyArray5[0] = createKeyboardKey2(340, "Shift", 2.25F);
      keyboardKeyArray5[1] = createKeyboardKey(90, "Z");

      keyboardKeyArray5[2] = createKeyboardKey(88, "X");
      keyboardKeyArray5[3] = createKeyboardKey(67, "C");
      keyboardKeyArray5[4] = createKeyboardKey(86, "V");
      keyboardKeyArray5[5] = createKeyboardKey(66, "B");
      keyboardKeyArray5[6] = createKeyboardKey(78, "N");

      keyboardKeyArray5[7] = createKeyboardKey(77, "M");
      keyboardKeyArray5[8] = createKeyboardKey(44, ",");

      keyboardKeyArray5[9] = createKeyboardKey(46, ".");

      keyboardKeyArray5[10] = createKeyboardKey(47, "/");

      keyboardKeyArray5[11] = createKeyboardKey2(344, "Shift", 2.75F);

      keyboardKeyArray5[12] = computeKeyboardKey((0.6F));

      keyboardKeyArray5[13] = createKeyboardKey(265, "^");
      List list5 = List.of(keyboardKeyArray5);

      KeyboardKey[] keyboardKeyArray6 = new KeyboardKey[12];

      keyboardKeyArray6[0] = createKeyboardKey2(341, "Ctrl", (1.25F));

      keyboardKeyArray6[1] = createKeyboardKey2(343, "Win", (1.25F));

      keyboardKeyArray6[2] = createKeyboardKey2(342, "Alt", (1.25F));
      keyboardKeyArray6[3] = createKeyboardKey2(32, "Space", 6.25F);

      keyboardKeyArray6[4] = createKeyboardKey2(346, "Alt", 1.25F);

      keyboardKeyArray6[5] = createKeyboardKey2(347, "Win", 1.25F);

      keyboardKeyArray6[6] = createKeyboardKey2(348, "Menu", 1.25F);

      keyboardKeyArray6[7] = createKeyboardKey2(345, "Ctrl", (1.25F));

      keyboardKeyArray6[8] = computeKeyboardKey((0.6F));

      keyboardKeyArray6[9] = createKeyboardKey(263, "<");

      keyboardKeyArray6[10] = createKeyboardKey(264, "v");
      keyboardKeyArray6[11] = createKeyboardKey(262, ">");
      return List.of(list, list2, list3, list4, list5, List.of(keyboardKeyArray6));
   }

   private KeyboardLayout() {
   }

   private static KeyboardKey createKeyboardKey2(int intValue, String string, float floatValue) {
      return new KeyboardKey(intValue, string, floatValue, false);
   }

   static {
      KeyboardKey keyboardKey = createKeyboardKey(282, "Num");

      KeyboardKey keyboardKey2 = createKeyboardKey(331, "/");

      KeyboardKey keyboardKey3 = createKeyboardKey(332, "*");

      List list = List.of(keyboardKey, keyboardKey2, keyboardKey3, createKeyboardKey(333, "-"));
      KeyboardKey keyboardKey4 = createKeyboardKey(327, "7");
      KeyboardKey keyboardKey5 = createKeyboardKey(328, "8");

      KeyboardKey keyboardKey6 = createKeyboardKey(329, "9");

      List list2 = List.of(keyboardKey4, keyboardKey5, keyboardKey6, createKeyboardKey(334, "+"));
      List list3 = List.of(createKeyboardKey(324, "4"), createKeyboardKey(325, "5"), createKeyboardKey(326, "6"), computeKeyboardKey(1.0F));

      KeyboardKey keyboardKey7 = createKeyboardKey(321, "1");

      KeyboardKey keyboardKey8 = createKeyboardKey(322, "2");
      KeyboardKey keyboardKey9 = createKeyboardKey(323, "3");

      List list4 = List.of(keyboardKey7, keyboardKey8, keyboardKey9, createKeyboardKey(335, "Entr"));

      listList = List.of(list, list2, list3, list4, List.of(createKeyboardKey2(320, "0", (2.0F)), createKeyboardKey(330, ".")));
   }

   static List computeList4(String string) {
      switch (string.hashCode()) {
         case 53419:
            if (string.equals("60%")) {
               return computeList();
            }

            break;
         case 83125:

            if (string.equals("TKL")) {
               return computeList3();
            }
      }

      return computeList2();
   }
}
