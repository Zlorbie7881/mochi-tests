package cc.mochi;

import java.awt.Color;
import java.util.Locale;

public class ColorAccess5 {
   public static Color getWHITE() {
      return Color.WHITE;
   }

   public static Locale getROOT() {
      return Locale.ROOT;
   }

   public static TextStyle getCAPTION() {
      return TextStyle.CAPTION;
   }

   public static Color getBLACK() {
      return Color.BLACK;
   }

}
