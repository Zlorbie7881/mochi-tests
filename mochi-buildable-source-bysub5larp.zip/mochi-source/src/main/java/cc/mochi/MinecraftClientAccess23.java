package cc.mochi;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Direction;

public class MinecraftClientAccess23 {
   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static Item getGLOWSTONE() {
      return Items.GLOWSTONE;
   }

   public static Block getRESPAWN_ANCHOR() {
      return Blocks.RESPAWN_ANCHOR;
   }

   public static ClientWorld getWorld(MinecraftClient minecraftClient) {
      return minecraftClient.world;
   }

   public static void setBooleanState(boolean booleanState) {
      AnchorModule.booleanState = booleanState;
   }

   public static Item getTOTEM_OF_UNDYING() {
      return Items.TOTEM_OF_UNDYING;
   }

   public static HitResult getCrosshairTarget(MinecraftClient minecraftClient) {
      return minecraftClient.crosshairTarget;
   }

   public static Direction getSOUTH() {
      return Direction.SOUTH;
   }

   public static boolean getBooleanState() {
      return AnchorModule.booleanState;
   }

}
