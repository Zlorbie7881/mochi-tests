package cc.mochi;

public enum HudVerticalAlignment {
   TOP,
   CENTRE,
   BOTTOM;

   private static HudVerticalAlignment[] createValues() {
      return new HudVerticalAlignment[]{TOP, CENTRE, BOTTOM};
   }
}
