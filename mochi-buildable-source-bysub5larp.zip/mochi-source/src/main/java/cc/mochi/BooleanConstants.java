package cc.mochi;

public class BooleanConstants {
   public static Boolean getTRUE() {
      return Boolean.TRUE;
   }
}
