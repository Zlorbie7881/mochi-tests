package cc.mochi;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.Std140Builder;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTextureView;
import java.nio.ByteBuffer;
import java.util.OptionalInt;
import org.lwjgl.system.MemoryStack;

final class AuroraBackdropRenderer {
   private GpuBuffer gpuBuffer;

   void updateState() {
      if (this.gpuBuffer != null) {
         this.gpuBuffer.close();
      }

      this.gpuBuffer = null;
   }

   private static String getStringConstant() {
      return "Mochi aurora backdrop";
   }

   private static String getStringConstant2() {
      return "Mochi backdrop uniforms";
   }

   void updateStateForGpuTextureView(GpuTextureView gpuTextureView, int[] intArray, int intValue, float floatValue, float floatValue2, float floatValue3, float floatValue4) {
      CommandEncoder commandEncoder = RenderSystem.getDevice().createCommandEncoder();
      if (this.gpuBuffer == null || this.gpuBuffer.isClosed()) {
         this.gpuBuffer = RenderSystem.getDevice().createBuffer(() -> getStringConstant2(), 136, 112L);
      }

      int width = gpuTextureView.getWidth(0);
      int height = gpuTextureView.getHeight(0);
      MemoryStack memoryStack = MemoryStack.stackPush();

      try {
         Std140Builder std140Builder = Std140Builder.onStack(memoryStack, 112);

         for (int intValue2 = 0; intValue2 < 4; intValue2++) {
            int intValue3 = intArray[Math.min(intValue2, intArray.length - 1)];
            std140Builder.putVec4(
               (float)(intValue3 >> 16 & 0xFF) / 255.0F, (float)(intValue3 >> 8 & 0xFF) / 255.0F, (float)(intValue3 & 0xFF) / 255.0F, (float)(intValue3 >>> 24) / 255.0F
            );
         }

         std140Builder.putVec4((float)(intValue >> 16 & 0xFF) / 255.0F, (float)(intValue >> 8 & 0xFF) / 255.0F, (float)(intValue & 0xFF) / 255.0F, (float)(intValue >>> 24) / 255.0F);
         std140Builder.putVec4(floatValue, floatValue2, floatValue3, floatValue4);
         std140Builder.putVec4((float)width, (float)height, 1.0F / (float)Math.max(1, width), 1.0F / (float)Math.max(1, height));
         ByteBuffer byteBuffer = std140Builder.get();
         commandEncoder.writeToBuffer(this.gpuBuffer.slice(), byteBuffer);
      } catch (Throwable failure) {
         if (memoryStack != null) {
            try {
               memoryStack.close();
            } catch (Throwable failure2) {
               failure.addSuppressed(failure2);
            }
         }

         throw failure;
      }

      if (memoryStack != null) {
         memoryStack.close();
      }

      RenderPass renderPass = commandEncoder.createRenderPass(() -> getStringConstant(), gpuTextureView, OptionalInt.empty());

      try {
         renderPass.setPipeline(UiRenderPipelines.AURORA_BACKDROP);
         renderPass.setUniform("MochiBackdrop", this.gpuBuffer);
         renderPass.draw(0, 3);
      } catch (Throwable failure3) {
         if (renderPass != null) {
            try {
               renderPass.close();
            } catch (Throwable failure4) {
               failure3.addSuppressed(failure4);
            }
         }

         throw failure3;
      }

      if (renderPass != null) {
         renderPass.close();
      }
   }
}
