package cc.mochi;

final class GuardedRenderBackend extends DelegatingRenderBackend {
   private boolean booleanState;
   private final RenderBackendManager renderBackendManager;

   private boolean booleanState2;

   @Override
   protected boolean render2(BooleanRenderCall booleanRenderCall) {
      if (!this.booleanState && !this.booleanState2) {
         try {
            return booleanRenderCall.render();
         } catch (Throwable throwable) {
            this.updateStateForThrowable(throwable);
            return false;
         }
      } else {
         return false;
      }
   }

   @Override
   protected float render(FloatRenderCall floatRenderCall) {
      if (!this.booleanState && !this.booleanState2) {
         try {
            return floatRenderCall.render();
         } catch (Throwable throwable) {
            this.updateStateForThrowable(throwable);
            return 0.0F;
         }
      } else {
         return 0.0F;
      }
   }

   public GuardedRenderBackend(RenderBackendManager renderBackendManager2, UiRenderBackend uiRenderBackend2) {
      super(uiRenderBackend2);
      this.renderBackendManager = renderBackendManager2;
   }

   @Override
   public void close() {
      if (!this.booleanState2) {
         this.booleanState2 = true;

         try {
            this.uiRenderBackend.close();
         } catch (Throwable throwable) {
            this.updateStateForThrowable(throwable);
         }
      }
   }

   @Override
   protected void run(Runnable runnable) {
      if (!this.booleanState && !this.booleanState2) {
         try {
            runnable.run();
         } catch (Throwable throwable) {
            this.updateStateForThrowable(throwable);
         }
      }
   }

   private void updateStateForThrowable(Throwable throwable) {
      if (!this.booleanState) {
         this.booleanState = true;

         try {
            this.uiRenderBackend.close();
         } catch (Throwable failure) {
            throwable.addSuppressed(failure);
         }

         this.booleanState2 = true;
         this.renderBackendManager.updateStateForThrowable2(throwable);
      }
   }
}
