package cc.mochi;

public final class HalfScale {
   private HalfScale() {
   }

   public static float half(float floatValue) {
      return floatValue / 2.0F;
   }
}
