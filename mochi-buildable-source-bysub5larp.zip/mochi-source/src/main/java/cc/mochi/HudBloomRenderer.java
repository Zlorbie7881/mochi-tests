package cc.mochi;

import cc.mochi.event.impl.render.Render2DEvent;
import cc.mochi.utils.platform.PlatformService;
import java.awt.Color;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BooleanSupplier;
import java.util.function.DoubleSupplier;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.helpers.NOPLogger;

public final class HudBloomRenderer {
   private static final Logger logger = NOPLogger.NOP_LOGGER;

   public static final ThreadLocal<UiRenderBackend> ACTIVE_BACKEND = new ThreadLocal<>();
   private static final Set<String> REPORTED_FAILURES = ConcurrentHashMap.newKeySet();

   public static boolean isFallback() {
      return requireActiveBackend().isFallback();
   }

   public static void fillGlowingRoundedRect(float x, float y, float width, float height, float radius, Color color, Color color2, float blur, float spread) {
      requireActiveBackend().fillGlowingRoundedRect(x, y, width, height, radius, color, color2, blur, spread);
   }

   public static void updateState() {
      try {
         Render2D.updateState16();
      } catch (RuntimeException failure) {
         reportFailureOnce("HUD bloom", failure);
      }
   }

   public static void drawTextureRegion(
      Identifier identifier,
      float floatValue,
      float floatValue2,
      float floatValue3,
      float floatValue4,
      float floatValue5,
      float floatValue6,
      int intValue,
      int intValue2,
      int intValue3,
      int intValue4,
      float floatValue7,
      Color color
   ) {
      requireActiveBackend().drawTextureRegion(identifier, floatValue, floatValue2, floatValue3, floatValue4, floatValue5, floatValue6, intValue, intValue2, intValue3, intValue4, floatValue7, color);
   }

   public static void pushTransform() {
      requireActiveBackend().pushTransform();
   }

   public static void updateStateForRender2DEvent(
      Render2DEvent render2DEvent, Identifier identifier, float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5, float floatValue6, int intValue, int intValue2, int intValue3, int intValue4
   ) {
      UiRenderBackend uiRenderBackend = ACTIVE_BACKEND.get();
      if (uiRenderBackend != null && !uiRenderBackend.isFallback()) {
         uiRenderBackend.drawTextureRegion(identifier, floatValue, floatValue2, floatValue3, floatValue4, floatValue5, floatValue6, intValue, intValue2, intValue3, intValue4, 0.0F, Color.WHITE);
      } else {
         RenderBackendManager.getINSTANCE().updateStateForDrawContext(render2DEvent.getContext(), render2DEvent.getWidth(), render2DEvent.getHeight(), identifier, floatValue, floatValue2, floatValue3, floatValue4, floatValue5, floatValue6, intValue, intValue2, intValue3, intValue4);
      }
   }

   public static void drawGlowOutline(float x, float y, float width, float height, float radius, float blur, float spread, Color color) {
      requireActiveBackend().drawGlowOutline(x, y, width, height, radius, blur, spread, color);
   }

   public static void popBloom() {
      requireActiveBackend().popBloom();
   }

   public static void popOpacity() {
      requireActiveBackend().popOpacity();
   }

   public static void drawCamouflage(float x, float y, float width, float height, float radius) {
      requireActiveBackend().drawCamouflage(x, y, width, height, radius);
   }

   public static void drawText(String text, float x, float y, float size, Color color, FontFace font) {
      requireActiveBackend().drawText(text, x, y, size, color, font);
   }

   public static void fillCircle(float centerX, float centerY, float radius, Color color) {
      requireActiveBackend().fillCircle(centerX, centerY, radius, color);
   }

   public static float measureFontHeight(float size, FontFace font) {
      return requireActiveBackend().measureFontHeight(size, font);
   }

   public static void fillVerticalGradient(float x, float y, float width, float height, float radius, Color topColor, Color bottomColor) {
      requireActiveBackend().fillVerticalGradient(x, y, width, height, radius, topColor, bottomColor);
   }

   public static UiRenderBackend computeUiRenderBackendForDrawContext(DrawContext drawContext, int intValue, int intValue2) {
      requireNoActiveFrame();
      return activateBackend(RenderBackendManager.getINSTANCE().computeUiRenderBackendForDrawContext2(drawContext, intValue, intValue2));
   }

   public static void drawLine(float startX, float startY, float endX, float endY, float thickness, Color color) {
      requireActiveBackend().drawLine(startX, startY, endX, endY, thickness, color);
   }

   public static void strokeCircle(float centerX, float centerY, float radius, float thickness, Color color) {
      requireActiveBackend().strokeCircle(centerX, centerY, radius, thickness, color);
   }

   private static UiRenderBackend requireActiveBackend() {
      UiRenderBackend uiRenderBackend = ACTIVE_BACKEND.get();
      if (uiRenderBackend == null) {
         throw new IllegalStateException("No active 2D rendering frame");
      } else {
         return uiRenderBackend;
      }
   }

   public static void fillAngledGradient(float x, float y, float width, float height, float radius, Color startColor, Color endColor, float angle) {
      requireActiveBackend().fillAngledGradient(x, y, width, height, radius, startColor, endColor, angle);
   }

   public static void popTransform() {
      requireActiveBackend().popTransform();
   }

   public static void rotate(float angle) {
      requireActiveBackend().rotate(angle);
   }

   public static void drawShadow(float x, float y, float width, float height, float radius, float blur, float offset, Color color) {
      requireActiveBackend().drawShadow(x, y, width, height, radius, blur, offset, color);
   }

   private HudBloomRenderer() {
   }

   public static void applyClip() {
      requireActiveBackend().applyClip();
   }

   public static void pushClip(float x, float y, float width, float height) {
      requireActiveBackend().pushClip(x, y, width, height);
   }

   public static void fillHorizontalGradient(float x, float y, float width, float height, float radius, Color leftColor, Color rightColor) {
      requireActiveBackend().fillHorizontalGradient(x, y, width, height, radius, leftColor, rightColor);
   }

   public static void translate(float offsetX, float offsetY) {
      requireActiveBackend().translate(offsetX, offsetY);
   }

   public static void flushBloom() {
      requireActiveBackend().flushBloom();
   }

   public static void scaleAround(float floatValue, float offsetX, float offsetY) {
      UiRenderBackend uiRenderBackend = requireActiveBackend();
      uiRenderBackend.translate(offsetX, offsetY);
      uiRenderBackend.scale(floatValue, floatValue);
      uiRenderBackend.translate(-offsetX, -offsetY);
   }

   public static void pushBloom(float intensity) {
      requireActiveBackend().pushBloom(intensity);
   }

   public static void popClip() {
      requireActiveBackend().popClip();
   }

   public static void updateStateForThrowable(Throwable throwable) {
      RenderBackendManager.getINSTANCE().updateStateForThrowable2(throwable);
   }

   private static void requireNoActiveFrame() {
      if (ACTIVE_BACKEND.get() != null) {
         throw new IllegalStateException("Nested 2D rendering frame");
      }
   }

   public static UiRenderBackend computeUiRenderBackendForRender2DEvent(Render2DEvent render2DEvent) {
      requireNoActiveFrame();
      return activateBackend(RenderBackendManager.getINSTANCE().computeUiRenderBackendForDrawContext3(render2DEvent.getContext(), render2DEvent.getWidth(), render2DEvent.getHeight()));
   }

   public static void scale(float scaleX, float scaleY) {
      requireActiveBackend().scale(scaleX, scaleY);
   }

   public static float measureText(String text, float size, FontFace font) {
      return requireActiveBackend().measureText(text, size, font);
   }

   public static void configureBloom(BooleanSupplier booleanSupplier, DoubleSupplier doubleSupplier) {
      Render2D.updateStateForBooleanSupplier(booleanSupplier, doubleSupplier);
   }

   public static void pushOpacity(float opacity) {
      requireActiveBackend().pushOpacity(opacity);
   }

   public static void setClip(float x, float y, float width, float height) {
      requireActiveBackend().setClip(x, y, width, height);
   }

   public static void drawRoundedTexture(String string, float x, float y, float width, float height, float radius, Color color) {
      requireActiveBackend().drawRoundedTexture(string, x, y, width, height, radius, color);
   }

   public static void fillRoundedCorners(float x, float y, float width, float height, float topLeftRadius, float topRightRadius, float bottomRightRadius, float bottomLeftRadius, Color color) {
      requireActiveBackend().fillRoundedCorners(x, y, width, height, topLeftRadius, topRightRadius, bottomRightRadius, bottomLeftRadius, color);
   }

   public static boolean drawAurora(int[] intArray, int intValue, float floatValue, float floatValue2, float floatValue3) {
      return requireActiveBackend().drawAurora(intArray, intValue, floatValue, floatValue2, floatValue3);
   }

   private static UiRenderBackend activateBackend(UiRenderBackend uiRenderBackend) {
      RenderBackendLease renderBackendLease = new RenderBackendLease(uiRenderBackend);
      ACTIVE_BACKEND.set(renderBackendLease);
      return renderBackendLease;
   }

   public static boolean checkCondition() {
      return !requireActiveBackend().isFallback() && !PlatformService.isMobile();
   }

   public static boolean drawGlassPanel(GlassPanelStyle glassPanelStyle) {
      return requireActiveBackend().drawGlassPanel(glassPanelStyle);
   }

   public static void strokeArc(float centerX, float centerY, float radius, float thickness, float startAngle, float sweepAngle, Color color) {
      requireActiveBackend().strokeArc(centerX, centerY, radius, thickness, startAngle, sweepAngle, color);
   }

   public static boolean checkCondition2() {
      return RenderBackendManager.getINSTANCE().checkCondition();
   }

   public static void reportFailureOnce(String string, Throwable throwable) {
      if (REPORTED_FAILURES.add(string)) {
         logger.error("A {} frame failed; the rest of that frame was skipped (reported once)", string, throwable);
      }
   }

   public static void fillRect(float x, float y, float width, float height, Color color) {
      requireActiveBackend().fillRect(x, y, width, height, color);
   }

   public static void drawLineSegment(float startX, float startY, float endX, float endY, float thickness, Color color) {
      requireActiveBackend().drawLineSegment(startX, startY, endX, endY, thickness, color);
   }

   public static void fillRoundedRect(float x, float y, float width, float height, float radius, Color color) {
      requireActiveBackend().fillRoundedRect(x, y, width, height, radius, color);
   }

   public static void drawTextureFromResource(String string, float x, float y, float width, float height, Color color) {
      requireActiveBackend().drawTextureFromResource(string, x, y, width, height, color);
   }

   public static void updateState2() {
      Render2D.updateState10();
   }

   public static void strokeRoundedRect(float x, float y, float width, float height, float radius, float thickness, Color color) {
      requireActiveBackend().strokeRoundedRect(x, y, width, height, radius, thickness, color);
   }
}
