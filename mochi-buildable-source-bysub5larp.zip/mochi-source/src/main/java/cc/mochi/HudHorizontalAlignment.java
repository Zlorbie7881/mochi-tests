package cc.mochi;

public enum HudHorizontalAlignment {
   LEFT,
   CENTRE,
   RIGHT;

   private static HudHorizontalAlignment[] createValues() {
      return new HudHorizontalAlignment[]{LEFT, CENTRE, RIGHT};
   }
}
