package cc.mochi;

import java.awt.Color;
import net.minecraft.client.gui.DrawContext;

public class DrawContextWidgets {
   public static void updateStateForDrawContext(DrawContext drawContext, int intValue, int intValue2, int intValue3, int intValue4, String string, boolean booleanValue, boolean booleanValue2) {
      Color color10 = LegacyUiColors.color10;
      Color color = LegacyUiColors.color;
      RenderUtils.updateStateForDrawContext10(drawContext, intValue, intValue2, intValue3, 24, 6, color.getRGB());
      LegacyWidgets.drawText(drawContext, string, intValue + 8, intValue2 + 8, LegacyUiColors.color3);
      if (booleanValue) {
         LegacyWidgets.updateStateForDrawContext12(drawContext, intValue + intValue3 - 20, intValue2 + 8, 8, booleanValue2, LegacyUiColors.color4);
      }

      if (!booleanValue2) {
         RenderUtils.updateStateForDrawContext10(drawContext, intValue, intValue2 + 24, intValue3, intValue4 - 24, 6, color10.getRGB());
         LegacyWidgets.updateStateForDrawContext(drawContext, intValue, intValue2, intValue3, intValue4, 6, 1, LegacyUiColors.color15);
      }
   }

   public static void updateStateForDrawContext2(DrawContext drawContext, int intValue, int intValue2, int intValue3, int intValue4, int intValue5, int intValue6, Color color) {
      for (int intValue7 = 0; intValue7 <= intValue3 / intValue5; intValue7++) {
         int intValue8 = intValue + intValue7 * intValue5;
         drawContext.fill(intValue8, intValue2, intValue8 + 1, intValue2 + intValue4, color.getRGB());
      }

      for (int intValue9 = 0; intValue9 <= intValue4 / intValue6; intValue9++) {
         int intValue10 = intValue2 + intValue9 * intValue6;
         drawContext.fill(intValue, intValue10, intValue + intValue3, intValue10 + 1, color.getRGB());
      }
   }
}
