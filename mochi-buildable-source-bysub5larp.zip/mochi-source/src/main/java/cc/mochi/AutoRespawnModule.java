package cc.mochi;

import cc.mochi.event.impl.player.TickEvent;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gui.screen.DeathScreen;

public class AutoRespawnModule extends Module {
   private int counter;

   private final DoubleSetting delayTicksSetting = new DoubleSetting("Delay (ticks)", 0.0, 40.0, 0.0, 1.0);

   public AutoRespawnModule() {
      super("Auto Respawn", "Respawns you automatically after death.", ModuleCategory.PLAYER);
      this.addSetting(this.delayTicksSetting);
   }

   @EventHandler
   private void onTick(TickEvent tickEvent) {
      ThreadLocalRandom.current().nextInt(15);
      if ((MinecraftClientAccess3.getPlayer(mc) != null)) {
         ThreadLocalRandom.current().nextInt(13);

         if (!(mc.currentScreen instanceof DeathScreen)) {
            setCounter(this, 0);
         } else if (this.counter++ >= getDelayTicksSetting(this).intValue()) {
            setCounter(this, 0);
            mc.player.requestRespawn();
            mc.setScreen(null);
         }
      }
   }

   public static void setCounter(AutoRespawnModule autoRespawnModule, int counter2) {
      autoRespawnModule.counter = counter2;
   }

   public static DoubleSetting getDelayTicksSetting(AutoRespawnModule autoRespawnModule) {
      return autoRespawnModule.delayTicksSetting;
   }

   @Override
   public void onDisable() {
      this.counter = 0;
   }

}
