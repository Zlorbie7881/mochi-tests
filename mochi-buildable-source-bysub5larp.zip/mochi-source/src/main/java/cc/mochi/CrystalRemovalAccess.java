package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity.RemovalReason;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.hit.HitResult;

public class CrystalRemovalAccess {
   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static RemovalReason getKILLED() {
      return RemovalReason.KILLED;
   }

   public static HitResult getCrosshairTarget(MinecraftClient minecraftClient) {
      return minecraftClient.crosshairTarget;
   }

   public static TagKey<Item> getHOES() {
      return ItemTags.HOES;
   }

   public static RegistryEntry<StatusEffect> getSTRENGTH() {
      return StatusEffects.STRENGTH;
   }

   public static TagKey<Item> getSHOVELS() {
      return ItemTags.SHOVELS;
   }
}
