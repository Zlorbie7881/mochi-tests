package cc.mochi;

public enum MainAxisAlignment {
   START,
   END,
   CENTER,
   SPACE_BETWEEN,
   SPACE_AROUND,
   SPACE_EVENLY;

   private static MainAxisAlignment[] createValues() {
      return new MainAxisAlignment[]{START, END, CENTER, SPACE_BETWEEN, SPACE_AROUND, SPACE_EVENLY};
   }
}
