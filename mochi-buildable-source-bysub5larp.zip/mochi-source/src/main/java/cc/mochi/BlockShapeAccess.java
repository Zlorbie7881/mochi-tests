package cc.mochi;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.enums.SlabType;
import net.minecraft.item.Item;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public class BlockShapeAccess {
   public static double getMinZ(Box box) {
      return box.minZ;
   }

   public static double getMinY(Box box) {
      return box.minY;
   }

   public static Block getCRAFTING_TABLE() {
      return Blocks.CRAFTING_TABLE;
   }

   public static SlabType getBOTTOM() {
      return SlabType.BOTTOM;
   }

   public static Type getBLOCK() {
      return Type.BLOCK;
   }

   public static double getZ(Vec3d vec3d) {
      return vec3d.z;
   }

   public static TagKey<Block> getTRAPDOORS() {
      return BlockTags.TRAPDOORS;
   }

   public static TagKey<Item> getWOODEN_SLABS() {
      return ItemTags.WOODEN_SLABS;
   }

   public static SlabType getTOP() {
      return SlabType.TOP;
   }

   public static TagKey<Block> getRAILS() {
      return BlockTags.RAILS;
   }

   public static double getX(Vec3d vec3d) {
      return vec3d.x;
   }

   public static TagKey<Block> getFENCE_GATES() {
      return BlockTags.FENCE_GATES;
   }

   public static Block getDAMAGED_ANVIL() {
      return Blocks.DAMAGED_ANVIL;
   }

   public static TagKey<Block> getDOORS() {
      return BlockTags.DOORS;
   }

   public static Direction getDOWN() {
      return Direction.DOWN;
   }

   public static Block getSMITHING_TABLE() {
      return Blocks.SMITHING_TABLE;
   }

   public static Type getMISS() {
      return Type.MISS;
   }

   public static Direction getUP() {
      return Direction.UP;
   }

   public static Block getRESPAWN_ANCHOR() {
      return Blocks.RESPAWN_ANCHOR;
   }

   public static Block getSTONECUTTER() {
      return Blocks.STONECUTTER;
   }

   public static double getMinX(Box box) {
      return box.minX;
   }
}
