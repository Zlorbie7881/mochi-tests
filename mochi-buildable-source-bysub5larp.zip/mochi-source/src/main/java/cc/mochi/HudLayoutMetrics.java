package cc.mochi;

public final class HudLayoutMetrics {
   @SafeVarargs
   public static float computeFloat(float floatValue, float floatValue2, Class... classArray) {
      float floatValue3 = floatValue;
      Class[] classArray2 = classArray;
      int length = classArray.length;

      int intValue = 0;

      while (intValue < length) {
         Class objectValue = classArray2[intValue];
         HudLayout hudLayout = computeHudLayoutForClass(objectValue);
         if (hudLayout != null) {
            floatValue3 = Math.max(floatValue3, hudLayout.getX() + hudLayout.getWidth() + floatValue2);
         }

         intValue++;
      }

      return floatValue3;
   }

   @SafeVarargs
   public static float computeFloat2(float floatValue, Class... classArray) {
      float floatValue2 = floatValue;
      Class[] classArray2 = classArray;
      int length = classArray.length;
      int intValue = 0;

      while (intValue < length) {
         Class objectValue = classArray2[intValue];
         HudLayout hudLayout = computeHudLayoutForClass(objectValue);
         if (hudLayout != null) {
            floatValue2 = Math.max(floatValue2, hudLayout.getY() + hudLayout.getHeight() + 3.0F);
         }

         intValue++;
      }

      return floatValue2;
   }

   private static HudLayout computeHudLayoutForClass(Class objectValue) {
      HudElement hudElement = HudElements.computeHudElementForClass(objectValue);
      if (hudElement == null) {
         return null;
      } else {
         return hudElement.computeHudLayout();
      }
   }

   private HudLayoutMetrics() {
   }

   @SafeVarargs
   public static float computeFloat3(float floatValue, Class... classArray) {
      return computeFloat(floatValue, 3.0F, classArray);
   }

   @SafeVarargs
   public static float computeFloat4(float floatValue, Class... classArray) {
      float floatValue2 = Math.max(1.0F, (float)UiViewport.getWidth());
      float floatValue3 = (3.4028235E38F);
      Class[] classArray2 = classArray;
      int length = classArray.length;

      for (int intValue = 0; intValue < length; intValue++) {
         Class objectValue = classArray2[intValue];
         HudLayout hudLayout = computeHudLayoutForClass(objectValue);
         if (hudLayout != null) {
            floatValue3 = Math.min(floatValue3, hudLayout.getX());
         }
      }

      if (floatValue3 == Float.MAX_VALUE) {
         return floatValue;
      } else {
         return Math.max(floatValue, floatValue2 - floatValue3 + 3.0F);
      }
   }
}
