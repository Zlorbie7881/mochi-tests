package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.component.ComponentType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.potion.Potion;
import net.minecraft.potion.Potions;
import net.minecraft.registry.entry.RegistryEntry;

public class MinecraftClientAccess29 {
   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static ClientPlayerInteractionManager getInteractionManager(MinecraftClient minecraftClient) {
      return minecraftClient.interactionManager;
   }

   public static ComponentType<PotionContentsComponent> getPOTION_CONTENTS() {
      return DataComponentTypes.POTION_CONTENTS;
   }

   public static Screen getCurrentScreen(MinecraftClient minecraftClient) {
      return minecraftClient.currentScreen;
   }

   public static RegistryEntry<Potion> getHEALING() {
      return Potions.HEALING;
   }

   public static RegistryEntry<Potion> getSTRONG_HEALING() {
      return Potions.STRONG_HEALING;
   }

   public static ActionPriority getHIGH() {
      return ActionPriority.HIGH;
   }

}
