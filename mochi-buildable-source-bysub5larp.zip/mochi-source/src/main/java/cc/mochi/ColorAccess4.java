package cc.mochi;

import java.awt.Color;

public class ColorAccess4 {
   public static Color getBLACK() {
      return Color.BLACK;
   }
}
