package cc.mochi;

import com.google.common.base.Preconditions;
import org.jetbrains.annotations.Range;

public class ColorChannels {
   public static float[] normalizeRgba(int[] intArray) {
      Preconditions.checkArgument(intArray.length == 4, "Expected int[] of size 4, got " + intArray.length);

      for (int intValue = 0; intValue < intArray.length; intValue++) {
         Preconditions.checkArgument(isByteChannel(intArray[intValue]), "Expected in[" + intValue + "] to be 0-255, got " + intArray[intValue]);
      }

      return new float[]{(float)intArray[0] / 255.0F, (float)intArray[1] / 255.0F, (float)intArray[2] / 255.0F, (float)intArray[3] / 255.0F};
   }

   public static int[] unpackArgbToRgba(int argb) {
      int intValue = argb >> 24 & 0xFF;
      int intValue2 = argb >> 16 & 0xFF;
      int intValue3 = argb >> 8 & 0xFF;
      int intValue4 = argb & 0xFF;
      return new int[]{intValue2, intValue3, intValue4, intValue};
   }

   public static int packRgba(
      @Range(from = 0L,to = 255L) int red, @Range(from = 0L,to = 255L) int green, @Range(from = 0L,to = 255L) int blue, @Range(from = 0L,to = 255L) int alpha
   ) {
      Preconditions.checkArgument(isByteChannel(red), "Expected r to be 0-255, received " + red);
      Preconditions.checkArgument(isByteChannel(green), "Expected g to be 0-255, received " + green);
      Preconditions.checkArgument(isByteChannel(blue), "Expected b to be 0-255, received " + blue);
      Preconditions.checkArgument(isByteChannel(alpha), "Expected a to be 0-255, received " + alpha);
      return red << 24 | green << 16 | blue << 8 | alpha;
   }

   private static boolean isByteChannel(int channel) {
      return channel >= 0 && channel <= 255;
   }

   public static int[] unpackRgba(int rgba) {
      int intValue = rgba >> 24 & 0xFF;
      int intValue2 = rgba >> 16 & 0xFF;
      int intValue3 = rgba >> 8 & 0xFF;
      int intValue4 = rgba & 0xFF;
      return new int[]{intValue, intValue2, intValue3, intValue4};
   }

   public static int[] unpackRgb(int rgb) {
      int intValue = rgb >> 16 & 0xFF;
      int intValue2 = rgb >> 8 & 0xFF;
      int intValue3 = rgb & 0xFF;
      return new int[]{intValue, intValue2, intValue3};
   }

   public static int packArgb(
      @Range(from = 0L,to = 255L) int red, @Range(from = 0L,to = 255L) int green, @Range(from = 0L,to = 255L) int blue, @Range(from = 0L,to = 255L) int alpha
   ) {
      Preconditions.checkArgument(isByteChannel(red), "Expected r to be 0-255, received " + red);
      Preconditions.checkArgument(isByteChannel(green), "Expected g to be 0-255, received " + green);
      Preconditions.checkArgument(isByteChannel(blue), "Expected b to be 0-255, received " + blue);
      Preconditions.checkArgument(isByteChannel(alpha), "Expected a to be 0-255, received " + alpha);
      return alpha << 24 | red << 16 | green << 8 | blue;
   }
}
