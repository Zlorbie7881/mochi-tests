package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.texture.GlTexture;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30;

final class MainFramebufferBridge {
   private static int framebufferId;
   private static int colorTextureId;
   private static int width;
   private static int height;

   static void delete() {
      if (framebufferId != 0 && GL30.glIsFramebuffer(framebufferId)) {
         GL30.glDeleteFramebuffers(framebufferId);
      }

      framebufferId = 0;
      colorTextureId = 0;
      width = 0;
      height = 0;
   }

   private MainFramebufferBridge() {
   }

   static int getOrCreate() {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      Framebuffer framebuffer = minecraftClient == null ? null : minecraftClient.getFramebuffer();
      if (framebuffer != null && framebuffer.getColorAttachment() instanceof GlTexture var2) {
         int colorTextureId2 = var2.getGlId();
         int width2 = var2.getWidth(0);
         int height2 = var2.getHeight(0);
         if (colorTextureId2 == 0 || width2 <= 0 || height2 <= 0 || !GL11.glIsTexture(colorTextureId2)) {
            return 0;
         } else if (framebufferId != 0 && colorTextureId == colorTextureId2 && width == width2 && height == height2 && GL30.glIsFramebuffer(framebufferId)) {
            return framebufferId;
         } else {
            delete();
            int framebufferId2 = GL30.glGenFramebuffers();
            if (framebufferId2 == 0) {
               return 0;
            } else {
               GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, framebufferId2);
               GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, colorTextureId2, 0);
               GL11.glDrawBuffer(36064);
               if (GL30.glCheckFramebufferStatus(GL30.GL_FRAMEBUFFER) != 36053) {
                  GL30.glDeleteFramebuffers(framebufferId2);
                  return 0;
               } else {
                  framebufferId = framebufferId2;
                  colorTextureId = colorTextureId2;
                  width = width2;
                  height = height2;
                  return framebufferId;
               }
            }
         }
      } else {
         return 0;
      }
   }
}
