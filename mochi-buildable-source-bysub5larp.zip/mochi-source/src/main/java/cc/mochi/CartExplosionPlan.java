package cc.mochi;

public record CartExplosionPlan(BlockExposure slab, BlockPlacementPlan fire, ShotAngle shot) {
   public BlockPlacementPlan getFire2() {
      return getFire(this);
   }

   public ShotAngle getShot2() {
      return getShot(this);
   }

   public static BlockPlacementPlan getFire(CartExplosionPlan cartExplosionPlan) {
      return cartExplosionPlan.fire;
   }

   public BlockExposure getSlab() {
      return this.slab;
   }

   public static ShotAngle getShot(CartExplosionPlan cartExplosionPlan) {
      return cartExplosionPlan.shot;
   }
}
