package cc.mochi;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

public final class FriendsModule extends Module {
   private final KeybindSetting friendKeySetting = new KeybindSetting("Friend Key", -1, false);
   private boolean booleanState;

   public static KeybindSetting getFriendKeySetting(FriendsModule friendsModule) {
      return friendsModule.friendKeySetting;
   }

   private void updateState() {
      HitResult crosshairTarget = mc.crosshairTarget;
      if (crosshairTarget instanceof EntityHitResult) {
         EntityHitResult crosshairTarget2 = (EntityHitResult)crosshairTarget;
         if (crosshairTarget2.getEntity() instanceof PlayerEntity var2) {
            if (var2 != MinecraftClientAccess24.getPlayer(mc)) {
               String string = var2.getName().getString();
               if (FriendManager.testPlayerEntity(var2)) {
                  return;
               }

               FriendManager.updateStateForUUID4(var2.getUuid(), string);
               NotificationManager.getINSTANCE().updateState(true, string);
               return;
            }
         }
      }
   }

   public void updateState2() {
      boolean booleanState2 = KeybindUtils.checkCondition(getFriendKeySetting(this).getKeyCode());
      if (booleanState2) {
         if (!this.booleanState) {
            this.updateState();
         }
      }

      this.booleanState = booleanState2;
   }

   @Override
   public void onEnable() {
      ClickGuiScreen.updateStateForClickGuiTab(ClickGuiTab.FRIENDS);

      this.setEnabled(false);
   }

   public KeybindSetting getFriendKeySetting3() {
      return getFriendKeySetting(this);
   }

   public FriendsModule() {
      super("Friends", "Manage players that combat modules should ignore", -1, ModuleCategory.CLIENT);
      this.addSetting(this.friendKeySetting);
      this.getSettings().removeIf(objectValue -> this.testSetting((Setting)objectValue));
   }

   private boolean testSetting(Setting setting) {
      if (setting instanceof KeybindSetting) {
         if (!setting.equals(this.friendKeySetting)) {
            return true;
         }
      } else {
         ThreadLocalRandom.current().nextInt(16);
      }

      return false;
   }
}
