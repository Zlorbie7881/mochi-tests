package cc.mochi;

import cc.mochi.event.impl.network.DisconnectEvent;
import cc.mochi.event.impl.player.TickEndEvent;
import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.event.impl.render.Render2DEvent;
import cc.mochi.event.impl.world.WorldChangeEvent;
import cc.mochi.mixin.HandledScreenAccessor;
import cc.mochi.utils.combat.SystemInputSimulator;
import cc.mochi.utils.keybinding.simulation.CursorGlide;
import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.IntToDoubleFunction;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.Items;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.slot.Slot;

public final class AutoCartRefillModule extends Module {
   private long longState;
   private CartRefillState cartRefillState;
   private final ChoiceSetting modeSetting;

   private String string;

   private int age;
   private final HotbarPatternSetting hotbarPatternSetting = new HotbarPatternSetting("Hotbar Pattern");

   private long longState2;

   private CartRefillSlotMove cartRefillSlotMove;
   private ClientPlayerEntity clientPlayerEntity;

   private boolean booleanState;
   private final DoubleSetting cursorSpeedSetting;
   private final int[] intArray;

   private long longState3;

   private long longState4;

   private long longState5;
   private final CursorGlide cursorGlide;

   private ClientWorld clientWorld;

   private InventoryScreen inventoryScreen;

   private InventoryScreen inventoryScreen2;

   public static ClientPlayerEntity getClientPlayerEntity(AutoCartRefillModule autoCartRefillModule) {
      return autoCartRefillModule.clientPlayerEntity;
   }

   public static void setClientPlayerEntity(AutoCartRefillModule autoCartRefillModule, ClientPlayerEntity clientPlayerEntity2) {
      autoCartRefillModule.clientPlayerEntity = clientPlayerEntity2;
   }

   @EventHandler
   private void onTickEnd(TickEndEvent tickEndEvent) {
      if (getCartRefillState(this) == CartRefillState.SILENT) {
         if (this.checkCondition3() && nanoTime() >= this.longState4 && HotbarSelectionManager.checkCondition2()) {
            ThreadLocalRandom.current().nextInt(15);
            if (!CombatTickBudget.checkCondition()) {
               if (!getClientPlayerEntity(this).isUsingItem() && !RotationManager.getBooleanState()) {
                  CartRefillSlotMove cartRefillSlotMove2 = this.computeCartRefillSlotMoveForIntToDoubleFunction(null);
                  if (cartRefillSlotMove2 == null) {
                     ThreadLocalRandom.current().nextInt(14);

                     this.updateState2(500L);
                     return;
                  }

                  if (!this.testCartRefillSlotMove(cartRefillSlotMove2)) {
                     return;
                  }

                  if (InventoryUtils.checkCondition(cartRefillSlotMove2.getSource(), cartRefillSlotMove2.getHotbar())) {
                     this.updateStateForCartRefillSlotMove(cartRefillSlotMove2);
                  }

                  return;
               }
            }
         }
      } else {
         ThreadLocalRandom.current().nextInt(5);
      }
   }

   private CartRefillSlotMove computeCartRefillSlotMoveForIntToDoubleFunction(IntToDoubleFunction intToDoubleFunction) {
      if (MinecraftClientAccess31.getPlayer(mc) != null) {
         if (getHotbarPatternSetting(this).hasPatterns()) {
            return CartRefillPlanner.computeCartRefillSlotMoveForIntToDoubleFunction(HotbarPatternCapture.computeStringArrayForHotbarPatternSetting(this.hotbarPatternSetting), HotbarPatternCapture.computeStringArray(), intToDoubleFunction, intValue -> this.checkCondition(intValue));
         }
      }

      return null;
   }

   public static void setLongState2(AutoCartRefillModule autoCartRefillModule, long longState22) {
      autoCartRefillModule.longState2 = longState22;
   }

   public static void setCartRefillSlotMove(AutoCartRefillModule autoCartRefillModule, CartRefillSlotMove cartRefillSlotMove2) {
      autoCartRefillModule.cartRefillSlotMove = cartRefillSlotMove2;
   }

   public static ChoiceSetting getModeSetting(AutoCartRefillModule autoCartRefillModule) {
      return autoCartRefillModule.modeSetting;
   }

   public static void setInventoryScreen(AutoCartRefillModule autoCartRefillModule, InventoryScreen inventoryScreen3) {
      autoCartRefillModule.inventoryScreen = inventoryScreen3;
   }

   public static ClientWorld getClientWorld(AutoCartRefillModule autoCartRefillModule) {
      return autoCartRefillModule.clientWorld;
   }

   public static CartRefillState getCartRefillState(AutoCartRefillModule autoCartRefillModule) {
      return autoCartRefillModule.cartRefillState;
   }

   public static InventoryScreen getInventoryScreen(AutoCartRefillModule autoCartRefillModule) {
      return autoCartRefillModule.inventoryScreen;
   }

   public static InventoryScreen getInventoryScreen2(AutoCartRefillModule autoCartRefillModule) {
      return autoCartRefillModule.inventoryScreen2;
   }

   public AutoCartRefillModule() {
      super("Auto Cart Refill", "Restores TNT minecarts to their imported hotbar slots", ModuleCategory.PLAYER);
      String[] stringArray = new String[2];

      stringArray[0] = "Legit";
      stringArray[1] = "Silent";
      this.modeSetting = new ChoiceSetting("Mode", "Legit", stringArray);

      this.cursorSpeedSetting = new DoubleSetting("Cursor Speed", (1.0), (100.0), (75.0), (1.0));
      this.cursorGlide = new CursorGlide();
      this.intArray = new int[9];
      this.cartRefillState = CartRefillState.IDLE;

      this.longState2 = -1L;
      this.hotbarPatternSetting.setPredicate(objectValue -> equals((HotbarItemPattern)objectValue));
      this.hotbarPatternSetting.setImportLabel("Import from Hotbar");
      this.cursorSpeedSetting.setVisibility(() -> this.equals2());
      Setting[] settingArray = new Setting[]{this.hotbarPatternSetting, null, null};

      settingArray[1] = this.modeSetting;
      settingArray[2] = this.cursorSpeedSetting;
      this.addSettings(settingArray);
   }

   public static CartRefillSlotMove getCartRefillSlotMove(AutoCartRefillModule autoCartRefillModule) {
      return autoCartRefillModule.cartRefillSlotMove;
   }

   @EventHandler
   private void onRender(Render2DEvent render2DEvent) {
      setLongState(this, getLongState(this) + 1L);
      if (getCartRefillState(this) != CartRefillState.HOVER) {
         ThreadLocalRandom.current().nextInt(10);
      } else {
         int intValue = 18;
         ThreadLocalRandom.current().nextInt(11);
         if (!this.checkCondition3()) {
            this.updateState2(1000L);
         } else {
            if (nanoTime() >= this.longState4 && !getClientPlayerEntity(this).isUsingItem()) {
               if (!CombatTickBudget.checkCondition()) {
                  HandledScreenAccessor inventoryScreen22 = (HandledScreenAccessor)getInventoryScreen2(this);
                  double scaledCursorX = SystemInputSimulator.getScaledCursorX(getInventoryScreen2(this).width);
                  double scaledCursorY = SystemInputSimulator.getScaledCursorY(getInventoryScreen2(this).height);
                  IntToDoubleFunction intToDoubleFunction = intValue2 -> this.computeDoubleForHandledScreenAccessor(inventoryScreen22, scaledCursorX, scaledCursorY, intValue2);
                  CartRefillSlotMove cartRefillSlotMove2 = this.cartRefillSlotMove != null && this.testCartRefillSlotMove(this.cartRefillSlotMove) ? this.cartRefillSlotMove : this.computeCartRefillSlotMoveForIntToDoubleFunction(intToDoubleFunction);
                  if (cartRefillSlotMove2 == null) {
                     this.updateState2(500L);
                     return;
                  }

                  if (!cartRefillSlotMove2.equals(getCartRefillSlotMove(this))) {
                     this.cursorGlide.cancel();

                     setLongState2(this, (-1L));
                     this.cartRefillSlotMove = cartRefillSlotMove2;
                  }

                  Slot slot = ((PlayerScreenHandler)this.inventoryScreen2.getScreenHandler()).getSlot(InventoryUtils.computeInt2(cartRefillSlotMove2.getSource()));
                  if (slot.inventory == getClientPlayerEntity(this).getInventory() && slot.canTakeItems(this.clientPlayerEntity)) {
                     intValue = inventoryScreen22.getX() + MinecraftClientAccess31.getX(slot);

                     double requestX = (double)(intValue + 8);
                     double requestY = (double)(inventoryScreen22.getY() + slot.y + 8);
                     boolean booleanValue = getCursorGlide(this).glideTo(this.inventoryScreen2.width, this.inventoryScreen2.height, requestX, requestY, this.cursorSpeedSetting.getValue(), 0.5);
                     double scaledCursorX2 = SystemInputSimulator.getScaledCursorX(getInventoryScreen2(this).width);
                     double scaledCursorY2 = SystemInputSimulator.getScaledCursorY(this.inventoryScreen2.height);
                     if (booleanValue && inventoryScreen22.invokeGetSlotAt(scaledCursorX2, scaledCursorY2) == slot) {
                        long longState22 = getLongState2(this);

                        if (longState22 < (0L)) {
                           inventoryScreen22.setFocusedSlot(slot);
                           setLongState2(this, getLongState(this));
                           return;
                        }

                        if (this.longState > this.longState2) {
                           if (HotbarSelectionManager.checkCondition2() && this.testCartRefillSlotMove(cartRefillSlotMove2)) {
                              if (!InventoryUtils.testInventoryScreen(this.inventoryScreen2, slot, cartRefillSlotMove2.getHotbar())) {
                                 ThreadLocalRandom.current().nextInt(6);

                                 this.intArray[cartRefillSlotMove2.getHotbar()] = 2;
                                 this.cartRefillSlotMove = null;

                                 setLongState2(this, (-1L));
                                 this.cursorGlide.cancel();
                                 return;
                              }

                              this.updateStateForCartRefillSlotMove(cartRefillSlotMove2);
                              return;
                           }
                        }

                        return;
                     }

                     setLongState2(this, -1L);
                     return;
                  }

                  this.updateState2(1000L);
                  return;
               }
            }
         }
      }
   }

   private void updateStateForCartRefillSlotMove(CartRefillSlotMove cartRefillSlotMove2) {
      setCartRefillSlotMove(this, cartRefillSlotMove2);
      this.age = getClientPlayerEntity(this).age;
      PlayerListEntry playerListEntry;
      if (mc.getNetworkHandler() == null) {
         playerListEntry = null;
      } else {
         playerListEntry = mc.getNetworkHandler().getPlayerListEntry(this.clientPlayerEntity.getUuid());
      }

      PlayerListEntry playerListEntry2 = playerListEntry;
      int intValue;
      if (playerListEntry2 == null) {
         intValue = 0;
      } else {
         intValue = Math.max(0, playerListEntry2.getLatency());
      }

      int intValue2 = intValue;
      long longValue = nanoTime();

      long longValue2 = (long)Math.min(1000, Math.max(75, intValue2 + 50));

      this.longState4 = longValue + longValue2 * 1000000L;
      this.cartRefillState = CartRefillState.VERIFY;
      getCursorGlide(this).cancel();
      HotbarSelectionManager.updateState3(this);
   }

   public static HotbarPatternSetting getHotbarPatternSetting(AutoCartRefillModule autoCartRefillModule) {
      return autoCartRefillModule.hotbarPatternSetting;
   }

   public static CartRefillState getHOVER() {
      return CartRefillState.HOVER;
   }

   private boolean checkCondition(int intValue) {
      return (this.intArray[intValue] >= 2);
   }

   private boolean checkCondition2() {
      if (mc.player != null) {
         if (mc.world != null) {
            if (MinecraftClientAccess31.getInteractionManager(mc) != null) {
               ThreadLocalRandom.current().nextInt(13);

               ThreadLocalRandom.current().nextInt(11);

               if (MinecraftClientAccess31.getPlayer(mc).isAlive()) {
                  if (!MinecraftClientAccess31.getPlayer(mc).isSpectator()) {
                     if (!mc.isPaused()) {
                        return true;
                     }
                  }
               }
            }
         }
      }

      return false;
   }

   private Boolean equals2() {
      return getModeSetting(this).equals("Legit");
   }

   @EventHandler(
      priority = -200
   )
   private void onTick(TickEvent tickEvent) {
      HotbarSelectionManager.updateState2();
      if (!this.checkCondition2()) {
         this.updateState2((500L));
      } else {
         label147: {
            if (getCartRefillState(this) == CartRefillState.IDLE) {
               if (nanoTime() < this.longState5) {
                  break label147;
               }

               if (mc.player.isUsingItem() || CombatTickBudget.checkCondition() || RotationManager.getBooleanState() || this.computeCartRefillSlotMoveForIntToDoubleFunction(null) == null) {
                  break label147;
               }

               this.updateState();
            }

            if (getCartRefillState(this) == CartRefillState.IDLE) {
               return;
            }

            if (this.checkCondition3()) {
               long longValue = nanoTime() - this.longState3;

               if (longValue <= 30000000000L) {
                  if (!this.booleanState) {
                     HotbarSelectionManager.updateState(this);
                  }

                  if (getCartRefillState(this) == CartRefillState.VERIFY) {
                     if (nanoTime() < getLongState4(this)) {
                        return;
                     }

                     if (this.clientPlayerEntity.age <= getAge(this)) {
                        return;
                     }

                     if (!InventoryUtils.testItem(getCartRefillSlotMove(this).getHotbar(), MinecraftClientAccess31.getTNT_MINECART())) {
                        this.intArray[getCartRefillSlotMove(this).getHotbar()]++;
                     }

                     setCartRefillSlotMove(this, null);

                     setLongState2(this, (-1L));
                     getCursorGlide(this).cancel();
                     this.cartRefillState = this.booleanState ? CartRefillState.SILENT : CartRefillState.HOVER;
                  }

                  if (!mc.player.isUsingItem() && !CombatTickBudget.checkCondition() && (!this.booleanState || !RotationManager.getBooleanState())) {
                     if (this.computeCartRefillSlotMoveForIntToDoubleFunction(null) == null) {
                        this.updateState2(500L);
                        return;
                     }

                     HotbarSelectionManager.updateState(this);
                     return;
                  }

                  HotbarSelectionManager.updateState3(this);
                  return;
               }
            }

            this.updateState2(1000L);
            return;
         }
      }
   }

   public static long getLongState4(AutoCartRefillModule autoCartRefillModule) {
      return autoCartRefillModule.longState4;
   }

   public static long getLongState2(AutoCartRefillModule autoCartRefillModule) {
      return autoCartRefillModule.longState2;
   }

   private static boolean equals(HotbarItemPattern hotbarItemPattern) {
      return "minecraft:tnt_minecart".equals(hotbarItemPattern.getItem());
   }

   public static void setClientWorld(AutoCartRefillModule autoCartRefillModule, ClientWorld clientWorld2) {
      autoCartRefillModule.clientWorld = clientWorld2;
   }

   private void updateState() {
      boolean booleanState2 = this.modeSetting.equals("Silent");
      if (booleanState2) {
         if (!InventoryUtils.checkCondition3()) {
            return;
         }
      } else {
         if (MinecraftClientAccess31.getCurrentScreen(mc) != null && !(MinecraftClientAccess31.getCurrentScreen(mc) instanceof InventoryScreen)) {
            return;
         }
      }

      if (!booleanState2) {
         ThreadLocalRandom.current().nextInt(14);

         if (mc.currentScreen == null) {
            if (mc.player.isCreative()) {
               return;
            }
         } else {
            ThreadLocalRandom.current().nextInt(7);
         }
      }

      setClientPlayerEntity(this, mc.player);
      setClientWorld(this, MinecraftClientAccess31.getWorld(mc));
      this.booleanState = booleanState2;
      this.string = getHotbarPatternSetting(this).computeString();
      Arrays.fill(getIntArray(this), 0);
      this.longState3 = nanoTime();

      this.longState4 = this.longState3 + 70000000L;
      if (booleanState2) {
         setCartRefillState(this, CartRefillState.SILENT);
      } else {
         if (mc.currentScreen == null) {
            setInventoryScreen(this, new InventoryScreen(getClientPlayerEntity(this)));
            mc.setScreen(this.inventoryScreen);
         }

         if (!(mc.currentScreen instanceof InventoryScreen var2)) {
            this.updateState2((1000L));
            return;
         }

         setInventoryScreen22(this, var2);
         this.cartRefillState = CartRefillState.HOVER;
      }
   }

   @EventHandler
   private void onDisconnect(DisconnectEvent disconnectEvent) {
      this.updateState2(0L);
   }

   public static CursorGlide getCursorGlide(AutoCartRefillModule autoCartRefillModule) {
      return autoCartRefillModule.cursorGlide;
   }

   private static long nanoTime() {
      return System.nanoTime();
   }

   @Override
   public void onDisable() {
      this.updateState2(0L);
   }

   public static void setInventoryScreen22(AutoCartRefillModule autoCartRefillModule, InventoryScreen inventoryScreen22) {
      autoCartRefillModule.inventoryScreen2 = inventoryScreen22;
   }

   private boolean checkCondition3() {
      if (this.checkCondition2() && MinecraftClientAccess31.getPlayer(mc) == this.clientPlayerEntity) {
         if (mc.world == getClientWorld(this)) {
            if (this.booleanState == this.modeSetting.equals("Silent")) {
               if (this.string.equals(getHotbarPatternSetting(this).computeString())) {
                  if (getClientPlayerEntity(this).currentScreenHandler == getClientPlayerEntity(this).playerScreenHandler) {
                     if (getClientPlayerEntity(this).playerScreenHandler.getCursorStack().isEmpty()) {
                        if (this.booleanState) {
                           ThreadLocalRandom.current().nextInt(14);
                           if (mc.currentScreen == null) {
                              return true;
                           }
                        } else if (MinecraftClientAccess31.getCurrentScreen(mc) == this.inventoryScreen2) {
                           return true;
                        }
                     }
                  }
               }
            }
         }
      }

      return false;
   }

   public static int[] getIntArray(AutoCartRefillModule autoCartRefillModule) {
      return autoCartRefillModule.intArray;
   }

   public static void setLongState(AutoCartRefillModule autoCartRefillModule, long longState6) {
      autoCartRefillModule.longState = longState6;
   }

   private void updateState2(long longValue) {
      HotbarSelectionManager.updateState3(this);
      this.cursorGlide.cancel();
      if (getInventoryScreen(this) != null && MinecraftClientAccess31.getPlayer(mc) == getClientPlayerEntity(this)) {
         ThreadLocalRandom.current().nextInt(6);
         if (MinecraftClientAccess31.getWorld(mc) == this.clientWorld) {
            if (MinecraftClientAccess31.getCurrentScreen(mc) == getInventoryScreen(this)) {
               if (((PlayerScreenHandler)getInventoryScreen(this).getScreenHandler()).getCursorStack().isEmpty()) {
                  this.clientPlayerEntity.closeHandledScreen();
               }
            }
         }
      }

      this.cartRefillState = CartRefillState.IDLE;
      setClientPlayerEntity(this, null);
      this.clientWorld = null;
      setInventoryScreen(this, null);
      this.inventoryScreen2 = null;
      setString(this, null);
      setCartRefillSlotMove(this, null);
      long longValue2;

      this.longState2 = (-1L);
      Arrays.fill(this.intArray, 0);
      longValue2 = nanoTime();

      setLongState5(this, longValue2 + longValue * 1000000L);
   }

   public static long getLongState(AutoCartRefillModule autoCartRefillModule) {
      return autoCartRefillModule.longState;
   }

   public static CartRefillState getVERIFY() {
      return CartRefillState.VERIFY;
   }

   public static void setString(AutoCartRefillModule autoCartRefillModule, String string2) {
      autoCartRefillModule.string = string2;
   }

   public static int getAge(AutoCartRefillModule autoCartRefillModule) {
      return autoCartRefillModule.age;
   }

   @Override
   public void onEnable() {
      this.updateState2((0L));
   }

   private boolean testCartRefillSlotMove(CartRefillSlotMove cartRefillSlotMove2) {
      if (cartRefillSlotMove2 != null) {
         if (this.hotbarPatternSetting.canImportSlot(cartRefillSlotMove2.getHotbar()) && !InventoryUtils.testItem(cartRefillSlotMove2.getHotbar(), Items.TNT_MINECART)) {
            ThreadLocalRandom.current().nextInt(12);

            if (getClientPlayerEntity(this).getInventory().getStack(cartRefillSlotMove2.getSource()).isOf(MinecraftClientAccess31.getTNT_MINECART())) {
               return true;
            }
         }
      }

      return false;
   }

   public static CartRefillState getIDLE() {
      return CartRefillState.IDLE;
   }

   public static void setCartRefillState(AutoCartRefillModule autoCartRefillModule, CartRefillState cartRefillState2) {
      autoCartRefillModule.cartRefillState = cartRefillState2;
   }

   private double computeDoubleForHandledScreenAccessor(HandledScreenAccessor handledScreenAccessor, double doubleValue, double doubleValue2, int intValue) {
      Slot slot = ((PlayerScreenHandler)getInventoryScreen2(this).getScreenHandler()).getSlot(InventoryUtils.computeInt2(intValue));
      double doubleValue3 = (double)(handledScreenAccessor.getX() + MinecraftClientAccess31.getX(slot) + 8) - doubleValue;
      double doubleValue4 = (double)(handledScreenAccessor.getY() + MinecraftClientAccess31.getY(slot) + 8) - doubleValue2;
      return doubleValue3 * doubleValue3 + doubleValue4 * doubleValue4;
   }

   public static void setLongState5(AutoCartRefillModule autoCartRefillModule, long longState52) {
      autoCartRefillModule.longState5 = longState52;
   }

   @EventHandler
   private void onWorldChange(WorldChangeEvent worldChangeEvent) {
      this.updateState2((0L));
   }

}
