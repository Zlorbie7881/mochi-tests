package cc.mochi;

import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.event.impl.render.Render2DEvent;
import java.awt.Color;
import java.net.http.HttpClient;
import java.net.http.HttpClient.Builder;
import java.time.Duration;
import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.util.math.MathHelper;

public class DynamicIslandModule extends Module implements HudElement {
   private final BooleanSetting animationsSetting;

   private final ChoiceSetting blurQualitySetting;
   private final DoubleSetting opacitySetting;

   private volatile MediaSnapshot mediaSnapshot;

   private final BooleanSetting ySetting;

   private FloatAnimation floatAnimation;

   private final BooleanSetting pingSetting;

   private ScheduledExecutorService scheduledExecutorService;

   private HudLayout hudLayout;

   private final BooleanSetting blurSetting;

   private final BooleanSetting xSetting;

   private volatile float floatState;

   private float floatState2;

   private final BooleanSetting tPSSetting;

   private final DoubleSetting animationSpeedSetting;
   private final DoubleSetting sizeSetting = new DoubleSetting("Size", 8.0, 32.0, 23.0, 1.0);
   private final BooleanSetting spotifySetting;

   private static final FontFace fontFace = FontFace.SEMIBOLD;

   private final BooleanSetting camoSetting;

   private final BooleanSetting fPSSetting;

   private final BooleanSetting zSetting;

   private long timestampMillis;

   public static final HttpClient httpClient;

   private final BooleanSetting adaptiveSpotifyColorsSetting;

   private static final FontFace fontFace2 = FontFace.MEDIUM;

   private final DoubleSetting blurRadiusSetting;

   private float floatState3;

   private final BooleanSetting coordinatesSetting;

   private final ChoiceSetting animationStyleSetting;

   private static final Color color = new Color(8, 8, 10);

   private final DoubleSetting themeTintSetting;

   private String format(double doubleValue) {
      return String.format(Locale.ROOT, "%.1f", doubleValue);
   }

   @Override
   public void onEnable() {
      this.updateState3();
   }

   private void updateStateForStringBuilder(StringBuilder stringBuilder, String string, double doubleValue) {
      if (!stringBuilder.isEmpty()) {
         stringBuilder.append("  ");
      }

      stringBuilder.append(string).append(' ').append(this.format(doubleValue));
   }

   private String computeString2() {
      if (mc.getNetworkHandler() != null && mc.player != null) {
         PlayerListEntry playerListEntry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
         return playerListEntry == null ? "--" : playerListEntry.getLatency() + "ms";
      } else {
         return "--";
      }
   }

   private void updateState2(boolean booleanValue) {
      float radius2 = Math.max(0.75F, Math.min(1.35F, this.sizeSetting.floatValue() / 16.0F));
      boolean booleanValue2 = this.spotifySetting.getValue() && this.mediaSnapshot != MediaSnapshot.EMPTY && this.mediaSnapshot.getPlaying();
      boolean booleanValue3 = booleanValue2 || this.coordinatesSetting.getValue();
      float floatValue = this.computeFloat4(radius2);
      float floatState32 = this.computeFloat(radius2, booleanValue2);
      float floatState22;
      float floatValue2;
      if (!this.animationsSetting.getValue()) {
         floatState22 = booleanValue3 ? 1.0F : 0.0F;
         floatValue2 = floatState32;
         this.floatAnimation = null;
         this.floatState3 = ((-1.0F));
         AnimationRegistry.remove("mochi.dynamic-island.expand");
      } else {
         long longValue;
         EasingFunction easingFunction;
         label133: {
            longValue = Math.max(1L, (long)(360.0F / this.animationSpeedSetting.floatValue()));
            String selected = this.animationStyleSetting.getSelected();

            switch (selected.hashCode()) {
               case -2018804923:
                  if (selected.equals("Linear")) {
                     easingFunction = EasingFunctionAccess.LINEAR;
                     break label133;
                  }
                  break;
               case -1814666802:
                  if (selected.equals("Smooth")) {
                     easingFunction = EasingFunctionAccess.OUT_CUBIC;
                     break label133;
                  }
            }

            easingFunction = EasingFunctionAccess.OUT_BACK;
         }

         EasingFunction easingFunction2 = easingFunction;
         floatState22 = AnimationRegistry.computeFloatForEasingFunction("mochi.dynamic-island.expand", booleanValue3 ? 1.0F : 0.0F, longValue, easingFunction2);
         floatValue2 = this.computeFloatForEasingFunction(floatState32, longValue, easingFunction2);
      }

      float width = floatValue + (floatValue2 - floatValue) * floatState22;
      float height = (30.0F + 34.0F * floatState22) * radius2;
      this.updateState4(width, height);
      if (booleanValue) {
         this.hudLayout.updateDragging();
      }

      float x = this.hudLayout.getX();
      float y = this.hudLayout.getY();
      ThemeSnapshot themeSnapshot = ClickGuiModule.computeThemeSnapshot();
      int intValue = Math.round(this.opacitySetting.floatValue() * 2.55F);
      int intValue2 = Math.round((float)intValue * ClickGuiModule.computeFloat2());
      Color color2;
      Color color3;
      if (this.adaptiveSpotifyColorsSetting.getValue() && booleanValue2 && this.mediaSnapshot.getMediaColor() != null) {
         Color mediaColor = this.mediaSnapshot.getMediaColor();
         color2 = this.computeColorForColor(mediaColor, Color.WHITE, 0.3F);
         color3 = this.computeColorForColor(color, mediaColor, 0.1F);
      } else {
         color2 = ThemeSnapshot.computeColorForColor(themeSnapshot.getAccent2());
         color3 = this.computeColorForColor(color, color2, this.themeTintSetting.floatValue() / 100.0F * 0.18F);
      }

      float radius = height / 2.0F;
      intValue2 = Math.round((float)intValue * Math.max(0.6F, ClickGuiModule.computeFloat2()));
      boolean booleanValue4 = this.camoSetting.getValue() && HudBloomRenderer.checkCondition();
      if (this.blurSetting.getValue() && HudBloomRenderer.checkCondition() && intValue2 < 250) {
         BlurQualityAccess.checkCondition(x, y, width, height, radius, this.blurRadiusSetting.floatValue(), this.blurQualitySetting.getSelected());
      }

      HudBloomRenderer.drawGlowOutline(x, y, width, height, radius, 16.0F, 5.0F, new Color(0, 0, 0, Math.round((float)(110 * intValue) / 255.0F)));
      if (booleanValue4) {
         cc.mochi.CamouflageRenderer.checkCondition6((float)System.nanoTime() / 1.0E9F, ClickGuiModule.computeColorArrayForThemeSnapshot(themeSnapshot));
         HudBloomRenderer.drawCamouflage(x, y, width, height, radius);
      } else {
         HudBloomRenderer.fillVerticalGradient(x, y, width, height, radius, this.createColor(this.computeColorForColor(color3, Color.WHITE, 0.05F), intValue2), this.createColor(color3, intValue2));
         if (!HudBloomRenderer.isFallback()) {
            HudBloomRenderer.fillAngledGradient(
               x + width * 0.15F,
               y + height * 0.35F,
               width * 0.7F,
               height * 1.3F,
               radius,
               this.createColor(color2, Math.round(26.0F * floatState22 + 10.0F)),
               new Color(0, 0, 0, 0),
               1.6F
            );
         }
      }

      if (!HudBloomRenderer.isFallback()) {
         HudBloomRenderer.strokeRoundedRect(x, y, width, height, radius, 1.0F, new Color(255, 255, 255, Math.min(intValue, 22)));
         HudBloomRenderer.pushClip(x, y + height * 0.5F, width, height * 0.5F + 1.0F);
         LegacyUiTheme.updateStateForRunnable(0.5F, () -> this.strokeRoundedRect(x, y, width, height, radius, color2, intValue, floatState22));
         HudBloomRenderer.popClip();
         HudBloomRenderer.fillVerticalGradient(x + radius * 0.6F, y + 1.5F, width - radius * 1.2F, 1.2F, 0.6F, this.createColor(Color.WHITE, Math.min(intValue, 34)), this.createColor(Color.WHITE, 0));
         this.updateStateForColor(x, y, width, height, color2, floatState22);
      }

      this.floatState2 = floatState22;
      if (floatState22 > 0.08F) {
         this.updateStateForColor2(x, y, width, height, radius2, color2, intValue, floatState22, themeSnapshot);
      }

      if (floatState22 < 0.92F) {
         this.updateStateForColor5(x, y, width, height, radius2, color2, intValue, themeSnapshot);
      }
   }

   @EventHandler
   private void onRender2D(Render2DEvent render2DEvent) {
      if (mc.player != null && mc.world != null) {
         if (!GlCapabilities.checkCondition2()) {
            boolean booleanValue = mc.currentScreen instanceof ChatScreen;
            if (mc.currentScreen == null || booleanValue) {
               this.computeHudLayout();

               try (UiRenderBackend uiRenderBackend = HudBloomRenderer.computeUiRenderBackendForRender2DEvent(render2DEvent)) {
                  this.updateState2(booleanValue);
               }
            }
         }
      }
   }

   private float computeFloat(float floatValue, boolean booleanValue) {
      float floatValue2 = this.computeFloat3(floatValue);
      if (!booleanValue) {
         return floatValue2 + 18.0F * floatValue;
      } else {
         float floatValue3 = 115.0F * floatValue + floatValue2;
         return Math.max(300.0F * floatValue, floatValue3);
      }
   }

   @Override
   public String computeString() {
      return this.getName();
   }

   private void updateState3() {
      if (this.scheduledExecutorService == null) {
         ThreadFactory threadFactory = runnable -> computeThreadForRunnable(runnable);
         this.scheduledExecutorService = Executors.newSingleThreadScheduledExecutor(threadFactory);
         ScheduledExecutorService scheduledExecutorService2 = this.scheduledExecutorService;
         Runnable runnable2 = () -> this.updateMediaSnapshot();

         scheduledExecutorService2.scheduleWithFixedDelay(runnable2, 0L, 1500L, TimeUnit.MILLISECONDS);
      }
   }

   private float computeFloat2(float floatValue) {
      float floatValue2 = 8.0F * floatValue;
      int intValue = 0;
      float floatValue3 = 0.0F;
      if (this.fPSSetting.getValue()) {
         floatValue3 = 0.0F + this.computeFloat5(this.computeString5(), floatValue);
         intValue++;
      }

      if (this.pingSetting.getValue()) {
         floatValue3 += this.computeFloat5(this.computeString2(), floatValue);
         intValue++;
      }

      if (this.tPSSetting.getValue()) {
         floatValue3 += this.computeFloat5(this.format2(), floatValue);
         intValue++;
      }

      if (intValue > 1) {
         floatValue3 += floatValue2 * (float)(intValue - 1);
      }

      return floatValue3;
   }

   private String computeString3() {
      if (this.coordinatesSetting.getValue() && mc.player != null) {
         StringBuilder stringBuilder = new StringBuilder();
         if (this.xSetting.getValue()) {
            stringBuilder.append("X ").append(this.format(mc.player.getX()));
         }

         if (this.ySetting.getValue()) {
            this.updateStateForStringBuilder(stringBuilder, "Y", mc.player.getY());
         }

         if (this.zSetting.getValue()) {
            this.updateStateForStringBuilder(stringBuilder, "Z", mc.player.getZ());
         }

         return stringBuilder.toString();
      } else {
         return "";
      }
   }

   private void updateStateForColor(float x, float y, float width, float height, Color color2, float floatValue5) {
      int intValue = Math.round(73.6F * floatValue5);
      if (intValue > 1) {
         HudBloomRenderer.drawShadow(x, y, width, height, height / 2.0F, 12.0F, 1.5F, this.createColor(color2, intValue));
      }
   }

   private String computeString4(String text, float size, float floatValue) {
      if (text != null && !text.isEmpty()) {
         if (HudBloomRenderer.measureText(text, size, fontFace) <= floatValue) {
            return text;
         } else {
            String string2 = "...";
            String string = text;

            while (string.length() > 1 && HudBloomRenderer.measureText(string + string2, size, fontFace) > floatValue) {
               string = string.substring(0, string.length() - 1);
            }

            return string + string2;
         }
      } else {
         return ClientText.CLIENT_NAME.toString();
      }
   }

   private void updateStateForColor2(float floatValue, float floatValue2, float floatValue3, float floatValue4, float radius, Color color2, int intValue, float floatValue5, ThemeSnapshot themeSnapshot) {
      float floatValue6 = 9.0F * radius;
      float floatValue7 = 44.0F * radius;
      float x = floatValue + floatValue6;
      float y = floatValue2 + (floatValue4 - floatValue7) / 2.0F;
      MediaSnapshot mediaSnapshot2 = this.mediaSnapshot;
      boolean booleanValue = this.spotifySetting.getValue() && mediaSnapshot2 != MediaSnapshot.EMPTY && mediaSnapshot2.getPlaying();
      if (booleanValue) {
         if (mediaSnapshot2.getCoverPath() != null && !HudBloomRenderer.isFallback()) {
            HudBloomRenderer.drawRoundedTexture(mediaSnapshot2.getCoverPath(), x, y, floatValue7, floatValue7, 8.0F * radius, Color.WHITE);
            HudBloomRenderer.strokeRoundedRect(x, y, floatValue7, floatValue7, 8.0F * radius, 1.0F, new Color(255, 255, 255, 38));
         } else {
            HudBloomRenderer.fillRoundedRect(x, y, floatValue7, floatValue7, 8.0F * radius, new Color(31, 197, 92, intValue));
            this.updateStateForColor4(x + floatValue7 / 2.0F, y + floatValue7 / 2.0F, radius, Color.WHITE);
         }
      }

      float floatValue8 = this.computeFloat3(radius);
      float x2 = booleanValue ? x + floatValue7 + 9.0F * radius : floatValue + floatValue6;
      float floatValue9 = Math.max(45.0F, floatValue3 - x2 + floatValue - floatValue6 - floatValue8);
      if (booleanValue) {
         String text = this.computeString4(mediaSnapshot2.getTitle(), 12.0F * radius, floatValue9);
         String text2 = this.computeString4(mediaSnapshot2.getArtist(), 9.5F * radius, floatValue9);
         float y2 = floatValue2 + 15.0F * radius;
         HudBloomRenderer.drawText(text, x2, y2, 12.0F * radius, Color.WHITE, fontFace);
         HudBloomRenderer.drawText(text2, x2, y2 + 14.0F * radius, 9.5F * radius, this.createColor(LegacyUiTheme.color4, intValue), fontFace2);
         float y3 = floatValue2 + floatValue4 - 8.0F * radius;
         float width = Math.max(12.0F, floatValue9 - 3.0F * radius);
         HudBloomRenderer.fillRoundedRect(x2, y3, width, 2.0F * radius, radius, new Color(255, 255, 255, 32));
         float floatValue10 = this.computeFloatForMediaSnapshot(mediaSnapshot2);
         float width2 = width * floatValue10;
         if (width2 > 0.0F) {
            float x4 = x2 + width - width2;
            LegacyUiTheme.updateStateForRunnable(0.6F, () -> this.fillRoundedRect(x4, y3, width2, radius, color2, intValue));
         }
      }

      float floatValue11 = floatValue + floatValue3 - floatValue6;
      float floatValue12 = this.computeFloat2(radius);
      float x5 = floatValue11 - floatValue12;
      float floatValue14 = floatValue2 + 19.0F * radius;
      float floatValue15 = 8.0F * radius;
      float x6 = x5;
      if (this.fPSSetting.getValue()) {
         this.updateStateForColor6(x5, floatValue14, this.computeString5(), "assets/mochi/textures/icons/fps.png", radius, color2, intValue, this.floatState2);
         x6 = x5 + this.computeFloat5(this.computeString5(), radius) + floatValue15;
      }

      if (this.pingSetting.getValue()) {
         this.updateStateForColor6(x6, floatValue14, this.computeString2(), "assets/mochi/textures/icons/ping.png", radius, color2, intValue, this.floatState2);
         x6 += this.computeFloat5(this.computeString2(), radius) + floatValue15;
      }

      if (this.tPSSetting.getValue()) {
         this.updateStateForColor6(x6, floatValue14, this.format2(), "T", radius, color2, intValue, this.floatState2);
      }

      String text3 = this.computeString3();
      if (!text3.isEmpty()) {
         float y4 = floatValue2 + 38.0F * radius;
         float floatValue17 = HudBloomRenderer.measureText(text3, 9.0F * radius, fontFace2);
         float x3 = floatValue12 > 0.0F ? x5 + (floatValue12 - floatValue17) / 2.0F : floatValue + (floatValue3 - floatValue17) / 2.0F;
         HudBloomRenderer.drawText(text3, x3, y4, 9.0F * radius, this.createColor(themeSnapshot.getSecondaryText2(), intValue), fontFace2);
      }
   }

   private float computeFloat3(float floatValue) {
      float floatValue2 = this.computeFloat2(floatValue);
      String text = this.computeString3();
      if (!text.isEmpty()) {
         floatValue2 = Math.max(floatValue2, HudBloomRenderer.measureText(text, 9.0F * floatValue, fontFace2));
      }

      return floatValue2;
   }

   @EventHandler
   private void onTick(TickEvent tickEvent) {
      long timestampMillis2 = System.currentTimeMillis();
      if (this.timestampMillis > 0L) {
         float floatValue = 1000.0F / Math.max(1.0F, (float)(timestampMillis2 - this.timestampMillis));
         this.floatState = this.floatState + (Math.max(0.0F, Math.min(20.0F, floatValue)) - this.floatState) * 0.2F;
      }

      this.timestampMillis = timestampMillis2;
   }

   private void fillRoundedRect(float x, float y, float width, float radius, Color color2, int intValue) {
      HudBloomRenderer.fillRoundedRect(x, y, width, 2.0F * radius, radius, this.createColor(color2, intValue));
   }

   public DynamicIslandModule() {
      super("Dynamic Island", "Displays an animated media and game HUD", -1, ModuleCategory.RENDER);
      this.opacitySetting = new DoubleSetting("Opacity", 0.0, 100.0, 86.0, 1.0);
      this.themeTintSetting = new DoubleSetting("Theme Tint", 0.0, 100.0, 35.0, 1.0);
      this.spotifySetting = new BooleanSetting("Spotify", true);
      this.adaptiveSpotifyColorsSetting = new BooleanSetting("Adaptive Spotify Colors", true);
      this.fPSSetting = new BooleanSetting("FPS", true);
      this.pingSetting = new BooleanSetting("Ping", true);
      this.tPSSetting = new BooleanSetting("TPS", true);
      this.coordinatesSetting = new BooleanSetting("Coordinates", false);
      this.xSetting = new BooleanSetting("X", true);
      this.ySetting = new BooleanSetting("Y", true);
      this.zSetting = new BooleanSetting("Z", true);
      this.blurSetting = new BooleanSetting("Blur", true);
      this.camoSetting = new BooleanSetting("Camo", false);
      this.blurRadiusSetting = new DoubleSetting("Blur Radius", 4.0, 48.0, 26.0, 1.0);
      this.blurQualitySetting = new ChoiceSetting("Blur Quality", "Balanced", "Performance", "Balanced", "Quality");
      this.animationsSetting = new BooleanSetting("Animations", true);
      this.animationStyleSetting = new ChoiceSetting("Animation Style", "Spring", "Spring", "Smooth", "Linear");
      this.animationSpeedSetting = new DoubleSetting("Animation Speed", 0.25, 3.0, 1.0, 0.05);
      this.floatState3 = ((-1.0F));
      this.mediaSnapshot = MediaSnapshot.EMPTY;
      this.floatState = 20.0F;
      this.addSettings(
         new Setting[]{
            this.sizeSetting,
            this.opacitySetting,
            this.themeTintSetting,
            this.spotifySetting,
            this.adaptiveSpotifyColorsSetting,
            this.fPSSetting,
            this.pingSetting,
            this.tPSSetting,
            this.coordinatesSetting,
            this.xSetting,
            this.ySetting,
            this.zSetting,
            this.blurSetting,
            this.blurRadiusSetting,
            this.blurQualitySetting,
            this.animationsSetting,
            this.animationStyleSetting,
            this.animationSpeedSetting,
            this.camoSetting
         }
      );
      this.xSetting.setVisibility(() -> this.coordinatesSetting.getValue());
      this.ySetting.setVisibility(() -> this.coordinatesSetting.getValue());
      this.zSetting.setVisibility(() -> this.coordinatesSetting.getValue());
      this.blurRadiusSetting.setVisibility(() -> this.blurSetting.getValue());
      this.blurQualitySetting.setVisibility(() -> this.blurSetting.getValue());
      this.animationStyleSetting.setVisibility(() -> this.animationsSetting.getValue());
      this.animationSpeedSetting.setVisibility(() -> this.animationsSetting.getValue());
   }

   private float computeFloatForEasingFunction(float floatState32, long longValue, EasingFunction easingFunction) {
      if (this.floatState3 < 0.0F) {
         this.floatState3 = floatState32;
         this.floatAnimation = null;
         return floatState32;
      } else if (floatState32 != this.floatState3) {
         float floatValue = this.floatAnimation != null ? this.floatAnimation.computeFloat() : this.floatState3;
         this.floatAnimation = new FloatAnimation(floatValue, floatState32, longValue, easingFunction);
         this.floatState3 = floatState32;
         return this.floatAnimation.computeFloat();
      } else {
         return this.floatAnimation != null && !this.floatAnimation.getBooleanState() ? this.floatAnimation.computeFloat() : this.floatState3;
      }
   }

   @Override
   public float getFloatConstant() {
      return 30.0F;
   }

   private void updateStateForColor3(String string, String text, float x, float y, float size, Color color2) {
      if (!HudBloomRenderer.isFallback() && (string.equals("assets/mochi/textures/icons/fps.png") || string.equals("assets/mochi/textures/icons/ping.png"))) {
         HudBloomRenderer.drawTextureFromResource(string, x, y, size, size, color2);
      } else {
         float floatValue2 = HudBloomRenderer.measureText(text, size, fontFace);
         HudBloomRenderer.drawText(text, x + (size - floatValue2) / 2.0F, y, size, color2, fontFace);
      }
   }

   @Override
   public boolean checkCondition() {
      return false;
   }

   @Override
   public void onDisable() {
      if (this.scheduledExecutorService != null) {
         this.scheduledExecutorService.shutdownNow();
         this.scheduledExecutorService = null;
      }

      this.mediaSnapshot = MediaSnapshot.EMPTY;
      this.floatState = 20.0F;
      this.timestampMillis = 0L;
      this.floatAnimation = null;
      this.floatState3 = ((-1.0F));
      AnimationRegistry.remove("mochi.dynamic-island.expand");
   }

   @Override
   public float getFloatConstant2() {
      return 180.0F;
   }

   private float computeFloat4(float floatValue) {
      float floatValue2 = 18.0F * floatValue;
      if (this.fPSSetting.getValue()) {
         floatValue2 += this.computeFloat5(this.computeString5(), floatValue);
      }

      if (this.pingSetting.getValue()) {
         floatValue2 += this.computeFloat5(this.computeString2(), floatValue) + 9.0F * floatValue;
      }

      if (this.tPSSetting.getValue()) {
         floatValue2 += this.computeFloat5(this.format2(), floatValue) + 9.0F * floatValue;
      }

      return Math.max(138.0F * floatValue, floatValue2);
   }

   private String format2() {
      return String.format(Locale.ROOT, "%.1f", Math.max(0.0F, Math.min(20.0F, this.floatState)));
   }

   private static Thread computeThreadForRunnable(Runnable runnable) {
      Thread thread = new Thread(runnable, ClientText.MEDIA_THREAD.toString());
      thread.setDaemon(true);
      return thread;
   }

   private float computeFloatForMediaSnapshot(MediaSnapshot mediaSnapshot2) {
      if (mediaSnapshot2.getLengthMicros() <= 0L) {
         return 0.0F;
      } else {
         long positionMicros = mediaSnapshot2.getPositionMicros();
         if (mediaSnapshot2.getPlaying() && mediaSnapshot2.getSampledAt() > 0L) {
            long longValue = Math.max(0L, System.currentTimeMillis() - mediaSnapshot2.getSampledAt());

            positionMicros += longValue * 1000L;
         }

         return Math.max(0.0F, Math.min(1.0F, 1.0F - (float)positionMicros / (float)mediaSnapshot2.getLengthMicros()));
      }
   }

   private float computeFloat5(String text, float floatValue) {
      return 11.0F * floatValue + 3.0F * floatValue + HudBloomRenderer.measureText(text, 9.5F * floatValue, fontFace2);
   }

   private Color computeColorForColor(Color color2, Color color3, float floatValue) {
      float floatValue2 = Math.max(0.0F, Math.min(1.0F, floatValue));
      return new Color(
         Math.round((float)color2.getRed() + (float)(color3.getRed() - color2.getRed()) * floatValue2),
         Math.round((float)color2.getGreen() + (float)(color3.getGreen() - color2.getGreen()) * floatValue2),
         Math.round((float)color2.getBlue() + (float)(color3.getBlue() - color2.getBlue()) * floatValue2)
      );
   }

   private String computeString5() {
      int currentFps = mc.getCurrentFps();
      return currentFps > 0 ? String.valueOf(currentFps) : "--";
   }

   private void strokeRoundedRect(float x, float y, float width, float height, float radius, Color color2, int intValue, float floatValue6) {
      HudBloomRenderer.strokeRoundedRect(x, y, width, height, radius, 1.0F, this.createColor(color2, Math.round((float)intValue * (0.25F + 0.35F * floatValue6))));
   }

   private Color createColor(Color color2, int intValue) {
      return new Color(color2.getRed(), color2.getGreen(), color2.getBlue(), Math.min(color2.getAlpha(), intValue));
   }

   @Override
   public HudLayout computeHudLayout() {
      if (this.hudLayout == null) {
         this.hudLayout = new HudLayout(0.0F, 10.0F, 180.0F, 30.0F);
      }

      return this.hudLayout;
   }

   private void updateStateForColor4(float floatValue, float floatValue2, float floatValue3, Color color2) {
      HudBloomRenderer.drawLine(floatValue - 7.0F * floatValue3, floatValue2 - 3.0F * floatValue3, floatValue + 5.0F * floatValue3, floatValue2 - 1.0F * floatValue3, 2.0F * floatValue3, color2);
      HudBloomRenderer.drawLine(floatValue - 6.0F * floatValue3, floatValue2 + 1.0F * floatValue3, floatValue + 4.0F * floatValue3, floatValue2 + 2.5F * floatValue3, 2.0F * floatValue3, color2);
      HudBloomRenderer.drawLine(floatValue - 4.0F * floatValue3, floatValue2 + 5.0F * floatValue3, floatValue + 3.0F * floatValue3, floatValue2 + 6.0F * floatValue3, 2.0F * floatValue3, color2);
   }

   private void updateStateForColor5(float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5, Color color2, int intValue, ThemeSnapshot themeSnapshot) {
      float floatValue6 = 9.0F * floatValue5;
      float floatValue7 = floatValue2 + floatValue4 / 2.0F;
      float x = floatValue + floatValue3 - floatValue6;
      if (this.tPSSetting.getValue()) {
         String text = this.format2();
         float floatValue9 = this.computeFloat5(text, floatValue5);
         x -= floatValue9;
         this.updateStateForColor6(x, floatValue7, text, "T", floatValue5, color2, intValue, 1.0F - this.floatState2);
         x -= 9.0F * floatValue5;
      }

      if (this.pingSetting.getValue()) {
         String text2 = this.computeString2();
         float floatValue10 = this.computeFloat5(text2, floatValue5);
         x -= floatValue10;
         this.updateStateForColor6(x, floatValue7, text2, "assets/mochi/textures/icons/ping.png", floatValue5, color2, intValue, 1.0F - this.floatState2);
         x -= 9.0F * floatValue5;
      }

      if (this.fPSSetting.getValue()) {
         String text3 = this.computeString5();
         float floatValue11 = this.computeFloat5(text3, floatValue5);
         x -= floatValue11;
         this.updateStateForColor6(x, floatValue7, text3, "assets/mochi/textures/icons/fps.png", floatValue5, color2, intValue, 1.0F - this.floatState2);
      }
   }

   @Override
   public void updateState() {
      this.computeHudLayout().setAlignmentAndInsets(HudHorizontalAlignment.CENTRE, HudVerticalAlignment.TOP, 0.0F, 10.0F);
   }

   private void updateStateForColor6(float x, float floatValue2, String text, String string2, float floatValue3, Color color2, int intValue, float floatValue4) {
      int intValue2 = (int)((float)intValue * MathHelper.clamp(floatValue4 * 1.15F, 0.0F, 1.0F));
      float size = 11.0F * floatValue3;
      this.updateStateForColor3(
         string2,
         string2.equals("assets/mochi/textures/icons/fps.png") ? "F" : (string2.equals("assets/mochi/textures/icons/ping.png") ? "P" : "T"),
         x,
         floatValue2 - size / 2.0F,
         size,
         this.createColor(color2, intValue2)
      );
      HudBloomRenderer.drawText(
         text,
         x + size + 3.0F * floatValue3,
         floatValue2 - HudBloomRenderer.measureFontHeight(9.5F * floatValue3, fontFace) / 2.0F,
         9.5F * floatValue3,
         new Color(LegacyUiTheme.color3.getRed(), LegacyUiTheme.color3.getGreen(), LegacyUiTheme.color3.getBlue(), intValue2),
         fontFace
      );
   }

   static {
      Builder builder = HttpClient.newBuilder();

      httpClient = builder.connectTimeout(Duration.ofSeconds(2L)).build();
   }

   private void updateMediaSnapshot() {
      this.mediaSnapshot = MediaSnapshot.computeMediaSnapshot2();
   }
}
