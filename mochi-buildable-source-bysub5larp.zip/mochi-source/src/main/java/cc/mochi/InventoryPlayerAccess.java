package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.util.collection.DefaultedList;

public class InventoryPlayerAccess {
   public static Screen getCurrentScreen(MinecraftClient minecraftClient) {
      return minecraftClient.currentScreen;
   }

   public static KeyBinding getSwapHandsKey(GameOptions gameOptions) {
      return gameOptions.swapHandsKey;
   }

   public static int getId(Slot slot) {
      return slot.id;
   }

   public static Item getTOTEM_OF_UNDYING() {
      return Items.TOTEM_OF_UNDYING;
   }

   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static ClientPlayerInteractionManager getInteractionManager(MinecraftClient minecraftClient) {
      return minecraftClient.interactionManager;
   }

   public static int getX(Slot slot) {
      return slot.x;
   }

   public static int getY(Slot slot) {
      return slot.y;
   }

   public static GameOptions getOptions(MinecraftClient minecraftClient) {
      return minecraftClient.options;
   }

   public static DefaultedList<Slot> getSlots(ScreenHandler screenHandler) {
      return screenHandler.slots;
   }
}
