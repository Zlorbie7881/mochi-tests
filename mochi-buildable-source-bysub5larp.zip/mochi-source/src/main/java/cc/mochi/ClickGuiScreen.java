package cc.mochi;

import cc.mochi.utils.platform.PlatformService;
import java.awt.Color;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

public class ClickGuiScreen extends Screen implements ClientGuiScreen {
   private static ClickGuiTab clickGuiTab;
   private long timestampNanos;

   private final ClickGuiRoot clickGuiRoot;
   private final UiRenderContext uiRenderContext = new UiRenderContext();
   private boolean booleanState;
   private final UiContext uiContext = new UiContext();
   private float floatState;
   private float floatState2;

   public static ClickGuiRoot getClickGuiRoot(ClickGuiScreen clickGuiScreen) {
      return clickGuiScreen.clickGuiRoot;
   }

   public void render(DrawContext drawContext, int mouseX, int mouseY, float tickDelta) {
      long now = System.nanoTime();
      float delta = Math.min((0.1F), Math.max((1.0E-4F), (float)(now - this.timestampNanos) * 1.0E-9F));
      this.timestampNanos = now;
      if (this.width <= 0 || this.height <= 0) return;
      UiRenderBackend target = HudBloomRenderer.computeUiRenderBackendForDrawContext(drawContext, this.width, this.height);
      UiRenderContext context = getUiRenderContext(this);
      try {
         context.setBackend(target);
         float scale = this.computeFloat();
         context.updateScale(scale);
         if (this.checkCondition(delta)) return;
         float opacity = computeFloat2(this.floatState2);
         ThemeSnapshot theme = ThemeSnapshot.computeThemeSnapshot2(opacity);
         float logicalWidth = (float)this.width / scale;
         float logicalHeight = (float)this.height / scale;
         this.updateStateForUiRenderContext(context, theme, delta, logicalWidth, logicalHeight, opacity);
         double x = (float)mouseX / scale;
         double y = (float)mouseY / scale;
         context.updateState(x, y);
         context.setDrawContext(getFloatState2(this) > (0.9F) && !this.clickGuiRoot.checkCondition2() ? drawContext : null);
         this.uiContext.beginFrame(context, theme, x, y, delta);
         try {
            this.clickGuiRoot.updateStateForUiContext2(this.uiContext, logicalWidth, logicalHeight, opacity);
         } finally {
            this.uiContext.commitFrame();
            context.setDrawContext(null);
         }
      } catch (RuntimeException error) {
         HudBloomRenderer.reportFailureOnce("ClickGUI", error);
         RenderBackendManager.getINSTANCE().updateStateForThrowable2(error);
      } finally {
         context.close();
      }
   }

   public static void setTimestampNanos(ClickGuiScreen clickGuiScreen, long timestampNanos2) {
      clickGuiScreen.timestampNanos = timestampNanos2;
   }

   public static boolean getBooleanState(ClickGuiScreen clickGuiScreen) {
      return clickGuiScreen.booleanState;
   }

   public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      getUiContext(this).getInputRouter().dispatchScroll(mouseX / (double)this.computeFloat(), mouseY / (double)this.computeFloat(), verticalAmount);
      return true;
   }

   public static float getFloatState(ClickGuiScreen clickGuiScreen) {
      return clickGuiScreen.floatState;
   }

   public boolean shouldCloseOnEsc() {
      return true;
   }

   public boolean charTyped(CharInput input) {
      if (this.clickGuiRoot.checkCondition3((char)input.codepoint())) {
         ThreadLocalRandom.current().nextInt(5);
         return true;
      } else {
         return super.charTyped(input);
      }
   }

   public ClickGuiScreen() {
      super(Text.literal(MochiMetadata.NAME));
      this.clickGuiRoot = new ClickGuiRoot(objectValue -> this.updateStateForClickGuiTab2((ClickGuiTab)objectValue));
      this.timestampNanos = System.nanoTime();
   }

   public static UiContext getUiContext(ClickGuiScreen clickGuiScreen) {
      return clickGuiScreen.uiContext;
   }

   public static void setFloatState2(ClickGuiScreen clickGuiScreen, float floatState22) {
      clickGuiScreen.floatState2 = floatState22;
   }

   public static UiRenderContext getUiRenderContext(ClickGuiScreen clickGuiScreen) {
      return clickGuiScreen.uiRenderContext;
   }

   public static ClickGuiTab getClickGuiTab() {
      return clickGuiTab;
   }

   public static float getFloatState2(ClickGuiScreen clickGuiScreen) {
      return clickGuiScreen.floatState2;
   }

   protected void init() {
      super.init();
      if (clickGuiTab != null) {
         ClickGuiTab clickGuiTab2 = getClickGuiTab();
         clickGuiTab = null;
         this.updateStateForClickGuiTab2(clickGuiTab2);
      }

      if (ClickGuiModule.getValue5()) {
         if (ClickGuiModule.getValue3()) {
            this.clickGuiRoot.updateState3();

            ThreadLocalRandom.current().nextInt(11);
         }
      }
   }

   public static void setClickGuiTab(ClickGuiTab clickGuiTab2) {
      clickGuiTab = clickGuiTab2;
   }

   public void renderBackground(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
   }

   public void removed() {
      super.removed();
      getClickGuiRoot(this).updateState2();
      if (MochiClient.INSTANCE != null) {
         ProfileManager profileManager = MochiClientAccess.getINSTANCE().getProfileManager();

         profileManager.updateState3("default", true);
      }
   }

   public static void setBooleanState(ClickGuiScreen clickGuiScreen, boolean booleanState2) {
      clickGuiScreen.booleanState = booleanState2;
   }

   private float computeFloat() {
      return WindowScaleMath.computeFloat(this.width, this.height) * Math.max(0.5F, ClickGuiModule.floatValue5());
   }

   public boolean mouseReleased(Click click) {
      this.uiContext.getInputRouter().endDrag(click.x() / (double)this.computeFloat(), click.y() / (double)this.computeFloat());

      return true;
   }

   public static void updateStateForClickGuiTab(ClickGuiTab clickGuiTab2) {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if ((minecraftClient != null)) {
         Screen currentScreen = minecraftClient.currentScreen;
         if (currentScreen instanceof ClickGuiScreen) {
            ThreadLocalRandom.current().nextInt(15);
            ClickGuiScreen currentScreen2 = (ClickGuiScreen)currentScreen;
            currentScreen2.updateStateForClickGuiTab2(clickGuiTab2);
         } else {
            ThreadLocalRandom.current().nextInt(12);

            setClickGuiTab(clickGuiTab2);
            minecraftClient.setScreen((Screen)(PlatformService.isMobile() ? new ClickGuiOverlayScreen() : new ClickGuiScreen()));
         }
      }
   }

   public void close() {
      if (!getBooleanState(this)) {
         ThreadLocalRandom.current().nextInt(8);

         setBooleanState(this, true);
         getClickGuiRoot(this).updateState2();
         ClientSounds.updateState5();
         if (ClickGuiModule.computeInt2() <= 0) {
            if (this.client != null) {
               this.client.setScreen(null);
            }
         }
      } else {
         ThreadLocalRandom.current().nextInt(12);
      }
   }

   public boolean mouseDragged(Click click, double offsetX, double offsetY) {
      this.uiContext.getInputRouter().updateDrag(click.x() / (double)this.computeFloat(), click.y() / (double)this.computeFloat());

      return true;
   }

   private static void setEnabled(SelfDestructModule selfDestructModule) {
      selfDestructModule.setEnabled(true);
   }

   private void updateState() {
      if (MochiClientAccess.getINSTANCE() != null) {
         MochiClient.INSTANCE.getModuleManager().findFirst(SelfDestructModule.class).ifPresent(objectValue -> setEnabled((SelfDestructModule)objectValue));
      }

      this.close();
   }

   public static int[] getIntArray3() {
      return ClickGuiActionSwitchMap.intArray3;
   }

   private void updateStateForClickGuiTab2(ClickGuiTab clickGuiTab2) {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      switch (getIntArray3()[clickGuiTab2.ordinal()]) {
         case 1:

            ClientSounds.updateState4();
            minecraftClient.setScreen(new KeybindsScreen());
            break;
         case 2:
            ClientSounds.updateState4();
            if (MochiClientAccess.getINSTANCE() != null) {
               MochiClientAccess.getINSTANCE().getModuleManager().findFirst(HudEditorModule.class).ifPresent(objectValue -> ((HudEditorModule)objectValue).setScreen());
            } else {
            }
            break;
         case 3:

            MochiClientAccess.getConfirmationDialog(getClickGuiRoot(this).getModuleBrowser12())
               .updateStateForControlTone(
                  "Self destruct?",
                  "Every module is switched off and purged, the client detaches from the loader, and its configs, credentials, logs and jar are wiped. The game stays open.",
                  "Self destruct",
                  ControlTone.DANGER,
                  () -> this.updateState()
               );

            break;
         default:
            byte byteValue = 9;
            ThreadLocalRandom.current().nextInt(4);
            this.clickGuiRoot.updateStateForClickGuiTab(clickGuiTab2);
      }
   }

   private static float computeFloat2(float progress) {
      String selected2 = ClickGuiModule.getSelected2();

      switch (selected2.hashCode()) {
         case -2018804923:
            if (selected2.equals("Linear")) {
               return AnimatedFloat.linear(progress);
            }
            break;
         case 1799654555:

            if (selected2.equals("Ease Out Quart")) {
               return AnimatedFloat.outQuart(progress);
            }
      }

      return AnimatedFloat.outCubic(progress);
   }

   public boolean mouseClicked(Click click, boolean doubled) {
      if (this.booleanState) {
         return true;
      } else {
         this.clickGuiRoot.updateStateForUiContext(this.uiContext, click.x() / (double)this.computeFloat(), click.y() / (double)this.computeFloat(), click.button());

         return true;
      }
   }

   public boolean shouldPause() {
      return false;
   }

   private void updateStateForUiRenderContext(UiRenderContext uiRenderContext2, ThemeSnapshot themeSnapshot, float floatValue, float width2, float height2, float floatValue4) {
      if (ClickGuiModule.getValue7()) {
         ThreadLocalRandom.current().nextInt(5);
         uiRenderContext2.updateState7(ClickGuiModule.floatValue4(), ClickGuiModule.floatValue3(), ClickGuiModule.checkCondition());
      }

      byte byteValue;
      label111: {
         if (uiRenderContext2.supportsEffects() && ClickGuiModule.getValue6()) {
            if (CamouflageRenderer.checkCondition4()) {
               byteValue = 1;
               break label111;
            }
         }

         byteValue = 0;
      }

      byte byteValue2;
      label105: {
         byteValue2 = byteValue;
         if (byteValue2 != 0) {
            if (ClickGuiModule.checkCondition3()) {
               byteValue = 1;
               break label105;
            }
         } else {
            byteValue = 17;
            ThreadLocalRandom.current().nextInt(16);
         }

         byteValue = 0;
      }

      byte byteValue3 = byteValue;
      if (byteValue2 != 0) {
         this.floatState += floatValue;
         CamouflageRenderer.updateFloatState(ClickGuiModule.floatValue());
         Color[] colorArray = ClickGuiModule.computeColorArrayForThemeSnapshot(themeSnapshot);
         if (byteValue3 != 0) {
            CamouflageRenderer.checkCondition(getFloatState(this), 0, 0, 1.0F, colorArray);
         } else {
            CamouflageRenderer.checkCondition2(getFloatState(this), 0, 0, floatValue4, colorArray);
         }
      }

      uiRenderContext2.updateState2();
      if (byteValue2 != 0) {
         byteValue = 22;
         ThreadLocalRandom.current().nextInt(16);
         if (byteValue3 == 0) {
            return;
         }
      } else {
         byteValue = 13;
         ThreadLocalRandom.current().nextInt(7);
      }

      if (themeSnapshot.getBlurEnabled()) {
         if (uiRenderContext2.getBlurAvailable()) {
            uiRenderContext2.testBlurQuality2(ClickGuiModule.max(), BlurQuality.computeBlurQuality(themeSnapshot.getBlurQuality2()));
         }
      }

      String backdropMode = themeSnapshot.getBackdropMode();

      byteValue = -1;

      switch (backdropMode.hashCode()) {
         case 2433880:
            if (backdropMode.equals("None")) {
               return;
            }
            break;
         case 154295120:
            if (backdropMode.equals("Gradient")) {
               Color backdropDim2 = themeSnapshot.getBackdropDim2();
               Color backdropDim22 = themeSnapshot.getBackdropDim2();
               Color color = UiRenderContext.withAlpha(themeSnapshot.getGradientMid(), (float)themeSnapshot.getBackdropDim2().getAlpha());

               uiRenderContext2.fillVerticalGradient(0.0F, 0.0F, width2, height2, 0.0F, backdropDim2, UiRenderContext.blendColors(backdropDim22, color, (0.35F)));
               return;
            }
            break;
         case 1972453248:
            if (backdropMode.equals("Aurora")) {
               byteValue = 19;
               ThreadLocalRandom.current().nextInt(11);
               uiRenderContext2.drawAuroraBackdrop(themeSnapshot, width2, height2, 0.8F * floatValue4, themeSnapshot.getMotion());
               return;
            }
      }

      uiRenderContext2.fillRect(0.0F, (0.0F), width2, height2, themeSnapshot.getBackdropDim2());
   }

   private boolean checkCondition(float floatValue) {
      int intValue;
      if (getBooleanState(this)) {
         intValue = ClickGuiModule.computeInt2();
      } else {
         intValue = ClickGuiModule.computeInt();
      }

      ThreadLocalRandom.current().nextInt(8);
      float floatValue2 = (float)intValue / (1000.0F);

      intValue = 2142237956;

      float floatValue3 = (1.0F) / Math.max((1.0E-4F), floatValue2);

      setFloatState2(this, Math.max((0.0F), Math.min(1.0F, this.floatState2 + (getBooleanState(this) ? -floatValue : floatValue) * floatValue3)));
      if (this.booleanState) {
         if (getFloatState2(this) <= (0.001F)) {
            if (this.client != null) {
               this.client.setScreen(null);
            }

            return true;
         }
      }

      return false;
   }

   public boolean keyPressed(KeyInput input) {
      if (getBooleanState(this)) {
         return true;
      } else {
         if (getClickGuiRoot(this).checkCondition(input.key(), input.hasCtrlOrCmd(), input.hasShift())) {
            ThreadLocalRandom.current().nextInt(13);
            return true;
         } else if (input.isEscape()) {
            this.close();

            return true;
         } else {
            return super.keyPressed(input);
         }
      }
   }
}
