package cc.mochi;

public class AutoAnchorModule extends AnchorModule {
   private final DoubleSetting aimSpeedSetting;
   private final BooleanSetting aimSetting = new BooleanSetting("Aim", true);

   private final BooleanSetting silentAimSetting;

   public AutoAnchorModule() {
      super("Auto Anchor", "Automatically fills and explodes anchors.");
      this.aimSpeedSetting = new DoubleSetting("Aim Speed", 1.0, 50.0, 10.0, 1.0);
      this.silentAimSetting = new BooleanSetting("Silent Aim", false);

      Setting[] settingArray = new Setting[3];

      settingArray[0] = this.aimSetting;

      settingArray[1] = this.aimSpeedSetting;
      settingArray[2] = this.silentAimSetting;
      this.addSettings(settingArray);
      this.aimSpeedSetting.setVisibility(() -> this.isAimEnabled());
      this.silentAimSetting.setVisibility(() -> this.isAimEnabled());
   }

   @Override
   protected boolean isSilentAimEnabled() {
      return this.silentAimSetting.isOn();
   }

   @Override
   protected boolean isAimEnabled() {
      return this.aimSetting.isOn();
   }

   public static DoubleSetting getAimSpeedSetting(AutoAnchorModule autoAnchorModule) {
      return autoAnchorModule.aimSpeedSetting;
   }

   @Override
   protected double computeDouble() {
      return getAimSpeedSetting(this).getValue();
   }
}
