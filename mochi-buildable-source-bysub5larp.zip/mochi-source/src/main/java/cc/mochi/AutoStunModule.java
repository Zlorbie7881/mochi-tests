package cc.mochi;

import cc.mochi.event.impl.combat.TriggerBotReadyEvent;
import cc.mochi.event.impl.player.TickEvent;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class AutoStunModule extends Module implements AttackInputBlocker, PlayerStatusListener, AttackTargetBlocker {
   private StunState stunState;
   private final DoubleRangeSetting reactionTimeTicksSetting;

   public static boolean booleanState;

   private final DoubleSetting breakChanceSetting;

   private UUID uUID;

   private UUID uUID2;

   private long longState;

   private final BooleanSetting autoStunSetting;

   private int intState;
   private final ChoiceSetting modeSetting;

   private final BooleanSetting onlyWeaponSetting;

   private final DoubleSetting stunChanceSetting;

   private PlayerEntity playerEntity;

   private int intState2;

   private long longState2;

   private final BooleanSetting swapBackSetting;

   private long longState3;

   private boolean booleanState2;

   private boolean booleanState3;

   private long longState4;

   private long longState5;

   private int intState3;

   private void updateState() {
      if (getLongState(this) > 0L) {
         if (System.currentTimeMillis() < this.longState) {
            return;
         }

         ThreadLocalRandom.current().nextInt(6);

         ThreadLocalRandom.current().nextInt(3);
      }

      if (this.swapBackSetting.isOn()) {
         ThreadLocalRandom.current().nextInt(7);

         if (this.booleanState2) {
            this.updateState12();
         }
      }

      this.updateState9();

      this.updateState7(true);
   }

   public static void setStunState(AutoStunModule autoStunModule, StunState stunState2) {
      autoStunModule.stunState = stunState2;
   }

   public static void setBooleanState2(AutoStunModule autoStunModule, boolean booleanState22) {
      autoStunModule.booleanState2 = booleanState22;
   }

   public static ChoiceSetting getModeSetting(AutoStunModule autoStunModule) {
      return autoStunModule.modeSetting;
   }

   public static DoubleSetting getStunChanceSetting(AutoStunModule autoStunModule) {
      return autoStunModule.stunChanceSetting;
   }

   public static void setLongState4(AutoStunModule autoStunModule, long longState42) {
      autoStunModule.longState4 = longState42;
   }

   public static void setIntState3(AutoStunModule autoStunModule, int intState32) {
      autoStunModule.intState3 = intState32;
   }

   private void updateState2() {
      if (System.currentTimeMillis() >= this.longState2) {
         if (!this.checkCondition3()) {
            this.updateState10(true);
         } else {
            EntityBoundsAccess.getPlayer(mc).getInventory().setSelectedSlot(this.intState2);
            if (mc.attackCooldown <= 0) {
               if (!this.checkCondition()) {
                  if (!(getAttackCooldown(mc) > 0)) {
                     this.updateState10(true);
                  }
               } else {
                  this.updateState6();
               }
            }
         }
      }
   }

   public static long getLongState5(AutoStunModule autoStunModule) {
      return autoStunModule.longState5;
   }

   public static long getLongState(AutoStunModule autoStunModule) {
      return autoStunModule.longState;
   }

   private void updateState3() {
      if (!(System.currentTimeMillis() < this.longState5)) {
         if (!this.checkCondition3()) {
            this.updateState10(true);
         } else if (getAttackCooldown(mc) <= 0) {
            if (!this.checkCondition()) {
               if (getAttackCooldown(mc) <= 0) {
                  this.updateState10(true);
               }
            } else {
               ThreadLocalRandom.current().nextInt(6);
               long longState6;
               if (getSwapBackSetting(this).isOn() && getBooleanState2(this)) {
                  longState6 = System.currentTimeMillis() + this.computeLong(15.0, 60.0);
               } else {
                  longState6 = (4587436946509339153L);

                  longState6 = 0L;
               }

               setLongState(this, longState6);
               setStunState(this, StunState.WAITING_SWAP_BACK);
            }
         }
      }
   }

   private Boolean computeBoolean() {
      byte byteValue;
      if (!this.equals()) {
         byteValue = 20;
         ThreadLocalRandom.current().nextInt(16);
         byteValue = 1;
      } else {
         byteValue = 0;
      }

      return Boolean.valueOf((byteValue != 0));
   }

   private boolean checkCondition() {
      if (CombatActionCoordinator.checkCondition()) {
         return false;
      } else {
         if (mc.player != null) {
            ThreadLocalRandom.current().nextInt(15);
            if (!mc.player.isUsingItem()) {
               if (mc.crosshairTarget != null) {
                  if (mc.crosshairTarget.getType() == Type.ENTITY) {
                     return AttackActions.testMinecraftClient(mc, "combat.attack.autoshieldbreak");
                  }
               }
            }
         }

         return false;
      }
   }

   public static UUID getUUID(AutoStunModule autoStunModule) {
      return autoStunModule.uUID;
   }

   public static BooleanSetting getOnlyWeaponSetting(AutoStunModule autoStunModule) {
      return autoStunModule.onlyWeaponSetting;
   }

   public static boolean getBooleanState2(AutoStunModule autoStunModule) {
      return autoStunModule.booleanState2;
   }

   public static long getLongState4(AutoStunModule autoStunModule) {
      return autoStunModule.longState4;
   }

   private boolean testPlayerEntity(PlayerEntity playerEntity2) {
      if (playerEntity2 != null) {
         if (playerEntity2.getMainHandStack().isOf(EntityBoundsAccess.getSHIELD())) {
            return true;
         }

         ThreadLocalRandom.current().nextInt(3);
         if (playerEntity2.getOffHandStack().isOf(EntityBoundsAccess.getSHIELD())) {
            return true;
         }

         if (playerEntity2.isUsingItem()) {
            if (playerEntity2.isBlocking()) {
               return true;
            }
         }
      }

      return false;
   }

   private boolean testPlayerEntity2(PlayerEntity playerEntity2) {
      if (playerEntity2 != null) {
         if (playerEntity2.isBlocking()) {
            ThreadLocalRandom.current().nextInt(17);
            return true;
         }
      }

      return false;
   }

   private boolean checkCondition2() {
      return mc.player.getMainHandStack().getItem() instanceof AxeItem;
   }

   public static void setIntState(AutoStunModule autoStunModule, int intState4) {
      autoStunModule.intState = intState4;
   }

   public static void setUUID(AutoStunModule autoStunModule, UUID uUID3) {
      autoStunModule.uUID = uUID3;
   }

   public static int getIntState3(AutoStunModule autoStunModule) {
      return autoStunModule.intState3;
   }

   @EventHandler
   private void onTriggerBotReady(TriggerBotReadyEvent triggerBotReadyEvent) {
      if (this.isEnabled()) {
         if (!EntityBoundsAccess.getBooleanState()) {
            if (getStunState(this) == StunState.IDLE) {
               if (!this.checkCondition5()) {
                  return;
               }
            }
         }

         triggerBotReadyEvent.setCancelled(true);
      }
   }

   public static void setLongState(AutoStunModule autoStunModule, long longState6) {
      autoStunModule.longState = longState6;
   }

   @Override
   public void onEnable() {
      this.updateState11();

      this.updateState7(false);

      setLongState32(this, (0L));
   }

   private void updateState4() {
      booleanState = false;
      long longState43 = System.currentTimeMillis();
      PlayerEntity playerEntity2 = this.computePlayerEntity();
      if (!this.testPlayerEntity5(playerEntity2)) {
         ThreadLocalRandom.current().nextInt(3);

         setLongState4(this, -1L);
      } else {
         label93:
         if (!mc.player.isUsingItem()) {
            label99: {
               if (this.onlyWeaponSetting.isOn()) {
                  if (!this.checkCondition6()) {
                     break label99;
                  }
               }

               if (!this.contains()) {
                  if (!this.checkCondition2()) {
                     break label99;
                  }
               }

               int intState22 = this.computeInt();
               if (intState22 >= 0) {
                  if (!this.testPlayerEntity6(playerEntity2)) {
                     this.updateState9();
                  } else {
                     EntityBoundsAccess.setBooleanState(true);
                     if (longState43 < this.longState3) {
                        setLongState4(this, -1L);
                     } else {
                        long longState42 = this.longState4;

                        long longValue2;
                        if (longState42 < (0L)) {
                           setLongState4(this, longState43);
                           setIntState3(this, (int)this.computeLong(this.reactionTimeTicksSetting.getLowerValue2(), this.reactionTimeTicksSetting.getUpperValue3()));
                        }

                        longState42 = longState43 - getLongState4(this);

                        longValue2 = -8381349490041325767L;

                        if (longState42 / 50L >= (long)getIntState3(this)) {
                           setIntState(this, mc.player.getInventory().getSelectedSlot());
                           setUUID(this, playerEntity2.getUuid());
                           this.intState2 = intState22;
                           this.booleanState2 = ((getIntState(this) != intState22 ? 1 : 0) != 0);
                           if (this.booleanState2) {
                              longValue2 = this.computeLong((15.0), 60.0);
                           } else {
                              longValue2 = (758178294369346531L);

                              longValue2 = 0L;
                           }

                           this.longState2 = longState43 + longValue2;
                           setStunState(this, StunState.WAITING_ATTACK);
                           this.updateState5();
                        }
                     }
                  }
               }
            }
         } else {
            ThreadLocalRandom.current().nextInt(5);
            break label93;
         }
      }
   }

   @Override
   public boolean shouldBlockAttackInput() {
      if (this.isEnabled()) {
         if (this.equals()) {
            if (this.testPlayerEntity7(this.computePlayerEntity())) {
               ThreadLocalRandom.current().nextInt(5);
               return true;
            }
         }
      }

      return false;
   }

   public static StunState getWAITING_ATTACK() {
      return StunState.WAITING_ATTACK;
   }

   public static StunState getIDLE() {
      return StunState.IDLE;
   }

   public AutoStunModule() {
      super("Auto Stun", "Sword-to-axe shield stunner", ModuleCategory.COMBAT);

      this.reactionTimeTicksSetting = new DoubleRangeSetting("Reaction Time (Ticks)", (0.0), (20.0), 1.0, 2.0, 1.0);

      this.breakChanceSetting = new DoubleSetting("Break Chance (%)", (0.0), 100.0, (100.0), (1.0));

      this.stunChanceSetting = new DoubleSetting("Stun Chance (%)", 0.0, 100.0, (100.0), 1.0);
      String[] stringArray = new String[2];

      stringArray[0] = "Auto";

      stringArray[1] = "On Hit";
      this.modeSetting = new ChoiceSetting("Mode", "On Hit", stringArray);
      this.onlyWeaponSetting = new BooleanSetting("Only Weapon", true);
      this.swapBackSetting = new BooleanSetting("Swap Back", true);
      this.autoStunSetting = new BooleanSetting("Auto Stun", true);
      this.stunState = StunState.IDLE;

      this.longState4 = (-1L);

      this.intState = -1;

      this.intState2 = -1;
      this.addSetting(this.modeSetting);
      this.addSetting(this.reactionTimeTicksSetting);
      this.reactionTimeTicksSetting.setVisibility(() -> this.computeBoolean());
      this.addSetting(this.breakChanceSetting);
      this.addSetting(this.stunChanceSetting);
      this.addSetting(this.onlyWeaponSetting);
      this.addSetting(this.swapBackSetting);
      this.addSetting(this.autoStunSetting);
   }

   private void updateState5() {
      if (System.currentTimeMillis() >= getLongState2(this)) {
         PlayerEntity playerEntity2 = this.computePlayerEntity();
         if (!EntityBoundsAccess.getPlayer(mc).isUsingItem()) {
            if (playerEntity2 != null) {
               if (getUUID(this) != null) {
                  if (getUUID(this).equals(playerEntity2.getUuid())) {
                     if (playerEntity2.isAlive() && this.testPlayerEntity3(playerEntity2)) {
                        if (this.testPlayerEntity(playerEntity2) && this.testPlayerEntity2(playerEntity2) && this.testPlayerEntity8(playerEntity2) && this.testPlayerEntity4(playerEntity2)) {
                           EntityBoundsAccess.getPlayer(mc).getInventory().setSelectedSlot(getIntState2(this));
                           if (!this.checkCondition()) {
                              this.updateState10(true);
                              return;
                           }

                           this.updateState6();
                           return;
                        }
                     }
                  } else {
                     ThreadLocalRandom.current().nextInt(3);
                  }
               }
            }
         }

         this.updateState10(true);
      }
   }

   private long computeLong(double doubleValue, double doubleValue2) {
      long longValue;
      if (doubleValue2 <= doubleValue) {
         longValue = Math.round(doubleValue);
      } else {
         ThreadLocalRandom.current().nextInt(5);
         longValue = Math.round(doubleValue + (doubleValue2 - doubleValue) * ThreadLocalRandom.current().nextDouble());
      }

      return longValue;
   }

   private boolean testPlayerEntity3(PlayerEntity playerEntity2) {
      Vec3d eyePos = mc.player.getEyePos();
      Box boundingBox = playerEntity2.getBoundingBox();
      double doubleValue = MathHelper.clamp(EntityBoundsAccess.getX(eyePos), EntityBoundsAccess.getMinX(boundingBox), boundingBox.maxX);
      double doubleValue2 = MathHelper.clamp(EntityBoundsAccess.getY(eyePos), EntityBoundsAccess.getMinY(boundingBox), boundingBox.maxY);
      double doubleValue3 = MathHelper.clamp(eyePos.z, EntityBoundsAccess.getMinZ(boundingBox), boundingBox.maxZ);
      double doubleValue4 = EntityBoundsAccess.getX(eyePos) - doubleValue;
      double doubleValue5 = EntityBoundsAccess.getY(eyePos) - doubleValue2;
      double doubleValue6 = eyePos.z - doubleValue3;
      return (doubleValue4 * doubleValue4 + doubleValue5 * doubleValue5 + doubleValue6 * doubleValue6 <= 8.41);
   }

   public static StunState getStunState(AutoStunModule autoStunModule) {
      return autoStunModule.stunState;
   }

   private boolean checkCondition3() {
      if (this.playerEntity != null) {
         if (getPlayerEntity(this).isAlive()) {
            HitResult crosshairTarget = EntityBoundsAccess.getCrosshairTarget(mc);
            if (crosshairTarget instanceof EntityHitResult) {
               ThreadLocalRandom.current().nextInt(14);
               EntityHitResult crosshairTarget2 = (EntityHitResult)crosshairTarget;
               if (crosshairTarget2.getEntity() == getPlayerEntity(this)) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   public static int getAttackCooldown(MinecraftClient minecraftClient) {
      return minecraftClient.attackCooldown;
   }

   @Override
   public void onDisable() {
      this.updateState12();
      this.updateState11();
      this.updateState7(false);
      this.longState3 = 0L;
   }

   private boolean checkCondition4() {
      if (EntityBoundsAccess.getPlayer(mc) != null) {
         if (EntityBoundsAccess.getWorld(mc) != null) {
            if (mc.currentScreen == null) {
               ThreadLocalRandom.current().nextInt(5);
               return true;
            }
         }
      }

      return false;
   }

   public boolean returnFalse() {
      return false;
   }

   private boolean testPlayerEntity4(PlayerEntity playerEntity2) {
      if (mc.crosshairTarget instanceof EntityHitResult var2) {
         if (var2.getEntity() == playerEntity2) {
            double doubleValue = MathHelper.clamp((0.15), 0.0, 1.0);
            if (doubleValue <= 0.0) {
               ThreadLocalRandom.current().nextInt(13);

               return true;
            }

            ThreadLocalRandom.current().nextInt(12);
            Vec3d pos = var2.getPos();
            Box boundingBox = playerEntity2.getBoundingBox();
            double doubleValue2 = Math.min(pos.x - boundingBox.minX, boundingBox.maxX - EntityBoundsAccess.getX(pos)) / Math.max(0.001, boundingBox.getLengthX() / 2.0);
            return (doubleValue2 >= doubleValue);
         }
      }

      return false;
   }

   private void updateState6() {
      EntityBoundsAccess.setBooleanState(false);
      if (this.autoStunSetting.isOn()) {
         double doubleValue = ThreadLocalRandom.current().nextDouble();
         long longValue = (7092930250988111075L);

         if (doubleValue * (100.0) < getStunChanceSetting(this).getValue()) {
            longValue = System.currentTimeMillis();

            setLongState5(this, longValue + this.computeLong((15.0), 30.0));
            this.stunState = StunState.WAITING_STUN;
            return;
         }
      }

      long longState6;
      if (this.swapBackSetting.isOn() && getBooleanState2(this)) {
         longState6 = System.currentTimeMillis();

         longState6 += this.computeLong(15.0, (60.0));
      } else {
         longState6 = 0L;
      }

      setLongState(this, longState6);
      this.stunState = StunState.WAITING_SWAP_BACK;
   }

   public static int getIntState2(AutoStunModule autoStunModule) {
      return autoStunModule.intState2;
   }

   private void updateState7(boolean booleanValue) {
      setStunState(this, StunState.IDLE);

      booleanState = false;

      this.longState4 = (-1L);
      setIntState3(this, 0);
      setLongState(this, 0L);
      setIntState22(this, -1);
      this.longState2 = 0L;

      setLongState5(this, (0L));

      this.booleanState2 = false;
      setPlayerEntity(this, null);
      if (booleanValue) {
         setUUID(this, null);
      }
   }

   public static int getIntState(AutoStunModule autoStunModule) {
      return autoStunModule.intState;
   }

   public static PlayerEntity getPlayerEntity(AutoStunModule autoStunModule) {
      return autoStunModule.playerEntity;
   }

   private boolean testPlayerEntity5(PlayerEntity playerEntity2) {
      if (playerEntity2 != null && playerEntity2.isAlive()) {
         if (!FriendManager.testPlayerEntity(playerEntity2)) {
            if (this.testPlayerEntity(playerEntity2)) {
               if (this.testPlayerEntity2(playerEntity2)) {
                  if (this.testPlayerEntity8(playerEntity2)) {
                     if (this.testPlayerEntity3(playerEntity2)) {
                        if (this.testPlayerEntity4(playerEntity2)) {
                           return true;
                        }
                     } else {
                        ThreadLocalRandom.current().nextInt(17);
                     }
                  }
               }
            }
         }
      }

      return false;
   }

   private void updateState8() {
      if (System.currentTimeMillis() >= getLongState5(this)) {
         PlayerEntity playerEntity2 = this.computePlayerEntity();
         if (playerEntity2 != null && this.uUID != null && getUUID(this).equals(playerEntity2.getUuid())) {
            if (playerEntity2.isAlive()) {
               if (this.testPlayerEntity3(playerEntity2)) {
                  if (this.testPlayerEntity4(playerEntity2)) {
                     if (mc.attackCooldown > 0) {
                        return;
                     }

                     if (!this.checkCondition()) {
                        if (mc.attackCooldown > 0) {
                           return;
                        }

                        this.updateState10(true);
                        return;
                     }

                     long longState6;
                     if (getSwapBackSetting(this).isOn() && this.booleanState2) {
                        ThreadLocalRandom.current().nextInt(17);
                        longState6 = System.currentTimeMillis();

                        longState6 += this.computeLong((15.0), (60.0));
                     } else {
                        longState6 = 0L;
                     }

                     this.longState = longState6;
                     setStunState(this, StunState.WAITING_SWAP_BACK);
                     return;
                  }
               }
            }
         }

         this.updateState10(true);
      }
   }

   public static void setLongState5(AutoStunModule autoStunModule, long longState52) {
      autoStunModule.longState5 = longState52;
   }

   private void updateState9() {
      long longState32;
      if (this.equals()) {
         longState32 = (-8598449476889672592L);

         longState32 = 0L;

         ThreadLocalRandom.current().nextInt(12);
      } else {
         longState32 = System.currentTimeMillis() + this.computeLong(1600.0, 2400.0);
      }

      this.longState3 = longState32;
   }

   private boolean testPlayerEntity6(PlayerEntity playerEntity2) {
      if (!playerEntity2.getUuid().equals(this.uUID2)) {
         this.uUID2 = playerEntity2.getUuid();
         byte byteValue;
         if (ThreadLocalRandom.current().nextDouble() * 100.0 < this.breakChanceSetting.getValue()) {
            byteValue = 1;
         } else {
            byteValue = 6;
            ThreadLocalRandom.current().nextInt(3);
            byteValue = 0;
         }

         this.booleanState3 = (byteValue != 0);
      }

      return getBooleanState3(this);
   }

   public static BooleanSetting getSwapBackSetting(AutoStunModule autoStunModule) {
      return autoStunModule.swapBackSetting;
   }

   private void updateState10(boolean booleanValue) {
      if (booleanValue) {
         this.updateState9();
      } else {
         ThreadLocalRandom.current().nextInt(4);
      }

      if (this.swapBackSetting.isOn()) {
         if (getBooleanState2(this)) {
            this.updateState12();
         }
      } else {
         ThreadLocalRandom.current().nextInt(3);
      }

      this.updateState7(true);
   }

   @EventHandler
   private void onTickEvent(TickEvent tickEvent) {
      if (CombatActionCoordinator.checkCondition()) {
         ThreadLocalRandom.current().nextInt(3);
      } else if (!this.checkCondition4()) {
         this.updateState12();
         this.updateState11();

         this.updateState7(false);
      } else {
         if (!this.equals()) {
            this.updateState13();
         }

         if (this.equals()) {
            if (this.stunState == StunState.IDLE) {
               return;
            }
         } else {
            ThreadLocalRandom.current().nextInt(14);
         }

         switch (getStunState(this)) {
            case IDLE:
               byte byteValue = 15;
               ThreadLocalRandom.current().nextInt(8);
               this.updateState4();
               break;
            case WAITING_ATTACK:

               if (this.equals()) {
                  this.updateState2();
               } else {
                  ThreadLocalRandom.current().nextInt(12);
                  this.updateState5();
               }
               break;
            case WAITING_STUN:
               if (this.equals()) {
                  ThreadLocalRandom.current().nextInt(10);
                  this.updateState3();
               } else {
                  this.updateState8();
               }
               break;
            case WAITING_SWAP_BACK:
               this.updateState();
         }
      }
   }

   public static long getLongState2(AutoStunModule autoStunModule) {
      return autoStunModule.longState2;
   }

   @Override
   public boolean shouldBlockAttackTarget(Entity entity) {
      return this.testPlayerEntity7(entity instanceof PlayerEntity var2 ? var2 : null);
   }

   private PlayerEntity computePlayerEntity() {
      HitResult crosshairTarget = mc.crosshairTarget;
      if (crosshairTarget instanceof EntityHitResult) {
         EntityHitResult crosshairTarget2 = (EntityHitResult)crosshairTarget;
         Entity entity = crosshairTarget2.getEntity();
         if (entity instanceof PlayerEntity) {
            return (PlayerEntity)entity;
         }
      }

      return null;
   }

   private int computeInt() {
      int intValue = 0;

      while (true) {
         if (intValue >= 9) {
            return -1;
         }

         if (EntityBoundsAccess.getPlayer(mc).getInventory().getStack(intValue).getItem() instanceof AxeItem) {
            return intValue;
         }

         intValue++;
      }
   }

   public static StunState getWAITING_SWAP_BACK() {
      return StunState.WAITING_SWAP_BACK;
   }

   private boolean testPlayerEntity7(PlayerEntity playerEntity2) {
      if (CombatActionCoordinator.checkCondition()) {
         return false;
      } else {
         if (this.isEnabled() && this.equals()) {
            if (this.stunState == StunState.IDLE) {
               if (this.testPlayerEntity9(playerEntity2)) {
                  if (!EntityBoundsAccess.getPlayer(mc).isUsingItem()) {
                     if (!getOnlyWeaponSetting(this).isOn() || this.checkCondition6()) {
                        if (this.contains() || this.checkCondition2()) {
                           int intState22 = this.computeInt();
                           if (intState22 >= 0 && this.testPlayerEntity6(playerEntity2)) {
                              setIntState(this, mc.player.getInventory().getSelectedSlot());
                              setUUID(this, playerEntity2.getUuid());
                              this.playerEntity = playerEntity2;
                              this.intState2 = intState22;
                              setBooleanState2(this, ((getIntState(this) != intState22 ? 1 : 0) != 0));
                              this.longState2 = System.currentTimeMillis();
                              booleanState = true;
                              setStunState(this, StunState.WAITING_ATTACK);
                              if (getLongState2(this) <= System.currentTimeMillis()) {
                                 this.updateState2();
                              }

                              return true;
                           }

                           return false;
                        }
                     }
                  }
               }
            } else {
               ThreadLocalRandom.current().nextInt(17);
            }
         }

         return false;
      }
   }

   private boolean checkCondition5() {
      if (this.equals()) {
         return false;
      } else if (this.stunState != StunState.IDLE) {
         return true;
      } else {
         PlayerEntity playerEntity2 = this.computePlayerEntity();
         if (this.testPlayerEntity5(playerEntity2)) {
            if (this.computeInt() >= 0) {
               if (!mc.player.isUsingItem()) {
                  if (!this.onlyWeaponSetting.isOn()) {
                     return true;
                  }

                  if (this.checkCondition6()) {
                     ThreadLocalRandom.current().nextInt(3);

                     return true;
                  }
               }
            }
         }

         return false;
      }
   }

   private void updateState11() {
      this.uUID2 = null;

      this.booleanState3 = false;
   }

   private void updateState12() {
      if (mc.player != null) {
         ThreadLocalRandom.current().nextInt(7);
         if (this.intState >= 0) {
            if (getIntState(this) < 9) {
               EntityBoundsAccess.getPlayer(mc).getInventory().setSelectedSlot(getIntState(this));

               ThreadLocalRandom.current().nextInt(6);
            }
         }
      }

      this.intState = -1;
   }

   public static void setIntState22(AutoStunModule autoStunModule, int intState22) {
      autoStunModule.intState2 = intState22;
   }

   private boolean contains() {
      return EntityBoundsAccess.getPlayer(mc).getMainHandStack().getItem().toString().toLowerCase().contains("sword");
   }

   @Override
   public void onPlayerStatus(PlayerEntity playerEntity2) {
      if (this.isEnabled()) {
         if (playerEntity2 != null) {
            if (this.uUID != null) {
               if (this.uUID.equals(playerEntity2.getUuid())) {
                  this.updateState9();
               }
            }
         }
      }
   }

   private boolean testPlayerEntity8(PlayerEntity playerEntity2) {
      double doubleValue = EntityBoundsAccess.getPlayer(mc).getX() - playerEntity2.getX();
      double doubleValue2 = mc.player.getZ() - playerEntity2.getZ();
      double doubleValue3 = Math.sqrt(doubleValue * doubleValue + doubleValue2 * doubleValue2);
      if (doubleValue3 < 1.0E-4) {
         return true;
      } else {
         byte byteValue = 9;
         ThreadLocalRandom.current().nextInt(4);
         float floatValue = (float)Math.toRadians((double)playerEntity2.getYaw());
         double doubleValue4 = -Math.sin((double)floatValue) * doubleValue / doubleValue3 + Math.cos((double)floatValue) * doubleValue2 / doubleValue3;

         if (doubleValue4 > (0.0)) {
            byteValue = 1;
         } else {
            byteValue = 0;
         }

         return (byteValue != 0);
      }
   }

   public static void setPlayerEntity(AutoStunModule autoStunModule, PlayerEntity playerEntity2) {
      autoStunModule.playerEntity = playerEntity2;
   }

   private boolean checkCondition6() {
      ItemStack mainHandStack = mc.player.getMainHandStack();
      if (!(mainHandStack.getItem() instanceof AxeItem)) {
         if (!mainHandStack.getItem().toString().toLowerCase().contains("sword")) {
            return false;
         }
      }

      return true;
   }

   private boolean equals() {
      return getModeSetting(this).equals("On Hit");
   }

   public static boolean getBooleanState3(AutoStunModule autoStunModule) {
      return autoStunModule.booleanState3;
   }

   private boolean testPlayerEntity9(PlayerEntity playerEntity2) {
      if (playerEntity2 != null) {
         if (playerEntity2.isAlive()) {
            if (!FriendManager.testPlayerEntity(playerEntity2)) {
               if (this.testPlayerEntity(playerEntity2) && this.testPlayerEntity2(playerEntity2)) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   private void updateState13() {
      if (this.uUID2 != null) {
         if (EntityBoundsAccess.getWorld(mc) != null) {
            for (PlayerEntity playerEntity2 : mc.world.getPlayers()) {
               if (this.uUID2.equals(playerEntity2.getUuid())) {
                  if (!this.testPlayerEntity2(playerEntity2)) {
                     this.updateState11();
                  }

                  return;
               }
            }

            this.updateState11();
            return;
         }
      }
   }

   public static void setLongState32(AutoStunModule autoStunModule, long longState32) {
      autoStunModule.longState3 = longState32;
   }
}
