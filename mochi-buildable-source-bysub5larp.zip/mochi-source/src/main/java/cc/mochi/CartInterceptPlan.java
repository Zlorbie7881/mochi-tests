package cc.mochi;

import java.util.List;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public record CartInterceptPlan(BlockPos rail, List<Vec3d> path, int intercept, int placeOffset, Box serverBox, Box placeBox, Vec3d eye, Box exposedBox) {
   public Box getServerBox2() {
      return getServerBox(this);
   }

   public BlockPos getRail2() {
      return getRail(this);
   }

   public Box getExposedBox2() {
      return getExposedBox(this);
   }

   public static int getIntercept(CartInterceptPlan cartInterceptPlan) {
      return cartInterceptPlan.intercept;
   }

   public static BlockPos getRail(CartInterceptPlan cartInterceptPlan) {
      return cartInterceptPlan.rail;
   }

   public Vec3d getEye() {
      return this.eye;
   }

   public Box getPlaceBox2() {
      return getPlaceBox(this);
   }

   public int getPlaceOffset2() {
      return getPlaceOffset(this);
   }

   public static int getPlaceOffset(CartInterceptPlan cartInterceptPlan) {
      return cartInterceptPlan.placeOffset;
   }

   public Vec3d computeVec3d() {
      return ProjectileAimPlanner.computeVec3dForBlockPos(this.rail);
   }

   public int getIntercept2() {
      return getIntercept(this);
   }

   public static Box getServerBox(CartInterceptPlan cartInterceptPlan) {
      return cartInterceptPlan.serverBox;
   }

   public static Box getExposedBox(CartInterceptPlan cartInterceptPlan) {
      return cartInterceptPlan.exposedBox;
   }

   public static Box getPlaceBox(CartInterceptPlan cartInterceptPlan) {
      return cartInterceptPlan.placeBox;
   }

   public List getPath() {
      return this.path;
   }
}
