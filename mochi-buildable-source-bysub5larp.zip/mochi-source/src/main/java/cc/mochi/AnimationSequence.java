package cc.mochi;

public class AnimationSequence {
   private final AnimationSpec[] animationSpecArray;
   private long timestampMillis;
   private int counter;
   private boolean booleanState;
   private final String string;

   public float computeFloat() {
      if (this.booleanState) {
         return this.animationSpecArray[this.animationSpecArray.length - 1].targetValue();
      } else {
         long longValue = System.currentTimeMillis() - this.timestampMillis;
         long longValue2 = 0L;

         for (int intValue = 0; intValue < this.counter; intValue++) {
            longValue2 += this.animationSpecArray[intValue].delay() + this.animationSpecArray[intValue].duration();
         }

         if (longValue < longValue2 + this.animationSpecArray[this.counter].delay()) {
            return this.counter == 0 ? this.animationSpecArray[0].startValue() : this.animationSpecArray[this.counter - 1].targetValue();
         } else {
            String string2 = this.string + "_step_" + this.counter;
            float floatValue = AnimationRegistry.computeFloatForEasingFunction(string2, this.animationSpecArray[this.counter].targetValue(), this.animationSpecArray[this.counter].duration(), this.animationSpecArray[this.counter].easing());
            if (AnimationRegistry.checkCondition(string2)) {
               this.counter++;
               if (this.counter >= this.animationSpecArray.length) {
                  this.booleanState = true;
               }
            }

            return floatValue;
         }
      }
   }

   public boolean getBooleanState() {
      return this.booleanState;
   }

   public void updateState() {
      this.counter = 0;
      this.timestampMillis = System.currentTimeMillis();
      this.booleanState = false;

      for (int intValue = 0; intValue < this.animationSpecArray.length; intValue++) {
         AnimationRegistry.remove(this.string + "_step_" + intValue);
      }
   }

   public AnimationSequence(String string2, AnimationSpec... animationSpecArray2) {
      this.string = string2;
      this.animationSpecArray = animationSpecArray2;
      this.counter = 0;
      this.timestampMillis = System.currentTimeMillis();
      this.booleanState = false;
   }
}
