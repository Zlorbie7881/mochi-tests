package cc.mochi;

import java.util.Arrays;

public final class MeshBuffer {
   private int counter;
   private final float[] floatArray2;
   private int counter2;

   private int[] intArray2;

   private int counter3;
   private int intState;
   private int counter4;
   private int intState2;

   private float[] floatArray3 = new float[20480];
   private int[] intArray3;
   private boolean booleanState;

   public void updateState(int intState22) {
      this.counter4 = 0;
      if (intState22 != this.intState2 || this.counter2 <= this.intState) {
         this.intState2 = intState22;
         this.intArray2 = computeIntArray(this.intArray2, (this.counter2 + 1) * 3);
         this.intArray2[this.counter2 * 3] = intState22;
         this.intArray2[this.counter2 * 3 + 1] = this.counter3;
         this.intArray2[this.counter2 * 3 + 2] = 0;
         this.counter2++;
      }
   }

   public void updateState2() {
      this.counter3 = this.counter2 = this.counter = 0;
      this.booleanState = false;
      this.intState2 = -1;
      this.counter4 = 0;
   }

   public int computeInt(int intValue) {
      return this.intArray3[intValue * 2 + 1];
   }

   private static int[] computeIntArray(int[] intArray, int intValue) {
      return intValue <= intArray.length ? intArray : Arrays.copyOf(intArray, Math.max(intValue, intArray.length * 2));
   }

   private void updateState3(int intValue) {
      System.arraycopy(this.floatArray2, intValue * 5, this.floatArray3, this.counter3 * 5, 5);
      this.counter3++;
   }

   public int computeInt2(int intValue) {
      return this.intArray2[intValue * 3 + 2];
   }

   public MeshBuffer() {
      this.intArray2 = new int[192];
      this.intArray3 = new int[32];
      this.intState2 = -1;
      this.floatArray2 = new float[20];
   }

   public boolean getBooleanState() {
      return this.booleanState;
   }

   public int getCounter3() {
      return this.counter3;
   }

   public int computeInt3(int intValue) {
      return this.intArray3[intValue * 2];
   }

   public void updateState4(float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5) {
      if (this.booleanState && this.counter2 != this.intState) {
         int intValue = this.counter4 * 5;
         this.floatArray2[intValue] = floatValue;
         this.floatArray2[intValue + 1] = floatValue2;
         this.floatArray2[intValue + 2] = floatValue3;
         this.floatArray2[intValue + 3] = floatValue4;
         this.floatArray2[intValue + 4] = floatValue5;
         if (++this.counter4 >= 4) {
            this.counter4 = 0;
            this.floatArray3 = computeFloatArray(this.floatArray3, (this.counter3 + 6) * 5);
            this.updateState3(0);
            this.updateState3(1);
            this.updateState3(2);
            this.updateState3(2);
            this.updateState3(3);
            this.updateState3(0);
            this.intArray2[(this.counter2 - 1) * 3 + 2] = this.intArray2[(this.counter2 - 1) * 3 + 2] + 6;
         }
      }
   }

   private static float[] computeFloatArray(float[] floatArray, int intValue) {
      return intValue <= floatArray.length ? floatArray : Arrays.copyOf(floatArray, Math.max(intValue, floatArray.length * 2));
   }

   public int getCounter() {
      return this.counter;
   }

   public void updateState5() {
      if (this.booleanState) {
         this.updateState6();
      }

      this.booleanState = true;
      this.intState = this.counter2;
      this.intState2 = -1;
      this.counter4 = 0;
   }

   public void resetCounter4() {
      this.counter4 = 0;
   }

   public float[] getFloatArray3() {
      return this.floatArray3;
   }

   public int computeInt4(int intValue) {
      return this.intArray2[intValue * 3 + 1];
   }

   public int computeInt5(int intValue) {
      return this.intArray2[intValue * 3];
   }

   public void updateState6() {
      if (this.booleanState) {
         this.booleanState = false;
         this.counter4 = 0;
         int intValue = this.counter2 - this.intState;
         if (intValue > 0) {
            this.intArray3 = computeIntArray(this.intArray3, (this.counter + 1) * 2);
            this.intArray3[this.counter * 2] = this.intState;
            this.intArray3[this.counter * 2 + 1] = intValue;
            this.counter++;
         }
      }
   }
}
