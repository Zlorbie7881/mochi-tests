package cc.mochi;

public class ControlToneAccess {
   public static ControlTone getDANGER() {
      return ControlTone.DANGER;
   }

   public static ControlTone getSUCCESS() {
      return ControlTone.SUCCESS;
   }

   public static ControlTone getNEUTRAL() {
      return ControlTone.NEUTRAL;
   }
}
