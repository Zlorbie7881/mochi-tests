package cc.mochi;

public class DoubleSetting extends Setting {
   private final double minimum;
   private final double defaultValue;
   private final double maximum;
   private double value;
   private final double step;

   public static double getMinimum2(DoubleSetting doubleSetting) {
      return doubleSetting.minimum;
   }

   public static double getStep2(DoubleSetting doubleSetting) {
      return doubleSetting.step;
   }

   public static double getMaximum2(DoubleSetting doubleSetting) {
      return doubleSetting.maximum;
   }

   public double getMaximum() {
      return getMaximum2(this);
   }

   public static double getValue2(DoubleSetting doubleSetting) {
      return doubleSetting.value;
   }

   @Override
   public void reset() {
      this.value = getDefaultValue2(this);
   }

   public float floatValue() {
      return (float)this.value;
   }

   public double getValue() {
      return getValue2(this);
   }

   public double getStep() {
      return getStep2(this);
   }

   public static void setValue2(DoubleSetting doubleSetting, double value2) {
      doubleSetting.value = value2;
   }

   public static double getDefaultValue2(DoubleSetting doubleSetting) {
      return doubleSetting.defaultValue;
   }

   @Override
   public boolean isDefault() {
      return (getValue2(this) == this.defaultValue);
   }

   public double getDefaultValue() {
      return getDefaultValue2(this);
   }

   public DoubleSetting(String name, double minimum2, double maximum2, double doubleValue, double step2) {
      super(name);
      this.minimum = minimum2;
      this.maximum = maximum2;
      this.step = step2;
      this.setValue(doubleValue);
      this.defaultValue = this.value;
   }

   public double getMinimum() {
      return getMinimum2(this);
   }

   public int intValue() {
      return (int)getValue2(this);
   }

   public void setValue(double doubleValue) {
      double doubleValue2 = (1.0) / getStep2(this);
      setValue2(this, (double)Math.round(Math.max(getMinimum2(this), Math.min(getMaximum2(this), doubleValue)) * doubleValue2) / doubleValue2);
   }
}
