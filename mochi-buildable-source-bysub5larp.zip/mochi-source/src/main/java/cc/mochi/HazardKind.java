package cc.mochi;

public enum HazardKind {
   VOID,

   FALL,

   COBWEB,

   LAVA,

   FIRE,

   SOUL_FIRE,

   CAMPFIRE,

   SOUL_CAMPFIRE,
   MAGMA,
   CACTUS,
   BERRY_BUSH,
   WITHER_ROSE,
   POWDER_SNOW,
   DRIPSTONE;

   private static HazardKind[] computeHazardKindArray() {
      HazardKind[] hazardKindArray = new HazardKind[]{VOID, null, null, null, null, null, null, null, null, null, null, null, null, null};

      hazardKindArray[1] = FALL;
      hazardKindArray[2] = COBWEB;

      hazardKindArray[3] = LAVA;
      hazardKindArray[4] = FIRE;
      hazardKindArray[5] = SOUL_FIRE;
      hazardKindArray[6] = CAMPFIRE;

      hazardKindArray[7] = SOUL_CAMPFIRE;

      hazardKindArray[8] = MAGMA;

      hazardKindArray[9] = CACTUS;
      hazardKindArray[10] = BERRY_BUSH;

      hazardKindArray[11] = WITHER_ROSE;
      hazardKindArray[12] = POWDER_SNOW;
      hazardKindArray[13] = DRIPSTONE;
      return hazardKindArray;
   }
}
