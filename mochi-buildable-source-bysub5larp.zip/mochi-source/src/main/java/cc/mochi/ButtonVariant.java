package cc.mochi;

public enum ButtonVariant {
   PRIMARY,
   SECONDARY,
   GHOST,
   DANGER;

   private static final ButtonVariant[] ENUM_VALUES = {PRIMARY, SECONDARY, GHOST, DANGER};

   public static ButtonVariant[] getENUM_VALUES() {
      return ENUM_VALUES;
   }

   private static ButtonVariant[] createValues() {
      return new ButtonVariant[]{PRIMARY, SECONDARY, GHOST, DANGER};
   }
}
