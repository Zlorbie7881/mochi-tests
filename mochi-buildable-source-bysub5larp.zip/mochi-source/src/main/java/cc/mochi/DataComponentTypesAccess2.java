package cc.mochi;

import java.util.Locale;
import net.minecraft.component.ComponentType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;

public class DataComponentTypesAccess2 {
   public static Locale getROOT() {
      return Locale.ROOT;
   }

   public static ComponentType<ItemEnchantmentsComponent> getENCHANTMENTS() {
      return DataComponentTypes.ENCHANTMENTS;
   }

   public static RegistryKey<Registry<Enchantment>> getENCHANTMENT() {
      return RegistryKeys.ENCHANTMENT;
   }

}
