package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ServerInfo;

public class MinecraftClientAccess16 {
   public static Screen getCurrentScreen(MinecraftClient minecraftClient) {
      return minecraftClient.currentScreen;
   }

   public static String getAddress(ServerInfo serverInfo) {
      return serverInfo.address;
   }
}
