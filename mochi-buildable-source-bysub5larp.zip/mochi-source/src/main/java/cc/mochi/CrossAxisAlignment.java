package cc.mochi;

public enum CrossAxisAlignment {
   START,
   END,
   CENTER,
   STRETCH;

   private static CrossAxisAlignment[] createValues() {
      return new CrossAxisAlignment[]{START, END, CENTER, STRETCH};
   }
}
