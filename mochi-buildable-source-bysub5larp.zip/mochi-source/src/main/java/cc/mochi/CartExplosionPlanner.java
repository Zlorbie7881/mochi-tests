package cc.mochi;

import net.minecraft.util.math.Direction.Axis;

import cc.mochi.mixin.FireBlockAccessor;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Predicate;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CampfireBlock;
import net.minecraft.block.CandleBlock;
import net.minecraft.block.CandleCakeBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.SlabBlock;
import net.minecraft.block.enums.SlabType;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Direction.AxisDirection;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public final class CartExplosionPlanner {
   private static final double[] doubleArray14;

   private static final double[] doubleArray15;

   private static final double[] doubleArray16 = new double[]{0.0, ((-0.25)), 0.25};
   private static final double[][] doubleArrayArray2;

   private static final double[] doubleArray17;
   private static final double[] doubleArray18;

   private static final double[] doubleArray19;

   private static boolean testWorld(World world, ClientPlayerEntity clientPlayerEntity, Vec3d vec3d, BlockPos blockPos, Box box) {
      double blockInteractionRange = clientPlayerEntity.getBlockInteractionRange();
      double[][] doubleArrayArray = getDoubleArrayArray2();
      int length = doubleArrayArray.length;

      for (int intValue = 0; intValue < length; intValue++) {
         double[] doubleArray = doubleArrayArray[intValue];
         double x = (double)blockPos.getX();

         x += doubleArray[0];
         double doubleValue = (double)blockPos.getY() + 0.5;
         double z = (double)blockPos.getZ();

         Vec3d vec3d2 = new Vec3d(x, doubleValue, z + doubleArray[1]);
         if (!(vec3d.y <= CartGeometryAccess.getY(vec3d2) + 0.05)) {
            if (!(vec3d.squaredDistanceTo(vec3d2) > blockInteractionRange * blockInteractionRange)) {
               ThreadLocalRandom.current().nextInt(13);

               BlockHitResult blockHitResult = world.raycast(new RaycastContext(vec3d, vec3d2, ShapeType.OUTLINE, FluidHandling.NONE, clientPlayerEntity));
               if (blockHitResult.getType() == Type.MISS) {
                  if (!testVec3d(vec3d, vec3d2, box)) {
                     return true;
                  }
               }
            }
         }
      }

      return false;
   }

   public static boolean testWorld2(World world, BlockPos blockPos) {
      Box box = new Box(blockPos);
      Iterator iterator = world.getEntitiesByClass(TntMinecartEntity.class, box.expand(0.1), tntMinecartEntity -> ((Entity)((TntMinecartEntity)tntMinecartEntity)).isAlive()).iterator();

      while (iterator.hasNext()) {
         ThreadLocalRandom.current().nextInt(12);
         TntMinecartEntity tntMinecartEntity2 = (TntMinecartEntity)iterator.next();
         if (tntMinecartEntity2.getBoundingBox().intersects(box)) {
            double doubleValue = tntMinecartEntity2.getVelocity().lengthSquared();

            if (doubleValue < (1.0E-6)) {
               if (Math.abs(tntMinecartEntity2.getX() - tntMinecartEntity2.lastX) < 0.001) {
                  double doubleValue2 = Math.abs(tntMinecartEntity2.getY() - tntMinecartEntity2.lastY);

                  if (doubleValue2 < (0.001)) {
                     if (Math.abs(tntMinecartEntity2.getZ() - tntMinecartEntity2.lastZ) < 0.001) {
                        return true;
                     }

                     ThreadLocalRandom.current().nextInt(4);
                  }
               }
            }

            return false;
         }
      }

      return false;
   }

   public static ShotAngle computeShotAngleForWorld(World world, Entity entity, Vec3d vec3d, BlockPos blockPos, BlockPos blockPos2, Box box, float floatValue, RotationStep rotationStep) {
      Box box2 = computeBoxForWorld(world, blockPos);
      Vec3d vec3d2 = new Vec3d(box2.getCenter().x, CartGeometryAccess.getMinY(box2), box2.getCenter().z);
      ShotAngle shotAngle = null;
      Vec3d vec3d42 = null;
      double[] doubleArray = doubleArray16;
      int length = doubleArray.length;
      int length2 = 0;

      while (length2 < length) {
         double doubleValue = doubleArray[length2];
         double[] doubleArray2 = doubleArray16;
         int length3 = doubleArray2.length;

         for (int intValue = 0; intValue < length3; intValue++) {
            double doubleValue2 = doubleArray2[intValue];
            double[] doubleArray3 = doubleArray17;
            int length4 = doubleArray3.length;

            for (int intValue2 = 0; intValue2 < length4; intValue2++) {
               double doubleValue3 = doubleArray3[intValue2];
               Vec3d vec3d4 = vec3d2.add(doubleValue, doubleValue3, doubleValue2);
               ShotAngle shotAngle2 = computeShotAngleForWorld2(world, entity, vec3d, vec3d4, blockPos, blockPos2, box, floatValue, rotationStep, shotAngle);
               if (shotAngle2 != null) {
                  shotAngle = shotAngle2;
                  vec3d42 = vec3d4;
                  if (shotAngle2.getMargin() >= 0.15) {
                     return shotAngle2;
                  }

                  ThreadLocalRandom.current().nextInt(9);
               }
            }
         }

         length2++;
      }

      if (shotAngle == null) {
         return null;
      } else {
         Vec3d vec3d3 = vec3d42;
         double[] doubleArray4 = doubleArray19;
         length2 = doubleArray4.length;

         for (int intValue3 = 0; intValue3 < length2; intValue3++) {
            double doubleValue4 = doubleArray4[intValue3];
            double[] doubleArray5 = doubleArray19;
            int length5 = doubleArray5.length;

            for (int intValue4 = 0; intValue4 < length5; intValue4++) {
               double doubleValue5 = doubleArray5[intValue4];

               for (double doubleValue6 : doubleArray15) {
                  if (doubleValue4 == 0.0) {
                     if (doubleValue5 == (0.0)) {
                        if (doubleValue6 == (0.0)) {
                           continue;
                        }
                     }
                  }

                  ShotAngle shotAngle3 = computeShotAngleForWorld2(world, entity, vec3d, vec3d3.add(doubleValue4, doubleValue6, doubleValue5), blockPos, blockPos2, box, floatValue, rotationStep, shotAngle);
                  if (shotAngle3 != null) {
                     shotAngle = shotAngle3;
                  }
               }
            }
         }

         double margin = shotAngle.getMargin();

         return margin >= (0.03) ? shotAngle : null;
      }
   }

   private static List computeListForBox(Box box, Direction direction, double doubleValue) {
      ArrayList arrayList = new ArrayList();
      int intValue = direction.getDirection() == AxisDirection.POSITIVE ? 1 : 0;
      switch (CartAxisSwitchMap.intArray2[direction.getAxis().ordinal()]) {
         case 1:

            double doubleValue2 = intValue != 0 ? box.maxY : CartGeometryAccess.getMinY(box);
            double[][] doubleArrayArray = getDoubleArrayArray2();
            int length = doubleArrayArray.length;
            int intValue2 = 0;

            while (true) {
               if (intValue2 >= length) {
                  return arrayList;
               }

               double[] doubleArray = doubleArrayArray[intValue2];
               double doubleValue3 = box.minX + doubleArray[0] * box.getLengthX();
               double minZ = CartGeometryAccess.getMinZ(box);

               arrayList.add(new Vec3d(doubleValue3, doubleValue2, minZ + doubleArray[1] * box.getLengthZ()));
               intValue2++;
            }
         case 2:
         case 3:
            double[] doubleArray2;
            if (doubleValue - box.minY >= box.getLengthY() - 1.0E-6) {
               doubleArray2 = new double[5];

               doubleArray2[0] = (0.5);
               doubleArray2[1] = 0.35;
               doubleArray2[2] = 0.65;
               doubleArray2[3] = 0.2;

               doubleArray2[4] = (0.8);
            } else {
               doubleArray2 = doubleArray18;
            }

            double[] doubleArray22 = doubleArray2;
            int length2 = doubleArray22.length;

            for (int intValue3 = 0; intValue3 < length2; intValue3++) {
               double doubleValue4 = doubleArray22[intValue3];
               double doubleValue5 = CartGeometryAccess.getMinY(box) + doubleValue4 * box.getLengthY();
               if (!(doubleValue5 > doubleValue)) {
                  double[] doubleArray4 = getDoubleArray14();
                  int length3 = doubleArray4.length;

                  for (int intValue4 = 0; intValue4 < length3; intValue4++) {
                     double doubleValue6 = doubleArray4[intValue4];
                     Vec3d vec3d;
                     if (direction.getAxis() == Axis.X) {
                        double doubleValue7;
                        if (intValue != 0) {
                           ThreadLocalRandom.current().nextInt(14);
                           doubleValue7 = box.maxX;
                        } else {
                           doubleValue7 = CartGeometryAccess.getMinX(box);
                        }

                        vec3d = new Vec3d(doubleValue7, doubleValue5, CartGeometryAccess.getMinZ(box) + doubleValue6 * box.getLengthZ());
                     } else {
                        vec3d = new Vec3d(CartGeometryAccess.getMinX(box) + doubleValue6 * box.getLengthX(), doubleValue5, intValue != 0 ? CartGeometryAccess.getMaxZ(box) : box.minZ);
                     }

                     arrayList.add(vec3d);
                  }
               }
            }

            byte byteValue = 16;
            ThreadLocalRandom.current().nextInt(9);
      }

      return arrayList;
   }

   private static boolean testVec3d(Vec3d vec3d, Vec3d vec3d2, Box box) {
      if (!box.contains(vec3d)) {
         if (!box.raycast(vec3d, vec3d2).isPresent()) {
            return false;
         }
      }

      return true;
   }

   public static double[] getDoubleArray14() {
      return doubleArray14;
   }

   private static double computeDoubleForBox(Box box) {
      return Math.min(box.getLengthX(), Math.min(box.getLengthY(), box.getLengthZ())) / 2.0 - 1.0E-4;
   }

   public static double[][] getDoubleArrayArray2() {
      return doubleArrayArray2;
   }

   public static double computeDoubleForWorld(World world, Entity entity, Vec3d vec3d, float floatValue, float floatValue2, BlockPos blockPos, BlockPos blockPos2) {
      return computeDoubleForWorld3(world, entity, vec3d, floatValue, floatValue2, blockPos, blockPos2, null, true, ((-1.0)));
   }

   public static boolean testWorld3(World world, BlockPos blockPos) {
      BlockState blockState = world.getBlockState(blockPos);
      if (blockState.getBlock() instanceof SlabBlock) {
         if (blockState.get(SlabBlock.TYPE) == SlabType.BOTTOM) {
            return true;
         }
      }

      return false;
   }

   private static boolean equals(BlockPlacementPlan blockPlacementPlan, BlockHitResult blockHitResult) {
      return blockPlacementPlan.getCell2().equals(blockHitResult.getBlockPos().offset(blockHitResult.getSide()));
   }

   public static Box computeBoxForBlockPos(BlockPos blockPos) {
      return ProjectileAimPlanner.computeBoxForBlockPos(blockPos);
   }

   public static double computeDoubleForWorld2(World world, Entity entity, Vec3d vec3d, Box box, Box box2) {
      List list = CartCoverPlanner.computeListForBox(box);
      List list2 = CartCoverPlanner.toList2(world, entity, vec3d, list);
      if (box2 == null) {
         return (double)list2.size() / (double)list.size();
      } else {
         return CartCoverPlanner.computeDoubleForList2(list2, list.size(), vec3d, box2);
      }
   }

   public static CartExplosionPlan computeCartExplosionPlanForWorld(World world, ClientPlayerEntity clientPlayerEntity, CartCollisionScene cartCollisionScene, ItemStack itemStack, Vec3d vec3d, Vec3d vec3d2, float floatValue) {
      if (itemStack == null) {
         PlacementShot placementShot = computePlacementShotForWorld(world, clientPlayerEntity, cartCollisionScene, vec3d, vec3d2, floatValue);
         return placementShot == null ? null : new CartExplosionPlan(null, placementShot.getPlan(), placementShot.getShot());
      } else {
         if (itemStack.getItem() instanceof BlockItem var7 && var7.getBlock() instanceof SlabBlock) {
            BlockState blockState = (BlockState)var7.getBlock().getDefaultState().with(CartGeometryAccess.getTYPE(), SlabType.BOTTOM);
            Vec3d vec3d3 = ProjectileAimPlanner.computeVec3dForBlockPos(cartCollisionScene.getRail2());
            ArrayList arrayList = new ArrayList();
            Iterator iterator = CartGeometryAccess.getHORIZONTAL().iterator();

            while (iterator.hasNext()) {
               Direction direction = (Direction)iterator.next();

               BlockPos[] blockPosArray = new BlockPos[]{cartCollisionScene.getRail2().offset(direction), cartCollisionScene.getRail2().offset(direction).offset(direction.rotateYClockwise())};
               int length = blockPosArray.length;

               int intValue = 0;

               while (intValue < length) {
                  label128: {
                     BlockPos blockPos = blockPosArray[intValue];
                     CartCollisionScene cartCollisionScene2;
                     if (testWorld3(world, blockPos)) {
                        cartCollisionScene2 = new CartCollisionScene(cartCollisionScene.getRail2(), blockPos, world.getBlockState(blockPos), cartCollisionScene.getCart2(), cartCollisionScene.getPlayerBoxes3());
                     } else {
                        if (!testWorld5(world, cartCollisionScene, blockPos)) {
                           break label128;
                        }

                        if (computeBlockAimForWorld(world, clientPlayerEntity, vec3d2, blockPos, itemStack, floatValue, List.of(cartCollisionScene.getCart2())) == null) {
                           break label128;
                        }

                        cartCollisionScene2 = new CartCollisionScene(cartCollisionScene.getRail2(), blockPos, blockState, cartCollisionScene.getCart2(), cartCollisionScene.getPlayerBoxes3());
                     }

                     double x = (double)blockPos.getX();
                     double y = (double)blockPos.getY();
                     double z = (double)blockPos.getZ();
                     double doubleValue = (double)(blockPos.getX() + 1);
                     double y2 = (double)blockPos.getY();

                     y2 += (0.5);
                     int z2 = blockPos.getZ();

                     Box box = new Box(x, y, z, doubleValue, y2, (double)(z2 + 1));
                     double doubleValue2 = 0.0;

                     for (Box box2 : (java.lang.Iterable<Box>)(java.lang.Iterable<?>)(cartCollisionScene.getPlayerBoxes3())) {
                        doubleValue2 = Math.max(doubleValue2, computeDoubleForWorld2(world, clientPlayerEntity, vec3d3, box2, box));
                     }

                     arrayList.add(new CartExposureScene(cartCollisionScene2, doubleValue2));
                  }

                  intValue++;
               }
            }

            arrayList.sort(Comparator.comparingDouble(objectValue -> ((CartExposureScene)objectValue).getExposure2()));
            CartExplosionPlan cartExplosionPlan = null;

            long longValue22 = (-9223372036854775808L);

            for (CartExposureScene cartExposureScene : (java.lang.Iterable<CartExposureScene>)(java.lang.Iterable<?>)(arrayList)) {
               long longValue2 = Math.round(cartExposureScene.getExposure2() * 20.0);
               if (cartExplosionPlan != null && longValue2 != longValue22) {
                  break;
               }

               PlacementShot placementShot2 = computePlacementShotForWorld(world, clientPlayerEntity, cartExposureScene.getScene(), vec3d, vec3d2, floatValue);
               if (placementShot2 != null) {
                  if (cartExplosionPlan != null && !(placementShot2.getShot().getMargin() > cartExplosionPlan.getShot2().getMargin())) {
                     ThreadLocalRandom.current().nextInt(16);
                  } else {
                     cartExplosionPlan = new CartExplosionPlan(new BlockExposure(cartExposureScene.getScene().getSlab72(), cartExposureScene.getExposure2()), placementShot2.getPlan(), placementShot2.getShot());
                     longValue22 = longValue2;
                  }
               }
            }

            return cartExplosionPlan;
         }

         return null;
      }
   }

   public static BlockAim computeBlockAimForWorld(World world, ClientPlayerEntity clientPlayerEntity, Vec3d vec3d, BlockPos blockPos, ItemStack itemStack, float floatValue, List list) {
      if (itemStack.getItem() instanceof BlockItem var7) {
         ThreadLocalRandom.current().nextInt(11);
         Predicate predicate = objectValue -> testWorld9(world, clientPlayerEntity, var7, itemStack, blockPos, (BlockHitResult)objectValue);
         Direction[] directionArray = new Direction[]{CartGeometryAccess.getUP(), CartGeometryAccess.getNORTH(), null, null, null};

         directionArray[2] = CartGeometryAccess.getSOUTH();
         directionArray[3] = CartGeometryAccess.getWEST();
         directionArray[4] = CartGeometryAccess.getEAST();
         Direction[] directionArray2 = directionArray;
         int length = directionArray2.length;
         int intValue = 0;

         while (intValue < length) {
            Direction direction = directionArray2[intValue];
            BlockPos blockPos2 = blockPos.offset(direction.getOpposite());
            BlockState blockState = world.getBlockState(blockPos2);
            if (!blockState.isAir()) {
               if (!blockState.isReplaceable()) {
                  if (!blockState.hasBlockEntity()) {
                     if (!(CartCoverPlanner.testBlockState(blockState))) {
                        BlockAim blockAim = computeBlockAimForWorld3(world, clientPlayerEntity, vec3d, blockPos2, direction, 0.45, floatValue, predicate, list);
                        if (blockAim != null) {
                           ThreadLocalRandom.current().nextInt(10);
                           return blockAim;
                        }
                     }
                  }
               }
            }

            intValue++;
         }

         return null;
      } else {
         return null;
      }
   }

   public static double computeDoubleForWorld3(World world, Entity entity, Vec3d vec3d, float floatValue, float floatValue2, BlockPos blockPos, BlockPos blockPos2, Box box, boolean booleanValue, double doubleValue) {
      Box box2 = computeBoxForWorld(world, blockPos);
      double maxValue = Double.MAX_VALUE;
      Iterator iterator = computeList(floatValue, floatValue2, booleanValue).iterator();

      while (true) {
         if (!iterator.hasNext()) {
            return maxValue;
         }

         Vec3d vec3d2 = (Vec3d)iterator.next();
         maxValue = Math.min(maxValue, computeDoubleForWorld4(world, entity, vec3d, vec3d2, box2, blockPos, blockPos2, box));

         if (maxValue < (0.0)) {
            break;
         }

         if (maxValue <= doubleValue) {
            break;
         }
      }

      return ((-1.0));
   }

   public static float[] computeFloatArrayForVec3d(Vec3d vec3d, Vec3d vec3d2, float floatValue) {
      ThreadLocalRandom.current().nextInt(17);
      Vec3d vec3d22 = vec3d2;
      float[] floatArray = RotationMath.computeFloatArrayForVec3d(vec3d, vec3d2, floatValue);
      int intValue = 0;

      while (true) {
         if (intValue >= 3) {
            break;
         }

         double doubleValue = computeDoubleForVec3d(vec3d, computeVec3d(floatArray[0], floatArray[1]).multiply(3.15), vec3d2);
         if (Math.abs(doubleValue) < 0.001) {
            break;
         }

         vec3d22 = vec3d22.add(0.0, doubleValue, 0.0);
         floatArray = RotationMath.computeFloatArrayForVec3d(vec3d, vec3d22, floatValue);
         intValue++;
      }

      return floatArray;
   }

   public static boolean testWorld4(World world, ClientPlayerEntity clientPlayerEntity, BlockItem blockItem, ItemStack itemStack, BlockPos blockPos, BlockHitResult blockHitResult) {
      ItemPlacementContext itemPlacementContext = new ItemPlacementContext(clientPlayerEntity, Hand.MAIN_HAND, itemStack, blockHitResult);
      if (itemPlacementContext.getBlockPos().equals(blockPos)) {
         if (itemPlacementContext.canPlace()) {
            ThreadLocalRandom.current().nextInt(12);

            ThreadLocalRandom.current().nextInt(11);
            BlockState placementState = blockItem.getBlock().getPlacementState(itemPlacementContext);
            if (placementState != null) {
               if (placementState.getBlock() instanceof SlabBlock) {
                  if (placementState.get(CartGeometryAccess.getTYPE()) == CartGeometryAccess.getBOTTOM()) {
                     if (world.canPlace(placementState, blockPos, ShapeContext.of(clientPlayerEntity))) {
                        return true;
                     }
                  }
               }
            }

            return false;
         }

         ThreadLocalRandom.current().nextInt(17);
      } else {
         ThreadLocalRandom.current().nextInt(9);
      }

      return false;
   }

   static boolean testWorld5(World world, CartCollisionScene cartCollisionScene, BlockPos blockPos) {
      if (world.isChunkLoaded(blockPos)) {
         if (world.getWorldBorder().contains(blockPos)) {
            if (!cartCollisionScene.testBlockPos(blockPos)) {
               ThreadLocalRandom.current().nextInt(11);
               if (!blockPos.equals(cartCollisionScene.getRail2())) {
                  BlockState blockState = world.getBlockState(blockPos);
                  if (blockState.isReplaceable()) {
                     if (blockState.getFluidState().isEmpty()) {
                        return true;
                     }
                  }

                  return false;
               }
            }
         }
      } else {
         ThreadLocalRandom.current().nextInt(7);
      }

      return false;
   }

   private static boolean testWorld6(World world, Entity entity, Vec3d vec3d, Vec3d vec3d2, BlockPos blockPos) {
      Box box = new Box(vec3d, vec3d2);

      Box box2 = box.expand((1.0));
      Iterator iterator = world.getOtherEntities(entity, box2, entity2 -> ((Entity)entity2).canBeHitByProjectile()).iterator();

      while (true) {
         if (!iterator.hasNext()) {
            return false;
         }

         Entity entity3 = (Entity)iterator.next();
         if (testEntity(entity3, blockPos)) {
            ThreadLocalRandom.current().nextInt(10);
         } else if (entity == null || !entity.isConnectedThroughVehicle(entity3)) {
            if (entity3.getBoundingBox().raycast(vec3d, vec3d2).isPresent()) {
               break;
            }

            if (entity3.getBoundingBox().contains(vec3d)) {
               break;
            }

            ThreadLocalRandom.current().nextInt(4);
         }
      }

      return true;
   }

   static boolean testBox(Box box, Vec3d vec3d, Vec3d vec3d2) {
      if (!box.contains(vec3d)) {
         if (!box.raycast(vec3d, vec3d2).isPresent()) {
            if (!box.contains(vec3d2)) {
               ThreadLocalRandom.current().nextInt(4);
               return false;
            }
         }
      }

      return true;
   }

   static double computeDoubleForWorld4(World world, Entity entity, Vec3d vec3d, Vec3d vec3d2, Box box, BlockPos blockPos, BlockPos blockPos2, Box box2) {
      if (box.contains(vec3d)) {
         return ((-1.0));
      } else {
         Box box3 = computeBoxForBlockPos2(blockPos2, 0.0);
         double doubleValue = computeDoubleForBox(box);
         double doubleValue2 = computeDoubleForBox(box3);
         boolean raining = world.isRaining();

         double doubleValue3 = ((-1.0));
         Vec3d vec3d3 = vec3d;
         int intValue = 0;

         while (true) {
            ThreadLocalRandom.current().nextInt(5);
            BlockPos blockPos3 = BlockPos.ofFloored(vec3d3);
            if (world.isChunkLoaded(blockPos3)) {
               if (!world.getFluidState(blockPos3).isIn(CartGeometryAccess.getWATER())) {
                  if (raining) {
                     if (testWorld8(world, vec3d3)) {
                        doubleValue3 = ((-1.0));
                     }
                  }

                  Vec3d vec3d4 = vec3d3.add(vec3d2);
                  BlockHitResult collisionsIncludingWorldBorder = world.getCollisionsIncludingWorldBorder(new RaycastContext(vec3d3, vec3d4, CartGeometryAccess.getCOLLIDER(), FluidHandling.NONE, entity));
                  int intValue2 = collisionsIncludingWorldBorder.getType() == Type.BLOCK ? 1 : 0;
                  Vec3d vec3d5 = intValue2 != 0 ? collisionsIncludingWorldBorder.getPos() : vec3d4;
                  if (box2 != null) {
                     if (box2.contains(vec3d3)) {
                        return ((-1.0));
                     }

                     Optional optional = box2.raycast(vec3d3, vec3d4);
                     if (optional.isPresent() && vec3d3.squaredDistanceTo((Vec3d)optional.get()) < vec3d3.squaredDistanceTo(vec3d5)) {
                        vec3d5 = (Vec3d)optional.get();
                        intValue2 = 1;
                     }
                  }

                  Optional optional2 = box.raycast(vec3d3, vec3d5);
                  if (optional2.isPresent()) {
                     if (testWorld6(world, entity, vec3d3, (Vec3d)optional2.get(), blockPos)) {
                        return ((-1.0));
                     }

                     doubleValue3 = Math.max(doubleValue3, computeDoubleForBox2(box3, vec3d3, (Vec3d)optional2.get(), doubleValue2));

                     label122:
                     if (!(doubleValue3 < (0.0))) {
                        if (raining) {
                           if (testWorld8(world, (Vec3d)optional2.get())) {
                              break label122;
                           }
                        }

                        return Math.min(doubleValue3, computeDoubleForBox2(box, vec3d3, vec3d5, doubleValue));
                     }

                     return ((-1.0));
                  }

                  if (intValue2 == 0) {
                     if (!testWorld6(world, entity, vec3d3, vec3d4, blockPos)) {
                        doubleValue3 = Math.max(doubleValue3, computeDoubleForBox2(box3, vec3d3, vec3d4, doubleValue2));
                        if (raining && testWorld8(world, vec3d4)) {
                           doubleValue3 = ((-1.0));
                        }

                        vec3d3 = vec3d4;
                        vec3d2 = ProjectilePhysics.computeVec3dForVec3d(vec3d2);
                        intValue++;

                        if (intValue >= 12) {
                           return ((-1.0));
                        }
                        continue;
                     }
                  }

                  return ((-1.0));
               }
            }

            return ((-1.0));
         }
      }
   }

   private static boolean testClientPlayerEntity(ClientPlayerEntity clientPlayerEntity, Vec3d vec3d, Vec3d vec3d2, List list) {
      Iterator iterator = list.iterator();

      for (; iterator.hasNext(); ) {
         Box box = (Box)iterator.next();
         if (box != null) {
            if (testVec3d(vec3d, vec3d2, box)) {
               return true;
            }
         } else {
            ThreadLocalRandom.current().nextInt(3);
         }
      }

      return false;
   }

   static BlockPlacementPlan computeBlockPlacementPlanForWorld(World world, ClientPlayerEntity clientPlayerEntity, CartCollisionScene cartCollisionScene, Vec3d vec3d, BlockPos blockPos, float floatValue) {
      Box box = cartCollisionScene.computeBoxForWorld(world);
      List list;
      if (box == null) {
         list = List.of(cartCollisionScene.getCart2());
      } else {
         list = List.of(cartCollisionScene.getCart2(), box);
      }

      List list2 = list;

      for (Direction direction : Direction.values()) {
         BlockPos blockPos2 = blockPos.offset(direction.getOpposite());
         if (box != null) {
            if (blockPos2.equals(cartCollisionScene.getSlab72())) {
               if (direction == CartGeometryAccess.getUP()) {
                  if (testWorld(world, clientPlayerEntity, vec3d, blockPos2, cartCollisionScene.getCart2())) {
                     return new BlockPlacementPlan(blockPos, blockPos2, direction, true);
                  }
               }
               continue;
            }
         }

         if (blockPos2.equals(cartCollisionScene.getRail2())) {
         } else if (computeBlockAimForWorld2(world, clientPlayerEntity, vec3d, new BlockPlacementPlan(blockPos, blockPos2, direction, false), floatValue, list2) != null) {
            return new BlockPlacementPlan(blockPos, blockPos2, direction, false);
         }
      }

      return null;
   }

   static Box computeBoxForBlockPos2(BlockPos blockPos, double doubleValue) {
      double doubleValue2 = (1.0E-5) + doubleValue;
      double x = (double)blockPos.getX();

      double doubleValue3 = x - (0.25) + doubleValue2;
      double doubleValue4 = (double)blockPos.getY() - 0.5 + doubleValue2;
      double doubleValue5 = (double)blockPos.getZ() - 0.25 + doubleValue2;
      double doubleValue6 = (double)(blockPos.getX() + 1) + 0.25 - doubleValue2;
      int y = blockPos.getY();

      return new Box(doubleValue3, doubleValue4, doubleValue5, doubleValue6, (double)(y + 1) - doubleValue2, (double)(blockPos.getZ() + 1) + 0.25 - doubleValue2);
   }

   public static Vec3d computeVec3dForVec3d(Vec3d vec3d, double doubleValue) {
      double x = CartGeometryAccess.getX(vec3d);
      double doubleValue2 = vec3d.y + doubleValue;

      return new Vec3d(x, doubleValue2 - (0.10000000149011612), CartGeometryAccess.getZ(vec3d));
   }

   public static boolean testWorld7(World world, CartCollisionScene cartCollisionScene, BlockPos blockPos) {
      if (world.isChunkLoaded(blockPos)) {
         if (world.getWorldBorder().contains(blockPos)) {
            if (world.getBlockState(blockPos).isAir()) {
               BlockPos blockPos2 = blockPos.down();
               BlockState blockState = cartCollisionScene.computeBlockStateForWorld(world, blockPos2);
               if (blockState.isIn(BlockTags.SOUL_FIRE_BASE_BLOCKS)) {
                  return true;
               }

               if (blockState.isSideSolidFullSquare(world, blockPos2, Direction.UP)) {
                  return true;
               }

               Direction[] directionArray = Direction.values();
               int length = directionArray.length;
               int intValue = 0;

               while (intValue < length) {
                  Direction direction = directionArray[intValue];
                  if (testBlockState(cartCollisionScene.computeBlockStateForWorld(world, blockPos.offset(direction)))) {
                     return true;
                  }

                  ThreadLocalRandom.current().nextInt(16);
                  intValue++;
               }

               return false;
            }
         }
      } else {
         ThreadLocalRandom.current().nextInt(7);
      }

      return false;
   }

   static {
      double[] doubleArray = new double[3];

      doubleArray[0] = (0.35);

      doubleArray[1] = (0.2);
      doubleArray[2] = 0.5;
      doubleArray17 = doubleArray;
      doubleArray = new double[3];

      doubleArray[0] = (0.0);
      doubleArray[1] = ((-0.125));

      doubleArray[2] = 0.125;
      doubleArray19 = doubleArray;
      doubleArray = new double[3];

      doubleArray[0] = 0.0;
      doubleArray[1] = ((-0.075));

      doubleArray[2] = (0.075);
      doubleArray15 = doubleArray;
      double[][] doubleArrayArray = new double[13][];

      double[] doubleArray2 = new double[]{0.5, 0.0};

      doubleArray2[1] = (0.5);
      doubleArrayArray[0] = doubleArray2;

      double[] doubleArray3 = new double[2];

      doubleArray3[0] = (0.35);
      doubleArray3[1] = 0.5;
      doubleArrayArray[1] = doubleArray3;

      double[] doubleArray4 = new double[]{0.65, 0.0};

      doubleArray4[1] = 0.5;
      doubleArrayArray[2] = doubleArray4;
      double[] doubleArray5 = new double[2];

      doubleArray5[0] = (0.5);

      doubleArray5[1] = 0.35;
      doubleArrayArray[3] = doubleArray5;

      double[] doubleArray6 = new double[]{0.5, 0.0};

      doubleArray6[1] = (0.65);
      doubleArrayArray[4] = doubleArray6;

      double[] doubleArray7 = new double[2];

      doubleArray7[0] = (0.3);

      doubleArray7[1] = (0.3);
      doubleArrayArray[5] = doubleArray7;
      double[] doubleArray8 = new double[2];

      doubleArray8[0] = (0.7);

      doubleArray8[1] = (0.3);
      doubleArrayArray[6] = doubleArray8;
      double[] doubleArray9 = new double[]{0.3, 0.0};

      doubleArray9[1] = (0.7);
      doubleArrayArray[7] = doubleArray9;

      double[] doubleArray10 = new double[2];

      doubleArray10[0] = 0.7;

      doubleArray10[1] = (0.7);
      doubleArrayArray[8] = doubleArray10;

      doubleArrayArray[9] = new double[]{0.15, 0.5};

      double[] doubleArray11 = new double[2];

      doubleArray11[0] = 0.85;

      doubleArray11[1] = 0.5;
      doubleArrayArray[10] = doubleArray11;
      double[] doubleArray12 = new double[]{0.5, 0.0};

      doubleArray12[1] = (0.15);
      doubleArrayArray[11] = doubleArray12;

      double[] doubleArray13 = new double[2];

      doubleArray13[0] = 0.5;

      doubleArray13[1] = 0.85;
      doubleArrayArray[12] = doubleArray13;
      doubleArrayArray2 = doubleArrayArray;
      doubleArray = new double[4];

      doubleArray[0] = (0.25);

      doubleArray[1] = 0.15;
      doubleArray[2] = 0.35;

      doubleArray[3] = (0.42);
      doubleArray18 = doubleArray;

      doubleArray = new double[5];

      doubleArray[0] = (0.5);

      doubleArray[1] = (0.35);

      doubleArray[2] = (0.65);

      doubleArray[3] = (0.2);

      doubleArray[4] = 0.8;
      doubleArray14 = doubleArray;
   }

   public static BlockAim computeBlockAimForWorld2(World world, ClientPlayerEntity clientPlayerEntity, Vec3d vec3d, BlockPlacementPlan blockPlacementPlan, float floatValue, List list) {
      if (!testBlockState2(world.getBlockState(blockPlacementPlan.getSupport2()))) {
         return null;
      } else {
         ThreadLocalRandom.current().nextInt(5);

         return computeBlockAimForWorld3(world, clientPlayerEntity, vec3d, blockPlacementPlan.getSupport2(), blockPlacementPlan.getFace(), 1.0, floatValue, objectValue -> equals(blockPlacementPlan, (BlockHitResult)objectValue), list);
      }
   }

   public static boolean testBlockState(BlockState blockState) {
      return ((FireBlockAccessor)Blocks.FIRE).mochi$isFlammable(blockState);
   }

   private static boolean testWorld8(World world, Vec3d vec3d) {
      if (!world.hasRain(BlockPos.ofFloored(vec3d))) {
         ThreadLocalRandom.current().nextInt(17);

         if (!world.hasRain(BlockPos.ofFloored(vec3d.x, vec3d.y + 0.5, CartGeometryAccess.getZ(vec3d)))) {
            return false;
         }
      }

      return true;
   }

   public static boolean testBlockState2(BlockState blockState) {
      if (!blockState.isAir()) {
         ThreadLocalRandom.current().nextInt(7);

         if (!blockState.hasBlockEntity() && !CartCoverPlanner.testBlockState(blockState)) {
            if (!blockState.isOf(CartGeometryAccess.getTNT())) {
               if (!blockState.isIn(CartGeometryAccess.getFIRE())) {
                  if (!CampfireBlock.canBeLit(blockState)) {
                     if (!CandleBlock.canBeLit(blockState)) {
                        ThreadLocalRandom.current().nextInt(8);
                        if (!CandleCakeBlock.canBeLit(blockState)) {
                           return true;
                        }
                     }
                  } else {
                     ThreadLocalRandom.current().nextInt(3);
                  }
               }
            }
         }
      }

      return false;
   }

   static double computeDoubleForVec3d(Vec3d vec3d, Vec3d vec3d2, Vec3d vec3d3) {
      double doubleValue = Math.hypot(CartGeometryAccess.getX(vec3d3) - CartGeometryAccess.getX(vec3d), vec3d3.z - CartGeometryAccess.getZ(vec3d));
      Vec3d vec3d4 = vec3d;

      int intValue = 0;

      while (true) {
         if (intValue >= 12) {
            ThreadLocalRandom.current().nextInt(4);

            return (0.0);
         }

         Vec3d vec3d5 = vec3d4.add(vec3d2);
         double doubleValue2 = Math.hypot(vec3d4.x - vec3d.x, vec3d4.z - vec3d.z);
         double doubleValue3 = Math.hypot(CartGeometryAccess.getX(vec3d5) - CartGeometryAccess.getX(vec3d), CartGeometryAccess.getZ(vec3d5) - vec3d.z);
         if (doubleValue3 >= doubleValue) {
            double doubleValue4 = doubleValue3 - doubleValue2 < 1.0E-9 ? 0.0 : (doubleValue - doubleValue2) / (doubleValue3 - doubleValue2);
            return CartGeometryAccess.getY(vec3d3) - (vec3d4.y + (vec3d5.y - vec3d4.y) * doubleValue4);
         }

         vec3d4 = vec3d5;
         vec3d2 = ProjectilePhysics.computeVec3dForVec3d(vec3d2);
         intValue++;
      }
   }

   static BlockAim computeBlockAimForWorld3(World world, ClientPlayerEntity clientPlayerEntity, Vec3d vec3d, BlockPos blockPos, Direction direction, double doubleValue, float floatValue, Predicate predicate, List list) {
      BlockState blockState = world.getBlockState(blockPos);
      VoxelShape outlineShape = blockState.getOutlineShape(world, blockPos);
      if (outlineShape.isEmpty()) {
         return null;
      } else {
         Box box = outlineShape.getBoundingBox().offset(blockPos);
         double blockInteractionRange = clientPlayerEntity.getBlockInteractionRange();
         Iterator iterator = computeListForBox(box, direction, (double)blockPos.getY() + doubleValue).iterator();

         while (iterator.hasNext()) {
            Vec3d vec3d2 = (Vec3d)iterator.next();
            if (!(vec3d.squaredDistanceTo(vec3d2) > blockInteractionRange * blockInteractionRange)) {
               float[] floatArray = RotationMath.computeFloatArrayForVec3d(vec3d, vec3d2, floatValue);
               BlockHitResult blockHitResult = ProjectileAimPlanner.computeBlockHitResultForWorld(world, clientPlayerEntity, vec3d, floatArray[0], floatArray[1], blockInteractionRange);
               if (blockHitResult != null && blockHitResult.getBlockPos().equals(blockPos)) {
                  if (blockHitResult.getSide() == direction) {
                     if ((predicate.test(blockHitResult))) {
                        if (!testClientPlayerEntity(clientPlayerEntity, vec3d, blockHitResult.getPos(), list)) {
                           return new BlockAim(vec3d2, floatArray[0], floatArray[1], blockHitResult);
                        }
                     }
                  }
               }
            }
         }

         return null;
      }
   }

   static List computeList(float floatValue, float floatValue2, boolean booleanValue) {
      Vec3d vec3d = computeVec3d(floatValue, floatValue2).normalize();
      ArrayList arrayList = new ArrayList(booleanValue ? 15 : 1);

      arrayList.add(vec3d.multiply((3.15)));
      if (!booleanValue) {
         return arrayList;
      } else {
         int intValue = 0;

         do {
            byte byteValue = -1;

            do {
               double doubleValue = (double)byteValue * 0.0172275;
               double doubleValue2 = intValue == 0 ? doubleValue : 0.0;
               double doubleValue3;
               if (intValue == 1) {
                  doubleValue3 = doubleValue;
               } else {
                  doubleValue3 = (0.0);
               }

               double doubleValue4;
               if (intValue == 2) {
                  doubleValue4 = doubleValue;
               } else {
                  doubleValue4 = (0.0);
               }

               arrayList.add(vec3d.add(doubleValue2, doubleValue3, doubleValue4).multiply(3.15));
               byteValue += 2;
            } while (byteValue <= 1);

            intValue++;
         } while (intValue < 3);

         intValue = 0;

         do {
            double doubleValue5 = (intValue & 1) == 0 ? ((-0.0172275)) : 0.0172275;
            double doubleValue6;
            if ((2 | ~intValue) - ~intValue == 0) {
               doubleValue6 = ((-0.0172275));
            } else {
               doubleValue6 = (0.0172275);
            }

            double doubleValue7;
            if ((4 | ~intValue) - ~intValue == 0) {
               doubleValue7 = ((-0.0172275));
            } else {
               doubleValue7 = (0.0172275);
            }

            Vec3d vec3d2 = vec3d.add(doubleValue5, doubleValue6, doubleValue7);

            arrayList.add(vec3d2.multiply((3.15)));
            intValue++;
         } while (intValue < 8);

         return arrayList;
      }
   }

   private static double computeDoubleForPlacementShot(PlacementShot placementShot) {
      return -placementShot.getShot().getMargin();
   }

   static PlacementShot computePlacementShotForWorld(World world, ClientPlayerEntity clientPlayerEntity, CartCollisionScene cartCollisionScene, Vec3d vec3d, Vec3d vec3d2, float floatValue) {
      ArrayList arrayList = new ArrayList();
      Vec3d vec3d3 = Vec3d.ofCenter(cartCollisionScene.getRail2());

      int intValue = -1;

      do {
         int intValue2 = -1;

         do {
            int intValue3 = -1;

            do {
               BlockPos blockPos = cartCollisionScene.getRail2().add(intValue, intValue2, intValue3);
               if (!blockPos.equals(cartCollisionScene.getRail2())) {
                  ThreadLocalRandom.current().nextInt(10);
                  if (!blockPos.equals(cartCollisionScene.getRail2().down()) && !blockPos.equals(cartCollisionScene.getSlab72()) && !cartCollisionScene.testBlockPos(blockPos)) {
                     if ((testWorld7(world, cartCollisionScene, blockPos))) {
                        if (testBox(computeBoxForBlockPos2(blockPos, ((-0.6))), vec3d, cartCollisionScene.getCart2().getCenter())) {
                           BlockPlacementPlan blockPlacementPlan = computeBlockPlacementPlanForWorld(world, clientPlayerEntity, cartCollisionScene, vec3d2, blockPos, floatValue);
                           if (blockPlacementPlan != null) {
                              ShotAngle shotAngle = computeShotAngleForWorld(world, clientPlayerEntity, vec3d, cartCollisionScene.getRail2(), blockPos, cartCollisionScene.computeBoxForWorld(world), floatValue, null);
                              if (shotAngle != null) {
                                 ThreadLocalRandom.current().nextInt(14);
                                 arrayList.add(new PlacementShot(blockPlacementPlan, shotAngle, computeDoubleForVec3d2(vec3d, vec3d3, Vec3d.ofCenter(blockPos))));
                              }
                           }
                        }
                     }
                  }
               }

               intValue3++;
            } while (intValue3 <= 1);

            intValue2++;
         } while (intValue2 <= 1);

         intValue++;
      } while (intValue <= 1);

      return (PlacementShot)(arrayList.stream().min(Comparator.<PlacementShot>comparingDouble(placementShot -> computeDoubleForPlacementShot(placementShot)).thenComparingDouble(placementShot2 -> placementShot2.getOffLine())).orElse(null));
   }

   static double computeDoubleForVec3d2(Vec3d vec3d, Vec3d vec3d2, Vec3d vec3d3) {
      Vec3d vec3d4 = vec3d2.subtract(vec3d);
      double doubleValue = vec3d4.lengthSquared();

      double doubleValue2;
      if (doubleValue < (1.0E-9)) {
         doubleValue2 = 0.0;
      } else {
         doubleValue2 = (0.0);

         doubleValue2 = Math.max((0.0), Math.min((1.0), vec3d3.subtract(vec3d).dotProduct(vec3d4) / doubleValue));
      }

      double doubleValue22 = doubleValue2;
      return vec3d3.distanceTo(vec3d.add(vec3d4.multiply(doubleValue22)));
   }

   private static boolean testWorld9(World world, ClientPlayerEntity clientPlayerEntity, BlockItem blockItem, ItemStack itemStack, BlockPos blockPos, BlockHitResult blockHitResult) {
      return testWorld4(world, clientPlayerEntity, blockItem, itemStack, blockPos, blockHitResult);
   }

   public static Vec3d computeVec3d(float floatValue, float floatValue2) {
      return BlockInteractUtils.computeVec3d(floatValue2, floatValue);
   }

   public static boolean testBlockState3(BlockState blockState) {
      return CartCoverPlanner.testBlockState(blockState);
   }

   public static CartExplosionPlan computeCartExplosionPlanForWorld2(World world, ClientPlayerEntity clientPlayerEntity, CartCollisionScene cartCollisionScene, Vec3d vec3d, Vec3d vec3d2, float floatValue) {
      PlacementShot placementShot = computePlacementShotForWorld(world, clientPlayerEntity, cartCollisionScene, vec3d, vec3d2, floatValue);
      CartExplosionPlan cartExplosionPlan;
      if (placementShot == null) {
         cartExplosionPlan = null;
      } else {
         ThreadLocalRandom.current().nextInt(4);

         ThreadLocalRandom.current().nextInt(12);
         cartExplosionPlan = new CartExplosionPlan(null, placementShot.getPlan(), placementShot.getShot());
      }

      return cartExplosionPlan;
   }

   private CartExplosionPlanner() {
   }

   public static Box computeBoxForWorld(World world, BlockPos blockPos) {
      Box box = new Box(blockPos);

      Iterator iterator = world.getEntitiesByClass(
            TntMinecartEntity.class,
            box.expand((0.1)),
            tntMinecartEntity -> ((Entity)((TntMinecartEntity)tntMinecartEntity)).isAlive()
         )
         .iterator();

      while (iterator.hasNext()) {
         ThreadLocalRandom.current().nextInt(5);
         TntMinecartEntity tntMinecartEntity2 = (TntMinecartEntity)iterator.next();
         if (tntMinecartEntity2.getBoundingBox().intersects(box)) {
            return tntMinecartEntity2.getBoundingBox();
         }

         ThreadLocalRandom.current().nextInt(11);
      }

      return ProjectileAimPlanner.computeBoxForBlockPos(blockPos);
   }

   private static ShotAngle computeShotAngleForWorld2(World world, Entity entity, Vec3d vec3d, Vec3d vec3d2, BlockPos blockPos, BlockPos blockPos2, Box box, float floatValue, RotationStep rotationStep, ShotAngle shotAngle) {
      float[] floatArray = computeFloatArrayForVec3d(vec3d, vec3d2, floatValue);
      if (rotationStep != null) {
         floatArray = rotationStep.computeFloatArray(floatArray);

         ThreadLocalRandom.current().nextInt(14);
      }

      float floatValue2 = floatArray[0];

      float floatValue3 = floatArray[1];
      double margin;
      if (shotAngle == null) {
         margin = ((-1.0));
      } else {
         margin = shotAngle.getMargin();
      }

      double doubleValue = computeDoubleForWorld3(world, entity, vec3d, floatValue2, floatValue3, blockPos, blockPos2, box, true, margin);
      ShotAngle shotAngle2;
      if (doubleValue < 0.0) {
         ThreadLocalRandom.current().nextInt(13);

         shotAngle2 = null;
      } else {
         ThreadLocalRandom.current().nextInt(15);

         float floatValue4 = floatArray[0];

         shotAngle2 = new ShotAngle(floatValue4, floatArray[1], doubleValue);
      }

      return shotAngle2;
   }

   static double computeDoubleForBox2(Box box, Vec3d vec3d, Vec3d vec3d2, double doubleValue) {
      if (!testBox(box, vec3d, vec3d2)) {
         ThreadLocalRandom.current().nextInt(6);

         return ((-1.0));
      } else if (testBox(box.contract(doubleValue), vec3d, vec3d2)) {
         return doubleValue;
      } else {
         double doubleValue52 = 0.0;
         double doubleValue3 = doubleValue;

         int intValue = 0;

         do {
            double doubleValue4 = doubleValue52 + doubleValue3;

            double doubleValue5 = doubleValue4 / (2.0);
            if (testBox(box.contract(doubleValue5), vec3d, vec3d2)) {
               doubleValue52 = doubleValue5;
            } else {
               doubleValue3 = doubleValue5;
            }

            intValue++;
         } while (intValue < 16);

         return doubleValue52;
      }
   }

   private static boolean testEntity(Entity entity, BlockPos blockPos) {
      if (entity instanceof TntMinecartEntity) {
         if (entity.getBoundingBox().intersects(new Box(blockPos))) {
            ThreadLocalRandom.current().nextInt(11);

            return true;
         }
      }

      return false;
   }
}
