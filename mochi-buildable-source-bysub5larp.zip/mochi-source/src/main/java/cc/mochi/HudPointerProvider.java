package cc.mochi;

public interface HudPointerProvider {
   boolean isPressed();

   float getPointerY();

   float getPointerX();
}
