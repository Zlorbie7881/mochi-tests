package cc.mochi;

import java.awt.Color;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.StandardCopyOption;

public class ColorAccess8 {
   public static Color getWHITE() {
      return Color.WHITE;
   }

   public static Color getBLACK() {
      return Color.BLACK;
   }

   public static StandardCopyOption getREPLACE_EXISTING() {
      return StandardCopyOption.REPLACE_EXISTING;
   }

   public static Charset getUTF_8() {
      return StandardCharsets.UTF_8;
   }
}
