package cc.mochi;

public enum AnchorAvailability {
   EMPTY,
   VISUAL,
   READY,
   MISSING;

   private static AnchorAvailability[] computeAnchorAvailabilityArray() {
      AnchorAvailability[] anchorAvailabilityArray = new AnchorAvailability[4];

      anchorAvailabilityArray[0] = EMPTY;
      anchorAvailabilityArray[1] = VISUAL;
      anchorAvailabilityArray[2] = READY;
      anchorAvailabilityArray[3] = MISSING;
      return anchorAvailabilityArray;
   }
}
