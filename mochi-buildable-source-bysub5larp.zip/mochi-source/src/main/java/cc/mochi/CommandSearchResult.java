package cc.mochi;

public record CommandSearchResult(PaletteCommand command, int score) {
   public PaletteCommand getCommand() {
      return this.command;
   }

   public int getScore() {
      return this.score;
   }
}
