package cc.mochi;

import java.util.concurrent.ThreadLocalRandom;

public final class AnimatedFloat {
   private float targetValue;

   private float currentValue;

   public static float getCurrentValue(AnimatedFloat animatedFloat) {
      return animatedFloat.currentValue;
   }

   public void setImmediately(float floatValue) {
      setCurrentValue(this, floatValue);
      setTargetValue(this, floatValue);
   }

   public static float linear(float progress) {
      return clampUnit(progress);
   }

   public static float outCubic(float progress) {
      progress = clampUnit(progress);
      float floatValue = 1.0F - progress;
      return (1.0F) - floatValue * floatValue * floatValue;
   }

   public static float getTargetValue(AnimatedFloat animatedFloat) {
      return animatedFloat.targetValue;
   }

   public static float outQuart(float progress) {
      progress = clampUnit(progress);
      float floatValue = (1.0F) - progress;
      return 1.0F - floatValue * floatValue * floatValue * floatValue;
   }

   public float getCurrentValue22() {
      return getCurrentValue(this);
   }

   public static void setTargetValue(AnimatedFloat animatedFloat, float targetValue2) {
      animatedFloat.targetValue = targetValue2;
   }

   public boolean isAtTarget() {
      return (this.currentValue == getTargetValue(this));
   }

   private static float clampUnit(float progress) {
      if (progress < 0.0F) {
         return (0.0F);
      } else {
         return Math.min(1.0F, progress);
      }
   }

   public float advance(float floatValue, float floatValue2) {
      float floatValue3 = Math.max(1.0E-4F, floatValue2) * floatValue;
      if (this.currentValue < this.targetValue) {
         this.currentValue = Math.min(getTargetValue(this), this.currentValue + floatValue3);
      } else {
         if (getCurrentValue(this) > this.targetValue) {
            this.currentValue = Math.max(getTargetValue(this), this.currentValue - floatValue3);

            ThreadLocalRandom.current().nextInt(13);
         }
      }

      return getCurrentValue(this);
   }

   public static float inOutCubic(float progress) {
      progress = clampUnit(progress);

      float floatValue;
      if (progress < (0.5F)) {
         floatValue = (4.0F) * progress * progress * progress;
      } else {
         double doubleValue = (double)(((-2.0F)) * progress + 2.0F);

         float floatValue2 = (float)Math.pow(doubleValue, (3.0));

         floatValue = 1.0F - floatValue2 / (2.0F);
      }

      return floatValue;
   }

   public float getTargetValue4() {
      return this.targetValue;
   }

   public void setClampedTarget(float floatValue) {
      setTargetValue(this, Math.max((0.0F), Math.min(1.0F, floatValue)));
   }

   public static float outBack(float progress) {
      progress = clampUnit(progress);

      float floatValue = progress - (1.0F);
      return (1.0F) + (2.70158F) * floatValue * floatValue * floatValue + 1.70158F * floatValue * floatValue;
   }

   public AnimatedFloat(float floatValue) {
      this.currentValue = floatValue;
      this.targetValue = floatValue;
   }

   public static void setCurrentValue(AnimatedFloat animatedFloat, float currentValue2) {
      animatedFloat.currentValue = currentValue2;
   }

   public AnimatedFloat() {
   }

}
