package cc.mochi;

import cc.mochi.event.impl.player.JumpEvent;
import cc.mochi.event.impl.render.Render3DEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.texture.GlTexture;
import net.minecraft.util.math.Vec3d;

public final class JumpCirclesModule extends Module {
   private final ChoiceSetting modeSetting = new ChoiceSetting("Mode", "Burst", "Burst", "Water");

   private final BooleanSetting sparksSetting;

   private final DoubleSetting bloomStrengthSetting;
   private final BooleanSetting energyPillarSetting;

   private final List<JumpCircleInstance> jumpCircleInstanceList;

   private final BooleanSetting embersSetting;

   private final JumpCircleRenderStyle jumpCircleRenderStyle;

   private final DoubleSetting groundOffsetSetting;
   private final DoubleSetting pillarHeightSetting;
   private final DoubleSetting shockwavesSetting;

   private final DoubleSetting bloomRadiusSetting;

   private final JumpCircleStyle jumpCircleStyle;

   private float[] floatArray3;
   private final ColorSetting customColorSetting;

   private final BooleanSetting bloomSetting;
   private final BooleanSetting magicCircleSetting;

   private final DoubleSetting intensitySetting;

   private final Random random;

   private final ArrayDeque<JumpCircleEffect> jumpCircleEffectArrayDeque;

   private final ChoiceSetting colorModeSetting = new ChoiceSetting("Color Mode", "White", "White", "Mochi Theme", "Custom", "Rainbow");
   private final DoubleSetting durationSSetting;

   private final long timestampNanos;

   private final JumpCircleRenderer jumpCircleRenderer;
   private final DoubleSetting sizeSetting;

   private final List<JumpCircleInstance> jumpCircleInstanceList2;

   private final BooleanSetting throughWallsSetting;

   private final DoubleSetting sparkCountSetting;

   public JumpCirclesModule() {
      super("Jump Circles", "A burst of 3D light with bloom where you jump", -1, ModuleCategory.RENDER);
      this.customColorSetting = new ColorSetting("Custom Color", new Color(230, 240, 255));
      this.sizeSetting = new DoubleSetting("Size", 0.5, 2.5, 1.15, 0.05);
      this.durationSSetting = new DoubleSetting("Duration (s)", 0.6, 3.0, 1.4, 0.05);
      this.intensitySetting = new DoubleSetting("Intensity", 0.4, 2.0, 1.0, 0.05);
      this.magicCircleSetting = new BooleanSetting("Magic Circle", true);
      this.shockwavesSetting = new DoubleSetting("Shockwaves", 0.0, 3.0, 2.0, 1.0);
      this.energyPillarSetting = new BooleanSetting("Energy Pillar", true);
      this.pillarHeightSetting = new DoubleSetting("Pillar Height", 0.4, 3.5, 1.8, 0.05);
      this.sparksSetting = new BooleanSetting("Sparks", true);
      this.sparkCountSetting = new DoubleSetting("Spark Count", 8.0, 120.0, 48.0, 1.0);
      this.embersSetting = new BooleanSetting("Embers", true);
      this.bloomSetting = new BooleanSetting("Bloom", true);
      this.bloomStrengthSetting = new DoubleSetting("Bloom Strength", 0.0, 3.0, 1.0, 0.05);
      this.bloomRadiusSetting = new DoubleSetting("Bloom Radius", 0.5, 3.0, 1.0, 0.05);
      this.groundOffsetSetting = new DoubleSetting("Ground Offset", 0.0, 1.0, 0.0, 0.01);
      this.throughWallsSetting = new BooleanSetting("Through Walls", false);
      this.jumpCircleEffectArrayDeque = new ArrayDeque<>();
      this.jumpCircleRenderer = new JumpCircleRenderer();
      this.jumpCircleRenderStyle = new JumpCircleRenderStyle();
      this.jumpCircleStyle = new JumpCircleStyle();
      this.jumpCircleInstanceList2 = new ArrayList<>();
      this.jumpCircleInstanceList = new ArrayList<>();
      this.floatArray3 = new float[4608];
      this.random = new Random();
      this.timestampNanos = System.nanoTime();
      this.addSettings(
         new Setting[]{
            this.modeSetting,
            this.colorModeSetting,
            this.customColorSetting,
            this.sizeSetting,
            this.durationSSetting,
            this.intensitySetting,
            this.magicCircleSetting,
            this.shockwavesSetting,
            this.energyPillarSetting,
            this.pillarHeightSetting,
            this.sparksSetting,
            this.sparkCountSetting,
            this.embersSetting,
            this.bloomSetting,
            this.bloomStrengthSetting,
            this.bloomRadiusSetting,
            this.groundOffsetSetting,
            this.throughWallsSetting
         }
      );
      this.customColorSetting.setVisibility(() -> this.equals3());
      this.magicCircleSetting.setVisibility(() -> this.equals5());
      this.shockwavesSetting.setVisibility(() -> this.equals4());
      this.energyPillarSetting.setVisibility(() -> this.equals());
      this.pillarHeightSetting.setVisibility(() -> this.computeBoolean2());
      this.sparkCountSetting.setVisibility(() -> this.computeBoolean());
      this.embersSetting.setVisibility(() -> this.equals2());
      this.bloomStrengthSetting.setVisibility(() -> this.bloomSetting.getValue());
      this.bloomRadiusSetting.setVisibility(() -> this.bloomSetting.getValue());
   }

   @EventHandler
   private void onRender3D(Render3DEvent render3DEvent) {
      if (!this.isWorldUnavailable() && !this.jumpCircleEffectArrayDeque.isEmpty()) {
         if (!GlCapabilities.checkCondition5()) {
            this.jumpCircleStyle.floatState4 = this.sizeSetting.floatValue();
            this.jumpCircleStyle.floatState = this.durationSSetting.floatValue();
            this.jumpCircleStyle.floatState3 = this.pillarHeightSetting.floatValue();
            this.jumpCircleStyle.floatState2 = this.intensitySetting.floatValue();
            this.jumpCircleStyle.intState = this.shockwavesSetting.intValue();
            this.jumpCircleStyle.booleanState2 = this.magicCircleSetting.getValue();
            this.jumpCircleStyle.booleanState = this.energyPillarSetting.getValue();
            float floatValue = JumpCircleGeometry.max2(this.jumpCircleStyle);
            long longValue = System.nanoTime();
            Vec3d vec3d = Render3D.createVec3d();
            this.jumpCircleInstanceList2.clear();
            int intValue = 0;
            Iterator iterator = this.jumpCircleEffectArrayDeque.iterator();

            while (iterator.hasNext()) {
               JumpCircleEffect jumpCircleEffect = (JumpCircleEffect)iterator.next();
               float floatValue2 = (float)(longValue - jumpCircleEffect.start()) / 1.0E9F;
               if (floatValue2 > floatValue) {
                  iterator.remove();
               } else {
                  float floatState2 = (float)(jumpCircleEffect.x() - vec3d.x);
                  float floatState16 = (float)(jumpCircleEffect.y() - vec3d.y);
                  float floatState11 = (float)(jumpCircleEffect.z() - vec3d.z);

                  while (this.jumpCircleInstanceList.size() <= this.jumpCircleInstanceList2.size()) {
                     this.jumpCircleInstanceList.add(new JumpCircleInstance());
                  }

                  JumpCircleInstance jumpCircleInstance = this.jumpCircleInstanceList.get(this.jumpCircleInstanceList2.size());
                  this.jumpCircleStyle.booleanState3 = jumpCircleEffect.water();
                  if (JumpCircleGeometry.testJumpCircleStyle(this.jumpCircleStyle, floatValue2, jumpCircleEffect.seed(), floatState2, floatState16, floatState11, jumpCircleInstance)) {
                     this.jumpCircleInstanceList2.add(jumpCircleInstance);
                  }

                  if (jumpCircleEffect.water()) {
                     intValue = JumpCircleGeometry.computeIntForJumpCircleStyle(this.jumpCircleStyle, floatValue2, jumpCircleEffect.sparks(), floatState2, floatState16, floatState11, this.floatArray3, intValue);
                  } else {
                     intValue = JumpCircleGeometry.computeIntForJumpCircleStyle2(this.jumpCircleStyle, floatValue2, jumpCircleEffect.sparks(), floatState2, floatState16, floatState11, this.floatArray3, intValue);
                     intValue = JumpCircleGeometry.computeIntForJumpCircleStyle3(this.jumpCircleStyle, floatValue2, jumpCircleEffect.embers(), floatState2, floatState16, floatState11, this.floatArray3, intValue);
                  }
               }
            }

            if (!this.jumpCircleInstanceList2.isEmpty() || intValue != 0) {
               Color color = this.computeColorForThemeSnapshot(ClickGuiModule.computeThemeSnapshot(), System.currentTimeMillis());
               if (this.jumpCircleRenderer.getBooleanState() || !this.testColor(color, intValue)) {
                  this.updateStateForColor(color);
               }
            }
         }
      }
   }

   private Color computeColorForThemeSnapshot(ThemeSnapshot themeSnapshot, long longValue) {
      String selected = this.colorModeSetting.getSelected();
      switch (selected.hashCode()) {
         case -1656737386:
            if (selected.equals("Rainbow")) {
               return Color.getHSBColor((float)(longValue % 8000L) / 8000.0F, 0.65F, 1.0F);
            }
            break;
         case 745332651:
            if (selected.equals("Mochi Theme")) {
               return ThemeSnapshot.computeColorForColor(themeSnapshot.getAccent2());
            }
            break;
         case 2029746065:
            if (selected.equals("Custom")) {
               return this.customColorSetting.getValue();
            }
      }

      return new Color(244, 248, 255);
   }

   private Boolean equals() {
      return this.modeSetting.equals("Burst");
   }

   private Boolean equals2() {
      return this.modeSetting.equals("Burst");
   }

   private Boolean computeBoolean() {
      return this.modeSetting.equals("Burst") && this.sparksSetting.getValue();
   }

   private Boolean equals3() {
      return this.colorModeSetting.equals("Custom");
   }

   @Override
   public void onDisable() {
      super.onDisable();
      this.jumpCircleEffectArrayDeque.clear();
      if (RenderSystem.isOnRenderThread()) {
         this.jumpCircleRenderer.updateState5();
      } else {
         mc.execute(() -> this.jumpCircleRenderer.updateState5());
      }
   }

   private boolean testColor(Color color, int intValue) {
      Framebuffer framebuffer = mc.getFramebuffer();
      if (framebuffer != null && framebuffer.getColorAttachment() instanceof GlTexture var4 && framebuffer.getDepthAttachment() instanceof GlTexture var5) {
         this.jumpCircleRenderStyle.floatState2 = (float)color.getRed() / 255.0F;
         this.jumpCircleRenderStyle.floatState5 = (float)color.getGreen() / 255.0F;
         this.jumpCircleRenderStyle.floatState4 = (float)color.getBlue() / 255.0F;
         this.jumpCircleRenderStyle.booleanState2 = this.throughWallsSetting.getValue();
         this.jumpCircleRenderStyle.booleanState = this.bloomSetting.getValue();
         this.jumpCircleRenderStyle.floatState3 = this.bloomStrengthSetting.floatValue();
         this.jumpCircleRenderStyle.floatState = this.bloomRadiusSetting.floatValue();
         this.jumpCircleRenderStyle.floatState6 = (float)(System.nanoTime() - this.timestampNanos) / 1.0E9F;
         this.jumpCircleRenderer.updateStateForList2(this.jumpCircleInstanceList2, this.floatArray3, intValue, this.jumpCircleRenderStyle, Render3D.getMatrix4f(), var4.getGlId(), var5.getGlId(), framebuffer.textureWidth, framebuffer.textureHeight);
         return !this.jumpCircleRenderer.getBooleanState();
      } else {
         return false;
      }
   }

   private Boolean computeBoolean2() {
      return this.modeSetting.equals("Burst") && this.energyPillarSetting.getValue();
   }

   private void updateStateForColor(Color color) {
      Vec3d vec3d = Render3D.createVec3d();
      int rgb = color.getRGB();

      for (JumpCircleInstance jumpCircleInstance : this.jumpCircleInstanceList2) {
         if (jumpCircleInstance.floatState14 > 0.002F && jumpCircleInstance.floatState10 >= 0.05F) {
            Render3D.updateState2(
               (double)jumpCircleInstance.floatState2 + vec3d.x,
               (double)jumpCircleInstance.floatState16 + vec3d.y,
               (double)jumpCircleInstance.floatState11 + vec3d.z,
               (double)jumpCircleInstance.floatState10,
               (double)jumpCircleInstance.floatState5,
               (double)jumpCircleInstance.floatState5 * 2.0,
               Render3D.computeInt2(rgb, (int)(235.0F * Math.min(1.0F, jumpCircleInstance.floatState14))),
               64,
               this.throughWallsSetting.getValue()
            );
         }

         for (int intValue = 0; intValue < jumpCircleInstance.intState; intValue++) {
            int intValue2 = (int)(235.0F * Math.min(1.0F, jumpCircleInstance.floatArray[intValue]));
            if (intValue2 > 2 && !(jumpCircleInstance.floatArray2[intValue] < 0.05F)) {
               Render3D.updateState2(
                  (double)jumpCircleInstance.floatState2 + vec3d.x,
                  (double)jumpCircleInstance.floatState16 + vec3d.y,
                  (double)jumpCircleInstance.floatState11 + vec3d.z,
                  (double)jumpCircleInstance.floatArray2[intValue],
                  (double)jumpCircleInstance.floatArray3[intValue] * 1.5,
                  (double)jumpCircleInstance.floatArray3[intValue] * 5.0,
                  Render3D.computeInt2(rgb, intValue2),
                  64,
                  this.throughWallsSetting.getValue()
               );
            }
         }
      }
   }

   @EventHandler
   private void onJump(JumpEvent jumpEvent) {
      if (mc.player != null && mc.world != null) {
         if (!mc.player.isTouchingWater() && !mc.player.isGliding() && !mc.player.isClimbing()) {
            boolean booleanValue = this.modeSetting.equals("Water");
            float[] floatArray;
            float[] floatArray2;
            if (booleanValue) {
               floatArray = this.sparksSetting.getValue() ? JumpCircleGeometry.computeFloatArrayForRandom2(this.random, 14) : new float[0];
               floatArray2 = new float[0];
            } else {
               floatArray = this.sparksSetting.getValue() ? JumpCircleGeometry.computeFloatArrayForRandom(this.random, this.sparkCountSetting.intValue()) : new float[0];
               floatArray2 = this.embersSetting.getValue() && this.energyPillarSetting.getValue() ? JumpCircleGeometry.computeFloatArrayForRandom3(this.random, 22) : new float[0];
            }

            this.jumpCircleEffectArrayDeque
               .addLast(
                  new JumpCircleEffect(
                     mc.player.getX(), mc.player.getY() + this.groundOffsetSetting.getValue() + 0.015, mc.player.getZ(), System.nanoTime(), this.random.nextFloat(), booleanValue, floatArray, floatArray2
                  )
               );

            while (this.jumpCircleEffectArrayDeque.size() > 10) {
               this.jumpCircleEffectArrayDeque.removeFirst();
            }
         }
      }
   }

   private Boolean equals4() {
      return this.modeSetting.equals("Burst");
   }

   private Boolean equals5() {
      return this.modeSetting.equals("Burst");
   }
}
