package cc.mochi;

import cc.mochi.event.impl.player.TickEvent;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.util.math.MathHelper;

public class FullBrightModule extends Module {
   private Double doubleValue;
   private final ChoiceSetting modeSetting = new ChoiceSetting("Mode", "Both", "Both", "Gamma", "Night Vision");
   private final DoubleSetting fadeDurationMsSetting;

   private boolean booleanState;
   private long timestampMillis;
   private final DoubleSetting gammaLevelSetting = new DoubleSetting("Gamma Level", 0.1, 1.0, 1.0, 0.05);
   private final BooleanSetting smoothFadeSetting = new BooleanSetting("Smooth Fade", true);

   @Override
   public void onEnable() {
      super.onEnable();
      this.setDisplaySuffix(this.modeSetting.getSelected());
      this.doubleValue = this.computeDouble();
      this.timestampMillis = System.currentTimeMillis();
      this.booleanState = true;
      if (!this.isWorldUnavailable() && !this.smoothFadeSetting.getValue() && !this.modeSetting.equals("Night Vision")) {
         this.updateState(this.gammaLevelSetting.floatValue());
      }
   }

   @Override
   public void onDisable() {
      super.onDisable();
      this.booleanState = false;
      if (this.doubleValue != null) {
         this.updateState(this.doubleValue.floatValue());
         this.doubleValue = null;
      }
   }

   public FullBrightModule() {
      super("Full Bright", "Removes darkness with a smooth light ramp", ModuleCategory.RENDER);
      this.fadeDurationMsSetting = new DoubleSetting("Fade Duration (ms)", 100.0, 2000.0, 450.0, 50.0);
      this.addSettings(new Setting[]{this.modeSetting, this.gammaLevelSetting, this.smoothFadeSetting, this.fadeDurationMsSetting});
      this.gammaLevelSetting.setVisibility(() -> this.computeBoolean());
      this.fadeDurationMsSetting.setVisibility(() -> this.smoothFadeSetting.getValue());
   }

   public boolean checkCondition() {
      return this.isEnabled() && !this.modeSetting.equals("Gamma");
   }

   private void updateState(float floatValue) {
      if (mc != null && mc.options != null) {
         try {
            SimpleOption gamma = mc.options.getGamma();
            gamma.setValue(MathHelper.clamp((double)floatValue, 0.0, 1.0));
         } catch (Throwable failure) {
         }
      }
   }

   private Boolean computeBoolean() {
      return !this.modeSetting.equals("Night Vision");
   }

   private Double computeDouble() {
      try {
         return (Double)mc.options.getGamma().getValue();
      } catch (Throwable failure) {
         return 0.0;
      }
   }

   @EventHandler
   private void onTick(TickEvent tickEvent) {
      if (!this.isWorldUnavailable() && this.booleanState && this.smoothFadeSetting.getValue() && !this.modeSetting.equals("Night Vision")) {
         float floatValue = MathHelper.clamp((float)(System.currentTimeMillis() - this.timestampMillis) / (float)this.fadeDurationMsSetting.intValue(), 0.0F, 1.0F);
         float floatValue2 = 1.0F - (1.0F - floatValue) * (1.0F - floatValue);
         float floatValue3 = this.doubleValue == null ? 0.0F : this.doubleValue.floatValue();
         this.updateState(MathHelper.lerp(floatValue2, floatValue3, this.gammaLevelSetting.floatValue()));
         if (floatValue >= 1.0F) {
            this.booleanState = false;
         }
      }
   }
}
