package cc.mochi;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;

public class BlocksAccess {
   public static Block getRAIL() {
      return Blocks.RAIL;
   }
}
