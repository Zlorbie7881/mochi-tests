package cc.mochi;

import java.awt.Color;
import java.util.List;
import java.util.Locale;

public final class FriendsPanel extends UiPanel {
   private List<FriendEntry> friendEntryList;
   private final TextInputModel textInputModel = new TextInputModel(16);

   private final ScrollModel scrollModel = new ScrollModel();

   private void updateFriendEntryList() {
      this.friendEntryList = List.copyOf(FriendManager.copyOf());
   }

   @Override
   public boolean checkCondition() {
      if (this.textInputModel.getBooleanState2()) {
         this.textInputModel.updateState3(false);
         return true;
      } else {
         return false;
      }
   }

   public static TextInputModel getTextInputModel(FriendsPanel friendsPanel) {
      return friendsPanel.textInputModel;
   }

   private void updateStateForFriendEntry(FriendEntry friendEntry, String string) {
      if (friendEntry.getUuid2() != null) {
         FriendManager.updateStateForUUID3(friendEntry.getUuid2());
      } else {
         FriendManager.updateState(string);
      }

      this.updateState14("Removed " + string, false);
      ClientSounds.updateState2();
      this.updateFriendEntryList();
   }

   @Override
   public void updateState6() {
      getTextInputModel(this).updateState3(false);
   }

   @Override
   public boolean checkCondition2(char charValue) {
      return this.textInputModel.checkCondition3(charValue);
   }

   @Override
   protected float computeFloat2(float floatValue) {
      return Math.min(floatValue - 60.0F, 300.0F);
   }

   @Override
   protected float computeFloat() {
      return 320.0F;
   }

   public static List<FriendEntry> getFriendEntryList(FriendsPanel friendsPanel) {
      return friendsPanel.friendEntryList;
   }

   private void updateState() {
      String string = this.textInputModel.toString().trim();
      if (!string.isEmpty()) {
         if (FriendManager.checkCondition(string)) {
            this.updateState14(string + " is already a friend", true);
         } else {
            FriendManager.updateState2(string);
            this.updateState14("Added " + string, false);
         }

         getTextInputModel(this).updateState2();
         this.updateFriendEntryList();
      }
   }

   public FriendsPanel() {
      super("Friends", "Targeting modules leave these players alone");
      this.friendEntryList = List.of();
      this.updateFriendEntryList();
   }

   @Override
   public boolean checkCondition3(int intValue, boolean booleanValue) {
      if (!getTextInputModel(this).getBooleanState2()) {
         return false;
      } else if (intValue != 257 && intValue != 335) {
         if (intValue == 256) {
            getTextInputModel(this).updateState3(false);
            return true;
         } else {
            return getTextInputModel(this).checkCondition(intValue, booleanValue);
         }
      } else {
         if (!this.textInputModel.toString().isBlank()) {
            ClientSounds.updateState3();
            this.updateState();
         }

         return true;
      }
   }

   @Override
   protected void updateStateForUiContext(UiContext uiContext, Rect rect, boolean booleanValue, float opacity) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      float floatValue2 = ButtonWidgets.computeFloatForUiContext(uiContext, "Add", null);
      Rect rect2 = new Rect(rect.getX(), rect.getY(), rect.getWidth() - floatValue2 - 6.0F, 24.0F);
      TextInputWidget.updateStateForUiContext(uiContext, "friends.name", rect2, UiLayer.MODAL, this.textInputModel, "Player name", Icon.PLUS, opacity);
      ButtonWidgets.updateStateForUiContext(
         uiContext,
         "friends.add",
         new Rect(rect2.right() + 6.0F, rect.getY(), floatValue2, 24.0F),
         UiLayer.MODAL,
         ButtonVariant.PRIMARY,
         "Add",
         null,
         !this.textInputModel.toString().isBlank(),
         opacity,
         booleanValue ? () -> this.updateState() : null
      );
      Rect rect3 = new Rect(rect.getX(), rect.getY() + 24.0F + 10.0F, rect.getWidth(), rect.getHeight() - 24.0F - 10.0F);
      if (getFriendEntryList(this).isEmpty()) {
         EmptyStateWidget.updateStateForUiContext(uiContext, rect3, Icon.USERS, "No friends added", "Type a player's name above. Aim and combat modules will never pick them.", opacity);
      } else {
         float floatValue3 = this.scrollModel.update(uiContext, (float)getFriendEntryList(this).size() * 28.0F, rect3.getHeight());
         uiContext.getInputRouter().addScrollRegion(rect3, UiLayer.MODAL, wheelDelta -> this.scrollModel.scroll(wheelDelta));
         uiContext.getUiRenderContext().pushClip(rect3.getX() - 2.0F, rect3.getY(), rect3.getWidth() + 4.0F, rect3.getHeight());

         for (int intValue = 0; intValue < getFriendEntryList(this).size(); intValue++) {
            FriendEntry friendEntry = getFriendEntryList(this).get(intValue);
            String text = friendEntry.getName() != null ? friendEntry.getName() : String.valueOf(friendEntry.getUuid2());
            Rect rect4 = new Rect(rect3.getX(), rect3.getY() + (float)intValue * 28.0F - floatValue3, rect3.getWidth(), 25.0F);
            if (!(rect4.bottom() < rect3.getY()) && !(rect4.getY() > rect3.bottom())) {
               boolean hovered = booleanValue && uiContext.isHovered(rect4.intersection(rect3), UiLayer.MODAL);
               float floatValue4 = uiContext.animateHover("friends.row." + text, hovered);
               PanelRenderer.updateStateForUiContext7(uiContext, rect4, 8.0F, floatValue4, opacity);
               Color color = computeColor(text);
               uiContext.getUiRenderContext().fillCircle(rect4.getX() + 15.0F, rect4.centerY(), 8.0F, UiContext.multiplyAlpha(color, opacity));
               uiContext.drawCenteredText(text.isEmpty() ? "?" : text.substring(0, 1).toUpperCase(SettingUiAccess.getROOT()), rect4.getX() + 15.0F, rect4.centerY(), TextStyle.CAPTION, UiContext.multiplyAlpha(SettingUiAccess.getWHITE(), opacity));
               uiContext.drawVerticallyCenteredText(uiContext.ellipsize(text, TextStyle.STRONG, rect4.getWidth() - 70.0F), rect4.getX() + 30.0F, rect4.centerY(), TextStyle.STRONG, UiContext.multiplyAlpha(themeSnapshot2.getPrimaryText(), opacity));
               Rect rect5 = new Rect(rect4.right() - 24.0F, rect4.centerY() - 9.0F, 18.0F, 18.0F);
               ButtonWidgets.updateStateForUiContext2(uiContext, "friends.remove." + text, rect5, UiLayer.MODAL, Icon.CLOSE, opacity * Math.max(0.4F, floatValue4), booleanValue ? () -> this.updateStateForFriendEntry(friendEntry, text) : null);
            }
         }

         uiContext.getUiRenderContext().popClip();
         this.scrollModel.drawScrollbar(uiContext, rect3, (float)getFriendEntryList(this).size() * 28.0F, opacity);
      }
   }

   private static Color computeColor(String string) {
      float floatValue = (float)(string.toLowerCase(Locale.ROOT).hashCode() & 65535) / 65535.0F;
      return Color.getHSBColor(floatValue, 0.42F, 0.78F);
   }
}
