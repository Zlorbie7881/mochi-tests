package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.util.math.Vec3d;

public class MinecraftClientAccess2 {
   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static GameOptions getOptions(MinecraftClient minecraftClient) {
      return minecraftClient.options;
   }

   public static KeyBinding getBackKey(GameOptions gameOptions) {
      return gameOptions.backKey;
   }

   public static double getZ(Vec3d vec3d) {
      return vec3d.z;
   }

   public static KeyBinding getForwardKey(GameOptions gameOptions) {
      return gameOptions.forwardKey;
   }

}
