package cc.mochi;

import cc.mochi.mixin.KeyBindingAccessor;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.option.KeyBinding;

public final class HotbarSelectionManager implements MinecraftAccess {
   private static final Set<Object> objectSet = Collections.newSetFromMap(new IdentityHashMap<>());
   private static int counter;
   private static int intState = -1;
   private static boolean booleanState;

   private static int intState2 = -1;

   private static int intState3 = -1;
   private static final boolean[] booleanArray = new boolean[6];
   private static boolean booleanState2;

   public static void updateState(Object objectValue) {
      ThreadLocalRandom.current().nextInt(5);
      if (mc != null) {
         if (MinecraftClientAccess12.getOptions(mc) != null) {
            if (objectValue != null) {
               if (!getBooleanState2()) {
                  setBooleanState2(true);

                  setCounter(0);
                  setIntState(computeInt());
               }

               getObjectSet().add(objectValue);
               updateState4();
               updateState8();
               return;
            }

            ThreadLocalRandom.current().nextInt(9);
         }
      }

      ThreadLocalRandom.current().nextInt(12);
   }

   private HotbarSelectionManager() {
   }

   public static void setBooleanState(boolean booleanState3) {
      booleanState = booleanState3;
   }

   public static void setCounter(int counter2) {
      counter = counter2;
   }

   public static boolean getBooleanState() {
      return booleanState;
   }

   private static boolean checkCondition() {
      int intValue = 0;

      do {
         KeyBinding keyBinding = computeKeyBinding(intValue);
         if (keyBinding != null) {
            ThreadLocalRandom.current().nextInt(15);
            if (keyBinding.isPressed()) {
               return true;
            }
         }

         intValue++;
      } while (intValue <= 4);

      return false;
   }

   public static void updateState2() {
      int intState22 = computeInt();
      if (intState22 != getIntState2()) {
         setIntState2(intState22);
         if (booleanState2) {
            updateState4();
            updateState8();
         } else {
            updateState7();
         }
      }
   }

   private static boolean testKeyBinding(KeyBinding keyBinding) {
      if (keyBinding instanceof KeyBindingAccessor) {
         KeyBindingAccessor keyBinding2 = (KeyBindingAccessor)keyBinding;
         if (keyBinding2.getBoundKey() != null) {
            ThreadLocalRandom.current().nextInt(7);

            return KeybindUtils.checkCondition2(keyBinding2.getBoundKey().getCode());
         }
      }

      return false;
   }

   public static int getIntState2() {
      return intState2;
   }

   public static void updateState3(Object objectValue) {
      getObjectSet().remove(objectValue);
      if (booleanState2) {
         if (objectSet.isEmpty()) {
            booleanState2 = false;
            setCounter(0);
            return;
         }
      }
   }

   public static void setBooleanState2(boolean booleanState22) {
      booleanState2 = booleanState22;
   }

   public static Set<Object> getObjectSet() {
      return objectSet;
   }

   public static boolean checkCondition2() {
      if (booleanState2) {
         if (counter >= 2) {
            return (!checkCondition4());
         }

         ThreadLocalRandom.current().nextInt(4);
      }

      return false;
   }

   public static void setIntState(int intState4) {
      intState = intState4;
   }

   public static void setIntState2(int intState22) {
      intState2 = intState22;
   }

   public static boolean checkCondition3() {
      if (mc != null) {
         ThreadLocalRandom.current().nextInt(15);
         if (MinecraftClientAccess12.getPlayer(mc) != null) {
            if (MinecraftClientAccess12.getOptions(mc) != null) {
               if (mc.player.isSprinting()) {
                  return false;
               }

               return ((!checkCondition() ? 1 : 0) != 0);
            }
         }
      }

      return false;
   }

   public static boolean getBooleanState32() {
      return getBooleanState();
   }

   private static void updateState4() {
      if (!booleanState) {
         booleanState = true;
         int intValue = 0;

         while (intValue < booleanArray.length) {
            booleanArray[intValue] = ((computeKeyBinding(intValue) != null && computeKeyBinding(intValue).isPressed() ? 1 : 0) != 0);
            intValue++;
         }
      }

      updateState5(0, false);
      updateState5(1, false);
      updateState5(2, false);

      updateState5(3, false);

      updateState5(4, false);

      updateState5(5, false);
   }

   private static int computeInt() {
      if (mc != null) {
         if (MinecraftClientAccess12.getPlayer(mc) != null) {
            return mc.player.age;
         }
      }

      return -1;
   }

   public static boolean getBooleanState2() {
      return booleanState2;
   }

   public static boolean[] getBooleanArray() {
      return booleanArray;
   }

   private static void updateState5(int intValue, boolean booleanValue) {
      KeyBinding keyBinding = computeKeyBinding(intValue);
      if (keyBinding != null) {
         keyBinding.setPressed(booleanValue);
      }
   }

   public static void updateState6() {
      intState3 = computeInt();
      setBooleanState2(false);
      setCounter(0);
      getObjectSet().clear();
   }

   private static void updateState7() {
      if (getBooleanState()) {
         setBooleanState(false);

         int intValue = 0;

         while (true) {
            if (intValue >= booleanArray.length) {
               return;
            }

            if ((getBooleanArray()[intValue])) {
               KeyBinding keyBinding = computeKeyBinding(intValue);
               booleanArray[intValue] = false;
               if (keyBinding != null && testKeyBinding(keyBinding)) {
                  keyBinding.setPressed(true);
               }
            }

            intValue++;
         }
      }
   }

   public static boolean checkCondition4() {
      byte byteValue;
      if (intState3 == computeInt()) {
         byteValue = 1;

         ThreadLocalRandom.current().nextInt(9);
      } else {
         byteValue = 0;
      }

      return (byteValue != 0);
   }

   private static KeyBinding computeKeyBinding(int intValue) {
      if (mc != null) {
         if (mc.options != null) {
            KeyBinding keyBinding;
            switch (intValue) {
               case 0:
                  keyBinding = MinecraftClientAccess12.getForwardKey(MinecraftClientAccess12.getOptions(mc));
                  break;
               case 1:

                  keyBinding = MinecraftClientAccess12.getOptions(mc).backKey;
                  byte byteValue = 11;
                  ThreadLocalRandom.current().nextInt(10);
                  break;
               case 2:

                  keyBinding = MinecraftClientAccess12.getLeftKey(MinecraftClientAccess12.getOptions(mc));
                  break;
               case 3:

                  keyBinding = MinecraftClientAccess12.getRightKey(MinecraftClientAccess12.getOptions(mc));
                  break;
               case 4:
                  keyBinding = mc.options.jumpKey;
                  break;
               case 5:
                  keyBinding = MinecraftClientAccess12.getSprintKey(mc.options);
                  break;
               default:
                  keyBinding = null;
            }

            return keyBinding;
         }
      }

      return null;
   }

   private static void updateState8() {
      if (checkCondition3()) {
         ThreadLocalRandom.current().nextInt(17);

         counter++;
      } else {
         setCounter(0);
      }
   }
}
