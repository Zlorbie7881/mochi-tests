package cc.mochi;

import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.component.ComponentType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ChargedProjectilesComponent;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Hand;
import net.minecraft.util.ActionResult.SwingSource;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;

public class MinecraftClientAccess53 {
   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static ClientWorld getWorld(MinecraftClient minecraftClient) {
      return minecraftClient.world;
   }

   public static TagKey<Item> getWOODEN_SLABS() {
      return ItemTags.WOODEN_SLABS;
   }

   public static Hand getMAIN_HAND() {
      return Hand.MAIN_HAND;
   }

   public static Type getBLOCK() {
      return Type.BLOCK;
   }

   public static double getMinX(Box box) {
      return box.minX;
   }

   public static ClientPlayerInteractionManager getInteractionManager(MinecraftClient minecraftClient) {
      return minecraftClient.interactionManager;
   }

   public static ActionPriority getHIGH() {
      return ActionPriority.HIGH;
   }

   public static double getMaxX(Box box) {
      return box.maxX;
   }

   public static Screen getCurrentScreen(MinecraftClient minecraftClient) {
      return minecraftClient.currentScreen;
   }

   public static Item getFIREWORK_ROCKET() {
      return Items.FIREWORK_ROCKET;
   }

   public static Direction getUP() {
      return Direction.UP;
   }

   public static double getMinY(Box box) {
      return box.minY;
   }

   public static TagKey<Block> getFIRE() {
      return BlockTags.FIRE;
   }

   public static double getMinZ(Box box) {
      return box.minZ;
   }

   public static SwingSource getCLIENT() {
      return SwingSource.CLIENT;
   }

   public static TagKey<Block> getRAILS() {
      return BlockTags.RAILS;
   }

   public static ComponentType<ChargedProjectilesComponent> getCHARGED_PROJECTILES() {
      return DataComponentTypes.CHARGED_PROJECTILES;
   }

}
