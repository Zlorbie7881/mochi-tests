package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.collection.DefaultedList;

public class InventorySlotAccess {
   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static int getId(Slot slot) {
      return slot.id;
   }

   public static SlotActionType getPICKUP() {
      return SlotActionType.PICKUP;
   }

   public static int getY(Slot slot) {
      return slot.y;
   }

   public static DefaultedList<Slot> getSlots(ScreenHandler screenHandler) {
      return screenHandler.slots;
   }

   public static int getSyncId(ScreenHandler screenHandler) {
      return screenHandler.syncId;
   }

   public static ClientPlayerInteractionManager getInteractionManager(MinecraftClient minecraftClient) {
      return minecraftClient.interactionManager;
   }

}
