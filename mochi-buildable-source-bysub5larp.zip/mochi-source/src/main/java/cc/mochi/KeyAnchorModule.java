package cc.mochi;

import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.mixin.MinecraftClientAccessor;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.BlockState;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public final class KeyAnchorModule extends Module {
   private boolean booleanState;
   private boolean booleanState2;

   private boolean booleanState3;

   private boolean booleanState4;

   private final DoubleSetting delayMSSetting;
   private final DoubleSetting restoreDelayMsSetting;
   private final KeybindSetting activationKeySetting;
   private int intState;
   private long longState;

   private final Stopwatch stopwatch;

   public static void setIntState(KeyAnchorModule keyAnchorModule, int intState2) {
      keyAnchorModule.intState = intState2;
   }

   private boolean testSetting(Setting setting) {
      if (setting instanceof KeybindSetting) {
         if (!setting.equals(this.activationKeySetting)) {
            return true;
         }
      }

      return false;
   }

   public static int getIntState(KeyAnchorModule keyAnchorModule) {
      return keyAnchorModule.intState;
   }

   public static void setLongState(KeyAnchorModule keyAnchorModule, long longState2) {
      keyAnchorModule.longState = longState2;
   }

   public static Stopwatch getStopwatch(KeyAnchorModule keyAnchorModule) {
      return keyAnchorModule.stopwatch;
   }

   private void updateState() {
      HitResult crosshairTarget = MinecraftClientAccess22.getCrosshairTarget(mc);
      if (crosshairTarget instanceof BlockHitResult) {
         BlockHitResult crosshairTarget2 = (BlockHitResult)crosshairTarget;
         BlockPos blockPos = crosshairTarget2.getBlockPos();
         BlockState blockState = mc.world.getBlockState(blockPos);
         if (!blockState.isAir()) {
            if (blockState.getBlock() != MinecraftClientAccess22.getRESPAWN_ANCHOR()) {
               BlockPos blockPos2 = blockPos.offset(crosshairTarget2.getSide());
               if (this.testBlockPos(blockPos2)) {
                  ThreadLocalRandom.current().nextInt(14);
                  if (!this.booleanState3 && this.testItem(Items.RESPAWN_ANCHOR)) {
                     this.booleanState3 = true;
                     ((MinecraftClientAccessor)mc).invokeDoItemUse();
                  }
               }
            } else {
               int intValue = (Integer)blockState.get(MinecraftClientAccess22.getCHARGES());
               if (intValue > 0) {
                  if (this.testItem(Items.TOTEM_OF_UNDYING) || this.checkCondition()) {
                     ((MinecraftClientAccessor)mc).invokeDoItemUse();
                     this.updateState3();
                     setBooleanState3(this, true);
                  }
               } else if (this.testItem(Items.GLOWSTONE)) {
                  ((MinecraftClientAccessor)mc).invokeDoItemUse();

                  setBooleanState3(this, true);
               } else {
               }
            }
         }
      }
   }

   public static KeybindSetting getActivationKeySetting(KeyAnchorModule keyAnchorModule) {
      return keyAnchorModule.activationKeySetting;
   }

   private void updateState2() {
      if ((getBooleanState2(this))) {
         if (this.intState != -1) {
            mc.player.getInventory().setSelectedSlot(getIntState(this));
         }

         this.booleanState2 = false;

         setIntState(this, -1);

         setBooleanState(this, false);
         this.longState = 0L;
      }
   }

   @Override
   public void onDisable() {
      this.updateState2();
      super.onDisable();
   }

   public static boolean getBooleanState4(KeyAnchorModule keyAnchorModule) {
      return keyAnchorModule.booleanState4;
   }

   private void updateState3() {
      if (getIntState(this) != -1) {
         this.booleanState = true;
         setLongState(this, System.currentTimeMillis() + (long)this.restoreDelayMsSetting.intValue());
      }
   }

   public static boolean getBooleanState2(KeyAnchorModule keyAnchorModule) {
      return keyAnchorModule.booleanState2;
   }

   public static void setBooleanState(KeyAnchorModule keyAnchorModule, boolean booleanState5) {
      keyAnchorModule.booleanState = booleanState5;
   }

   @Override
   public void onEnable() {
      this.booleanState4 = false;
      this.booleanState2 = false;
      this.intState = -1;
      this.booleanState3 = false;
      setBooleanState(this, false);

      this.longState = (0L);
      getStopwatch(this).updateTimestampMillis();
      super.onEnable();
   }

   public static void setBooleanState3(KeyAnchorModule keyAnchorModule, boolean booleanState32) {
      keyAnchorModule.booleanState3 = booleanState32;
   }

   public static void setBooleanState2(KeyAnchorModule keyAnchorModule, boolean booleanState22) {
      keyAnchorModule.booleanState2 = booleanState22;
   }

   private boolean testBlockPos(BlockPos blockPos) {
      if (mc.world != null) {
         if (mc.player != null) {
            double doubleValue = MinecraftClientAccess22.getPlayer(mc).getEntityPos().distanceTo(Vec3d.ofCenter(blockPos));

            if (doubleValue > (4.5)) {
               return false;
            }

            if (!mc.world.getBlockState(blockPos).isAir()) {
               return false;
            }

            ThreadLocalRandom.current().nextInt(9);

            BlockPos blockPos2 = MinecraftClientAccess22.getPlayer(mc).getBlockPos();
            return ((!blockPos.equals(blockPos2) && !blockPos.equals(blockPos2.up()) ? 1 : 0) != 0);
         }

         ThreadLocalRandom.current().nextInt(13);
      }

      return false;
   }

   private void updateState4() {
      if (this.intState != -1) {
         MinecraftClientAccess22.getPlayer(mc).getInventory().setSelectedSlot(getIntState(this));
      }
   }

   public KeyAnchorModule() {
      super("Key Anchor", "Automatically places and explodes respawn anchors for PvP", -1, ModuleCategory.COMBAT);

      this.activationKeySetting = new KeybindSetting("Activation Key", 88, false);

      this.delayMSSetting = new DoubleSetting("Delay (MS)", (1.0), (500.0), (50.0), 1.0);

      this.restoreDelayMsSetting = new DoubleSetting("Restore Delay (ms)", (0.0), (1000.0), (100.0), 1.0);
      this.stopwatch = new Stopwatch();
      this.booleanState4 = false;
      this.booleanState2 = false;

      this.intState = -1;

      this.booleanState3 = false;
      this.booleanState = false;

      this.longState = (0L);
      Setting[] settingArray = new Setting[3];

      settingArray[0] = this.activationKeySetting;
      settingArray[1] = this.delayMSSetting;
      settingArray[2] = this.restoreDelayMsSetting;
      this.addSettings(settingArray);
      this.getSettings().removeIf(objectValue -> this.testSetting((Setting)objectValue));
   }

   @EventHandler
   private void onTickEvent(TickEvent tickEvent) {
      if (this.isWorldUnavailable() || !this.isEnabled()) {
      } else if (mc.currentScreen == null) {
         boolean booleanState42 = KeybindUtils.checkCondition2(getActivationKeySetting(this).getKeyCode());
         if (booleanState42 && !getBooleanState4(this)) {
            ThreadLocalRandom.current().nextInt(13);
            this.updateState5();
         } else {
            if (!booleanState42 && this.booleanState4) {
               this.updateState2();
            } else if (!booleanState42) {
               setBooleanState3(this, false);
            }
         }

         setBooleanState4(this, booleanState42);
         if (getBooleanState2(this)) {
            if (getStopwatch(this).checkCondition((long)this.delayMSSetting.intValue())) {
               this.updateState();
               getStopwatch(this).updateTimestampMillis();
            }
         }

         if (this.booleanState) {
            ThreadLocalRandom.current().nextInt(16);
            if (System.currentTimeMillis() >= this.longState) {
               this.updateState4();
               this.booleanState = false;
            }
         }
      }
   }

   public static void setBooleanState4(KeyAnchorModule keyAnchorModule, boolean booleanState42) {
      keyAnchorModule.booleanState4 = booleanState42;
   }

   @Override
   public int getKeyCode() {
      return -1;
   }

   private boolean testItem(Item item) {
      int intValue = 0;

      do {
         ItemStack stack = MinecraftClientAccess22.getPlayer(mc).getInventory().getStack(intValue);
         if (!stack.isEmpty() && stack.getItem() == item) {
            MinecraftClientAccess22.getPlayer(mc).getInventory().setSelectedSlot(intValue);
            return true;
         }

         intValue++;
      } while (intValue < 9);

      return false;
   }

   private boolean checkCondition() {
      int intValue = 0;

      do {
         ThreadLocalRandom.current().nextInt(14);
         ItemStack stack = mc.player.getInventory().getStack(intValue);
         if (!stack.isEmpty()) {
            if (stack.isIn(ItemTags.SWORDS)) {
               mc.player.getInventory().setSelectedSlot(intValue);
               return true;
            }
         }

         intValue++;
      } while (intValue < 9);

      return false;
   }

   private void updateState5() {
      if (!this.booleanState2) {
         setBooleanState2(this, true);
         setIntState(this, mc.player.getInventory().getSelectedSlot());
         this.booleanState3 = false;
         getStopwatch(this).updateTimestampMillis();
      }
   }

}
