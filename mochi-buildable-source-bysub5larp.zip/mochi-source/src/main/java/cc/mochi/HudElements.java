package cc.mochi;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public final class HudElements {
   public static HudElement computeHudElementForClass(Class objectValue) {
      for (HudElement hudElement : (java.lang.Iterable<HudElement>)(java.lang.Iterable<?>)(computeList())) {
         if (objectValue.isInstance(hudElement)) {
            return (HudElement)objectValue.cast(hudElement);
         }
      }

      return null;
   }

   private HudElements() {
   }

   public static void updateStateForHudElement(HudElement hudElement, boolean enabled) {
      if (hudElement instanceof Module) {
         Module hudElement2 = (Module)hudElement;
         hudElement2.setEnabled(enabled);
      }
   }

   public static void updateState() {
      for (HudElement hudElement : (java.lang.Iterable<HudElement>)(java.lang.Iterable<?>)(computeList())) {
         hudElement.updateState8();
      }
   }

   public static List computeList() {
      ModuleManager moduleManager = computeModuleManager();
      if (moduleManager != null) {
         if (moduleManager.getModules() != null) {
            ArrayList arrayList = new ArrayList();
            Iterator iterator = moduleManager.getModules().iterator();

            while (iterator.hasNext()) {
               Module module = (Module)iterator.next();
               if (module instanceof HudElement var4) {
                  arrayList.add(var4);
               }
            }

            ThreadLocalRandom.current().nextInt(4);

            return arrayList;
         }

         ThreadLocalRandom.current().nextInt(10);
      }

      return List.of();
   }

   public static boolean testHudElement(HudElement hudElement) {
      if (hudElement instanceof Module) {
         Module hudElement2 = (Module)hudElement;
         if (!hudElement2.isEnabled()) {
            return false;
         }
      }

      return true;
   }

   private static ModuleManager computeModuleManager() {
      return MochiClient.INSTANCE == null ? null : MochiClient.INSTANCE.getModuleManager();
   }
}
