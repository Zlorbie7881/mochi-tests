package cc.mochi;

import com.mojang.blaze3d.systems.RenderSystem;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.texture.NativeImage.Format;

final class GlyphAtlas {
   private final List<GlyphAtlasPage> glyphAtlasPageList = new ArrayList<>();

   TextureRegion computeTextureRegionForByteBuffer(ByteBuffer byteBuffer, int intValue, int intValue2) {
      GlyphAtlasPage glyphAtlasPage = this.glyphAtlasPageList.isEmpty() ? null : this.glyphAtlasPageList.get(this.glyphAtlasPageList.size() - 1);
      int[] intArray = glyphAtlasPage == null ? null : glyphAtlasPage.computeIntArray(intValue, intValue2);
      if (intArray == null) {
         glyphAtlasPage = new GlyphAtlasPage(this.glyphAtlasPageList.size());
         this.glyphAtlasPageList.add(glyphAtlasPage);
         intArray = glyphAtlasPage.computeIntArray(intValue, intValue2);
         if (intArray == null) {
            return null;
         }
      }

      int intValue3 = intArray[0];
      int intValue4 = intArray[1];
      RenderSystem.getDevice().createCommandEncoder().writeToTexture(glyphAtlasPage.gpuTexture, byteBuffer, Format.LUMINANCE, 0, 0, intValue3, intValue4, intValue, intValue2);
      return new TextureRegion(
         glyphAtlasPage.textureHandle, (float)intValue3 * 4.8828125E-4F, (float)intValue4 * 4.8828125E-4F, (float)(intValue3 + intValue) * 4.8828125E-4F, (float)(intValue4 + intValue2) * 4.8828125E-4F
      );
   }

   void updateState() {
      for (GlyphAtlasPage glyphAtlasPage : this.glyphAtlasPageList) {
         glyphAtlasPage.gpuTextureView.close();
         glyphAtlasPage.gpuTexture.close();
      }

      this.glyphAtlasPageList.clear();
   }
}
