package cc.mochi;

public class ClickGuiPanelSwitchMap {
   static final int[] intArray = new int[ClickGuiTab.values().length];

   static {
      try {
         intArray[ClickGuiTab.CONFIGS.ordinal()] = 1;
      } catch (NoSuchFieldError failure) {
      }

      try {
         intArray[ClickGuiTab.THEMES.ordinal()] = 2;
      } catch (NoSuchFieldError failure2) {
      }

      try {
         intArray[ClickGuiTab.FRIENDS.ordinal()] = 3;
      } catch (NoSuchFieldError failure3) {
      }
   }
}
