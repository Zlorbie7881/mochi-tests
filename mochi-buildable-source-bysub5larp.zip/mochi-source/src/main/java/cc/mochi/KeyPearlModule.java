package cc.mochi;

import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.mixin.KeyBindingAccessor;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.item.ItemStack;

public class KeyPearlModule extends Module {
   private boolean booleanState;

   private int intState;

   private int selectedSlot;
   private long longState;
   private final BooleanSetting randomizationSetting = new BooleanSetting("Randomization", false);
   private final DoubleRangeSetting randomDelayMsSetting;

   public static DoubleRangeSetting getRandomDelayMsSetting(KeyPearlModule keyPearlModule) {
      return keyPearlModule.randomDelayMsSetting;
   }

   public static long getLongState(KeyPearlModule keyPearlModule) {
      return keyPearlModule.longState;
   }

   @EventHandler
   private void onTickEvent(TickEvent tickEvent) {
      if (MinecraftClientAccess50.getPlayer(mc) != null) {
         if (mc.options != null && getSelectedSlot(this) != -1) {
            if (!this.booleanState) {
               if (mc.player.getMainHandStack().getItem() == MinecraftClientAccess50.getENDER_PEARL()) {
                  if (getLongState(this) > 0L) {
                     if (System.currentTimeMillis() < getLongState(this)) {
                        return;
                     }
                  } else {
                     ThreadLocalRandom.current().nextInt(17);
                  }

                  MinecraftClientAccess50.getOptions(mc).useKey.setPressed(true);
                  KeyBinding useKey2 = MinecraftClientAccess50.getUseKey(MinecraftClientAccess50.getOptions(mc));
                  if (useKey2 instanceof KeyBindingAccessor) {
                     ThreadLocalRandom.current().nextInt(6);
                     KeyBindingAccessor useKey22 = (KeyBindingAccessor)useKey2;
                     useKey22.setTimesPressed(useKey22.getTimesPressed() + 1);
                  } else {
                     ThreadLocalRandom.current().nextInt(8);
                  }

                  setBooleanState(this, true);
               } else if (MinecraftClientAccess50.getCurrentScreen(mc) == null) {
                  this.toggle();
               } else {
               }
            } else {
               ThreadLocalRandom.current().nextInt(17);
               setIntState(this, getIntState(this) + 1);
               if (this.intState >= 2) {
                  mc.options.useKey.setPressed(false);
                  if (mc.currentScreen == null) {
                     this.toggle();
                  }
               }
            }

            return;
         }
      }

      if (mc.currentScreen == null) {
         this.toggle();
      }
   }

   @Override
   public void onEnable() {
      setBooleanState(this, false);

      long longState2;

      this.selectedSlot = -1;

      longState2 = 1443202012L;
      setIntState(this, 0);
      setLongState(this, 0L);
      if (MinecraftClientAccess50.getPlayer(mc) == null) {
         if (mc.currentScreen == null) {
            this.toggle();
         }
      } else {
         int intValue = this.computeInt();
         if (intValue != -1) {
            this.selectedSlot = mc.player.getInventory().getSelectedSlot();
            MinecraftClientAccess50.getPlayer(mc).getInventory().setSelectedSlot(intValue);
            if (this.randomizationSetting.isOn()) {
               longState2 = System.currentTimeMillis() + this.computeLong();
            } else {
               longState2 = (6381018072776325690L);

               longState2 = 0L;
            }

            setLongState(this, longState2);
         } else if (mc.currentScreen == null) {
            this.toggle();
         } else {
         }
      }
   }

   public KeyPearlModule() {
      super("Key Pearl", "Swaps to and throws a pearl, then swaps back.", ModuleCategory.MOVEMENT);

      this.randomDelayMsSetting = new DoubleRangeSetting("Random Delay (ms)", 0.0, (500.0), 0.0, 25.0, 1.0);

      this.booleanState = false;
      this.selectedSlot = -1;

      this.longState = (0L);

      this.intState = 0;
      this.addSetting(this.randomizationSetting);
      this.addSetting(this.randomDelayMsSetting);
   }

   public static void setBooleanState(KeyPearlModule keyPearlModule, boolean booleanState2) {
      keyPearlModule.booleanState = booleanState2;
   }

   public static int getSelectedSlot(KeyPearlModule keyPearlModule) {
      return keyPearlModule.selectedSlot;
   }

   public static void setLongState(KeyPearlModule keyPearlModule, long longState2) {
      keyPearlModule.longState = longState2;
   }

   public static int getIntState(KeyPearlModule keyPearlModule) {
      return keyPearlModule.intState;
   }

   public static void setIntState(KeyPearlModule keyPearlModule, int intState2) {
      keyPearlModule.intState = intState2;
   }

   private int computeInt() {
      int intValue = 0;

      do {
         ItemStack stack = MinecraftClientAccess50.getPlayer(mc).getInventory().getStack(intValue);
         if (stack.getItem() == MinecraftClientAccess50.getENDER_PEARL()) {
            return intValue;
         }
      } while (++intValue < 9);

      return -1;
   }

   @Override
   public void onDisable() {
      if (mc.options != null) {
         KeyBinding useKey = MinecraftClientAccess50.getUseKey(MinecraftClientAccess50.getOptions(mc));

         useKey.setPressed(false);
      }

      if (this.selectedSlot != -1) {
         ThreadLocalRandom.current().nextInt(6);
         if (MinecraftClientAccess50.getPlayer(mc) != null) {
            MinecraftClientAccess50.getPlayer(mc).getInventory().setSelectedSlot(this.selectedSlot);
         }
      }

      this.selectedSlot = -1;

      setBooleanState(this, false);

      this.intState = 0;
      this.longState = 0L;
   }

   private long computeLong() {
      long longValue2 = Math.max((0L), (long)getRandomDelayMsSetting(this).getLowerValue2());

      long longValue3 = Math.max((0L), (long)getRandomDelayMsSetting(this).getUpperValue3());
      if (longValue3 < longValue2) {
         long longValue = longValue2;
         longValue2 = longValue3;
         longValue3 = longValue;
      }

      if (longValue3 == longValue2) {
         return longValue2;
      } else {
         ThreadLocalRandom threadLocalRandom = ThreadLocalRandom.current();

         return threadLocalRandom.nextLong(longValue2, longValue3 + (1L));
      }
   }

}
