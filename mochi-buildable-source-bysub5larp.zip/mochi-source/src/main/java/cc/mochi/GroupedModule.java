package cc.mochi;

public record GroupedModule(Module module, String group) {
   public Module getModule2() {
      return getModule(this);
   }

   public static Module getModule(GroupedModule groupedModule) {
      return groupedModule.module;
   }

   public static String getGroup(GroupedModule groupedModule) {
      return groupedModule.group;
   }

   public String getGroup2() {
      return getGroup(this);
   }
}
