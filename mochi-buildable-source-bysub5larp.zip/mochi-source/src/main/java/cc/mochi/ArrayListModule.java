package cc.mochi;

import cc.mochi.event.impl.render.Render2DEvent;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.util.math.MathHelper;

public class ArrayListModule extends Module implements HudElement {
   private final ChoiceSetting sortSetting = new ChoiceSetting("Sort", "Length", "Length", "Alphabetical");

   private static final FontFace fontFace = FontFace.MEDIUM;

   private static final Color color = new Color(9, 11, 18);

   private long timestampNanos;

   private final HudLayout hudLayout;

   private final DoubleSetting fontSizeSetting;

   private final ColorSetting customColorSetting;
   private final DoubleSetting cornerRadiusSetting;

   private final ChoiceSetting styleSetting = new ChoiceSetting("Style", "Glass", "Flat", "Strip", "Glass");
   private final BooleanSetting accentBarSetting;

   private final BooleanSetting animationsSetting;

   private final Map<String, Float> floatByString;

   private final BooleanSetting camoSetting;

   private final BooleanSetting backgroundSetting;

   private final StringSetting hiddenSetting;

   private final BooleanSetting showValueSetting;
   private final DoubleSetting paddingSetting;
   private final DoubleSetting bGAlphaSetting;
   private final BooleanSetting shadowSetting;
   private final ChoiceSetting colorModeSetting;

   @Override
   public String computeString() {
      return this.getName();
   }

   private String computeStringForModule(Module module) {
      if (!this.showValueSetting.getValue()) {
         return null;
      } else {
         for (Setting setting : (java.lang.Iterable<Setting>)(java.lang.Iterable<?>)(module.getSettings())) {
            if (setting instanceof DoubleSetting var4) {
               double value = var4.getValue();
               return " " + (value == (double)((long)value) ? String.valueOf((long)value) : String.format(Locale.ROOT, "%.1f", value));
            }
         }

         return null;
      }
   }

   private Boolean computeBoolean() {
      return !this.styleSetting.equals("Flat");
   }

   @Override
   public boolean checkCondition() {
      return false;
   }

   private Boolean equals() {
      return this.styleSetting.equals("Glass");
   }

   @Override
   public void updateState() {
      this.hudLayout.setAlignmentAndInsets(HudHorizontalAlignment.LEFT, HudVerticalAlignment.TOP, 4.0F, HudLayoutMetrics.computeFloat2(4.0F, WatermarkModule.class, StatsModule.class));
   }

   @EventHandler
   private void onRender2D(Render2DEvent render2DEvent) {
      if (mc.player != null && mc.world != null) {
         if (mc.currentScreen == null || mc.currentScreen instanceof ChatScreen) {
            if (!GlCapabilities.checkCondition3()) {
               long timestampNanos2 = System.nanoTime();
               float floatValue = this.timestampNanos == 0L ? 0.016666668F : MathHelper.clamp((float)(timestampNanos2 - this.timestampNanos) / 1.0E9F, 0.0F, 0.1F);
               this.timestampNanos = timestampNanos2;
               float floatValue2 = this.animationsSetting.getValue() ? LegacyUiTheme.computeFloat2(floatValue, 18.0F) : 1.0F;
               List list = this.computeList();
               HashMap hashMap = new HashMap();

               for (Module module : (java.lang.Iterable<Module>)(java.lang.Iterable<?>)(MochiClient.INSTANCE.getModuleManager().toList2())) {
                  if (!list.contains(module.getName().toLowerCase(Locale.ROOT))) {
                     hashMap.put(module.getName(), module);
                  }
               }

               for (String string : (java.lang.Iterable<String>)(java.lang.Iterable<?>)(hashMap.keySet())) {
                  this.floatByString.putIfAbsent(string, this.animationsSetting.getValue() ? 0.0F : 1.0F);
               }

               this.floatByString.replaceAll((string2, objectValue) -> computeFloatForMap(hashMap, floatValue2, string2, objectValue));
               this.floatByString.entrySet().removeIf(entry -> testMap(hashMap, entry));
               if (this.floatByString.isEmpty()) {
                  this.updateState8();
               } else {
                  ThemeSnapshot themeSnapshot = ClickGuiModule.computeThemeSnapshot();
                  HudTextStyle hudTextStyle = this.computeHudTextStyleForThemeSnapshot(themeSnapshot);

                  try (UiRenderBackend uiRenderBackend = HudBloomRenderer.computeUiRenderBackendForRender2DEvent(render2DEvent)) {
                     ArrayList arrayList = new ArrayList(this.floatByString.size());

                     for (Entry entry2 : this.floatByString.entrySet()) {
                        Module module2 = (Module)hashMap.get(entry2.getKey());
                        String string3 = HudTextRenderer.replace((String)entry2.getKey());
                        String string4 = module2 == null ? null : this.computeStringForModule(module2);
                        float floatValue3 = HudBloomRenderer.measureText(string3 + (string4 == null ? "" : string4), hudTextStyle.getSize(), fontFace);
                        arrayList.add(new ModuleListEntry(string3, string4, HudTextRenderer.computeFloat((Float)entry2.getValue()), floatValue3));
                     }

                     if (this.sortSetting.equals("Length")) {
                        arrayList.sort(Comparator.<Object>comparingDouble(objectValue2 -> (double)((ModuleListEntry)objectValue2).getWidth()).reversed().thenComparing(objectValue3 -> ((ModuleListEntry)objectValue3).getLabel()));
                     } else {
                        arrayList.sort(Comparator.comparing(objectValue4 -> ((ModuleListEntry)objectValue4).getLabel(), String.CASE_INSENSITIVE_ORDER));
                     }

                     ArrayList arrayList2 = new ArrayList(arrayList.size());

                     for (ModuleListEntry moduleListEntry : (java.lang.Iterable<ModuleListEntry>)(java.lang.Iterable<?>)(arrayList)) {
                        arrayList2.add(new HudTextLine(moduleListEntry.getLabel(), moduleListEntry.getSuffix(), null, 1.0F, moduleListEntry.getVisibility(), false));
                     }

                     HudTextLayout hudTextLayout = HudTextRenderer.computeHudTextLayoutForList(arrayList2, hudTextStyle);
                     this.updateState4(Math.max(1.0F, hudTextLayout.getWidth2()), Math.max(1.0F, hudTextLayout.getHeight2()));
                     float x = this.hudLayout.getX();
                     float y = this.hudLayout.getY();
                     float width = (float)UiViewport.getWidth();
                     boolean booleanValue = x + hudTextLayout.getWidth2() / 2.0F > width / 2.0F;
                     boolean booleanValue2 = y <= 6.0F || y + hudTextLayout.getHeight2() >= (float)UiViewport.getHeight() - 6.0F;
                     boolean booleanValue3 = booleanValue ? x + hudTextLayout.getWidth2() >= width - 6.0F : x <= 6.0F;
                     boolean booleanValue4 = !booleanValue2 || !booleanValue3;
                     if (this.backgroundSetting.getValue() && this.styleSetting.equals("Glass") && this.shadowSetting.getValue()) {
                        HudBloomRenderer.drawGlowOutline(x, y, hudTextLayout.getWidth2(), hudTextLayout.getHeight2(), hudTextStyle.getRadius(), 14.0F, 3.0F, LegacyUiTheme.createColor(Color.BLACK, 0.28F));
                     }

                     HudTextRenderer.updateStateForHudTextLayout(hudTextLayout, hudTextStyle, x, y, booleanValue, booleanValue4, (float)timestampNanos2 / 1.0E9F, themeSnapshot);
                  }
               }
            }
         }
      }
   }

   public ArrayListModule() {
      super("Array List", "Displays enabled modules", -1, ModuleCategory.RENDER);
      this.fontSizeSetting = new DoubleSetting("Font Size", 8.0, 24.0, 14.0, 1.0);
      this.paddingSetting = new DoubleSetting("Padding", 2.0, 14.0, 8.0, 1.0);
      this.backgroundSetting = new BooleanSetting("Background", true);
      this.bGAlphaSetting = new DoubleSetting("BG Alpha", 0.0, 255.0, 163.0, 5.0);
      this.cornerRadiusSetting = new DoubleSetting("Corner Radius", 0.0, 12.0, 8.0, 1.0);
      this.shadowSetting = new BooleanSetting("Shadow", false);
      this.accentBarSetting = new BooleanSetting("Accent Bar", true);
      this.showValueSetting = new BooleanSetting("Show Value", true);
      this.colorModeSetting = new ChoiceSetting("Color Mode", "Theme", "Theme", "Custom");
      this.customColorSetting = new ColorSetting("Custom Color", new Color(193, 124, 255));
      this.hiddenSetting = new StringSetting("Hidden", "");
      this.animationsSetting = new BooleanSetting("Animations", true);
      this.camoSetting = new BooleanSetting("Camo", false);
      this.hudLayout = new HudLayout(0.0F, 4.0F, 120.0F, 90.0F);
      this.floatByString = new HashMap<>();
      this.addSettings(new Setting[]{this.sortSetting, this.styleSetting, this.fontSizeSetting, this.paddingSetting, this.backgroundSetting, this.bGAlphaSetting, this.cornerRadiusSetting, this.shadowSetting, this.accentBarSetting, this.showValueSetting, this.colorModeSetting, this.customColorSetting, this.hiddenSetting, this.animationsSetting, this.camoSetting});
      this.customColorSetting.setVisibility(() -> this.equals2());
      this.cornerRadiusSetting.setVisibility(() -> this.computeBoolean());
      this.shadowSetting.setVisibility(() -> this.equals());
   }

   private Boolean equals2() {
      return this.colorModeSetting.equals("Custom");
   }

   private static boolean testMap(Map map, Entry entry) {
      return (Float)entry.getValue() <= 0.0F && !map.containsKey(entry.getKey());
   }

   @Override
   public float getFloatConstant2() {
      return 120.0F;
   }

   @Override
   public HudLayout computeHudLayout() {
      return this.hudLayout;
   }

   @Override
   public float getFloatConstant() {
      return 90.0F;
   }

   private static Float computeFloatForMap(Map map, float floatValue, String string, Float objectValue) {
      float floatValue2 = map.containsKey(string) ? 1.0F : 0.0F;
      float floatValue3 = objectValue + (floatValue2 - objectValue) * floatValue;
      return Math.abs(floatValue2 - floatValue3) < 0.002F ? floatValue2 : floatValue3;
   }

   private HudTextStyle computeHudTextStyleForThemeSnapshot(ThemeSnapshot themeSnapshot) {
      float value = (float)this.fontSizeSetting.getValue();
      float value2 = (float)this.paddingSetting.getValue();
      boolean booleanValue = this.styleSetting.equals("Glass");
      boolean booleanValue2 = this.styleSetting.equals("Strip");
      float floatValue = booleanValue ? (float)this.cornerRadiusSetting.getValue() : (booleanValue2 ? Math.min(3.0F, (float)this.cornerRadiusSetting.getValue()) : 0.0F);
      boolean booleanValue3 = this.colorModeSetting.equals("Custom");
      Color[] colorArray = booleanValue3 ? new Color[]{this.customColorSetting.getValue()} : new Color[]{ThemeSnapshot.computeColorForColor(themeSnapshot.getGradientStart()), ThemeSnapshot.computeColorForColor(themeSnapshot.getGradientMid()), ThemeSnapshot.computeColorForColor(themeSnapshot.getGradientEnd2())};
      float floatValue2 = this.backgroundSetting.getValue() ? (float)this.bGAlphaSetting.getValue() / 255.0F : 0.0F;
      return new HudTextStyle(
         fontFace,
         value,
         value2,
         Math.max(2.0F, value * 0.36F),
         floatValue,
         booleanValue ? 6.0F * value / 14.0F : 0.0F,
         12.0F * value / 14.0F,
         color,
         floatValue2,
         booleanValue && this.backgroundSetting.getValue(),
         this.camoSetting.getValue() && this.backgroundSetting.getValue(),
         this.accentBarSetting.getValue(),
         booleanValue2 ? 2.0F : 3.5F,
         colorArray[0],
         !booleanValue3,
         colorArray,
         booleanValue,
         0.12F
      );
   }

   private List computeList() {
      String value3 = this.hiddenSetting.getValue3();
      if (value3 != null && !value3.isBlank()) {
         ArrayList arrayList = new ArrayList();

         for (String string : value3.split(",")) {
            String string2 = string.trim().toLowerCase(Locale.ROOT);
            if (!string2.isEmpty()) {
               arrayList.add(string2);
            }
         }

         return arrayList;
      } else {
         return List.of();
      }
   }
}
