package cc.mochi;

import java.util.List;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.Box;

public record BlockCollisionData(BlockState state, List<Box> collisions) {
   public List getCollisions2() {
      return getCollisions(this);
   }

   public BlockState getState2() {
      return getState(this);
   }

   public static BlockState getState(BlockCollisionData blockCollisionData) {
      return blockCollisionData.state;
   }

   public static List<Box> getCollisions(BlockCollisionData blockCollisionData) {
      return blockCollisionData.collisions;
   }
}
