package cc.mochi;

public class GridCell {
   private int intState;

   public int intState2;
   public final int intState3;

   private int intState4;
   private int intState5;
   private int intState6;
   private final Runnable runnable;
   public int intState7 = 1;
   public final int intState8;

   public int getIntState5() {
      return this.intState5;
   }

   public int getIntState6() {
      return this.intState6;
   }

   public void updateState() {
      if (this.runnable != null) {
         this.runnable.run();
      }
   }

   public GridCell(int intState32, int intState82, Runnable runnable2) {
      this.intState2 = 1;
      this.intState3 = intState32;
      this.intState8 = intState82;
      this.runnable = runnable2;
   }

   public GridCell computeGridCell(int intState72, int intState22) {
      this.intState7 = intState72;
      this.intState2 = intState22;
      return this;
   }

   public int getIntState4() {
      return this.intState4;
   }

   public int getIntState() {
      return this.intState;
   }

   public void updateState2(int intState9, int intState52, int intState42, int intState62) {
      this.intState = intState9;
      this.intState5 = intState52;
      this.intState4 = intState42;
      this.intState6 = intState62;
   }
}
