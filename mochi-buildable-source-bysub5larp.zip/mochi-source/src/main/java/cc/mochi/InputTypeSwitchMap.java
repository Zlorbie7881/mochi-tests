package cc.mochi;

import net.minecraft.client.util.InputUtil.Type;

public class InputTypeSwitchMap {
   static final int[] intArray2 = new int[Type.values().length];

   static {
      label36: {
         try {
            int[] intArray = intArray2;
            int intValue = Type.KEYSYM.ordinal();

            intArray[intValue] = 1;
         } catch (NoSuchFieldError failure) {
            break label36;
         }
      }

      label32: {
         try {
            intArray2[Type.MOUSE.ordinal()] = 2;
         } catch (NoSuchFieldError failure2) {
            break label32;
         }
      }
   }
}
