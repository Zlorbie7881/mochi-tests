package cc.mochi;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest.Builder;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Duration;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import javax.imageio.ImageIO;

public record MediaSnapshot(String title, String artist, String coverPath, boolean playing, long positionMicros, long lengthMicros, long sampledAt, Color mediaColor) {
   public static final MediaSnapshot EMPTY = new MediaSnapshot("Nothing playing", "Spotify", null, false, 0L, 0L, 0L, null);
   private static String string;

   private static String string2;

   public boolean getPlaying() {
      return this.playing;
   }

   private static long computeLong(String string3) {
      if (string3 != null && !string3.isBlank()) {
         try {
            double doubleValue = Double.parseDouble(string3.trim());
            if (Double.isFinite(doubleValue) && !(doubleValue <= 0.0)) {
               return string3.contains(".") ? (long)(doubleValue * 1000000.0) : (long)doubleValue;
            } else {
               return 0L;
            }
         } catch (NumberFormatException failure) {
            return 0L;
         }
      } else {
         return 0L;
      }
   }

   private static String computeString(String string3, String string4) {
      try {
         String string5 = URLEncoder.encode(string3 + " " + string4, StandardCharsets.UTF_8);
         Builder builder = HttpRequest.newBuilder(URI.create("https://itunes.apple.com/search?term=" + string5 + "&media=music&entity=song&limit=10"));

         HttpRequest httpRequest = builder.timeout(Duration.ofSeconds(3L)).header("User-Agent", ClientText.USER_AGENT.toString()).GET().build();
         HttpResponse httpResponse = DynamicIslandModule.httpClient.send(httpRequest, BodyHandlers.ofString());
         if (httpResponse.statusCode() / 100 != 2) {
            return null;
         } else {
            JsonObject asJsonObject = JsonParser.parseString((String)httpResponse.body()).getAsJsonObject();
            JsonArray asJsonArray = asJsonObject.getAsJsonArray("results");
            if (asJsonArray != null && !asJsonArray.isEmpty()) {
               String asString = null;
               int intValue22 = 0;

               for (JsonElement jsonElement : asJsonArray) {
                  if (jsonElement.isJsonObject()) {
                     JsonObject asJsonObject2 = jsonElement.getAsJsonObject();
                     if (asJsonObject2.has("artworkUrl100")) {
                        String string6 = asJsonObject2.has("artistName") ? asJsonObject2.get("artistName").getAsString() : "";
                        String string7 = asJsonObject2.has("trackName") ? asJsonObject2.get("trackName").getAsString() : "";
                        int intValue2 = computeInt(string3, string4, string6, string7);
                        if (intValue2 > intValue22) {
                           intValue22 = intValue2;
                           asString = asJsonObject2.get("artworkUrl100").getAsString();
                        }
                     }
                  }
               }

               return intValue22 > 0 && asString != null ? asString.replace("100x100", "600x600") : null;
            } else {
               return null;
            }
         }
      } catch (Exception failure) {
         return null;
      }
   }

   public long getSampledAt() {
      return this.sampledAt;
   }

   public String getArtist() {
      return this.artist;
   }

   public Color getMediaColor() {
      return this.mediaColor;
   }

   private static String computeString2(String string3) {
      if (string3 == null) {
         return "";
      } else {
         String string4 = string3.toLowerCase(Locale.ROOT).trim();
         int intValue22 = string4.length();

         for (char charValue : new char[]{'(', '['}) {
            int intValue2 = string4.indexOf(charValue);
            if (intValue2 >= 0 && intValue2 < intValue22) {
               intValue22 = intValue2;
            }
         }

         return string4.substring(0, intValue22).trim();
      }
   }

   private static Color computeColor(String string3) {
      if (string3 == null) {
         return null;
      } else {
         try {
            BufferedImage bufferedImage = ImageIO.read(Path.of(string3).toFile());
            if (bufferedImage == null) {
               return null;
            } else {
               long longValue = 0L;
               long longValue2 = 0L;
               long longValue3 = 0L;
               int intValue = 0;
               int intValue2 = Math.max(1, bufferedImage.getWidth() / 8);
               int intValue3 = Math.max(1, bufferedImage.getHeight() / 8);

               for (int intValue4 = 0; intValue4 < bufferedImage.getHeight(); intValue4 += intValue3) {
                  for (int intValue5 = 0; intValue5 < bufferedImage.getWidth(); intValue5 += intValue2) {
                     int rgb = bufferedImage.getRGB(intValue5, intValue4);
                     longValue += (long)(rgb >> 16 & 0xFF);
                     longValue2 += (long)(rgb >> 8 & 0xFF);
                     longValue3 += (long)(rgb & 0xFF);
                     intValue++;
                  }
               }

               return intValue == 0 ? null : new Color((int)(longValue / (long)intValue), (int)(longValue2 / (long)intValue), (int)(longValue3 / (long)intValue));
            }
         } catch (Exception failure) {
            return null;
         }
      }
   }

   private static String computeString3(String string3) {
      if (string3 != null && !string3.isBlank()) {
         try {
            if (string3.startsWith("file:")) {
               Path path = Path.of(URI.create(string3));
               return Files.isRegularFile(path) ? path.toString() : null;
            } else if (!string3.startsWith("http://") && !string3.startsWith("https://")) {
               Path path2 = Path.of(string3);
               return Files.isRegularFile(path2) ? path2.toString() : null;
            } else {
               Path path3 = Path.of(System.getProperty("java.io.tmpdir"), "mochi-spotify-" + Integer.toHexString(string3.hashCode()) + ".jpg");
               if (!Files.isRegularFile(path3)) {
                  Builder builder = HttpRequest.newBuilder(URI.create(string3));

                  HttpRequest httpRequest = builder.timeout(Duration.ofSeconds(3L)).header("User-Agent", ClientText.USER_AGENT.toString()).GET().build();
                  HttpResponse httpResponse = DynamicIslandModule.httpClient.send(httpRequest, BodyHandlers.ofByteArray());
                  byte[] byteArray = (byte[])httpResponse.body();
                  if (httpResponse.statusCode() / 100 != 2 || byteArray.length == 0 || byteArray.length > 2000000) {
                     return null;
                  }

                  Files.write(path3, byteArray, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
               }

               return path3.toString();
            }
         } catch (Exception failure) {
            return null;
         }
      } else {
         return null;
      }
   }

   private static MediaSnapshot computeMediaSnapshot() {
      String string3 = computeString4(
         new String[]{
            "powershell",
            "-NoProfile",
            "-NonInteractive",
            "-Command",
            "(Get-Process -Name spotify -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowTitle } | Select-Object -First 1 -ExpandProperty MainWindowTitle)"
         }
      );
      if (string3 != null && !string3.isBlank()) {
         String string4 = string3.strip();
         if (!string4.equalsIgnoreCase("Spotify") && !string4.equalsIgnoreCase("Spotify Free") && !string4.equalsIgnoreCase("Spotify Premium")) {
            int intValue = string4.indexOf(" - ");
            if (intValue > 0 && intValue + 3 < string4.length()) {
               String string5 = string4.substring(0, intValue).trim();
               String string6 = string4.substring(intValue + 3).trim();
               if (!string5.isEmpty() && !string6.isEmpty()) {
                  String string22 = string5 + "\u0000" + string6;
                  String string7;
                  if (string22.equals(string2)) {
                     string7 = string;
                  } else {
                     string7 = computeString3(computeString(string5, string6));
                     string2 = string22;
                     string = string7;
                  }

                  return createMediaSnapshot(string6, string5, string7, true, 0L, 0L);
               } else {
                  return EMPTY;
               }
            } else {
               return EMPTY;
            }
         } else {
            return EMPTY;
         }
      } else {
         return EMPTY;
      }
   }

   private static boolean checkCondition(String string3, String string4) {
      if (string3.equals(string4)) {
         return true;
      } else if (!string3.isEmpty() && !string4.isEmpty()) {
         String string5 = string3.length() <= string4.length() ? string3 : string4;
         return string5.length() < 4 ? false : string3.contains(string4) || string4.contains(string3);
      } else {
         return false;
      }
   }

   private static int computeInt(String string3, String string4, String string5, String string6) {
      String string7 = computeString2(string3);
      String string8 = computeString2(string4);
      String string9 = computeString2(string5);
      String string10 = computeString2(string6);
      byte byteValue = 0;
      if (checkCondition(string8, string10)) {
         byteValue = (byte)4;
      }

      if (checkCondition(string7, string9)) {
         byteValue += 2;
      }

      return byteValue;
   }

   private static String computeString4(String[] stringArray) {
      Process process = null;

      try {
         process = new ProcessBuilder(stringArray).redirectErrorStream(true).start();

         if (!process.waitFor(2000L, TimeUnit.MILLISECONDS)) {
            process.destroyForcibly();
            return null;
         } else {
            return new String(process.getInputStream().readAllBytes()).strip();
         }
      } catch (InterruptedException failure) {
         if (process != null) {
            process.destroyForcibly();
         }

         Thread.currentThread().interrupt();
         return null;
      } catch (IOException failure2) {
         if (process != null) {
            process.destroyForcibly();
         }

         return null;
      }
   }

   private static MediaSnapshot createMediaSnapshot(String string3, String string4, String string5, boolean booleanValue, long longValue, long longValue2) {
      return new MediaSnapshot(string3, string4, string5, booleanValue, longValue, longValue2, System.currentTimeMillis(), computeColor(string5));
   }

   public String getTitle() {
      return this.title;
   }

   public long getPositionMicros() {
      return this.positionMicros;
   }

   public static MediaSnapshot computeMediaSnapshot2() {
      String string3 = System.getenv(ClientText.MEDIA_TITLE_ENV.toString());
      String string4 = System.getenv(ClientText.MEDIA_ARTIST_ENV.toString());
      String string5 = System.getenv(ClientText.MEDIA_COVER_ENV.toString());
      String string6 = System.getenv(ClientText.MEDIA_PLAYING_ENV.toString());
      if (string3 != null && !string3.isBlank() && string4 != null && !string4.isBlank()) {
         return createMediaSnapshot(string3, string4, computeString3(string5), !"false".equalsIgnoreCase(string6), computeLong(System.getenv(ClientText.MEDIA_POSITION_ENV.toString())), computeLong(System.getenv(ClientText.MEDIA_LENGTH_ENV.toString())));
      } else {
         String string7 = System.getProperty("os.name", "").toLowerCase();
         if (string7.contains("win")) {
            return computeMediaSnapshot();
         } else {
            String[] stringArray = string7.contains("mac")
               ? new String[]{
                  "osascript",
                  "-e",
                  "tell application \"Spotify\" to return (player state as string) & tab & name of current track & tab & artist of current track & tab & player position & tab & duration of current track"
               }
               : new String[]{
                  "playerctl", "-p", "spotify", "metadata", "--format", "{{status}}\t{{title}}\t{{artist}}\t{{mpris:artUrl}}\t{{position}}\t{{mpris:length}}"
               };
            String string8 = computeString4(stringArray);
            if (string8 != null && !string8.isBlank()) {
               String[] stringArray2 = string8.strip().split("\\t", -1);
               if (stringArray2.length >= 3 && !stringArray2[1].isBlank() && !stringArray2[2].isBlank()) {
                  boolean booleanValue = !"paused".equalsIgnoreCase(stringArray2[0]) && !"stopped".equalsIgnoreCase(stringArray2[0]);
                  boolean booleanValue2 = stringArray2.length >= 6;
                  String string9 = booleanValue2 ? stringArray2[3] : null;
                  String string10 = booleanValue2 ? stringArray2[4] : (stringArray2.length >= 4 ? stringArray2[3] : null);
                  String string11 = booleanValue2 ? stringArray2[5] : (stringArray2.length >= 5 ? stringArray2[4] : null);
                  return createMediaSnapshot(stringArray2[1], stringArray2[2], computeString3(string9), booleanValue, computeLong(string10), computeLong(string11));
               } else {
                  return EMPTY;
               }
            } else {
               return EMPTY;
            }
         }
      }
   }

   public long getLengthMicros() {
      return this.lengthMicros;
   }

   public String getCoverPath() {
      return this.coverPath;
   }
}
