package cc.mochi;

import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.event.impl.world.WorldChangeEvent;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.math.Vec3d;

public class AutoPotModule extends Module {
   private int intState;
   private final Stopwatch stopwatch;
   private long longState;

   private final BooleanSetting randomizationSetting;
   private int intState2;

   private final DoubleSetting strengthSetting;

   private final DoubleSetting healthSetting;
   private int intState3;

   private final BooleanSetting silentSetting;

   private final DoubleSetting responseSetting;

   private final DoubleSetting randomnessSetting;

   private final DoubleSetting potToHealthSetting;

   private final DoubleRangeSetting randomDelayMsSetting;

   private void updateState() {
      if (!this.checkCondition()) {
         ThreadLocalRandom.current().nextInt(7);
      } else {
         int intValue = this.computeInt2();
         if (intValue <= 0) {
            this.updateState6();
         } else {
            InventorySynchronization.updateStateForMinecraftClient4(mc);
            if (this.computeInt2() < intValue) {
               this.updateState11(3, (0L));
            } else {
               ThreadLocalRandom.current().nextInt(3);

               if ((this.intState = getIntState(this) + 1) >= 2) {
                  this.updateState11(3, 0L);
               } else {
                  this.updateState11(2, (200L));
               }
            }
         }
      }
   }

   private void updateState2() {
      if (!((double)MinecraftClientAccess29.getPlayer(mc).getHealth() > this.healthSetting.getValue())) {
         if (getRandomizationSetting(this).isOn()) {
            if (!ActionArbitrator.testDelay("combat.autopot", Math.round(this.randomDelayMsSetting.getLowerValue2()), Math.round(this.randomDelayMsSetting.getUpperValue3()))) {
               return;
            }
         }

         setIntState3(this, InventoryUtils.computeInt());
         if (getIntState3(this) < 0) {
            ThreadLocalRandom.current().nextInt(14);
         } else {
            int intValue = this.computeInt();

            if ((intValue != -1)) {
               MinecraftClientAccess29.getPlayer(mc).getInventory().setSelectedSlot(intValue);

               this.intState = 0;
               this.updateState10();

               this.updateState11(1, (0L));
            }
         }
      }
   }

   private static boolean testItemStack(ItemStack itemStack, boolean booleanValue) {
      if (itemStack != null) {
         if (itemStack.getItem() == Items.SPLASH_POTION) {
            PotionContentsComponent potionContentsComponent = (PotionContentsComponent)itemStack.get(MinecraftClientAccess29.getPOTION_CONTENTS());
            if (potionContentsComponent == null) {
               return false;
            }

            ThreadLocalRandom.current().nextInt(12);

            Optional optional = potionContentsComponent.potion();
            if (optional.isEmpty()) {
               return false;
            }

            if (booleanValue) {
         return ((RegistryEntry)optional.get()).matches(MinecraftClientAccess29.getSTRONG_HEALING());
      } else {
         return ((RegistryEntry)optional.get()).matches(MinecraftClientAccess29.getHEALING());
      }
         }
      }

      return false;
   }

   public static void setIntState(AutoPotModule autoPotModule, int intState4) {
      autoPotModule.intState = intState4;
   }

   @EventHandler
   private void onTickEvent(TickEvent tickEvent) {
      if (!PlayerStateUtils.isPlayerUnavailable() && MinecraftClientAccess29.getInteractionManager(mc) != null) {
         if (MinecraftClientAccess29.getCurrentScreen(mc) != null) {
            this.updateState8();
         } else {
            switch (getIntState2(this)) {
               case 0:
                  this.updateState2();
                  break;
               case 1:
                  this.updateState5();
                  break;
               case 2:
                  this.updateState();
                  break;
               case 3:

                  this.updateState6();
                  break;
               case 4:
                  this.updateState3();

                  break;
               case 5:

                  this.updateState4();
                  break;
               default:

                  this.updateState8();
            }
         }
      } else {
         this.updateState8();
      }
   }

   private boolean checkCondition() {
      return getStopwatch(this).checkCondition(this.longState);
   }

   private Vec3d computeVec3d() {
      float yaw = mc.player.getYaw();
      double doubleValue = Math.toRadians((double)yaw);
      return MinecraftClientAccess29.getPlayer(mc).getEyePos().add(-Math.sin(doubleValue) * 10.0, 0.0, Math.cos(doubleValue) * 10.0);
   }

   @Override
   public void onEnable() {
      this.updateState8();
   }

   public static Stopwatch getStopwatch(AutoPotModule autoPotModule) {
      return autoPotModule.stopwatch;
   }

   private RotationProfile computeRotationProfile() {
      RotationProfile rotationProfile = RotationProfile.createRotationProfile();
      double value = this.strengthSetting.getValue();

      rotationProfile = rotationProfile.withMaxRotationSpeed(value * (60.0));

      value = (0.1);
      double value2 = this.responseSetting.getValue();

      return rotationProfile.computeRotationProfile10((0.1) + value2 / (100.0) * 0.9)
         .computeRotationProfile4(MathUtils.computeDouble6((int)Math.round(getRandomnessSetting(this).getValue())))
         .withSilentAim(getSilentSetting(this).isOn());
   }

   private void updateState3() {
      label29: {
         if (!(RotationManager.computeFloat7() <= (15.0F))) {
            if (!this.stopwatch.checkCondition(400L)) {
               break label29;
            }
         }

         RotationManager.updateState9(this);

         this.updateState11(5, 300L);
      }
   }

   public static BooleanSetting getSilentSetting(AutoPotModule autoPotModule) {
      return autoPotModule.silentSetting;
   }

   public static int getIntState2(AutoPotModule autoPotModule) {
      return autoPotModule.intState2;
   }

   @Override
   public void onDisable() {
      this.updateState8();
      ActionArbitrator.reset("combat.autopot");
   }

   private void updateState4() {
      if ((double)mc.player.getHealth() > getPotToHealthSetting(this).getValue()) {
         this.updateState8();
      } else {
         if (this.checkCondition()) {
            this.updateState8();
         }
      }
   }

   private void updateState5() {
      float floatValue = RotationManager.computeFloat7();

      if (floatValue >= (85.0F)) {
         this.updateState11(2, (0L));
      } else {
         ThreadLocalRandom.current().nextInt(6);
         Stopwatch stopwatch2 = getStopwatch(this);

         if (!stopwatch2.checkCondition((200L))) {
            ThreadLocalRandom.current().nextInt(9);
         } else {
            this.updateState6();
         }
      }
   }

   public static DoubleSetting getRandomnessSetting(AutoPotModule autoPotModule) {
      return autoPotModule.randomnessSetting;
   }

   private static boolean testItemStack2(ItemStack itemStack) {
      return testItemStack(itemStack, false);
   }

   public static void setIntState2(AutoPotModule autoPotModule, int intState22) {
      autoPotModule.intState2 = intState22;
   }

   private void updateState6() {
      this.updateState7();
      this.updateState9();

      this.updateState11(4, 0L);
   }

   public static BooleanSetting getRandomizationSetting(AutoPotModule autoPotModule) {
      return autoPotModule.randomizationSetting;
   }

   public static void setIntState3(AutoPotModule autoPotModule, int intState32) {
      autoPotModule.intState3 = intState32;
   }

   @EventHandler
   private void onWorldChange(WorldChangeEvent worldChangeEvent) {
      if (worldChangeEvent.getWorld() != mc.world) {
         this.updateState8();
         ActionArbitrator.reset("combat.autopot");
      }
   }

   public static int getIntState3(AutoPotModule autoPotModule) {
      return autoPotModule.intState3;
   }

   private int computeInt() {
      int intValue = InventoryUtils.computeIntForPredicate2(objectValue -> testItemStack3((ItemStack)objectValue));
      if (intValue != -1) {
         return intValue;
      } else {
         return InventoryUtils.computeIntForPredicate2(objectValue2 -> testItemStack2((ItemStack)objectValue2));
      }
   }

   private Vec3d computeVec3d2() {
      if (MinecraftClientAccess29.getPlayer(mc) == null) {
         return null;
      } else {
         ThreadLocalRandom.current().nextInt(8);
         float yaw = MinecraftClientAccess29.getPlayer(mc).getYaw();
         double doubleValue = Math.toRadians((double)yaw);
         double doubleValue2 = -Math.sin(doubleValue) * 0.1;
         double doubleValue3 = Math.cos(doubleValue) * 0.1;
         return MinecraftClientAccess29.getPlayer(mc).getEntityPos().add(doubleValue2, ((-5.0)), doubleValue3);
      }
   }

   private int computeInt2() {
      ItemStack mainHandStack = mc.player.getMainHandStack();
      if (mainHandStack.getItem() == Items.SPLASH_POTION) {
         return mainHandStack.getCount();
      } else {
         return 0;
      }
   }

   private void updateState7() {
      if (mc.player == null) {
         ThreadLocalRandom.current().nextInt(4);
         setIntState3(this, -1);
      } else {
         if (this.intState3 >= 0) {
            mc.player.getInventory().setSelectedSlot(this.intState3);
         }

         this.intState3 = -1;
      }
   }

   private void updateState8() {
      this.updateState7();
      RotationManager.updateState9(this);
      this.intState2 = 0;

      this.longState = (0L);
      this.stopwatch.updateTimestampMillis();

      setIntState(this, 0);
   }

   private void updateState9() {
      RotationManager.updateStateForActionPriority(this, ActionPriority.HIGH, () -> this.computeVec3d(), this.computeRotationProfile());
   }

   public static int getIntState(AutoPotModule autoPotModule) {
      return autoPotModule.intState;
   }

   private static boolean testItemStack3(ItemStack itemStack) {
      return testItemStack(itemStack, true);
   }

   private void updateState10() {
      RotationManager.updateStateForActionPriority(this, ActionPriority.HIGH, () -> this.computeVec3d2(), this.computeRotationProfile());
   }

   public static DoubleSetting getPotToHealthSetting(AutoPotModule autoPotModule) {
      return autoPotModule.potToHealthSetting;
   }

   public AutoPotModule() {
      super("Auto Pot", "Automatically throws health potions.", ModuleCategory.COMBAT);

      this.healthSetting = new DoubleSetting("Health", (1.0), (20.0), (10.0), (1.0));

      this.potToHealthSetting = new DoubleSetting("Pot To Health", (1.0), (20.0), 18.0, (1.0));

      this.strengthSetting = new DoubleSetting("Strength", (1.0), (20.0), (10.0), 1.0);

      this.responseSetting = new DoubleSetting("Response", (0.0), (100.0), (60.0), 1.0);

      this.randomnessSetting = new DoubleSetting("Randomness", 1.0, 100.0, (10.0), (1.0));
      this.silentSetting = new BooleanSetting("Silent", true);

      this.randomizationSetting = new BooleanSetting("Randomization", false);

      this.randomDelayMsSetting = new DoubleRangeSetting("Random Delay (ms)", 0.0, 500.0, (0.0), 25.0, 1.0);
      this.stopwatch = new Stopwatch();
      this.intState2 = 0;

      this.intState3 = -1;
      this.addSetting(this.healthSetting);
      this.addSetting(this.potToHealthSetting);
      this.addSetting(this.strengthSetting);
      this.addSetting(this.responseSetting);
      this.addSetting(this.randomnessSetting);
      this.addSetting(this.silentSetting);
      this.addSetting(this.randomizationSetting);
      this.addSetting(this.randomDelayMsSetting);
   }

   public static void setLongState(AutoPotModule autoPotModule, long longState2) {
      autoPotModule.longState = longState2;
   }

   private void updateState11(int intState22, long longValue) {
      setIntState2(this, intState22);

      setLongState(this, Math.max((0L), longValue));
      this.stopwatch.updateTimestampMillis();
   }
}
