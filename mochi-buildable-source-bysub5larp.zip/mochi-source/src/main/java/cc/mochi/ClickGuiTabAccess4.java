package cc.mochi;

public class ClickGuiTabAccess4 {
   public static ClickGuiTab getTHEMES() {
      return ClickGuiTab.THEMES;
   }
}
