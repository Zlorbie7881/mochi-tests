package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil.Type;
import net.minecraft.inventory.Inventory;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.collection.DefaultedList;

public class MinecraftClientAccess39 {
   public static int getX(Slot slot) {
      return slot.x;
   }

   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static Inventory getInventory(Slot slot) {
      return slot.inventory;
   }

   public static KeyBinding[] getHotbarKeys(GameOptions gameOptions) {
      return gameOptions.hotbarKeys;
   }

   public static KeyBinding getDropKey(GameOptions gameOptions) {
      return gameOptions.dropKey;
   }

   public static KeyBinding getInventoryKey(GameOptions gameOptions) {
      return gameOptions.inventoryKey;
   }

   public static Type getSCANCODE() {
      return Type.SCANCODE;
   }

   public static ClientPlayerInteractionManager getInteractionManager(MinecraftClient minecraftClient) {
      return minecraftClient.interactionManager;
   }

   public static Type getKEYSYM() {
      return Type.KEYSYM;
   }

   public static GameOptions getOptions(MinecraftClient minecraftClient) {
      return minecraftClient.options;
   }

   public static DefaultedList<Slot> getSlots(ScreenHandler screenHandler) {
      return screenHandler.slots;
   }

   public static int getId(Slot slot) {
      return slot.id;
   }

   public static int getSyncId(ScreenHandler screenHandler) {
      return screenHandler.syncId;
   }

   public static SlotActionType getPICKUP() {
      return SlotActionType.PICKUP;
   }

}
