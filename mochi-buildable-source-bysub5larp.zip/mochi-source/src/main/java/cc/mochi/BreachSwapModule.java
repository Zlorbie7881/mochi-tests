package cc.mochi;

import cc.mochi.event.impl.player.TickEvent;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.MaceItem;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry.Reference;
import net.minecraft.util.hit.EntityHitResult;

public class BreachSwapModule extends Module implements AttackInputBlocker, AttackTargetBlocker {
   private int intState;
   private int intState2;
   private LivingEntity livingEntity;

   private final DoubleRangeSetting switchDelayTicksSetting;
   private long timestampMillis;

   private double y;
   private boolean booleanState;

   private final BooleanSetting swordOnlySetting;

   private boolean booleanState2;

   private final DoubleSetting maxFallHeightSetting;
   private int intState3;
   private int intState4;

   private final BooleanSetting ignoreShieldsSetting;

   private final BooleanSetting onlyCritsSetting = new BooleanSetting("Only Crits", true);

   @Override
   public void onEnable() {
      this.updateState2();
      setY(this, mc.player != null ? mc.player.getY() : 0.0);
   }

   @Override
   public void onDisable() {
      if (mc.player != null) {
         if (this.intState4 != -1) {
            this.updateState(this.intState4);
         }
      }

      this.updateState2();
   }

   private boolean checkCondition() {
      if (mc.player.isOnGround()) {
         return true;
      } else {
         byte byteValue;
         if (MinecraftClientAccess13.getPlayer(mc).getY() - this.y <= this.maxFallHeightSetting.getValue()) {
            byteValue = 1;
         } else {
            byteValue = 0;

            ThreadLocalRandom.current().nextInt(12);
         }

         return (byteValue != 0);
      }
   }

   @EventHandler
   private void onTickEvent(TickEvent tickEvent) {
      if ((MinecraftClientAccess13.getPlayer(mc) != null)) {
         if (CombatActionCoordinator.checkCondition()) {
            this.updateState2();
         } else if (!AutoStunModule.booleanState) {
            if (MinecraftClientAccess13.getPlayer(mc).isOnGround()) {
               this.y = MinecraftClientAccess13.getPlayer(mc).getY();
            }

            if (getBooleanState2(this)) {
               if (System.currentTimeMillis() - this.timestampMillis >= 1L) {
                  this.updateState(this.intState);
                  if (getLivingEntity(this) != null) {
                     if (this.livingEntity.isAlive()) {
                        ThreadLocalRandom.current().nextInt(9);
                        MinecraftClientAccess13.setCrosshairTarget(mc, new EntityHitResult(this.livingEntity));
                     }
                  }

                  if (!AttackActions.testMinecraftClient(mc, "combat.attack.breachswap")) {
                     if (this.intState4 != -1) {
                        this.updateState(this.intState4);
                     }

                     this.updateState2();
                     return;
                  }

                  ThreadLocalRandom.current().nextInt(3);
                  this.booleanState2 = false;
                  this.booleanState = true;
                  setTimestampMillis(this, System.currentTimeMillis());
                  setIntState2(this, 0);
               }
            } else {
               if (getBooleanState(this)) {
                  setIntState2(this, getIntState2(this) + 1);
                  if (getIntState2(this) >= this.intState3) {
                     this.updateState(this.intState4);
                     this.updateState2();
                  }
               }
            }
         }
      }
   }

   public static void setTimestampMillis(BreachSwapModule breachSwapModule, long timestampMillis2) {
      breachSwapModule.timestampMillis = timestampMillis2;
   }

   private void updateState(int intValue) {
      if (intValue >= 0) {
         ThreadLocalRandom.current().nextInt(14);
         if (intValue < 9) {
            if (mc.player.getInventory().getSelectedSlot() != intValue) {
               MinecraftClientAccess13.getPlayer(mc).getInventory().setSelectedSlot(intValue);
            }
         }
      } else {
         ThreadLocalRandom.current().nextInt(6);
      }
   }

   public static LivingEntity getLivingEntity(BreachSwapModule breachSwapModule) {
      return breachSwapModule.livingEntity;
   }

   private int computeInt() {
      Reference orThrow = mc.world.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT).getOrThrow(Enchantments.BREACH);
      int intValue = 0;

      while (true) {
         if (intValue >= 9) {
            return -1;
         }

         ItemStack stack = mc.player.getInventory().getStack(intValue);
         Item item = stack.getItem();
         if (item instanceof MaceItem) {
            if (EnchantmentHelper.getLevel(orThrow, stack) > 0) {
               return intValue;
            }
         } else {
            ThreadLocalRandom.current().nextInt(5);
         }

         intValue++;
      }
   }

   public static void setY(BreachSwapModule breachSwapModule, double y2) {
      breachSwapModule.y = y2;
   }

   @Override
   public boolean shouldBlockAttackTarget(Entity entity) {
      if (CombatActionCoordinator.checkCondition()) {
         return false;
      } else {
         ThreadLocalRandom.current().nextInt(15);
         if (MinecraftClientAccess13.getBooleanState()) {
            return false;
         } else {
            if (MinecraftClientAccess13.getPlayer(mc) != null) {
               if (MinecraftClientAccess13.getWorld(mc) != null) {
                  if (!this.booleanState) {
                     if (!this.booleanState2) {
                        ThreadLocalRandom.current().nextInt(5);
                        if (entity instanceof LivingEntity) {
                           LivingEntity entity2 = (LivingEntity)entity;
                           return this.testLivingEntity(entity2);
                        }

                        return false;
                     }

                     ThreadLocalRandom.current().nextInt(8);
                  }

                  return true;
               }
            }

            return false;
         }
      }
   }

   public static void setIntState3(BreachSwapModule breachSwapModule, int intState32) {
      breachSwapModule.intState3 = intState32;
   }

   public static boolean getBooleanState2(BreachSwapModule breachSwapModule) {
      return breachSwapModule.booleanState2;
   }

   public static boolean getBooleanState(BreachSwapModule breachSwapModule) {
      return breachSwapModule.booleanState;
   }

   private void updateState2() {
      this.booleanState2 = false;
      setBooleanState(this, false);
      this.intState4 = -1;
      this.intState = -1;
      this.livingEntity = null;

      setTimestampMillis(this, (0L));

      setIntState3(this, 0);
      this.intState2 = 0;
   }

   public static void setIntState4(BreachSwapModule breachSwapModule, int intState42) {
      breachSwapModule.intState4 = intState42;
   }

   public static int getIntState2(BreachSwapModule breachSwapModule) {
      return breachSwapModule.intState2;
   }

   public boolean checkCondition2() {
      if (!getBooleanState(this)) {
         if (!getBooleanState2(this)) {
            ThreadLocalRandom.current().nextInt(9);

            return false;
         }
      }

      return true;
   }

   public static void setBooleanState(BreachSwapModule breachSwapModule, boolean booleanState3) {
      breachSwapModule.booleanState = booleanState3;
   }

   public static void setIntState2(BreachSwapModule breachSwapModule, int intState22) {
      breachSwapModule.intState2 = intState22;
   }

   private boolean checkCondition3() {
      if (mc.player.fallDistance > 0.0) {
         if (!MinecraftClientAccess13.getPlayer(mc).isOnGround()) {
            if (!MinecraftClientAccess13.getPlayer(mc).isClimbing()) {
               if (!MinecraftClientAccess13.getPlayer(mc).isTouchingWater()) {
                  if (!MinecraftClientAccess13.getPlayer(mc).isRiding()) {
                     if (!MinecraftClientAccess13.getPlayer(mc).isSprinting()) {
                        return true;
                     }
                  }
               }
            }
         } else {
            ThreadLocalRandom.current().nextInt(13);
         }
      }

      return false;
   }

   @Override
   public boolean shouldBlockAttackInput() {
      if (CombatActionCoordinator.checkCondition()) {
         return false;
      } else if (MinecraftClientAccess13.getBooleanState()) {
         return false;
      } else {
         ThreadLocalRandom.current().nextInt(12);
         if (MinecraftClientAccess13.getPlayer(mc) != null) {
            if (mc.world != null) {
               if (!this.booleanState) {
                  if (!this.booleanState2) {
                     if (MinecraftClientAccess13.getCrosshairTarget(mc) instanceof EntityHitResult var1) {
                        Entity entity = var1.getEntity();
                        if (entity instanceof LivingEntity) {
                           LivingEntity entity2 = (LivingEntity)entity;
                           return this.testLivingEntity(entity2);
                        }

                        ThreadLocalRandom.current().nextInt(4);
                     }

                     return false;
                  }
               }
            }
         }

         return false;
      }
   }

   public static DoubleRangeSetting getSwitchDelayTicksSetting(BreachSwapModule breachSwapModule) {
      return breachSwapModule.switchDelayTicksSetting;
   }

   private boolean testLivingEntity(LivingEntity livingEntity2) {
      if (this.ignoreShieldsSetting.isOn() && livingEntity2.isBlocking()) {
         return false;
      } else {
         ItemStack mainHandStack = MinecraftClientAccess13.getPlayer(mc).getMainHandStack();
         if (this.swordOnlySetting.isOn()) {
            ThreadLocalRandom.current().nextInt(5);

            if (!mainHandStack.isIn(MinecraftClientAccess13.getSWORDS())) {
               return false;
            }
         }

         if (this.onlyCritsSetting.isOn()) {
            if (!this.checkCondition3()) {
               return false;
            }
         }

         if (!this.checkCondition()) {
            return false;
         } else {
            int intState5 = this.computeInt();

            if (intState5 == -1) {
               return false;
            } else {
               setIntState4(this, this.getSelectedSlot());
               this.intState = intState5;
               this.livingEntity = livingEntity2;
               this.booleanState2 = true;
               this.timestampMillis = System.currentTimeMillis();
               int intValue = (int)Math.round(this.switchDelayTicksSetting.getLowerValue2());
               int intValue2 = (int)Math.round(getSwitchDelayTicksSetting(this).getUpperValue3());
               int intState32;
               if (intValue >= intValue2) {
                  ThreadLocalRandom.current().nextInt(17);
                  intState32 = intValue;
               } else {
                  intState32 = ThreadLocalRandom.current().nextInt(intValue, intValue2 + 1);
               }

               this.intState3 = intState32;

               return true;
            }
         }
      }
   }

   public BreachSwapModule() {
      super("Breach Swap", "Switches to a Breach enchanted mace when attacking", ModuleCategory.COMBAT);
      this.ignoreShieldsSetting = new BooleanSetting("Ignore Shields", true);
      this.swordOnlySetting = new BooleanSetting("Sword Only", true);

      this.switchDelayTicksSetting = new DoubleRangeSetting("Switch Delay (Ticks)", 0.0, 10.0, 1.0, (5.0), 1.0);

      this.maxFallHeightSetting = new DoubleSetting("Max Fall Height", (0.0), (5.0), 1.5, (0.1));

      this.intState4 = -1;

      this.intState = -1;
      this.addSetting(this.onlyCritsSetting);
      this.addSetting(this.ignoreShieldsSetting);
      this.addSetting(this.swordOnlySetting);
      this.addSetting(this.switchDelayTicksSetting);
      this.addSetting(this.maxFallHeightSetting);
   }

   private int getSelectedSlot() {
      return mc.player.getInventory().getSelectedSlot();
   }

}
