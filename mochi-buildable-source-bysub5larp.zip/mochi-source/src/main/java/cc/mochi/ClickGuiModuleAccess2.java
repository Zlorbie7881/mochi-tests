package cc.mochi;

public class ClickGuiModuleAccess2 {
   public static DoubleSetting getOpacitySetting() {
      return ClickGuiModule.opacitySetting;
   }

   public static BooleanSetting getGlassPanelsSetting() {
      return ClickGuiModule.glassPanelsSetting;
   }

   public static DoubleSetting getBlurStrengthSetting() {
      return ClickGuiModule.blurStrengthSetting;
   }

   public static BooleanSetting getReducedMotionSetting() {
      return ClickGuiModule.reducedMotionSetting;
   }

   public static DoubleSetting getGlassRefractionSetting() {
      return ClickGuiModule.glassRefractionSetting;
   }

   public static DoubleSetting getBloomIntensitySetting() {
      return ClickGuiModule.bloomIntensitySetting;
   }

   public static BooleanSetting getBackgroundBlurSetting() {
      return ClickGuiModule.backgroundBlurSetting;
   }

   public static BooleanSetting getGradientSetting() {
      return ClickGuiModule.gradientSetting;
   }

   public static DoubleSetting getOpeningDurationSetting() {
      return ClickGuiModule.openingDurationSetting;
   }

   public static DoubleSetting getGlassBlurSetting() {
      return ClickGuiModule.glassBlurSetting;
   }

   public static ChoiceSetting getEasingSetting() {
      return ClickGuiModule.easingSetting;
   }

   public static BooleanSetting getShowSearchSetting() {
      return ClickGuiModule.showSearchSetting;
   }

   public static BooleanSetting getAutoFocusSearchSetting() {
      return ClickGuiModule.autoFocusSearchSetting;
   }

   public static ColorSetting getAccentColorSetting() {
      return ClickGuiModule.accentColorSetting;
   }

   public static DoubleSetting getUIScaleSetting() {
      return ClickGuiModule.uIScaleSetting;
   }

   public static ChoiceSetting getBlurQualitySetting() {
      return ClickGuiModule.blurQualitySetting;
   }

   public static BooleanSetting getBloomSetting() {
      return ClickGuiModule.bloomSetting;
   }

   public static BooleanSetting getOnlyOnModuleSetting() {
      return ClickGuiModule.onlyOnModuleSetting;
   }

   public static BooleanSetting getSearchSettingNamesSetting() {
      return ClickGuiModule.searchSettingNamesSetting;
   }

   public static BooleanSetting getCursorHighlightSetting() {
      return ClickGuiModule.cursorHighlightSetting;
   }

   public static ChoiceSetting getThemeSetting() {
      return ClickGuiModule.themeSetting;
   }
}
