package cc.mochi;

import net.minecraft.entity.Entity;

public interface AttackTargetBlocker {
   boolean shouldBlockAttackTarget(Entity entity);
}
