package cc.mochi;

public enum AttackWaitState {
   SWING,
   WAIT,
   RELEASE_AND_WAIT;

   private static final AttackWaitState[] ENUM_VALUES = {SWING, WAIT, RELEASE_AND_WAIT};

   public static AttackWaitState[] getENUM_VALUES() {
      return ENUM_VALUES;
   }

   private static AttackWaitState[] computeAttackWaitStateArray() {
      AttackWaitState[] attackWaitStateArray = new AttackWaitState[3];

      attackWaitStateArray[0] = SWING;
      attackWaitStateArray[1] = WAIT;

      attackWaitStateArray[2] = RELEASE_AND_WAIT;
      return attackWaitStateArray;
   }
}
