package cc.mochi;

import cc.mochi.event.impl.network.DisconnectEvent;
import cc.mochi.event.impl.player.TickEndEvent;
import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.event.impl.world.WorldChangeEvent;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;

public final class HotbarSwapSession implements MinecraftAccess {
   private final Deque<Integer> integerDeque = new ArrayDeque<>();

   private final Object object;
   private final ClientPlayerEntity clientPlayerEntity;

   private int intState;
   private final int intState2;
   private static HotbarSwapSession hotbarSwapSession;
   private final ClientWorld clientWorld;

   public static HotbarSwapSession getHotbarSwapSession() {
      return hotbarSwapSession;
   }

   public static void setIntState(HotbarSwapSession hotbarSwapSession2, int intState3) {
      hotbarSwapSession2.intState = intState3;
   }

   @EventHandler
   private void onDisconnect(DisconnectEvent disconnectEvent) {
      this.updateState();
   }

   private HotbarSwapSession(Object object2, ClientPlayerEntity clientPlayerEntity2, ClientWorld clientWorld2, int intState22, List list) {
      this.object = object2;
      this.clientPlayerEntity = clientPlayerEntity2;
      this.clientWorld = clientWorld2;
      this.intState2 = intState22;

      for (int intValue : (java.lang.Iterable<Integer>)(java.lang.Iterable<?>)(list)) {
         this.integerDeque.push(intValue);
      }
   }

   public static ClientPlayerEntity getClientPlayerEntity(HotbarSwapSession hotbarSwapSession2) {
      return hotbarSwapSession2.clientPlayerEntity;
   }

   public static int getIntState(HotbarSwapSession hotbarSwapSession2) {
      return hotbarSwapSession2.intState;
   }

   public static int getIntState2(HotbarSwapSession hotbarSwapSession2) {
      return hotbarSwapSession2.intState2;
   }

   @EventHandler
   private void onTickEnd(TickEndEvent tickEndEvent) {
      if (MinecraftClientAccess35.getPlayer(mc) == this.clientPlayerEntity) {
         if (!getIntegerDeque(this).isEmpty()) {
            ThreadLocalRandom.current().nextInt(3);

            if (HotbarSelectionManager.checkCondition2()) {
               ThreadLocalRandom.current().nextInt(15);
               if (!CombatTickBudget.checkCondition()) {
                  if (RotationManager.computeVec3d(getObject(this)) == null) {
                     if (InventoryUtils.checkCondition2(getIntegerDeque(this).peek(), getIntState2(this))) {
                        this.integerDeque.pop();
                        this.intState = 0;
                     }

                     return;
                  }
               }
            }
         } else {
            ThreadLocalRandom.current().nextInt(5);
         }
      }
   }

   public static void setHotbarSwapSession(HotbarSwapSession hotbarSwapSession2) {
      hotbarSwapSession = hotbarSwapSession2;
   }

   public static Object getObject(HotbarSwapSession hotbarSwapSession2) {
      return hotbarSwapSession2.object;
   }

   @EventHandler
   private void onWorldChange(WorldChangeEvent worldChangeEvent) {
      this.updateState();
   }

   private void updateState() {
      HotbarSelectionManager.updateState3(this);
      HotbarSwapCoordinator.updateState4(this.object);
      MinecraftClientAccess35.getINSTANCE().getMochiEventBus().unsubscribe(this);
      if (getHotbarSwapSession() == this) {
         ThreadLocalRandom.current().nextInt(14);
         hotbarSwapSession = null;
      }
   }

   public static void updateStateForClientPlayerEntity(Object objectValue, ClientPlayerEntity clientPlayerEntity2, ClientWorld clientWorld2, int intValue, List list) {
      if (hotbarSwapSession != null) {
         getHotbarSwapSession().updateState();
      }

      setHotbarSwapSession(new HotbarSwapSession(objectValue, clientPlayerEntity2, clientWorld2, intValue, list));
      MinecraftClientAccess35.getINSTANCE().getMochiEventBus().subscribe(hotbarSwapSession);
   }

   @EventHandler(
      priority = -100
   )
   private void onTick(TickEvent tickEvent) {
      HotbarSelectionManager.updateState2();
      if (mc.player == getClientPlayerEntity(this)) {
         if (mc.world == this.clientWorld) {
            int intState3 = getIntState(this);

            int intValue = intState3 + 1;
            setIntState(this, intState3 + 1);
            if (intValue <= 200) {
               if (this.integerDeque.isEmpty()) {
                  HotbarSelectionManager.updateState3(this);
                  if (!HotbarSelectionManager.getBooleanState32()) {
                     this.updateState();
                  }

                  return;
               }

               if (!this.clientPlayerEntity.isUsingItem() && MinecraftClientAccess35.getCurrentScreen(mc) == null) {
                  if (RotationManager.computeVec3d(this.object) == null) {
                     HotbarSelectionManager.updateState(this);
                     return;
                  }
               }

               HotbarSelectionManager.updateState3(this);
               return;
            }
         }
      }

      this.updateState();
   }

   public static boolean checkCondition() {
      return (getHotbarSwapSession() != null);
   }

   public static Deque<Integer> getIntegerDeque(HotbarSwapSession hotbarSwapSession2) {
      return hotbarSwapSession2.integerDeque;
   }

}
