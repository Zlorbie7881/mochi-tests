package cc.mochi;

import cc.mochi.utils.platform.PlatformService;
import java.awt.Color;
import java.util.concurrent.ThreadLocalRandom;

public class ClickGuiModule extends Module {
   public static final ChoiceSetting themeSetting;

   public static final BooleanSetting uISoundsSetting;

   public static final ChoiceSetting accentSourceSetting;

   public static final ColorSetting accentColorSetting;
   @Deprecated
   public static final DoubleSetting legacyOpacitySetting;

   public static final BooleanSetting showSearchSetting;
   public static final BooleanSetting autoFocusSearchSetting;

   public static final BooleanSetting searchSettingNamesSetting;

   public static final BooleanSetting showModuleDescriptionsSetting;

   public static final DoubleSetting openingDurationSetting;

   public static final DoubleSetting uIScaleSetting;

   public static final ChoiceSetting backdropModeSetting;

   public static final DoubleSetting camoSpeedSetting;
   public static final BooleanSetting gradientSetting;

   public static final DoubleSetting blurStrengthSetting;

   public static final ChoiceSetting blurQualitySetting;
   public static final BooleanSetting onlyOnModuleSetting;
   @Deprecated
   public static final DoubleSetting legacyBlurStrengthSetting;
   public static final BooleanSetting glassPanelsSetting;

   public static final ChoiceSetting easingSetting;

   public static final BooleanSetting cursorHighlightSetting;
   public static final BooleanSetting backgroundBlurSetting;

   public static final BooleanSetting bloomSetting;

   public static final BooleanSetting reducedMotionSetting;

   public static final DoubleSetting opacitySetting;
   @Deprecated
   public static final BooleanSetting legacyUiSoundsSetting;

   public static final DoubleSetting glassRefractionSetting;

   public static final DoubleSetting closingDurationSetting;

   public static final DoubleSetting glassBlurSetting;

   public static final DoubleSetting bloomIntensitySetting;

   @Deprecated
   public static final ChoiceSetting gUIFontSetting;

   @Deprecated
   public static final BooleanSetting legacyBackgroundBlurSetting;

   public static float max() {
      return Math.max((0.25F), Math.min((4.0F), ClickGuiModuleAccess2.getBlurStrengthSetting().floatValue() / 8.0F));
   }

   public static Color[] computeColorArrayForThemeSnapshot(ThemeSnapshot themeSnapshot) {
      Color[] colorArray = new Color[4];

      colorArray[0] = themeSnapshot.getGradientStart();
      colorArray[1] = themeSnapshot.getGradientMid();
      colorArray[2] = themeSnapshot.getGradientEnd2();
      colorArray[3] = themeSnapshot.getAccent2();
      return colorArray;
   }

   public static boolean getValue() {
      return reducedMotionSetting.getValue();
   }

   public static float getFloatConstant() {
      return 5.0F;
   }

   @Override
   public void onEnable() {
      ThemeManager.updateState(ClickGuiModuleAccess2.getThemeSetting().getSelected());
      if (mc.currentScreen == null) {
         mc.setScreen(new ClickGuiScreen());
      }

      this.setEnabled(false);
   }

   public static float floatValue() {
      return camoSpeedSetting.floatValue();
   }

   public static float floatValue2() {
      return blurStrengthSetting.floatValue();
   }

   public ClickGuiModule() {
      super("Click Gui", "Opens the Mochi ClickGUI", 344, ModuleCategory.CLIENT);
      updateState();
      Setting[] settingArray = new Setting[]{
         themeSetting,
         uISoundsSetting,
         accentSourceSetting,
         accentColorSetting,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null
      };

      settingArray[4] = showSearchSetting;
      settingArray[5] = autoFocusSearchSetting;
      settingArray[6] = searchSettingNamesSetting;
      settingArray[7] = showModuleDescriptionsSetting;
      settingArray[8] = uIScaleSetting;

      settingArray[9] = backdropModeSetting;
      settingArray[10] = gradientSetting;
      settingArray[11] = onlyOnModuleSetting;
      settingArray[12] = camoSpeedSetting;
      settingArray[13] = opacitySetting;

      settingArray[14] = glassPanelsSetting;
      settingArray[15] = glassBlurSetting;

      settingArray[16] = glassRefractionSetting;

      settingArray[17] = cursorHighlightSetting;

      settingArray[18] = backgroundBlurSetting;
      settingArray[19] = blurStrengthSetting;
      settingArray[20] = blurQualitySetting;
      settingArray[21] = bloomSetting;
      settingArray[22] = bloomIntensitySetting;

      settingArray[23] = openingDurationSetting;
      settingArray[24] = closingDurationSetting;
      settingArray[25] = easingSetting;
      settingArray[26] = reducedMotionSetting;
      this.addSettings(settingArray);
   }

   public static boolean equals() {
      return backdropModeSetting.equals("Aurora");
   }

   public static float computeFloat() {
      return computeFloat2();
   }

   public static int getIntConstant() {
      return 0;
   }

   public static boolean checkCondition() {
      if (ClickGuiModuleAccess2.getCursorHighlightSetting().getValue()) {
         if (!ClickGuiModuleAccess2.getReducedMotionSetting().getValue()) {
            return true;
         }
      }

      return false;
   }

   private static Boolean valueOf() {
      return Boolean.valueOf((!ClickGuiModuleAccess2.getReducedMotionSetting().getValue()));
   }

   public static boolean checkCondition2() {
      if (ClickGuiModuleAccess2.getGradientSetting().getValue()) {
         if (!onlyOnModuleSetting.getValue()) {
            return true;
         }
      }

      return false;
   }

   private static Boolean computeBoolean() {
      byte byteValue;
      if (!reducedMotionSetting.getValue()) {
         byteValue = 1;
      } else {
         byteValue = 12;
         ThreadLocalRandom.current().nextInt(11);
         byteValue = 0;
      }

      return Boolean.valueOf((byteValue != 0));
   }

   public static boolean getValue2() {
      return showModuleDescriptionsSetting.getValue();
   }

   public static float floatValue3() {
      return ClickGuiModuleAccess2.getGlassRefractionSetting().floatValue();
   }

   public static float getFloatConstant2() {
      return 10.0F;
   }

   public static void setValue(float floatValue) {
      uIScaleSetting.setValue((double)floatValue);
   }

   public static float max2() {
      return Math.max(0.0F, bloomIntensitySetting.floatValue() / (100.0F));
   }

   public static int computeInt() {
      int intValue = 22;
      ThreadLocalRandom.current().nextInt(14);
      if (ClickGuiModuleAccess2.getReducedMotionSetting().getValue()) {
         intValue = 0;
      } else {
         intValue = ClickGuiModuleAccess2.getOpeningDurationSetting().intValue();

         ThreadLocalRandom.current().nextInt(15);
      }

      return intValue;
   }

   public static ThemeSnapshot computeThemeSnapshot() {
      return ThemeSnapshot.computeThemeSnapshot();
   }

   public static float floatValue4() {
      return ClickGuiModuleAccess2.getGlassBlurSetting().floatValue();
   }

   public static boolean getValue3() {
      return ClickGuiModuleAccess2.getShowSearchSetting().getValue();
   }

   public static int computeInt2() {
      int intValue;
      if (reducedMotionSetting.getValue()) {
         intValue = 0;
      } else {
         intValue = closingDurationSetting.intValue();

         ThreadLocalRandom.current().nextInt(17);
      }

      return intValue;
   }

   public static boolean checkCondition3() {
      if (gradientSetting.getValue()) {
         if (onlyOnModuleSetting.getValue()) {
            return true;
         }

         ThreadLocalRandom.current().nextInt(17);
      }

      return false;
   }

   public static String getSelected() {
      return blurQualitySetting.getSelected();
   }

   public static boolean getValue4() {
      return ClickGuiModuleAccess2.getBackgroundBlurSetting().getValue();
   }

   static {
      themeSetting = new ThemeChoiceSetting("Theme", ThemeManager.getString2(), ThemeManager.computeStringArray());
      ThemeManager.updateStateForConsumer(objectValue -> themeSetting.setChoices((String[])objectValue));
      HudBloomRenderer.configureBloom(() -> checkCondition5(), () -> (double)max2());
      uISoundsSetting = new BooleanSetting("UI Sounds", true);
      accentSourceSetting = new ChoiceSetting("Accent Source", "Theme", "Theme", "Custom");
      accentColorSetting = new ColorSetting("Accent Color", new Color(255, 167, 199));
      showSearchSetting = new BooleanSetting("Show Search", true);
      autoFocusSearchSetting = new BooleanSetting("Auto-focus Search", true);
      searchSettingNamesSetting = new BooleanSetting("Search Setting Names", true);
      showModuleDescriptionsSetting = new BooleanSetting("Show Module Descriptions", true);
      uIScaleSetting = new DoubleSetting("UI Scale", 0.75, 1.25, 1.0, 0.05);
      String[] stringArray = new String[4];

      stringArray[0] = "None";

      stringArray[1] = "Dim";
      stringArray[2] = "Gradient";

      stringArray[3] = "Aurora";
      backdropModeSetting = new ChoiceSetting("Backdrop Mode", "Aurora", stringArray);
      gradientSetting = new BooleanSetting("Gradient", false);
      onlyOnModuleSetting = new BooleanSetting("Only On Module", false);
      camoSpeedSetting = new DoubleSetting("Camo Speed", 0.1, (2.5), (0.8), 0.05);
      opacitySetting = new DoubleSetting("Opacity", (1.0), 100.0, (72.0), (1.0));
      glassPanelsSetting = new BooleanSetting("Glass Panels", true);
      glassBlurSetting = new DoubleSetting("Glass Blur", (4.0), 40.0, 18.0, 1.0);
      glassRefractionSetting = new DoubleSetting("Glass Refraction", 0.0, 20.0, (10.0), 1.0);
      cursorHighlightSetting = new BooleanSetting("Cursor Highlight", true);
      backgroundBlurSetting = new BooleanSetting("Background Blur", false);
      blurStrengthSetting = new DoubleSetting("Blur Strength", (1.0), 30.0, 14.0, 1.0);
      String[] stringArray2 = new String[]{"Performance", null, null};

      stringArray2[1] = "Balanced";

      stringArray2[2] = "Quality";
      blurQualitySetting = new ChoiceSetting("Blur Quality", "Balanced", stringArray2);
      bloomSetting = new BooleanSetting("Bloom", true);
      bloomIntensitySetting = new DoubleSetting("Bloom Intensity", (0.0), (200.0), 100.0, 5.0);
      openingDurationSetting = new DoubleSetting("Opening Duration", (0.0), (1000.0), 320.0, (10.0));
      closingDurationSetting = new DoubleSetting("Closing Duration", 0.0, 1000.0, (220.0), (10.0));
      String[] stringArray3 = new String[3];

      stringArray3[0] = "Ease Out Cubic";
      stringArray3[1] = "Ease Out Quart";

      stringArray3[2] = "Linear";
      easingSetting = new ChoiceSetting("Easing", "Ease Out Cubic", stringArray3);
      reducedMotionSetting = new BooleanSetting("Reduced Motion", false);
      legacyUiSoundsSetting = uISoundsSetting;
      gUIFontSetting = new ChoiceSetting("GUI Font", "Quicksand", "Quicksand");
      legacyBlurStrengthSetting = blurStrengthSetting;
      legacyOpacitySetting = opacitySetting;
      legacyBackgroundBlurSetting = backgroundBlurSetting;
   }

   public static boolean getValue5() {
      return ClickGuiModuleAccess2.getAutoFocusSearchSetting().getValue();
   }

   private static Boolean valueOf2() {
      return Boolean.valueOf((!reducedMotionSetting.getValue()));
   }

   public static Color computeColor() {
      ThemeManager.updateState(themeSetting.getSelected());
      if (accentSourceSetting.equals("Custom")) {
         return ClickGuiModuleAccess2.getAccentColorSetting().getValue();
      } else {
         return ThemeManager.getOrDefault().getAccent2();
      }
   }

   public static float getFloatConstant3() {
      return (4.0F);
   }

   public static String getSelected2() {
      return ClickGuiModuleAccess2.getEasingSetting().getSelected();
   }

   private static void updateState() {
      accentColorSetting.setVisibility(() -> equals2());
      autoFocusSearchSetting.setVisibility(showSearchSetting::getValue);
      ClickGuiModuleAccess2.getSearchSettingNamesSetting().setVisibility(showSearchSetting::getValue);
      ClickGuiModuleAccess2.getOnlyOnModuleSetting().setVisibility(ClickGuiModuleAccess2.getGradientSetting()::getValue);
      camoSpeedSetting.setVisibility(ClickGuiModuleAccess2.getGradientSetting()::getValue);
      ClickGuiModuleAccess2.getBlurQualitySetting().setVisibility(ClickGuiModuleAccess2.getBackgroundBlurSetting()::getValue);
      ClickGuiModuleAccess2.getBloomIntensitySetting().setVisibility(ClickGuiModuleAccess2.getBloomSetting()::getValue);
      glassBlurSetting.setVisibility(glassPanelsSetting::getValue);
      ClickGuiModuleAccess2.getGlassRefractionSetting().setVisibility(ClickGuiModuleAccess2.getGlassPanelsSetting()::getValue);
      cursorHighlightSetting.setVisibility(ClickGuiModuleAccess2.getGlassPanelsSetting()::getValue);
      openingDurationSetting.setVisibility(() -> computeBoolean());
      closingDurationSetting.setVisibility(() -> valueOf());
      ClickGuiModuleAccess2.getEasingSetting().setVisibility(() -> valueOf2());
   }

   public static int getIntConstant2() {
      return 0;
   }

   public static ThemeSnapshot computeThemeSnapshot2(float floatValue) {
      return ThemeSnapshot.computeThemeSnapshot2(floatValue);
   }

   public static boolean checkCondition4() {
      if (showSearchSetting.getValue()) {
         if (ClickGuiModuleAccess2.getSearchSettingNamesSetting().getValue()) {
            return true;
         }
      }

      return false;
   }

   public static String getSelected3() {
      return backdropModeSetting.getSelected();
   }

   public static boolean checkCondition5() {
      if (ClickGuiModuleAccess2.getBloomSetting().getValue()) {
         if (!PlatformService.isMobile()) {
            ThreadLocalRandom.current().nextInt(13);

            return true;
         }
      }

      return false;
   }

   public static float getFloatConstant4() {
      return 20.0F;
   }

   public static float floatValue5() {
      return ClickGuiModuleAccess2.getUIScaleSetting().floatValue();
   }

   public static String getStringConstant() {
      return "Quicksand";
   }

   public static boolean getValue6() {
      return gradientSetting.getValue();
   }

   public static boolean getValue7() {
      return glassPanelsSetting.getValue();
   }

   private static Boolean equals2() {
      return accentSourceSetting.equals("Custom");
   }

   public static float computeFloat2() {
      return ClickGuiModuleAccess2.getOpacitySetting().floatValue() / (100.0F);
   }

   public static boolean getValue8() {
      return uISoundsSetting.getValue();
   }
}
