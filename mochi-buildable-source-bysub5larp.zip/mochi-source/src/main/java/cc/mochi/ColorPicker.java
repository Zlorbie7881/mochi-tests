package cc.mochi;

import java.awt.Color;
import java.util.Map;
import java.util.WeakHashMap;

public final class ColorPicker {
   private final Map<ColorSetting, Float> floatByColorSetting = new WeakHashMap<>();

   private void updateStateForRect(Rect rect, ColorSetting colorSetting, UiContext uiContext, int intValue, double doubleValue, double doubleValue2) {
      ClientSounds.updateState();
      DragHandler dragHandler = (doubleValue3, doubleValue4) -> this.updateStateForRect4(rect, colorSetting, doubleValue3, doubleValue4);
      dragHandler.drag(doubleValue, doubleValue2);
      uiContext.getInputRouter().beginDrag(dragHandler);
   }

   private static void updateStateForUiContext(UiContext uiContext, Rect rect, float floatValue, float floatValue2) {
      float centerX = rect.getX() + rect.getWidth() * UiContext.clampUnit(floatValue);
      uiContext.getUiRenderContext().fillCircle(centerX, rect.centerY(), 5.5F, UiRenderContext.withAlpha(Color.BLACK, 70.0F * floatValue2));
      uiContext.getUiRenderContext().strokeCircle(centerX, rect.centerY(), 4.7F, 1.6F, UiContext.multiplyAlpha(ColorAccess5.getWHITE(), floatValue2));
   }

   private void setHsb(ColorSetting colorSetting, Rect rect, double doubleValue, double doubleValue2) {
      colorSetting.setHsb(
         this.computeFloatForColorSetting(colorSetting), UiContext.clampUnit((float)((doubleValue - (double)rect.getX()) / (double)rect.getWidth())), 1.0F - UiContext.clampUnit((float)((doubleValue2 - (double)rect.getY()) / (double)rect.getHeight()))
      );
   }

   private float computeFloatForColorSetting(ColorSetting colorSetting) {
      float[] hsb = colorSetting.getHsb();
      Float objectValue = getFloatByColorSetting(this).get(colorSetting);
      if (objectValue != null && (!(hsb[1] > 0.02F) || !(hsb[2] > 0.02F) || !(Math.abs(objectValue - hsb[0]) > 0.002F))) {
         return objectValue;
      } else {
         this.floatByColorSetting.put(colorSetting, hsb[0]);
         return hsb[0];
      }
   }

   public static Map<ColorSetting, Float> getFloatByColorSetting(ColorPicker colorPicker) {
      return colorPicker.floatByColorSetting;
   }

   public static float computeFloatForColorSetting2(ColorSetting colorSetting) {
      return 75.0F + (colorSetting.allowsAlpha() ? 13.0F : 0.0F) + 6.0F + 11.0F + 4.0F;
   }

   private static void updateStateForRect2(Rect rect, ColorSetting colorSetting, UiContext uiContext, int intValue, double doubleValue, double doubleValue2) {
      ClientSounds.updateState();
      DragHandler dragHandler = (doubleValue3, doubleValue4) -> updateStateForRect3(rect, colorSetting, doubleValue3, doubleValue4);
      dragHandler.drag(doubleValue, doubleValue2);
      uiContext.getInputRouter().beginDrag(dragHandler);
   }

   private void updateStateForColorSetting(ColorSetting colorSetting, Color color) {
      ClientSounds.updateState4();
      int intValue = colorSetting.allowsAlpha() ? colorSetting.getAlpha() : 255;
      colorSetting.setRgba(color.getRed(), color.getGreen(), color.getBlue(), intValue);
      getFloatByColorSetting(this).put(colorSetting, Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), null)[0]);
   }

   private static void updateStateForRect3(Rect rect, ColorSetting colorSetting, double doubleValue, double doubleValue2) {
      int intValue = Math.round(SliderWidgets.computeFloat(doubleValue, rect.getX(), rect.getWidth()) * 255.0F);
      colorSetting.setRgba(colorSetting.getRed(), colorSetting.getGreen(), colorSetting.getBlue(), intValue);
   }

   public void updateStateForUiContext2(UiContext uiContext, String string, ColorSetting colorSetting, float x, float floatValue2, float floatValue3, UiLayer uiLayer, Rect rect, float floatValue4) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      UiRenderContext uiRenderContext = uiContext.getUiRenderContext();
      float[] hsb = colorSetting.getHsb();
      float floatValue5 = this.computeFloatForColorSetting(colorSetting);
      Color hSBColor = Color.getHSBColor(floatValue5, 1.0F, 1.0F);
      Rect rect2 = new Rect(x, floatValue2, floatValue3, 62.0F);
      uiRenderContext.fillHorizontalGradient(rect2.getX(), rect2.getY(), rect2.getWidth(), rect2.getHeight(), 6.0F, UiContext.multiplyAlpha(ColorAccess5.getWHITE(), floatValue4), UiContext.multiplyAlpha(hSBColor, floatValue4));
      uiRenderContext.fillVerticalGradient(rect2.getX(), rect2.getY(), rect2.getWidth(), rect2.getHeight(), 6.0F, new Color(0, 0, 0, 0), UiRenderContext.withAlpha(Color.BLACK, 255.0F * floatValue4));
      uiRenderContext.strokeRoundedRect(rect2.getX(), rect2.getY(), rect2.getWidth(), rect2.getHeight(), 6.0F, 1.0F, UiContext.multiplyAlpha(themeSnapshot2.getHairline2(), floatValue4));
      float centerX = rect2.getX() + hsb[1] * rect2.getWidth();
      float centerY = rect2.getY() + (1.0F - hsb[2]) * rect2.getHeight();
      uiRenderContext.fillCircle(centerX, centerY, 4.2F, UiRenderContext.withAlpha(ColorAccess5.getBLACK(), 90.0F * floatValue4));
      uiRenderContext.strokeCircle(centerX, centerY, 3.6F, 1.6F, UiContext.multiplyAlpha(ColorAccess5.getWHITE(), floatValue4));
      uiContext.getInputRouter().addPressRegion(rect2.intersection(rect), uiLayer, (intValue, doubleValue, doubleValue2) -> this.updateStateForColorSetting2(colorSetting, rect2, uiContext, intValue, doubleValue, doubleValue2));
      float y = floatValue2 + 62.0F + 6.0F;
      Rect rect3 = new Rect(x, y, floatValue3, 7.0F);
      float floatValue9 = floatValue3 / 6.0F;

      for (int intValue2 = 0; intValue2 < 6; intValue2++) {
         Color hSBColor2 = Color.getHSBColor((float)intValue2 / 6.0F, 1.0F, 1.0F);
         Color hSBColor3 = Color.getHSBColor((float)(intValue2 + 1) / 6.0F, 1.0F, 1.0F);
         float floatValue10 = x + floatValue9 * (float)intValue2;
         uiRenderContext.fillHorizontalGradient(
            floatValue10 - (intValue2 > 0 ? 0.5F : 0.0F),
            y,
            floatValue9 + (intValue2 > 0 && intValue2 < 5 ? 1.0F : 0.5F),
            7.0F,
            intValue2 != 0 && intValue2 != 5 ? 0.0F : 3.5F,
            UiContext.multiplyAlpha(hSBColor2, floatValue4),
            UiContext.multiplyAlpha(hSBColor3, floatValue4)
         );
      }

      updateStateForUiContext(uiContext, rect3, floatValue5, floatValue4);
      uiContext.getInputRouter().addPressRegion(rect3.expand(3.0F).intersection(rect), uiLayer, (intValue3, doubleValue3, doubleValue4) -> this.updateStateForRect(rect3, colorSetting, uiContext, intValue3, doubleValue3, doubleValue4));
      float floatValue11 = y + 7.0F;
      if (colorSetting.allowsAlpha()) {
         floatValue11 += 6.0F;
         Rect rect4 = new Rect(x, floatValue11, floatValue3, 7.0F);
         Color color = new Color(colorSetting.getRed(), colorSetting.getGreen(), colorSetting.getBlue());
         uiRenderContext.fillRoundedRect(rect4.getX(), rect4.getY(), rect4.getWidth(), rect4.getHeight(), 3.5F, UiContext.multiplyAlpha(themeSnapshot2.getSurfaceSunken(), floatValue4));
         uiRenderContext.fillHorizontalGradient(rect4.getX(), rect4.getY(), rect4.getWidth(), rect4.getHeight(), 3.5F, new Color(color.getRed(), color.getGreen(), color.getBlue(), 0), UiContext.multiplyAlpha(color, floatValue4));
         updateStateForUiContext(uiContext, rect4, (float)colorSetting.getAlpha() / 255.0F, floatValue4);
         uiContext.getInputRouter().addPressRegion(rect4.expand(3.0F).intersection(rect), uiLayer, (intValue4, doubleValue5, doubleValue6) -> updateStateForRect2(rect4, colorSetting, uiContext, intValue4, doubleValue5, doubleValue6));
         floatValue11 += 7.0F;
      }

      floatValue11 += 6.0F;
      float y2 = floatValue11 + 5.5F;
      String text = colorSetting.allowsAlpha() ? String.format(ColorAccess5.getROOT(), "#%08X", colorSetting.getRgb()) : String.format(ColorAccess5.getROOT(), "#%06X", colorSetting.getRgb() & 16777215);
      uiContext.drawVerticallyCenteredText(text, x, y2, TextStyle.CAPTION, UiContext.multiplyAlpha(themeSnapshot2.getSecondaryText2(), floatValue4));
      Color[] colorArray = new Color[]{themeSnapshot2.getAccent2(), themeSnapshot2.getSecondaryAccent2(), themeSnapshot2.getGradientStart(), themeSnapshot2.getGradientMid(), themeSnapshot2.getGradientEnd2(), Color.WHITE, new Color(24, 24, 28)};
      float floatValue13 = x + floatValue3 - (float)colorArray.length * 15.0F + 4.0F;

      for (int intValue5 = 0; intValue5 < colorArray.length; intValue5++) {
         Color color2 = ThemeSnapshot.computeColorForColor(colorArray[intValue5]);
         Rect rect5 = new Rect(floatValue13 + (float)intValue5 * 15.0F, floatValue11, 11.0F, 11.0F);
         boolean hovered = uiContext.isHovered(rect5, uiLayer);
         float floatValue14 = uiContext.animateHover(string + ".sw" + intValue5, hovered);
         uiRenderContext.fillCircle(rect5.centerX(), rect5.centerY(), 5.5F + floatValue14, UiContext.multiplyAlpha(color2, floatValue4));
         uiRenderContext.strokeCircle(rect5.centerX(), rect5.centerY(), 5.5F + floatValue14, 1.0F, UiContext.multiplyAlpha(themeSnapshot2.getHairline2(), floatValue4));
         uiContext.getInputRouter().addClickRegion(rect5.intersection(rect), uiLayer, () -> this.updateStateForColorSetting(colorSetting, color2));
      }
   }

   private void updateStateForColorSetting2(ColorSetting colorSetting, Rect rect, UiContext uiContext, int intValue, double doubleValue, double doubleValue2) {
      ClientSounds.updateState();
      DragHandler dragHandler = (doubleValue3, doubleValue4) -> this.setHsb(colorSetting, rect, doubleValue3, doubleValue4);
      dragHandler.drag(doubleValue, doubleValue2);
      uiContext.getInputRouter().beginDrag(dragHandler);
   }

   private void updateStateForRect4(Rect rect, ColorSetting colorSetting, double doubleValue, double doubleValue2) {
      float floatValue = Math.min(0.999F, SliderWidgets.computeFloat(doubleValue, rect.getX(), rect.getWidth()));
      this.floatByColorSetting.put(colorSetting, floatValue);
      float[] hsb = colorSetting.getHsb();
      colorSetting.setHsb(floatValue, hsb[1], hsb[2]);
   }
}
