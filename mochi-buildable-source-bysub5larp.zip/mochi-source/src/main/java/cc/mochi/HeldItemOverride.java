package cc.mochi;

import cc.mochi.mixin.ClientPlayerInteractionManagerMixin;
import cc.mochi.mixin.KeyBindingAccessor;
import java.util.Collection;
import java.util.Iterator;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.locks.LockSupport;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.type.AttackRangeComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public final class HeldItemOverride {
   private static int selectedSlot2 = -1;
   private static boolean booleanState;

   private static int intState = -1;

   private static long currentTick22;

   private static ItemStack itemStack = ItemStack.EMPTY;

   private static boolean booleanState2;
   private static ClientPlayerEntity clientPlayerEntity;

   private static Object object;

   private static long longState = Long.MIN_VALUE;

   public static boolean getBooleanState() {
      return booleanState;
   }

   public static Object getObject() {
      return object;
   }

   public static int computeIntForClientPlayerEntity(ClientPlayerEntity clientPlayerEntity2) {
      return clientPlayerEntity2 == null ? -1 : InventoryUtils.computeIntForPredicate2(objectValue -> testClientPlayerEntity2(clientPlayerEntity2, (ItemStack)objectValue));
   }

   public static boolean getBooleanState2() {
      return booleanState2;
   }

   public static EntityHitResult computeEntityHitResultForClientPlayerEntity(ClientPlayerEntity clientPlayerEntity2, double doubleValue) {
      Vec3d eyePos = clientPlayerEntity2.getEyePos();

      Vec3d rotationVec = clientPlayerEntity2.getRotationVec((1.0F));
      Vec3d vec3d = eyePos.add(rotationVec.multiply(doubleValue));
      Box box = clientPlayerEntity2.getBoundingBox().stretch(rotationVec.multiply(doubleValue));

      Box box2 = box.expand((1.0));
      EntityHitResult entityHitResult = ProjectileUtil.raycast(clientPlayerEntity2, eyePos, vec3d, box2, entity -> testEntity((Entity)entity), doubleValue * doubleValue);
      if (entityHitResult == null) {
         return null;
      } else {
         ThreadLocalRandom.current().nextInt(15);
         double doubleValue2 = eyePos.distanceTo(entityHitResult.getPos());
         if (doubleValue2 > doubleValue) {
            return null;
         } else {
            HitResult hitResult = clientPlayerEntity2.raycast(doubleValue2, 1.0F, false);
            if (hitResult.getType() != MinecraftClientAccess47.getMISS()) {
               if (eyePos.squaredDistanceTo(hitResult.getPos()) < doubleValue2 * doubleValue2) {
                  return null;
               }
            }

            return entityHitResult;
         }
      }
   }

   public static void setClientPlayerEntity(ClientPlayerEntity clientPlayerEntity2) {
      clientPlayerEntity = clientPlayerEntity2;
   }

   public static void setLongState(long longState2) {
      longState = longState2;
   }

   public static boolean testClientPlayerEntity(ClientPlayerEntity clientPlayerEntity2, Entity entity, float floatValue, float floatValue2) {
      if (clientPlayerEntity2 != null) {
         if (entity != null && testItemStack(clientPlayerEntity2.getMainHandStack())) {
            int intValue = computeIntForClientPlayerEntity(clientPlayerEntity2);
            if (intValue >= 0) {
               if (intValue != clientPlayerEntity2.getInventory().getSelectedSlot()) {
                  ItemStack stack = clientPlayerEntity2.getInventory().getStack(intValue);
                  Vec3d eyePos = clientPlayerEntity2.getEyePos();
                  Vec3d vec3d = Vec3d.fromPolar(floatValue2, floatValue);
                  if (CombatPredicates.anyMatch(CombatPredicates.computeCollectionForClientPlayerEntity2(clientPlayerEntity2, stack, eyePos, vec3d))) {
                     return false;
                  }

                  Iterator iterator = CombatPredicates.computeCollectionForClientPlayerEntity3(clientPlayerEntity2, stack, eyePos, vec3d, (0.0F)).iterator();

                  while (true) {
                     if (!iterator.hasNext()) {
                        return false;
                     }

                     EntityHitResult entityHitResult = (EntityHitResult)iterator.next();
                     if (entityHitResult.getEntity() == entity) {
                        return true;
                     }

                     ThreadLocalRandom.current().nextInt(10);
                  }
               }
            }

            return false;
         }
      } else {
         ThreadLocalRandom.current().nextInt(13);
      }

      return false;
   }

   static {
      currentTick22 = (-9223372036854775808L);
   }

   public static long getLongState() {
      return longState;
   }

   public static int computeIntForClientPlayerEntity2(ClientPlayerEntity clientPlayerEntity2, int intValue) {
      int intValue2 = computeIntForClientPlayerEntity(clientPlayerEntity2);
      if (intValue2 < 0) {
         return intValue;
      } else {
         ItemStack stack = clientPlayerEntity2.getInventory().getStack(intValue2);

         int intValue3 = 0;

         while (true) {
            if (intValue3 >= intValue) {
               return intValue;
            }

            if (!clientPlayerEntity2.isBelowMinimumAttackCharge(stack, intValue3 - 1)) {
               ThreadLocalRandom.current().nextInt(11);
               return intValue3;
            }

            intValue3++;
         }
      }
   }

   public static void setIntState(int intState2) {
      intState = intState2;
   }

   public static void setBooleanState(boolean booleanState3) {
      booleanState = booleanState3;
   }

   public static void updateState() {
      if (object != null) {
         if (booleanState2) {
            HotbarSwapCoordinator.updateState(getObject());
         }
      }

      setObject(null);
      clientPlayerEntity = null;

      setIntState(-1);
      selectedSlot2 = -1;
      setItemStack(ItemStack.EMPTY);

      setLongState(Long.MIN_VALUE);
      booleanState2 = false;
      setBooleanState(false);
   }

   public static void updateStateForPlayerEntity(PlayerEntity playerEntity, Entity entity) {
      double doubleValue = playerEntity.getEntityInteractionRange() + 0.001;
      if (entity.getBoundingBox().squaredMagnitude(playerEntity.getEyePos()) > doubleValue * doubleValue) {
         currentTick22 = ActionSchedulers.getCurrentTick22();
      }
   }

   public static boolean testMinecraftClient(MinecraftClient minecraftClient, Object object2, boolean booleanState22) {
      ClientPlayerEntity clientPlayerEntity2 = MinecraftClientAccess47.getPlayer(minecraftClient);
      if (clientPlayerEntity2 != null && MinecraftClientAccess47.getWorld(minecraftClient) != null && MinecraftClientAccess47.getInteractionManager(minecraftClient) != null) {
         if (getObject() == null) {
            if (testItemStack(clientPlayerEntity2.getMainHandStack()) && CombatTickBudget.checkCondition2()) {
               int selectedSlot = clientPlayerEntity2.getInventory().getSelectedSlot();
               int intState2 = computeIntForClientPlayerEntity(clientPlayerEntity2);
               if (intState2 >= 0 && intState2 != selectedSlot) {
                  object = object2;
                  clientPlayerEntity = clientPlayerEntity2;
                  selectedSlot2 = selectedSlot;
                  intState = intState2;
                  itemStack = clientPlayerEntity2.getMainHandStack().copy();
                  setLongState(ActionSchedulers.getCurrentTick22());
                  setBooleanState2(booleanState22);
                  if (booleanState22) {
                     HotbarSwapCoordinator.updateStateForClientPlayerEntity(object2, clientPlayerEntity2, MinecraftClientAccess47.getWorld(minecraftClient), selectedSlot);
                     HotbarSwapCoordinator.updateState3(object2, intState2);
                  }

                  clientPlayerEntity2.getInventory().setSelectedSlot(intState2);
                  ((ClientPlayerInteractionManagerMixin.ClientPlayerInteractionManagerAccessor)MinecraftClientAccess47.getInteractionManager(minecraftClient)).mochi$syncSelectedSlot();
                  CombatTickBudget.setBooleanState222();
                  long longValue = System.nanoTime();

                  long longValue2 = longValue + 1000000L;

                  long longValue3 = 1000000L;

                  do {
                     LockSupport.parkNanos(longValue3);
                     longValue3 = longValue2 - System.nanoTime();
                  } while (longValue3 > 0L);

                  return true;
               }

               return false;
            }
         }
      }

      return false;
   }

   public static void setSelectedSlot2(int selectedSlot22) {
      selectedSlot2 = selectedSlot22;
   }

   public static void setBooleanState2(boolean booleanState22) {
      booleanState2 = booleanState22;
   }

   private static boolean testClientPlayerEntity2(ClientPlayerEntity clientPlayerEntity2, ItemStack itemStack2) {
      if (CombatPredicates.testItemStack(itemStack2)) {
         if (itemStack2.isItemEnabled(clientPlayerEntity2.getEntityWorld().getEnabledFeatures())) {
            return true;
         }
      }

      return false;
   }

   public static boolean checkCondition() {
      if (getObject() != null) {
         if (getLongState() == ActionSchedulers.getCurrentTick22()) {
            return true;
         }
      }

      return false;
   }

   public static void updateStateForMinecraftClient(MinecraftClient minecraftClient) {
      if (object != null && getLongState() != ActionSchedulers.getCurrentTick22()) {
         updateStateForMinecraftClient2(minecraftClient);
      }

      if ((getBooleanState())) {
         setBooleanState(false);
         if (minecraftClient.options != null) {
            if (MinecraftClientAccess47.getPlayer(minecraftClient) != null && !MinecraftClientAccess47.getUseKey(minecraftClient.options).isPressed()) {
               KeyBindingAccessor useKey = (KeyBindingAccessor)minecraftClient.options.useKey;
               useKey.setTimesPressed(useKey.getTimesPressed() + 1);
               return;
            }
         } else {
            ThreadLocalRandom.current().nextInt(5);
         }
      }
   }

   public static void setItemStack(ItemStack itemStack2) {
      itemStack = itemStack2;
   }

   private HeldItemOverride() {
   }

   private static boolean testEntity(Entity entity) {
      if (!entity.isSpectator()) {
         if (entity.canHit()) {
            return true;
         }
      }

      return false;
   }

   public static LivingEntity computeLivingEntityForClientPlayerEntity(ClientPlayerEntity clientPlayerEntity2, boolean booleanValue, double doubleValue) {
      if (clientPlayerEntity2 != null) {
         if (testItemStack(clientPlayerEntity2.getMainHandStack())) {
            int intValue = computeIntForClientPlayerEntity(clientPlayerEntity2);
            if (intValue >= 0) {
               if (intValue != clientPlayerEntity2.getInventory().getSelectedSlot()) {
                  ItemStack stack = clientPlayerEntity2.getInventory().getStack(intValue);
                  Vec3d eyePos = clientPlayerEntity2.getEyePos();
                  Vec3d vec3d = Vec3d.fromPolar(clientPlayerEntity2.getPitch(), clientPlayerEntity2.getHeadYaw());
                  if (!CombatPredicates.anyMatch(CombatPredicates.computeCollectionForClientPlayerEntity2(clientPlayerEntity2, stack, eyePos, vec3d))) {
                     ThreadLocalRandom.current().nextInt(10);
                     if (!CombatPredicates.anyMatch(CombatPredicates.computeCollectionForClientPlayerEntity(clientPlayerEntity2, stack))) {
                        Collection collection = CombatPredicates.computeCollectionForClientPlayerEntity3(clientPlayerEntity2, stack, eyePos, vec3d, (0.0F));
                        return CombatPredicates.computeLivingEntityForPlayerEntity(clientPlayerEntity2, eyePos, collection, booleanValue, doubleValue);
                     }
                  }

                  return null;
               }
            }

            return null;
         }

         ThreadLocalRandom.current().nextInt(12);
      }

      return null;
   }

   public static double computeDoubleForClientPlayerEntity(ClientPlayerEntity clientPlayerEntity2, double doubleValue) {
      double entityInteractionRange = clientPlayerEntity2.getEntityInteractionRange();
      int intValue = computeIntForClientPlayerEntity(clientPlayerEntity2);
      if (intValue >= 0) {
         if (intValue != clientPlayerEntity2.getInventory().getSelectedSlot()) {
            if (testItemStack(clientPlayerEntity2.getMainHandStack())) {
               AttackRangeComponent attackRangeComponent = (AttackRangeComponent)clientPlayerEntity2.getInventory().getStack(intValue).get(MinecraftClientAccess47.getATTACK_RANGE());
               double entityInteractionRange2;
               if (attackRangeComponent == null) {
                  entityInteractionRange2 = entityInteractionRange;
               } else {
                  ThreadLocalRandom.current().nextInt(9);
                  entityInteractionRange2 = Math.max(entityInteractionRange, Math.min((double)attackRangeComponent.maxRange(), doubleValue));
               }

               return entityInteractionRange2;
            }
         }
      }

      return entityInteractionRange;
   }

   public static boolean checkCondition2() {
      if (currentTick22 != ActionSchedulers.getCurrentTick22()) {
         if (!checkCondition()) {
            return false;
         }

         ThreadLocalRandom.current().nextInt(4);
      }

      setBooleanState(true);
      return true;
   }

   public static void setObject(Object object2) {
      object = object2;
   }

   private static void updateStateForMinecraftClient2(MinecraftClient minecraftClient) {
      Object object2 = getObject();
      ClientPlayerEntity clientPlayerEntity2 = clientPlayerEntity;
      int selectedSlot22 = selectedSlot2;
      int intState2 = intState;
      ItemStack itemStack2 = itemStack;
      boolean booleanState22 = getBooleanState2();
      object = null;
      setClientPlayerEntity(null);
      setIntState(-1);
      setSelectedSlot2(-1);
      itemStack = ItemStack.EMPTY;

      setLongState(Long.MIN_VALUE);

      booleanState2 = false;
      if (clientPlayerEntity2 != null) {
         if (minecraftClient.player == clientPlayerEntity2) {
            ThreadLocalRandom.current().nextInt(13);
            if (MinecraftClientAccess47.getInteractionManager(minecraftClient) != null) {
               if (clientPlayerEntity2.getInventory().getSelectedSlot() == intState2) {
                  ThreadLocalRandom.current().nextInt(16);
                  if (ItemStack.areItemsEqual(clientPlayerEntity2.getInventory().getStack(selectedSlot22), itemStack2)) {
                     ThreadLocalRandom.current().nextInt(3);
                     clientPlayerEntity2.getInventory().setSelectedSlot(selectedSlot22);
                     ((ClientPlayerInteractionManagerMixin.ClientPlayerInteractionManagerAccessor)minecraftClient.interactionManager).mochi$syncSelectedSlot();
                  }
               }
            }
         }
      }

      if (booleanState22) {
         HotbarSwapCoordinator.updateState4(object2);
      }
   }

   public static boolean testItemStack(ItemStack itemStack2) {
      if (!itemStack2.isEmpty()) {
         ThreadLocalRandom.current().nextInt(17);

         if (!itemStack2.contains(MinecraftClientAccess47.getATTACK_RANGE())) {
            if (!itemStack2.isIn(ItemTags.SWORDS)) {
               if (!itemStack2.isIn(ItemTags.AXES)) {
                  if (!itemStack2.isOf(MinecraftClientAccess47.getMACE())) {
                     return false;
                  }
               }
            }

            return true;
         }
      }

      return false;
   }

   public static boolean testClientPlayerEntity3(ClientPlayerEntity clientPlayerEntity2) {
      computeIntForClientPlayerEntity(clientPlayerEntity2);

      return (computeIntForClientPlayerEntity2(clientPlayerEntity2, 1) == 0);
   }
}
