package cc.mochi;

import com.mojang.blaze3d.opengl.GlStateManager;
import com.mojang.blaze3d.textures.TextureFormat;
import net.minecraft.client.texture.GlTexture;

final class HdrGlTexture extends GlTexture {
   private HdrGlTexture(String string, int intValue, int intValue2, int intValue3) {
      super(15, string, TextureFormat.RGBA8, intValue, intValue2, 1, 1, intValue3);
   }

   static HdrGlTexture computeHdrGlTexture(String string, int intValue, int intValue2) {
      GlStateManager.clearGlErrors();
      int intValue3 = GlStateManager._genTexture();
      GlStateManager._bindTexture(intValue3);
      GlStateManager._texParameter(3553, 33085, 0);
      GlStateManager._texParameter(3553, 33082, 0);
      GlStateManager._texParameter(3553, 33083, 0);
      GlStateManager._texImage2D(3553, 0, 34842, intValue, intValue2, 0, 6408, 5131, null);
      int intValue4 = GlStateManager._getError();
      if (intValue4 != 0) {
         GlStateManager._deleteTexture(intValue3);
         throw new IllegalStateException("RGBA16F is not available (GL error " + intValue4 + ")");
      } else {
         return new HdrGlTexture(string, intValue, intValue2, intValue3);
      }
   }
}
