package cc.mochi;

public class CombatActionOwnerAccess {
   public static CombatActionOwner getNONE() {
      return CombatActionOwner.NONE;
   }
}
