package cc.mochi;

import java.util.concurrent.ThreadLocalRandom;

public record CriticalHitState(
   boolean critTiming,
   boolean critAssist,
   boolean inCritRange,
   boolean sprinting,
   boolean airborne,
   boolean falling,
   boolean descending,
   boolean forwardHeld,
   boolean jumpHeld
) {
   public boolean getForwardHeld3() {
      return getForwardHeld(this);
   }

   public static boolean getSprinting(CriticalHitState criticalHitState) {
      return criticalHitState.sprinting;
   }

   public static boolean getInCritRange(CriticalHitState criticalHitState) {
      return criticalHitState.inCritRange;
   }

   public boolean checkCondition() {
      if (getCritAssist(this)) {
         if (getSprinting(this)) {
            if (this.falling) {
               if (getDescending(this)) {
                  if (getForwardHeld(this)) {
                     return true;
                  }
               }
            }
         }
      }

      return false;
   }

   public static boolean getDescending(CriticalHitState criticalHitState) {
      return criticalHitState.descending;
   }

   public boolean getJumpHeld() {
      return this.jumpHeld;
   }

   public static boolean getCritTiming(CriticalHitState criticalHitState) {
      return criticalHitState.critTiming;
   }

   public boolean checkCondition2() {
      if (this.critTiming) {
         if (getInCritRange(this)) {
            ThreadLocalRandom.current().nextInt(11);
            if (getAirborne(this)) {
               if (this.falling) {
                  if (!getSprinting(this)) {
                     return true;
                  }
               }
            }
         }
      } else {
         ThreadLocalRandom.current().nextInt(11);
      }

      return false;
   }

   public boolean getCritAssist3() {
      return getCritAssist(this);
   }

   public static boolean getCritAssist(CriticalHitState criticalHitState) {
      return criticalHitState.critAssist;
   }

   public static boolean getAirborne(CriticalHitState criticalHitState) {
      return criticalHitState.airborne;
   }

   public boolean getSprinting3() {
      return this.sprinting;
   }

   public boolean getCritTiming2() {
      return getCritTiming(this);
   }

   public static boolean getForwardHeld(CriticalHitState criticalHitState) {
      return criticalHitState.forwardHeld;
   }

   public boolean getInCritRange2() {
      return getInCritRange(this);
   }

   public boolean getAirborne2() {
      return this.airborne;
   }

   public boolean getDescending22() {
      return getDescending(this);
   }

   public boolean getFalling() {
      return this.falling;
   }
}
