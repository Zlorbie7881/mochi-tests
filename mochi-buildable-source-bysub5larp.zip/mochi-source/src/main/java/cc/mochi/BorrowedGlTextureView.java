package cc.mochi;

import com.mojang.blaze3d.textures.GpuTexture;
import net.minecraft.client.texture.GlTexture;
import net.minecraft.client.texture.GlTextureView;

final class BorrowedGlTextureView extends GlTextureView {
   public BorrowedGlTextureView(GlTexture glTexture) {
      super(glTexture, 0, 1);
   }

   public GlTexture texture() {
      return super.texture();
   }
}
