package cc.mochi;

class FontFaceSwitchMap {
   static final int[] intArray = new int[FontFace.values().length];

   static {
      try {
         intArray[FontFace.SEMIBOLD.ordinal()] = 1;
      } catch (NoSuchFieldError failure) {
      }

      try {
         intArray[FontFace.BOLD.ordinal()] = 2;
      } catch (NoSuchFieldError failure2) {
      }
   }
}
