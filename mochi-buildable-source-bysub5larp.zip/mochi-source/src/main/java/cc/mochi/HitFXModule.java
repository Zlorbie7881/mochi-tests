package cc.mochi;

import cc.mochi.event.impl.player.AttackEvent;
import cc.mochi.event.impl.render.Render3DEvent;
import java.awt.Color;
import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class HitFXModule extends Module {
   private final DoubleSetting particleCountSetting;

   private final DoubleSetting particleSizeSetting;

   private final ChoiceSetting colorModeSetting = new ChoiceSetting("Color Mode", "Mochi Theme", "Mochi Theme", "Custom", "Rainbow");

   private final BooleanSetting impactRingSetting;

   private final DoubleSetting gravitySetting;

   private final DoubleSetting hueJitterSetting;

   private final BooleanSetting glowSetting;
   private long timestampMillis;
   private final DoubleSetting ringSizeSetting;

   private final DoubleSetting upwardBiasSetting;

   private final DoubleSetting speedSetting;

   private final ColorSetting customColorSetting = new ColorSetting("Custom Color", new Color(255, 105, 151));

   private final DoubleSetting spreadSetting;

   private final BooleanSetting streaksSetting;

   private final ArrayDeque<TimedParticleOrigin> timedParticleOriginArrayDeque;

   private final DoubleSetting lifetimeSSetting;
   private final ArrayDeque<HitParticle> hitParticleArrayDeque;

   @Override
   public void onDisable() {
      super.onDisable();
      this.hitParticleArrayDeque.clear();
      this.timedParticleOriginArrayDeque.clear();
      this.timestampMillis = 0L;
   }

   private Boolean equals() {
      return this.colorModeSetting.equals("Custom");
   }

   @EventHandler
   private void onAttack(AttackEvent attackEvent) {
      if (mc.player != null && mc.world != null) {
         Entity target = attackEvent.getTarget();
         if (target != null && !target.isRemoved()) {
            ThreadLocalRandom threadLocalRandom = ThreadLocalRandom.current();
            float floatValue = this.colorModeSetting.equals("Custom") ? 0.0F : this.hueJitterSetting.floatValue();
            double width = (double)target.getWidth();
            double height = (double)target.getHeight();
            Vec3d vec3d = new Vec3d(target.getX(), target.getY(), target.getZ());
            Vec3d vec3d2 = vec3d.add(0.0, height * 0.5, 0.0).subtract(mc.player.getEyePos()).normalize();
            if (!Double.isFinite(vec3d2.x) || !Double.isFinite(vec3d2.y) || !Double.isFinite(vec3d2.z)) {
               vec3d2 = new Vec3d(0.0, 0.2, 0.0);
            }

            long longValue = System.currentTimeMillis();
            int intValue = this.particleCountSetting.intValue();

            for (int intValue2 = 0; intValue2 < intValue; intValue2++) {
               double doubleValue = vec3d.x + MathHelper.clamp((threadLocalRandom.nextDouble() - 0.5) * width - vec3d2.x * width * 0.5, -width * 0.5, width * 0.5);
               double doubleValue2 = vec3d.z + MathHelper.clamp((threadLocalRandom.nextDouble() - 0.5) * width - vec3d2.z * width * 0.5, -width * 0.5, width * 0.5);
               double doubleValue3 = vec3d.y + threadLocalRandom.nextDouble() * height;
               double doubleValue4 = threadLocalRandom.nextDouble() * Math.PI * 2.0;
               double doubleValue5 = Math.acos(threadLocalRandom.nextDouble() * 2.0 - 1.0);
               Vec3d vec3d3 = new Vec3d(Math.sin(doubleValue5) * Math.cos(doubleValue4), Math.sin(doubleValue5) * Math.sin(doubleValue4), Math.cos(doubleValue5));
               double doubleValue6 = this.speedSetting.getValue() * (1.0 + threadLocalRandom.nextDouble() * 1.1);
               Vec3d vec3d4 = vec3d2.multiply(-doubleValue6).add(vec3d3.multiply(this.spreadSetting.getValue() * (0.6 + threadLocalRandom.nextDouble() * 0.8))).add(0.0, this.upwardBiasSetting.getValue() * 0.55, 0.0);
               double doubleValue7 = vec3d4.x * vec3d2.x + vec3d4.z * vec3d2.z;
               if (doubleValue7 > 0.0) {
                  vec3d4 = vec3d4.subtract(vec3d2.x * doubleValue7 * 2.0, 0.0, vec3d2.z * doubleValue7 * 2.0);
               }

               double doubleValue8 = this.lifetimeSSetting.getValue() * (0.75 + threadLocalRandom.nextDouble() * 0.5);
               float floatValue2 = floatValue <= 0.0F ? 0.0F : (threadLocalRandom.nextFloat() * 2.0F - 1.0F) * floatValue;
               this.hitParticleArrayDeque
                  .addLast(
                     new HitParticle(new Vec3d(doubleValue, doubleValue3, doubleValue2), vec3d4, longValue, (float)doubleValue8, (float)((double)this.particleSizeSetting.floatValue() * (0.7 + threadLocalRandom.nextDouble() * 0.6)), floatValue2)
                  );
            }

            while (this.hitParticleArrayDeque.size() > 170) {
               this.hitParticleArrayDeque.removeFirst();
            }

            if (this.impactRingSetting.getValue()) {
               Vec3d vec3d5 = new Vec3d(vec3d.x - vec3d2.x * width * 0.6, vec3d.y + height * 0.55, vec3d.z - vec3d2.z * width * 0.6);
               this.timedParticleOriginArrayDeque.addLast(new TimedParticleOrigin(vec3d5, longValue));

               while (this.timedParticleOriginArrayDeque.size() > 8) {
                  this.timedParticleOriginArrayDeque.removeFirst();
               }
            }
         }
      }
   }

   private void updateStateForColor(long longValue, Color color) {
      Iterator iterator = this.timedParticleOriginArrayDeque.iterator();

      while (iterator.hasNext()) {
         TimedParticleOrigin timedParticleOrigin = (TimedParticleOrigin)iterator.next();
         float floatValue = (float)(longValue - timedParticleOrigin.spawnTime()) / 1000.0F / 0.42F;
         if (floatValue >= 1.0F) {
            iterator.remove();
         } else if (!(floatValue <= 0.0F)) {
            float floatValue2 = 1.0F - (1.0F - floatValue) * (1.0F - floatValue);
            double doubleValue = (double)(this.ringSizeSetting.floatValue() * (0.25F + 0.75F * floatValue2) + 0.15F * floatValue2);
            int intValue = (int)(235.0 * Math.pow((double)(1.0F - floatValue), 1.6));
            if (intValue > 2) {
               int rgb = computeColorForColor(color, Color.WHITE, (1.0F - floatValue) * 0.35F).getRGB();
               Render3D.updateState6(timedParticleOrigin.pos().x, timedParticleOrigin.pos().y, timedParticleOrigin.pos().z, doubleValue, Render3D.computeFloat(3.2F), Render3D.computeInt2(rgb, intValue / 4), 28, false);
               Render3D.updateState6(timedParticleOrigin.pos().x, timedParticleOrigin.pos().y, timedParticleOrigin.pos().z, doubleValue, Render3D.computeFloat(1.6F), Render3D.computeInt2(rgb, intValue), 28, false);
            }
         }
      }
   }

   private static Color computeColorForColor(Color color, Color color2, float floatValue) {
      floatValue = MathHelper.clamp(floatValue, 0.0F, 1.0F);
      return new Color(
         Math.round((float)color.getRed() + (float)(color2.getRed() - color.getRed()) * floatValue),
         Math.round((float)color.getGreen() + (float)(color2.getGreen() - color.getGreen()) * floatValue),
         Math.round((float)color.getBlue() + (float)(color2.getBlue() - color.getBlue()) * floatValue)
      );
   }

   private static Color computeColorForColor2(Color color, float floatValue) {
      if (floatValue == 0.0F) {
         return color;
      } else {
         float[] floatArray = Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), null);
         floatArray[0] = (floatArray[0] + floatValue + 1.0F) % 1.0F;
         return Color.getHSBColor(floatArray[0], floatArray[1], floatArray[2]);
      }
   }

   public HitFXModule() {
      super("Hit FX", "3D particles that burst off targets when hit", -1, ModuleCategory.RENDER);
      this.particleCountSetting = new DoubleSetting("Particle Count", 6.0, 48.0, 22.0, 1.0);
      this.particleSizeSetting = new DoubleSetting("Particle Size", 1.0, 8.0, 4.0, 0.5);
      this.speedSetting = new DoubleSetting("Speed", 0.5, 3.0, 1.4, 0.1);
      this.spreadSetting = new DoubleSetting("Spread", 0.2, 3.0, 1.0, 0.1);
      this.upwardBiasSetting = new DoubleSetting("Upward Bias", 0.0, 2.0, 0.6, 0.1);
      this.gravitySetting = new DoubleSetting("Gravity", 0.0, 2.5, 0.4, 0.05);
      this.lifetimeSSetting = new DoubleSetting("Lifetime (s)", 0.2, 2.0, 0.75, 0.05);
      this.hueJitterSetting = new DoubleSetting("Hue Jitter", 0.0, 1.0, 0.0, 0.05);
      this.glowSetting = new BooleanSetting("Glow", true);
      this.streaksSetting = new BooleanSetting("Streaks", true);
      this.impactRingSetting = new BooleanSetting("Impact Ring", true);
      this.ringSizeSetting = new DoubleSetting("Ring Size", 0.2, 1.5, 0.6, 0.05);
      this.hitParticleArrayDeque = new ArrayDeque<>();
      this.timedParticleOriginArrayDeque = new ArrayDeque<>();
      this.addSettings(new Setting[]{this.colorModeSetting, this.customColorSetting, this.particleCountSetting, this.particleSizeSetting, this.speedSetting, this.spreadSetting, this.upwardBiasSetting, this.gravitySetting, this.lifetimeSSetting, this.glowSetting, this.streaksSetting, this.impactRingSetting, this.ringSizeSetting, this.hueJitterSetting});
      this.customColorSetting.setVisibility(() -> this.equals());
      this.ringSizeSetting.setVisibility(() -> this.impactRingSetting.getValue());
   }

   private Color computeColorForThemeSnapshot(ThemeSnapshot themeSnapshot, long longValue) {
      String selected = this.colorModeSetting.getSelected();
      switch (selected.hashCode()) {
         case -1656737386:
            if (selected.equals("Rainbow")) {
               return Color.getHSBColor((float)(longValue % 8000L) / 8000.0F, 0.8F, 1.0F);
            }
            break;
         case 2029746065:
            if (selected.equals("Custom")) {
               return this.customColorSetting.getValue();
            }
      }

      return ThemeSnapshot.computeColorForColor(themeSnapshot.getAccent2());
   }

   @EventHandler
   private void onRender3D(Render3DEvent render3DEvent) {
      if (!this.isWorldUnavailable() && mc.player != null && mc.world != null) {
         if (!this.hitParticleArrayDeque.isEmpty() || !this.timedParticleOriginArrayDeque.isEmpty()) {
            if (!GlCapabilities.checkCondition5()) {
               long timestampMillis2 = System.currentTimeMillis();
               float floatValue = this.timestampMillis == 0L ? 0.016F : MathHelper.clamp((float)(timestampMillis2 - this.timestampMillis) / 1000.0F, 0.0F, 0.05F);
               this.timestampMillis = timestampMillis2;
               Color color = this.computeColorForThemeSnapshot(ClickGuiModule.computeThemeSnapshot(), timestampMillis2);
               this.updateStateForColor(timestampMillis2, color);
               this.updateStateForColor2(timestampMillis2, floatValue, color);
            }
         }
      }
   }

   private void updateStateForColor2(long longValue, float floatValue, Color color) {
      Iterator iterator = this.hitParticleArrayDeque.iterator();

      while (iterator.hasNext()) {
         HitParticle hitParticle = (HitParticle)iterator.next();
         float floatValue2 = (float)(longValue - hitParticle.longState) / 1000.0F;
         if (floatValue2 >= hitParticle.floatState) {
            iterator.remove();
         } else {
            float floatValue3 = (float)Math.exp(((-2.6)) * (double)floatValue);
            hitParticle.vec3d = hitParticle.vec3d.multiply((double)floatValue3);
            hitParticle.vec3d = hitParticle.vec3d.add(0.0, -this.gravitySetting.getValue() * (double)floatValue, 0.0);
            Vec3d vec3d2 = hitParticle.vec3d2;
            hitParticle.vec3d2 = hitParticle.vec3d2.add(hitParticle.vec3d.x * (double)floatValue, hitParticle.vec3d.y * (double)floatValue, hitParticle.vec3d.z * (double)floatValue);
            float floatValue4 = floatValue2 / hitParticle.floatState;
            float floatValue5 = 1.0F - floatValue4;
            int intValue = (int)(255.0F * floatValue5 * floatValue5);
            if (intValue > 0) {
               int rgb = computeColorForColor2(color, hitParticle.floatState3).getRGB();
               if (this.streaksSetting.getValue()) {
                  Render3D.updateState9(vec3d2.x, vec3d2.y, vec3d2.z, hitParticle.vec3d2.x, hitParticle.vec3d2.y, hitParticle.vec3d2.z, Render3D.computeFloat(1.25F), Render3D.computeInt2(rgb, intValue / 2), false);
               }

               float floatValue6 = 1.0F - 0.5F * floatValue4 * floatValue4;
               double doubleValue = Math.max(0.008, (double)hitParticle.floatState2 * 0.016 * (double)floatValue6);
               if (this.glowSetting.getValue()) {
                  Render3D.updateState8(hitParticle.vec3d2.x, hitParticle.vec3d2.y, hitParticle.vec3d2.z, doubleValue * 2.6, Render3D.computeInt2(rgb, intValue / 3), Render3D.computeInt2(rgb, 0), false);
               }

               double doubleValue2 = doubleValue * 0.5;
               Box box = new Box(hitParticle.vec3d2.x - doubleValue2, hitParticle.vec3d2.y - doubleValue2, hitParticle.vec3d2.z - doubleValue2, hitParticle.vec3d2.x + doubleValue2, hitParticle.vec3d2.y + doubleValue2, hitParticle.vec3d2.z + doubleValue2);
               Render3D.updateStateForBox2(box, Render3D.computeInt2(rgb, intValue * 3 / 4), false);
               Render3D.updateStateForBox(box, Render3D.computeFloat(0.9F), Render3D.computeInt2(16777215, intValue), false);
            }
         }
      }
   }
}
