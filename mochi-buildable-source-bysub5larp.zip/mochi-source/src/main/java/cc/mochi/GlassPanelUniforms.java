package cc.mochi;

record GlassPanelUniforms(float x, float y, float width, float height, float radius, float unit, float[] tint, float[] rim, float hover, float brightness) {
   public float getY() {
      return this.y;
   }

   public float[] getTint() {
      return this.tint;
   }

   public float[] getRim() {
      return this.rim;
   }

   public float getBrightness() {
      return this.brightness;
   }

   public float getX() {
      return this.x;
   }

   public float getHeight() {
      return this.height;
   }

   public float getRadius() {
      return this.radius;
   }

   public float getHover() {
      return this.hover;
   }

   public float getUnit() {
      return this.unit;
   }

   public float getWidth() {
      return this.width;
   }
}
