package cc.mochi;

public enum ClickGuiTab {
   CONFIGS("Configs", "Save, load and share setups", Icon.FOLDER, "config profile save load import export"),
   THEMES("Themes", "Pick a palette for the whole client", Icon.PALETTE, "theme colour color palette accent"),
   KEYBINDS("Key binds", "Every bind on one keyboard", Icon.KEYBOARD, "keybind bind key keyboard"),
   HUD_EDITOR("HUD editor", "Arrange the HUD on the live screen", Icon.LAYOUT, "hud layout move editor"),

   FRIENDS("Friends", "Players your modules leave alone", Icon.USERS, "friend player ignore"),

   SELF_DESTRUCT("Self destruct", "Remove every trace of the client", Icon.POWER, "self destruct panic remove");

   private static final ClickGuiTab[] ENUM_VALUES = {CONFIGS, THEMES, KEYBINDS, HUD_EDITOR, FRIENDS, SELF_DESTRUCT};

   public final String label;
   public final Icon icon;

   public final String keywords;
   public final String detail;

   private ClickGuiTab(String label2, String detail2, Icon icon2, String keywords2) {
      this.label = label2;
      this.detail = detail2;
      this.icon = icon2;
      this.keywords = keywords2;
   }

   private static ClickGuiTab[] createValues() {
      return new ClickGuiTab[]{CONFIGS, THEMES, KEYBINDS, HUD_EDITOR, FRIENDS, SELF_DESTRUCT};
   }

   public static ClickGuiTab[] getENUM_VALUES() {
      return ENUM_VALUES;
   }
}
