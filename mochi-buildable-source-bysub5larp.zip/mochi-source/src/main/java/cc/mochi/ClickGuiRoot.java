package cc.mochi;

import java.util.List;
import java.util.function.Consumer;

public final class ClickGuiRoot {
   private final CommandPalette commandPalette;

   private boolean booleanState;
   private final ModuleListView moduleListView;
   private final ModuleInspector moduleInspector;

   private final Consumer<ClickGuiTab> consumer;
   private final ModuleBrowser moduleBrowser = new ModuleBrowser();

   private String string;

   private UiPanel uiPanel;

   public void updateStateForUiContext(UiContext uiContext, double pointX, double pointY, int intValue) {
      if (!ModuleBrowserAccess.getKeybindCapture(getModuleBrowser(this)).checkCondition4(intValue)) {
         getModuleBrowser(this).settingEditor.updateState3(pointX, pointY);
         ModuleBrowserAccess.getTextInputModel(this.moduleBrowser).updateState3(false);
         if (getUiPanel(this) != null) {
            this.uiPanel.updateState6();
         }

         uiContext.getInputRouter().dispatchPress(pointX, pointY, intValue);
      }
   }

   public ClickGuiRoot(Consumer consumer2) {
      this.moduleListView = new ModuleListView();
      this.moduleInspector = new ModuleInspector();
      this.consumer = consumer2;
      this.commandPalette = new CommandPalette(() -> this.computeListForConsumer(consumer2));
   }

   public static CommandPalette getCommandPalette(ClickGuiRoot clickGuiRoot) {
      return clickGuiRoot.commandPalette;
   }

   public void updateStateForUiContext2(UiContext uiContext, float floatValue, float floatValue2, float opacity) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      Rect rect = computeRect(floatValue, floatValue2);
      float floatValue4 = rect.getWidth() < 640.0F ? 206.0F : 232.0F;
      Rect rect2 = new Rect(rect.getX() + 8.0F, rect.getY() + 8.0F, 148.0F, rect.getHeight() - 16.0F);
      Rect rect3 = new Rect(rect.right() - 8.0F - floatValue4, rect.getY() + 8.0F, floatValue4, rect.getHeight() - 16.0F);
      Rect rect4 = new Rect(rect2.right() + 8.0F, rect.getY() + 8.0F, rect3.getX() - 8.0F - rect2.right() - 8.0F, rect.getHeight() - 16.0F);
      float floatValue5 = (1.0F - opacity) * 10.0F;
      uiContext.getUiRenderContext().pushTransform();
      uiContext.getUiRenderContext().translate(0.0F, floatValue5);
      uiContext.getUiRenderContext().scaleAroundPoint(0.985F + 0.015F * opacity, rect.centerX(), rect.centerY());
      uiContext.getUiRenderContext()
         .fillAngledGradient(
            rect.getX() - rect.getWidth() * 0.25F,
            rect.getY() - rect.getHeight() * 0.35F,
            rect.getWidth() * 1.5F,
            rect.getHeight() * 1.7F,
            0.0F,
            UiContext.multiplyAlpha(themeSnapshot2.getAccent2(), (themeSnapshot2.getLight4() ? 0.05F : 0.08F) * opacity),
            UiContext.multiplyAlpha(themeSnapshot2.getAccent2(), 0.0F),
            1.3F
         );
      PanelRenderer.updateStateForUiContext5(uiContext, rect, 18.0F, opacity);
      uiContext.getInputRouter().addPressRegion(rect, UiLayer.BASE, (intValue, doubleValue, doubleValue2) -> updateState(intValue, doubleValue, doubleValue2));
      ClickGuiNavigation.updateStateForUiContext(uiContext, this.moduleBrowser, rect2, opacity, getConsumer(this), () -> this.commandPalette.updateState5());
      PanelRenderer.updateStateForUiContext9(uiContext, rect4, 12.0F, opacity);
      getModuleListView(this).updateStateForUiContext(uiContext, getModuleBrowser(this), rect4, opacity);
      PanelRenderer.updateStateForUiContext9(uiContext, rect3, 12.0F, opacity);
      this.moduleInspector.updateStateForUiContext(uiContext, this.moduleBrowser, rect3, opacity);
      uiContext.getUiRenderContext().popTransform();
      Rect rect5 = new Rect(0.0F, 0.0F, floatValue, floatValue2);
      ModuleBrowserAccess.getSettingEditor(getModuleBrowser(this)).updateStateForUiContext4(uiContext, rect5, opacity);
      String string2 = ModuleBrowserAccess.getKeybindCapture(this.moduleBrowser).checkCondition2() ? "Binding " + getModuleBrowser(this).keybindCapture.getString() + "  ·  press a key or mouse button  ·  Esc clears" : getString(this);
      if (ModuleBrowserAccess.getKeybindCapture(getModuleBrowser(this)).checkCondition2()) {
         this.string = string2;
      }

      if (string2 != null) {
         uiContext.getUiRenderContext().flushBloom();
         ToggleWidget.updateStateForUiContext(uiContext, "studio.banner", floatValue / 2.0F, Math.max(6.0F, rect.getY() - 32.0F), string2, ControlTone.ACCENT, ModuleBrowserAccess.getKeybindCapture(this.moduleBrowser).checkCondition2(), opacity);
      }

      if (this.uiPanel != null && !getUiPanel(this).testUiContext(uiContext, floatValue, floatValue2, opacity)) {
         setUiPanel(this, null);
      }

      ModuleBrowserAccess.getConfirmationDialog(this.moduleBrowser).updateStateForUiContext(uiContext, "studio.dialog", floatValue, floatValue2, opacity);
      getCommandPalette(this).updateStateForUiContext(uiContext, floatValue, floatValue2, opacity);
   }

   public static ModuleBrowser getModuleBrowser(ClickGuiRoot clickGuiRoot) {
      return clickGuiRoot.moduleBrowser;
   }

   public static void setUiPanel(ClickGuiRoot clickGuiRoot, UiPanel uiPanel2) {
      clickGuiRoot.uiPanel = uiPanel2;
   }

   private List computeListForConsumer(Consumer consumer2) {
      return CommandPaletteCommands.computeListForModuleBrowser(getModuleBrowser(this), consumer2);
   }

   public static Consumer<ClickGuiTab> getConsumer(ClickGuiRoot clickGuiRoot) {
      return clickGuiRoot.consumer;
   }

   public boolean checkCondition(int keyCode, boolean booleanValue, boolean booleanValue2) {
      if (getModuleBrowser(this).keybindCapture.checkCondition3(keyCode)) {
         return true;
      } else if (getCommandPalette(this).getBooleanState4()) {
         return getCommandPalette(this).checkCondition2(keyCode, booleanValue, booleanValue2);
      } else if (booleanValue && keyCode == 75) {
         getCommandPalette(this).updateState4();
         return true;
      } else if (ModuleBrowserAccess.getConfirmationDialog(this.moduleBrowser).getBooleanState2()) {
         if (keyCode == 256) {
            ModuleBrowserAccess.getConfirmationDialog(this.moduleBrowser).updateState2();
         }

         return true;
      } else if (this.uiPanel != null && getUiPanel(this).getBooleanState22()) {
         if (getUiPanel(this).checkCondition3(keyCode, booleanValue)) {
            return true;
         } else {
            if (keyCode == 256 && !this.uiPanel.checkCondition()) {
               this.uiPanel.updateState15();
               ClientSounds.updateState5();
            }

            return true;
         }
      } else if (getModuleBrowser(this).settingEditor.checkCondition2()) {
         return getModuleBrowser(this).settingEditor.checkCondition(keyCode, booleanValue);
      } else {
         if (this.moduleBrowser.textInputModel.getBooleanState2()) {
            if (keyCode == 256) {
               if (!ModuleBrowserAccess.getTextInputModel(this.moduleBrowser).isEmpty()) {
                  ModuleBrowserAccess.getTextInputModel(this.moduleBrowser).updateState2();
               } else {
                  ModuleBrowserAccess.getTextInputModel(getModuleBrowser(this)).updateState3(false);
               }

               return true;
            }

            if (keyCode == 257 || keyCode == 335) {
               List list = this.moduleBrowser.computeList();
               if (!list.isEmpty()) {
                  getModuleBrowser(this).updateStateForModule((Module)list.get(0));
                  ClientSounds.updateState5();
               }

               getModuleBrowser(this).textInputModel.updateState3(false);
               return true;
            }

            if (getModuleBrowser(this).textInputModel.checkCondition(keyCode, booleanValue)) {
               return true;
            }
         }

         if (keyCode == 256) {
            if (getModuleBrowser(this).settingEditor.checkCondition4()) {
               ClientSounds.updateState5();
               return true;
            } else if (this.moduleBrowser.checkCondition()) {
               ModuleBrowserAccess.getTextInputModel(this.moduleBrowser).updateState2();
               return true;
            } else {
               return false;
            }
         } else if ((!booleanValue || keyCode != 70) && keyCode != 47) {
            return false;
         } else {
            ModuleBrowserAccess.getTextInputModel(this.moduleBrowser).updateState3(true);
            this.booleanState = keyCode == 47;
            return true;
         }
      }
   }

   public static ModuleListView getModuleListView(ClickGuiRoot clickGuiRoot) {
      return clickGuiRoot.moduleListView;
   }

   private static void updateState(int intValue, double doubleValue, double doubleValue2) {
   }

   public static UiPanel getUiPanel(ClickGuiRoot clickGuiRoot) {
      return clickGuiRoot.uiPanel;
   }

   public boolean checkCondition2() {
      return getCommandPalette(this).getBooleanState4() || getModuleBrowser(this).confirmationDialog.getBooleanState2() || this.uiPanel != null && getUiPanel(this).getBooleanState22();
   }

   public static void setBooleanState(ClickGuiRoot clickGuiRoot, boolean booleanState2) {
      clickGuiRoot.booleanState = booleanState2;
   }

   public ModuleBrowser getModuleBrowser12() {
      return this.moduleBrowser;
   }

   public boolean checkCondition3(char charValue) {
      if (this.moduleBrowser.keybindCapture.checkCondition()) {
         return true;
      } else {
         if (getBooleanState(this)) {
            setBooleanState(this, false);
            if (charValue == '/') {
               return true;
            }
         }

         if (getCommandPalette(this).getBooleanState4()) {
            return this.commandPalette.checkCondition(charValue);
         } else if (this.moduleBrowser.confirmationDialog.getBooleanState2()) {
            return true;
         } else if (getUiPanel(this) != null && this.uiPanel.getBooleanState22()) {
            this.uiPanel.checkCondition2(charValue);
            return true;
         } else if (getModuleBrowser(this).settingEditor.checkCondition3(charValue)) {
            return true;
         } else if (Character.isISOControl(charValue)) {
            return false;
         } else {
            boolean booleanValue = ClickGuiModule.getValue5() && ClickGuiModule.getValue3();
            if (!getModuleBrowser(this).textInputModel.getBooleanState2() && booleanValue) {
               getModuleBrowser(this).textInputModel.updateState3(true);
            }

            if (this.moduleBrowser.textInputModel.getBooleanState2()) {
               ModuleBrowserAccess.getTextInputModel(this.moduleBrowser).checkCondition3(charValue);
               return true;
            } else {
               return false;
            }
         }
      }
   }

   private static Rect computeRect(float floatValue, float floatValue2) {
      float width = Math.min(floatValue - 16.0F, Math.max(560.0F, Math.min(740.0F, floatValue - 56.0F)));
      float height = Math.min(floatValue2 - 56.0F, Math.max(330.0F, Math.min(450.0F, floatValue2 - 96.0F)));
      return Rect.centered(floatValue / 2.0F, floatValue2 / 2.0F, width, height);
   }

   public static boolean getBooleanState(ClickGuiRoot clickGuiRoot) {
      return clickGuiRoot.booleanState;
   }

   public void updateState2() {
      this.moduleBrowser.settingEditor.updateState2();
      getModuleBrowser(this).keybindCapture.updateState();
      this.moduleBrowser.updateState();
   }

   public static String getString(ClickGuiRoot clickGuiRoot) {
      return clickGuiRoot.string;
   }

   public void updateState3() {
      ModuleBrowserAccess.getTextInputModel(this.moduleBrowser).updateState3(true);
   }

   public void updateStateForClickGuiTab(ClickGuiTab clickGuiTab) {
      Object objectValue;
      switch (clickGuiTab) {
         case CONFIGS:
            objectValue = new ConfigPanel(this.moduleBrowser.confirmationDialog);
            break;
         case THEMES:
            objectValue = new ThemeEditorPanel(getModuleBrowser(this).confirmationDialog);
            break;
         case FRIENDS:
            objectValue = new FriendsPanel();
            break;
         default:
            objectValue = null;
      }

      Object objectValue2 = objectValue;
      if (objectValue2 == null) {
         this.consumer.accept(clickGuiTab);
      } else {
         if (this.uiPanel != null) {
            getUiPanel(this).updateState15();
         }

         setUiPanel(this, (UiPanel)objectValue2);
         ClientSounds.updateState5();
      }
   }

}
