package cc.mochi;

import java.util.concurrent.ThreadLocalRandom;
import java.util.function.IntPredicate;
import java.util.function.IntToDoubleFunction;

public final class CartRefillPlanner {
   private CartRefillPlanner() {
   }

   public static CartRefillSlotMove computeCartRefillSlotMoveForIntToDoubleFunction(String[] stringArray, String[] stringArray2, IntToDoubleFunction intToDoubleFunction, IntPredicate intPredicate) {
      if (stringArray != null && stringArray2 != null) {
         int intValue = 0;

         while (intValue < stringArray.length && intValue < stringArray2.length) {
            label102:
            if ("minecraft:tnt_minecart".equals(stringArray[intValue]) && !"minecraft:tnt_minecart".equals(stringArray2[intValue])) {
               if (intPredicate != null) {
                  if (intPredicate.test(intValue)) {
                     break label102;
                  }
               }

               int intValue32 = -1;

               double positiveInfinity = (Double.POSITIVE_INFINITY);
               int intValue3 = 9;

               while (intValue3 < stringArray2.length) {
                  if ("minecraft:tnt_minecart".equals(stringArray2[intValue3])) {
                     double intValue33;
                     if (intToDoubleFunction == null) {
                        intValue33 = (double)intValue3;
                     } else {
                        intValue33 = intToDoubleFunction.applyAsDouble(intValue3);
                     }

                     double doubleValue = intValue33;
                     if (Double.isFinite(doubleValue) && doubleValue < positiveInfinity) {
                        positiveInfinity = doubleValue;
                        intValue32 = intValue3;
                     }
                  }

                  intValue3++;

                  if (intValue3 >= 36) {
                     break;
                  }
               }

               if (intValue32 >= 0) {
                  return new CartRefillSlotMove(intValue, intValue32);
               }
            }

            if (++intValue >= 9) {
               ThreadLocalRandom.current().nextInt(13);
               break;
            }
         }

         return null;
      } else {
         return null;
      }
   }
}
