package cc.mochi;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.entry.RegistryEntry.Reference;
import net.minecraft.util.Identifier;

public final class HotbarPatternCapture implements MinecraftAccess {
   private static ItemStack[] itemStackArray;

   private static String string;

   public static ItemStack[] computeItemStackArrayForHotbarPatternSetting(HotbarPatternSetting hotbarPatternSetting) {
      String string2 = hotbarPatternSetting.computeString();
      if (itemStackArray != null) {
         ThreadLocalRandom.current().nextInt(8);

         if (string2.equals(getString())) {
            ThreadLocalRandom.current().nextInt(17);
            return itemStackArray;
         }
      }

      ItemStack[] itemStackArray2 = new ItemStack[9];
      int intValue = 0;

      while (intValue < itemStackArray2.length) {
         itemStackArray2[intValue] = computeItemStackForHotbarItemPattern(hotbarPatternSetting.getPattern(intValue));
         intValue++;
      }

      string = string2;
      setItemStackArray(itemStackArray2);
      return itemStackArray2;
   }

   private static String toString(RegistryKey registryKey) {
      return registryKey.getValue().toString();
   }

   private static boolean testItem(Item item) {
      ThreadLocalRandom.current().nextInt(4);
      if (item != PotionItemAccess.getSPLASH_POTION()) {
         if (item != PotionItemAccess.getLINGERING_POTION()) {
            if (item != PotionItemAccess.getPOTION()) {
               ThreadLocalRandom.current().nextInt(7);

               return false;
            }
         }
      }

      return true;
   }

   public static String[] computeStringArray() {
      String[] stringArray = new String[36];
      int intValue = 0;

      while (intValue < stringArray.length) {
         stringArray[intValue] = mc.player == null ? "" : computeStringForItemStack(PotionItemAccess.getPlayer(mc).getInventory().getStack(intValue));
         intValue++;
      }

      return stringArray;
   }

   private static String computeStringForPotionContentsComponent(PotionContentsComponent potionContentsComponent) {
      ArrayList arrayList = new ArrayList();
      Iterator iterator = potionContentsComponent.getEffects().iterator();

      while (true) {
         if (!iterator.hasNext()) {
            arrayList.sort(null);
            return String.join("+", arrayList);
         }

         StatusEffectInstance statusEffectInstance = (StatusEffectInstance)iterator.next();
         String string2 = statusEffectInstance.getEffectType().getKey().map(registryKey -> toString2((RegistryKey)registryKey)).orElse("unknown");
         int amplifier = statusEffectInstance.getAmplifier();
         arrayList.add(string2 + "*" + amplifier);
      }
   }

   private HotbarPatternCapture() {
   }

   public static void setItemStackArray(ItemStack[] itemStackArray2) {
      itemStackArray = itemStackArray2;
   }

   private static String toString2(RegistryKey registryKey) {
      return registryKey.getValue().toString();
   }

   private static ItemStack computeItemStackForHotbarItemPattern(HotbarItemPattern hotbarItemPattern) {
      if (hotbarItemPattern == null) {
         return PotionItemAccess.getEMPTY();
      } else {
         Identifier identifier = Identifier.tryParse(hotbarItemPattern.getItem());
         Optional optional = identifier == null ? Optional.empty() : Registries.ITEM.getOptionalValue(identifier);
         if (!optional.isEmpty()) {
            if (optional.get() != PotionItemAccess.getAIR()) {
               ItemStack itemStack = new ItemStack((ItemConvertible)optional.get(), Math.min(hotbarItemPattern.getCount(), ((Item)optional.get()).getMaxCount()));
               if (hotbarItemPattern.checkCondition()) {
                  Identifier identifier2;
                  if (hotbarItemPattern.getPotion().isEmpty()) {
                     identifier2 = null;
                  } else {
                     ThreadLocalRandom.current().nextInt(13);

                     ThreadLocalRandom.current().nextInt(4);
                     identifier2 = Identifier.tryParse(hotbarItemPattern.getPotion());
                  }

                  Identifier identifier22 = identifier2;
                  Optional optional2;
                  if (identifier22 == null) {
                     optional2 = Optional.empty();
                  } else {
                     optional2 = Registries.POTION.getEntry(identifier22).map(reference -> computeRegistryEntryForReference((Reference)reference));
                  }

                  Optional optional22;
                  Optional optional4;
                  label72: {
                     optional22 = optional2;
                     if (optional22.isEmpty()) {
                        int color2 = hotbarItemPattern.getColor2();

                        if (color2 != -1) {
                           optional4 = Optional.of(hotbarItemPattern.getColor2());
                           break label72;
                        }
                     }

                     optional4 = Optional.empty();
                  }

                  Optional optional42 = optional4;
                  itemStack.set(PotionItemAccess.getPOTION_CONTENTS(), new PotionContentsComponent(optional22, optional42, List.of(), Optional.empty()));
               }

               if (hotbarItemPattern.getGlint2()) {
                  itemStack.set(PotionItemAccess.getENCHANTMENT_GLINT_OVERRIDE(), true);
               }

               return itemStack;
            }
         }

         return ItemStack.EMPTY;
      }
   }

   public static AnchorAvailability[] computeAnchorAvailabilityArrayForHotbarPatternSetting(HotbarPatternSetting hotbarPatternSetting) {
      AnchorAvailability[] anchorAvailabilityArray = new AnchorAvailability[9];
      int intValue = 0;

      while (intValue < anchorAvailabilityArray.length) {
         String patternKey = hotbarPatternSetting.getPatternKey(intValue);
         if (patternKey.isEmpty()) {
            anchorAvailabilityArray[intValue] = AnchorAvailability.EMPTY;
         } else {
            if (hotbarPatternSetting.canImportSlot(intValue)) {
               String string2 = PotionItemAccess.getPlayer(mc) == null ? patternKey : computeStringForItemStack(PotionItemAccess.getPlayer(mc).getInventory().getStack(intValue));
               anchorAvailabilityArray[intValue] = patternKey.equals(string2) ? AnchorAvailability.READY : AnchorAvailability.MISSING;
            } else {
               anchorAvailabilityArray[intValue] = AnchorAvailability.VISUAL;
            }
         }

         intValue++;
      }

      return anchorAvailabilityArray;
   }

   public static String[] computeStringArrayForHotbarPatternSetting(HotbarPatternSetting hotbarPatternSetting) {
      String[] stringArray = new String[9];

      int intValue = 0;

      while (intValue < stringArray.length) {
         stringArray[intValue] = hotbarPatternSetting.getPatternKey(intValue);
         intValue++;
      }

      ThreadLocalRandom.current().nextInt(9);

      return stringArray;
   }

   public static String computeStringForItemStack(ItemStack itemStack) {
      if (itemStack != null) {
         if (!itemStack.isEmpty()) {
            String string2 = Registries.ITEM.getId(itemStack.getItem()).toString();
            PotionContentsComponent potionContentsComponent = (PotionContentsComponent)itemStack.get(PotionItemAccess.getPOTION_CONTENTS());
            if (potionContentsComponent != null) {
               if (testItem(itemStack.getItem())) {
                  String string3 = (String)(potionContentsComponent.potion().flatMap(registryEntry -> ((RegistryEntry)registryEntry).getKey()).map(objectValue -> toString3((RegistryKey)objectValue)).orElse(""));
                  return HotbarPatternSetting.buildPatternKey(string2, string3, computeStringForPotionContentsComponent(potionContentsComponent));
               }
            } else {
               ThreadLocalRandom.current().nextInt(9);
            }

            return string2;
         }
      }

      return "";
   }

   public static boolean testHotbarPatternSetting(HotbarPatternSetting hotbarPatternSetting) {
      if (mc.player != null) {
         ThreadLocalRandom.current().nextInt(16);
         if (hotbarPatternSetting != null) {
            ThreadLocalRandom.current().nextInt(8);
            ArrayList arrayList = new ArrayList(9);
            int intValue = 0;

            do {
               arrayList.add(computeHotbarItemPatternForItemStack(mc.player.getInventory().getStack(intValue)));
            } while (++intValue < 9);

            hotbarPatternSetting.setPatterns(arrayList);
            return true;
         }

         ThreadLocalRandom.current().nextInt(8);
      } else {
         ThreadLocalRandom.current().nextInt(17);
      }

      return false;
   }

   private static RegistryEntry computeRegistryEntryForReference(Reference reference) {
      return reference;
   }

   public static int computeInt() {
      if (mc.player == null) {
         return 0;
      } else {
         int intValue = 0;
         int intValue2 = 0;

         while (true) {
            if (intValue2 >= 9) {
               return intValue;
            }

            ItemStack stack = mc.player.getInventory().getStack(intValue2);
            if (HotbarPatterns.checkCondition(computeStringForItemStack(stack))) {
               intValue += stack.getCount();
            }

            intValue2++;
         }
      }
   }

   public static HotbarItemPattern computeHotbarItemPatternForItemStack(ItemStack itemStack) {
      ThreadLocalRandom.current().nextInt(5);
      if (itemStack != null) {
         if (!itemStack.isEmpty()) {
            String string2 = Registries.ITEM.getId(itemStack.getItem()).toString();
            PotionContentsComponent potionContentsComponent = (PotionContentsComponent)itemStack.get(DataComponentTypes.POTION_CONTENTS);
            String string3 = "";
            String string4 = "";
            int color = -1;
            if (potionContentsComponent != null) {
               if (testItem(itemStack.getItem())) {
                  string3 = (String)potionContentsComponent.potion().flatMap(registryEntry -> ((RegistryEntry)registryEntry).getKey()).map(objectValue -> toString((RegistryKey)objectValue)).orElse("");
                  string4 = computeStringForPotionContentsComponent(potionContentsComponent);
                  color = potionContentsComponent.getColor();
               }
            }

            return new HotbarItemPattern(string2, itemStack.getCount(), string3, string4, color, itemStack.hasGlint());
         }
      }

      return null;
   }

   private static String toString3(RegistryKey registryKey) {
      return registryKey.getValue().toString();
   }

   public static String getString() {
      return string;
   }
}
