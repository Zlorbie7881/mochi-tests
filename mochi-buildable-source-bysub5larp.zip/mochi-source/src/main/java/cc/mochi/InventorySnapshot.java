package cc.mochi;

import cc.mochi.event.impl.network.DisconnectEvent;
import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.event.impl.world.WorldChangeEvent;
import cc.mochi.mixin.ClientPlayerInteractionManagerMixin;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;

public final class InventorySnapshot {
   private final ClientPlayerEntity clientPlayerEntity;
   private final int intState;

   private final ClientWorld clientWorld;

   private final int intState2;

   private void unsubscribe() {
      MinecraftClientAccess30.getINSTANCE().getMochiEventBus().unsubscribe(this);
   }

   public InventorySnapshot(ClientPlayerEntity clientPlayerEntity2, ClientWorld clientWorld2, int intState22, int intState3) {
      this.clientPlayerEntity = clientPlayerEntity2;
      this.clientWorld = clientWorld2;
      this.intState2 = intState22;
      this.intState = intState3;
   }

   public static ClientPlayerEntity getClientPlayerEntity(InventorySnapshot inventorySnapshot) {
      return inventorySnapshot.clientPlayerEntity;
   }

   @EventHandler
   private void onWorldChange(WorldChangeEvent worldChangeEvent) {
      this.unsubscribe();
   }

   public static int getIntState2(InventorySnapshot inventorySnapshot) {
      return inventorySnapshot.intState2;
   }

   @EventHandler
   private void onDisconnect(DisconnectEvent disconnectEvent) {
      this.unsubscribe();
   }

   @EventHandler(
      priority = -100
   )
   private void onTick(TickEvent tickEvent) {
      if (MinecraftClientAccess30.getPlayer(InstaCartModule.getMc2()) == this.clientPlayerEntity) {
         if (MinecraftClientAccess30.getWorld(InstaCartModule.getMc2()) == this.clientWorld && InventoryUtils.computeInt() == getIntState2(this)) {
            if (InstaCartModule.getMc2().interactionManager != null) {
               if (!getClientPlayerEntity(this).isUsingItem()) {
                  if (CombatTickBudget.checkCondition2()) {
                     InventoryUtils.updateState3(this.intState);
                     ((ClientPlayerInteractionManagerMixin.ClientPlayerInteractionManagerAccessor)InstaCartModule.getMc2().interactionManager).mochi$syncSelectedSlot();
                     CombatTickBudget.setBooleanState222();
                     this.unsubscribe();
                     return;
                  }
               }

               return;
            }

            return;
         }
      }

      this.unsubscribe();
   }
}
