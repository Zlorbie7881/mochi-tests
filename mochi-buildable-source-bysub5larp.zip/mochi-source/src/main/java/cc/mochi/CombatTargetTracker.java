package cc.mochi;

import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

public final class CombatTargetTracker {
   private static volatile long timestampMillis;
   private static volatile LivingEntity livingEntity;
   private static volatile UUID uUID;

   private LivingEntity livingEntity2;
   private UUID uUID2;

   public static LivingEntity getLivingEntity() {
      return livingEntity;
   }

   public static UUID getUUID() {
      return uUID;
   }

   public static void setUUID2(CombatTargetTracker combatTargetTracker, UUID uUID22) {
      combatTargetTracker.uUID2 = uUID22;
   }

   public static BooleanSetting createBooleanSetting() {
      return new BooleanSetting("Last Hit", false);
   }

   public static LivingEntity getLivingEntity2(CombatTargetTracker combatTargetTracker) {
      return combatTargetTracker.livingEntity2;
   }

   private static void updateStateForUUID(UUID uuid) {
      if (uuid != null) {
         if (uuid.equals(uUID)) {
            livingEntity = null;
            setUUID(null);

            setTimestampMillis((0L));
         }
      }
   }

   private boolean testEntity(Entity entity) {
      if (entity instanceof PlayerEntity) {
         ThreadLocalRandom.current().nextInt(3);
         if (this.testEntity2(entity)) {
            return true;
         }
      }

      return false;
   }

   public static void updateStateForEntity(Entity entity) {
      if (!AttackActions.getBooleanState2()) {
         if (!InventorySynchronization.checkCondition2()) {
            MinecraftClient minecraftClient = MinecraftClient.getInstance();
            if (entity instanceof PlayerEntity var2 && (minecraftClient.player == null || var2 != MinecraftClientAccess41.getPlayer(minecraftClient))) {
               livingEntity = var2;
               uUID = var2.getUuid();
               timestampMillis = System.currentTimeMillis();
               return;
            }

            return;
         }
      }
   }

   public void updateState() {
      this.livingEntity2 = null;
      setUUID2(this, null);
   }

   public static void setTimestampMillis(long timestampMillis2) {
      timestampMillis = timestampMillis2;
   }

   private LivingEntity computeLivingEntityForLivingEntity(LivingEntity livingEntity22) {
      setLivingEntity2(this, livingEntity22);
      setUUID2(this, livingEntity22.getUuid());
      return livingEntity22;
   }

   public static void setLivingEntity2(CombatTargetTracker combatTargetTracker, LivingEntity livingEntity22) {
      combatTargetTracker.livingEntity2 = livingEntity22;
   }

   private boolean checkCondition() {
      byte byteValue;
      label32: {
         if (livingEntity != null && getUUID() != null) {
            long longValue = System.currentTimeMillis() - timestampMillis;

            if (longValue <= 2000L) {
               byteValue = 1;
               break label32;
            }
         }

         byteValue = 0;
      }

      ThreadLocalRandom.current().nextInt(4);
      return (byteValue != 0);
   }

   public static void setUUID(UUID uUID3) {
      uUID = uUID3;
   }

   private boolean testEntity2(Entity entity) {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (entity != null) {
         byte byteValue = 23;
         ThreadLocalRandom.current().nextInt(16);

         if (minecraftClient.player != null) {
            if (minecraftClient.world != null) {
               if (entity != MinecraftClientAccess41.getPlayer(minecraftClient)) {
                  if (!entity.isRemoved()) {
                     if (entity instanceof LivingEntity var3) {
                        if (var3.isAlive()) {
                           if (entity.getEntityWorld() == minecraftClient.world) {
                              byteValue = 1;
                           } else {
                              byteValue = 18;
                              ThreadLocalRandom.current().nextInt(10);
                              byteValue = 0;
                           }

                           return (byteValue != 0);
                        }
                     }
                  }

                  return false;
               }
            }
         }
      }

      return false;
   }

   public boolean checkCondition2() {
      return (getLivingEntity2(this) != null);
   }

   private LivingEntity computeLivingEntityForLivingEntity2(LivingEntity livingEntity3) {
      ThreadLocalRandom.current().nextInt(10);

      if (this.testEntity(livingEntity3)) {
         return livingEntity3;
      } else {
         return null;
      }
   }

   public LivingEntity getLivingEntity23() {
      return this.livingEntity2;
   }

   public LivingEntity computeLivingEntityForLivingEntity3(LivingEntity livingEntity3, boolean booleanValue) {
      if (!booleanValue) {
         this.updateState();
         return livingEntity3;
      } else {
         LivingEntity livingEntity22 = this.computeLivingEntity();
         if (livingEntity22 != null && livingEntity22 != getLivingEntity2(this)) {
            if (this.testEntity(livingEntity22)) {
               return this.computeLivingEntityForLivingEntity(livingEntity22);
            }
         }

         if (this.livingEntity2 != null) {
            if (!this.testEntity2(this.livingEntity2)) {
               updateStateForUUID(this.uUID2);
               this.updateState();
            }
         }

         if (getLivingEntity2(this) != null) {
            ThreadLocalRandom.current().nextInt(7);

            return this.livingEntity2;
         } else {
            ThreadLocalRandom.current().nextInt(5);
            LivingEntity livingEntity23 = this.computeLivingEntityForLivingEntity2(livingEntity3);
            if (livingEntity23 == null) {
         return livingEntity3;
      } else {
         return this.computeLivingEntityForLivingEntity(livingEntity23);
      }
         }
      }
   }

   private LivingEntity computeLivingEntity() {
      if (this.checkCondition()) {
         return getLivingEntity();
      } else {
         return null;
      }
   }

}
