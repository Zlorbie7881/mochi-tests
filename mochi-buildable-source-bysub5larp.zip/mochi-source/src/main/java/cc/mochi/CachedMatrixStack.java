package cc.mochi;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionfc;

public class CachedMatrixStack extends MatrixStack {
   private final ObjectArrayList<MatrixSnapshot> objectArrayList = new ObjectArrayList(8);
   private MatrixSnapshot matrixSnapshot;

   public void push() {
      this.objectArrayList.add(this.matrixSnapshot = new MatrixSnapshot(new Matrix4f(this.matrixSnapshot.positionMatrix()), new Matrix3f(this.matrixSnapshot.normalMatrix())));
   }

   public CachedMatrixStack() {
      this.objectArrayList.add(this.matrixSnapshot = new MatrixSnapshot(new Matrix4f(), new Matrix3f()));
   }

   public void multiply(Quaternionfc quaternion, float originX, float originY, float originZ) {
      this.matrixSnapshot.positionMatrix().rotateAround(quaternion, originX, originY, originZ);
      this.matrixSnapshot.normalMatrix().rotate(quaternion);
   }

   public void loadIdentity() {
      this.matrixSnapshot.positionMatrix().identity();
      this.matrixSnapshot.normalMatrix().identity();
   }

   public void multiply(Quaternionfc quaternion) {
      this.matrixSnapshot.positionMatrix().rotate(quaternion);
      this.matrixSnapshot.normalMatrix().rotate(quaternion);
   }

   public void scale(float x, float y, float z) {
      this.matrixSnapshot.positionMatrix().scale(x, y, z);
      if (x == y && y == z) {
         if (x != 0.0F) {
            this.matrixSnapshot.normalMatrix().scale(Math.signum(x));
         }
      } else {
         float floatValue = 1.0F / x;
         float floatValue2 = 1.0F / y;
         float floatValue3 = 1.0F / z;
         float floatValue4 = (float)(1.0 / Math.cbrt((double)(floatValue * floatValue2 * floatValue3)));
         this.matrixSnapshot.normalMatrix().scale(floatValue4 * floatValue, floatValue4 * floatValue2, floatValue4 * floatValue3);
      }
   }

   public void translate(float x, float y, float z) {
      this.matrixSnapshot.positionMatrix().translate(x, y, z);
   }

   public Entry peek() {
      Entry entry = new Entry();
      entry.getPositionMatrix().set(this.matrixSnapshot.positionMatrix());
      entry.getNormalMatrix().set(this.matrixSnapshot.normalMatrix());
      return entry;
   }

   public void multiplyPositionMatrix(Matrix4fc matrix) {
      this.matrixSnapshot.positionMatrix().mul(matrix);
   }

   public boolean isEmpty() {
      return this.objectArrayList.size() == 1;
   }

   public void pop() {
      if (this.objectArrayList.size() == 1) {
         throw new IllegalStateException("Trying to pop an empty stack");
      } else {
         this.objectArrayList.pop();
         this.matrixSnapshot = (MatrixSnapshot)this.objectArrayList.top();
      }
   }
}
