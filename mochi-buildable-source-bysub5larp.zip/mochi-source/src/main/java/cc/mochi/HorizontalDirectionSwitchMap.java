package cc.mochi;

import net.minecraft.util.math.Direction;

public class HorizontalDirectionSwitchMap {
   static final int[] intArray = new int[Direction.values().length];

   static {
      try {
         intArray[Direction.NORTH.ordinal()] = 1;
      } catch (NoSuchFieldError failure) {
      }

      try {
         intArray[Direction.SOUTH.ordinal()] = 2;
      } catch (NoSuchFieldError failure2) {
      }

      try {
         intArray[Direction.EAST.ordinal()] = 3;
      } catch (NoSuchFieldError failure3) {
      }

      try {
         intArray[Direction.WEST.ordinal()] = 4;
      } catch (NoSuchFieldError failure4) {
      }
   }
}
