package cc.mochi;

import cc.mochi.event.impl.player.ItemUseEvent;
import cc.mochi.event.impl.player.MovementSendEvent;
import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.event.impl.world.WorldChangeEvent;
import cc.mochi.mixin.ClientPlayerInteractionManagerMixin;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Supplier;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.ActionResult.Success;
import net.minecraft.util.ActionResult.SwingSource;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.util.math.Direction.AxisDirection;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public final class AutoDrainModule extends Module {
   private BlockPos blockPos;
   private final BooleanSetting preAimSetting;

   private Vec3d vec3d;

   private final DoubleSetting fOVSetting;

   private final Map<BlockPos, Boolean> booleanByBlockPos;

   private long timestampMillis;

   private int intState;
   private final BooleanSetting swapBackSetting;

   private final Map<BlockPos, Long> longByBlockPos;

   private float floatState;
   private final DoubleSetting flickSpeedSetting;

   private final BooleanSetting silentRotationSetting;
   private final BooleanSetting targetWaterSetting;

   private long longState;

   private final Map<BlockPos, Long> longByBlockPos2;

   private final DoubleSetting radiusSetting;

   private long longState2;

   private long longState3;

   private int intState2;

   private Item item;

   private int intState3;

   private final DoubleSetting restoreDelayMsSetting;

   private Item item2;

   private boolean booleanState;
   private final BooleanSetting webLockSetting;

   private final Map<BlockPos, Long> longByBlockPos3;

   private ClientPlayerEntity clientPlayerEntity;

   private float floatState2;

   private boolean booleanState2;

   private boolean booleanState3;

   private final Map<BlockPos, Long> longByBlockPos4;

   private final BooleanSetting targetLavaSetting;
   private final BooleanSetting webFallbackSetting;

   public static PlacementOwner getSELF() {
      return PlacementOwner.SELF;
   }

   private static Vec3d computeVec3dForVec3d(Vec3d vec3d2) {
      return vec3d2;
   }

   public static float getFloatState(AutoDrainModule autoDrainModule) {
      return autoDrainModule.floatState;
   }

   public static void setClientPlayerEntity(AutoDrainModule autoDrainModule, ClientPlayerEntity clientPlayerEntity2) {
      autoDrainModule.clientPlayerEntity = clientPlayerEntity2;
   }

   private DrainTarget computeDrainTargetForBlockPos(BlockPos blockPos2, Vec3d vec3d2, boolean booleanValue) {
      Vec3d vec3d3 = Vec3d.ofCenter(blockPos2);
      Vec3d vec3d52 = null;

      double doubleValue62 = (1.7976931348623157E308);
      int intValue = -1;

      do {
         ThreadLocalRandom.current().nextInt(11);
         int intValue2 = -1;

         do {
            int intValue3 = -1;

            do {
               double doubleValue2 = (double)intValue * 0.3;
               double intValue22 = (double)intValue2;

               double doubleValue4 = intValue22 * (0.3);
               double intValue32 = (double)intValue3;

               Vec3d vec3d5 = vec3d3.add(doubleValue2, doubleValue4, intValue32 * (0.3));
               float[] floatArray = RotationMath.computeFloatArrayForVec3d(vec3d2, vec3d5, getFloatState(this));
               if ((this.testVec3d2(vec3d2, floatArray[0], floatArray[1], blockPos2))) {
                  double doubleValue6 = this.computeDouble2(floatArray) + (double)(Math.abs(intValue) + Math.abs(intValue2) + Math.abs(intValue3)) * 2.0;
                  if (doubleValue6 < doubleValue62) {
                     doubleValue62 = doubleValue6;
                     vec3d52 = vec3d5;
                  } else {
                     ThreadLocalRandom.current().nextInt(9);
                  }
               }

               intValue3++;
            } while (intValue3 <= 1);

            ThreadLocalRandom.current().nextInt(12);
         } while (++intValue2 <= 1);

         intValue++;
      } while (intValue <= 1);

      if (vec3d52 == null) {
         return null;
      } else {
         return new DrainTarget(DrainAction.BUCKET, blockPos2, vec3d52, booleanValue);
      }
   }

   private static double computeDouble(int intValue) {
      double intValue2 = (double)intValue;

      return (0.06) + intValue2 * (0.88) / 6.0;
   }

   private void setLongState222() {
      setLongState2(this, Long.MIN_VALUE);
   }

   public static DoubleSetting getFOVSetting(AutoDrainModule autoDrainModule) {
      return autoDrainModule.fOVSetting;
   }

   private DrainTarget computeDrainTargetForVec3d(Vec3d vec3d2, ItemStack itemStack, double doubleValue) {
      PlayerEntity playerEntity22 = null;

      double doubleValue32 = (1.7976931348623157E308);

      for (PlayerEntity playerEntity2 : mc.world.getPlayers()) {
         if (playerEntity2 != mc.player) {
            if (playerEntity2.isAlive()) {
               if (!playerEntity2.isSpectator()) {
                  if (!FriendManager.testPlayerEntity(playerEntity2)) {
                     if (!this.testItemStack(playerEntity2.getMainHandStack()) && !this.testItemStack(playerEntity2.getOffHandStack())) {
                     } else if (!mc.world.getBlockState(playerEntity2.getBlockPos()).isOf(Blocks.COBWEB)) {
                     } else {
                        double doubleValue3 = vec3d2.distanceTo(playerEntity2.getBoundingBox().getCenter());
                        if (doubleValue3 <= doubleValue + 1.0) {
                           if (doubleValue3 < doubleValue32) {
                              ThreadLocalRandom.current().nextInt(9);
                              doubleValue32 = doubleValue3;
                              playerEntity22 = playerEntity2;
                           }
                        } else {
                           ThreadLocalRandom.current().nextInt(15);
                        }
                     }
                  }
               }
            }
         }
      }

      if (playerEntity22 == null) {
         return null;
      } else {
         BlockPos blockPos2 = playerEntity22.getBlockPos().up();
         BlockState blockState = MinecraftClientAccess32.getWorld(mc).getBlockState(blockPos2);
         if (blockState.isReplaceable() && blockState.getFluidState().isEmpty()) {
            Vec3d vec3d3 = this.computeVec3dForBlockPos(blockPos2, vec3d2, itemStack);
            DrainTarget drainTarget;
            if (vec3d3 == null) {
               ThreadLocalRandom.current().nextInt(9);
               drainTarget = null;
            } else {
               drainTarget = new DrainTarget(DrainAction.PRE_AIM, blockPos2, vec3d3, true);
            }

            return drainTarget;
         } else {
            return null;
         }
      }
   }

   private void updateState() {
      this.longByBlockPos4.clear();
      this.longByBlockPos2.clear();
      getBooleanByBlockPos(this).clear();
      this.longByBlockPos.clear();
      getLongByBlockPos3(this).clear();
      this.booleanState3 = false;

      setLongState3(this, (0L));

      setIntState2(this, -1);
      Item item3 = MinecraftClientAccess32.getAIR();
      setItem2(this, item3);
      this.item = item3;
   }

   private static int computeInt(Vec3d[][] vec3dArrayArray, int intValue, int intValue2) {
      if (intValue >= 0) {
         if (intValue2 >= 0) {
            if (intValue < 7) {
               if (intValue2 < 7) {
                  if (vec3dArrayArray[intValue][intValue2] != null) {
                     return 1;
                  }
               }
            } else {
               ThreadLocalRandom.current().nextInt(13);
            }
         }
      }

      return 0;
   }

   public static BooleanSetting getSilentRotationSetting(AutoDrainModule autoDrainModule) {
      return autoDrainModule.silentRotationSetting;
   }

   public AutoDrainModule() {
      super("Auto Drain", "Drains enemy-placed water/lava (bucket, or cobweb-replace) and webs over water poured onto a web", ModuleCategory.COMBAT);

      this.radiusSetting = new DoubleSetting("Radius", 1.0, 6.0, (4.0), 1.0);
      this.fOVSetting = new DoubleSetting("FOV", 10.0, 180.0, 90.0, 1.0);

      this.targetWaterSetting = new BooleanSetting("Target Water", true);
      this.targetLavaSetting = new BooleanSetting("Target Lava", true);

      this.flickSpeedSetting = new DoubleSetting("Flick Speed", 360.0, 3600.0, 1800.0, (30.0));
      this.silentRotationSetting = new BooleanSetting("Silent Rotation", true);
      this.webLockSetting = new BooleanSetting("Web Lock", true);
      this.preAimSetting = new BooleanSetting("Pre Aim", true);
      this.webFallbackSetting = new BooleanSetting("Web Fallback", true);
      this.swapBackSetting = new BooleanSetting("Swap Back", true);

      this.restoreDelayMsSetting = new DoubleSetting("Restore Delay (ms)", 0.0, (500.0), 100.0, (1.0));

      this.longState2 = (-9223372036854775808L);
      this.intState3 = -1;

      this.intState = -1;
      this.longByBlockPos = new LinkedHashMap<>();
      this.longByBlockPos3 = new HashMap<>();
      this.longByBlockPos4 = new LinkedHashMap<>();
      this.longByBlockPos2 = new LinkedHashMap<>();
      this.booleanByBlockPos = new LinkedHashMap<>();
      this.intState2 = -1;
      this.item = Items.AIR;
      this.item2 = Items.AIR;
      Setting[] settingArray = new Setting[]{this.radiusSetting, this.fOVSetting, this.targetWaterSetting, null, null, null, null, null, null, null, null};

      settingArray[3] = this.targetLavaSetting;

      settingArray[4] = this.flickSpeedSetting;

      settingArray[5] = this.silentRotationSetting;
      settingArray[6] = this.webLockSetting;
      settingArray[7] = this.preAimSetting;
      settingArray[8] = this.webFallbackSetting;

      settingArray[9] = this.swapBackSetting;
      settingArray[10] = this.restoreDelayMsSetting;
      this.addSettings(settingArray);
      this.preAimSetting.setVisibility(() -> this.computeBoolean());
      this.restoreDelayMsSetting.setVisibility(() -> this.swapBackSetting.isOn());
   }

   public static Map<BlockPos, Long> getLongByBlockPos3(AutoDrainModule autoDrainModule) {
      return autoDrainModule.longByBlockPos3;
   }

   private int computeIntForBlockPos(BlockPos blockPos2) {
      byte byteValue;
      if (this.testBlockPos5(blockPos2)) {
         byteValue = 0;
      } else {
         byteValue = 1;
      }

      return byteValue;
   }

   public static void setTimestampMillis(AutoDrainModule autoDrainModule, long timestampMillis2) {
      autoDrainModule.timestampMillis = timestampMillis2;
   }

   private Vec3d computeVec3dForBlockPos(BlockPos blockPos2, Vec3d vec3d2, ItemStack itemStack) {
      Vec3d vec3d3 = null;
      double maxValue = Double.MAX_VALUE;
      Direction[] directionArray = Direction.values();
      int length = directionArray.length;
      int intValue = 0;

      for (; intValue < length; intValue++) {
         Direction direction = directionArray[intValue];
         BlockPos blockPos3 = blockPos2.offset(direction);
         BlockState blockState = mc.world.getBlockState(blockPos3);
         if (!blockState.isReplaceable()) {
            VoxelShape outlineShape = blockState.getOutlineShape(mc.world, blockPos3);
            if (!(outlineShape.isEmpty())) {
               Box box = outlineShape.getBoundingBox().offset(blockPos3);
               Direction opposite = direction.getOpposite();
               if (testDirection(opposite, box, vec3d2)) {
                  Vec3d[][] vec3dArrayArray = new Vec3d[7][7];

                  double[][] doubleArrayArray = new double[7][7];

                  int intValue2 = 0;

                  do {
                     int intValue3 = 0;

                     do {
                        Vec3d vec3d4 = computeVec3dForBox(box, opposite, computeDouble(intValue2), computeDouble(intValue3));
                        float[] floatArray = RotationMath.computeFloatArrayForVec3d(vec3d2, vec3d4, getFloatState(this));
                        ClientWorld world6 = MinecraftClientAccess32.getWorld(mc);
                        ClientPlayerEntity player15 = MinecraftClientAccess32.getPlayer(mc);

                        float floatValue = floatArray[0];

                        BlockHitTarget blockHitTarget = InteractionActions.computeBlockHitTargetForWorld(world6, player15, vec3d2, floatValue, floatArray[1], itemStack);
                        if (blockHitTarget != null && blockHitTarget.getCell().equals(blockPos2)) {
                           vec3dArrayArray[intValue2][intValue3] = vec3d4;
                           doubleArrayArray[intValue2][intValue3] = this.computeDouble2(floatArray);
                        }

                        intValue3++;
                     } while (intValue3 < 7);
                  } while (++intValue2 < 7);

                  intValue2 = 0;

                  while (true) {
                     int intValue4 = 0;

                     do {
                        if (vec3dArrayArray[intValue2][intValue4] != null) {
                           int intValue5 = computeInt(vec3dArrayArray, intValue2 - 1, intValue4) + computeInt(vec3dArrayArray, intValue2 + 1, intValue4);

                           int intValue6 = intValue5 + computeInt(vec3dArrayArray, intValue2, intValue4 - 1) + computeInt(vec3dArrayArray, intValue2, intValue4 + 1);

                           double doubleValue = (double)(4 - intValue6) * 1000.0 + doubleArrayArray[intValue2][intValue4];
                           if (doubleValue < maxValue) {
                              ThreadLocalRandom.current().nextInt(16);
                              maxValue = doubleValue;
                              vec3d3 = vec3dArrayArray[intValue2][intValue4];
                           }
                        }

                        intValue4++;
                     } while (intValue4 < 7);

                     if (++intValue2 >= 7) {
                        break;
                     }
                  }
               }
            }
         }
      }

      return vec3d3;
   }

   private Iterable computeIterable() {
      BlockPos blockPos2 = mc.player.getBlockPos();
      int intValue = this.radiusSetting.intValue() + 2;
      int intValue2 = MathHelper.floor(mc.player.getEyeY());
      int intValue3 = blockPos2.getX() - intValue;
      int intValue4 = intValue2 - 3;
      int intValue5 = blockPos2.getZ() - intValue;
      int intValue6 = blockPos2.getX() + intValue;

      return BlockPos.iterate(intValue3, intValue4, intValue5, intValue6, intValue2 + 4, blockPos2.getZ() + intValue);
   }

   private void updateState2(long longValue) {
      if (!(this.intState < 0)) {
         if (longValue - getTimestampMillis(this) >= (long)getRestoreDelayMsSetting(this).intValue()) {
            if (CombatTickBudget.checkCondition2()) {
               this.updateState5();
               return;
            }
         }
      }
   }

   private static boolean checkCondition(long longValue, Long objectValue) {
      return (objectValue < longValue);
   }

   public static Map<BlockPos, Boolean> getBooleanByBlockPos(AutoDrainModule autoDrainModule) {
      return autoDrainModule.booleanByBlockPos;
   }

   @EventHandler
   private void onAfterMovement(MovementSendEvent.After after) {
      this.floatState = after.yaw();
      this.floatState2 = after.pitch();
      this.vec3d = after.sentEye();
      this.booleanState2 = true;
   }

   private boolean testBlockPos(BlockPos position) {
      FluidState fluid = mc.world.getFluidState(position);
      return this.longByBlockPos2.containsKey(position) && !fluid.isEmpty() && fluid.isStill()
         && (fluid.isIn(MinecraftClientAccess32.getWATER()) || fluid.isIn(MinecraftClientAccess32.getLAVA()));
   }

   private BlockHitTarget computeBlockHitTargetForBlockPos(BlockPos blockPos2, ItemStack itemStack) {
      BlockHitTarget blockHitTarget = InteractionActions.computeBlockHitTargetForWorld(MinecraftClientAccess32.getWorld(mc), MinecraftClientAccess32.getPlayer(mc), this.computeVec3d(), getFloatState(this), getFloatState2(this), itemStack);
      if (blockHitTarget != null) {
         if (blockHitTarget.getCell().equals(blockPos2)) {
            ThreadLocalRandom.current().nextInt(9);

            return blockHitTarget;
         }
      }

      return null;
   }

   private boolean testBlockPos2(BlockPos blockPos2) {
      BlockPos blockPos3 = MinecraftClientAccess32.getPlayer(mc).getBlockPos();
      int intValue = this.radiusSetting.intValue();
      int intValue2 = MathHelper.floor(MinecraftClientAccess32.getPlayer(mc).getEyeY());
      if (Math.abs(blockPos2.getX() - blockPos3.getX()) <= intValue) {
         if (Math.abs(blockPos2.getZ() - blockPos3.getZ()) <= intValue) {
            int y = blockPos2.getY();

            if (y >= intValue2 - 2) {
               y = blockPos2.getY();

               if (y <= intValue2 + 3) {
                  return true;
               }
            }
         } else {
            ThreadLocalRandom.current().nextInt(7);
         }
      }

      return false;
   }

   private void updateState3(long longValue) {
      Map longByBlockPos5 = getLongByBlockPos(this);

      removeIf(longByBlockPos5, longValue - 1200L);
      getLongByBlockPos3(this).values().removeIf(objectValue -> checkCondition3(longValue, objectValue));
      this.updateStateForMap(this.longByBlockPos4, longValue);
      this.updateStateForMap(getLongByBlockPos22(this), longValue);
   }

   public static Map<BlockPos, Long> getLongByBlockPos(AutoDrainModule autoDrainModule) {
      return autoDrainModule.longByBlockPos;
   }

   public static boolean getBooleanState3(AutoDrainModule autoDrainModule) {
      return autoDrainModule.booleanState3;
   }

   private Boolean computeBoolean() {
      if (getSilentRotationSetting(this).isOn()) {
         if (this.webLockSetting.isOn()) {
            return true;
         }
      }

      return false;
   }

   public static DoubleSetting getRestoreDelayMsSetting(AutoDrainModule autoDrainModule) {
      return autoDrainModule.restoreDelayMsSetting;
   }

   private void updateState4(long longState32) {
      int intState22;
      Item item3;
      Item item4;
      label45: {
         label47: {
            intState22 = InventoryUtils.computeInt();
            item3 = MinecraftClientAccess32.getPlayer(mc).getMainHandStack().getItem();
            item4 = MinecraftClientAccess32.getPlayer(mc).getOffHandStack().getItem();
            if (intState22 == this.intState2) {
               if (testItem2(this.item)) {
                  if (item3 == MinecraftClientAccess32.getBUCKET()) {
                     break label47;
                  }
               } else {
                  ThreadLocalRandom.current().nextInt(17);
               }
            }

            if (!testItem2(getItem2(this))) {
               break label45;
            }

            if (item4 != MinecraftClientAccess32.getBUCKET()) {
               break label45;
            }
         }

         this.longState3 = longState32;
      }

      setIntState2(this, intState22);
      this.item = item3;
      setItem2(this, item4);
   }

   public static float getFloatState2(AutoDrainModule autoDrainModule) {
      return autoDrainModule.floatState2;
   }

   private static Vec3d computeVec3dForBox(Box box, Direction direction, double doubleValue, double doubleValue2) {
      Axis axis = direction.getAxis();
      double doubleValue3;
      if (direction.getDirection() == MinecraftClientAccess32.getPOSITIVE()) {
         doubleValue3 = box.getMax(axis);

         doubleValue3 -= (0.001);
      } else {
         doubleValue3 = box.getMin(axis);

         doubleValue3 += (0.001);

         ThreadLocalRandom.current().nextInt(9);
      }

      double doubleValue32 = doubleValue3;
      Vec3d vec3d2;
      switch (DrainAxisSwitchMap.intArray2[axis.ordinal()]) {
         case 1:

            vec3d2 = new Vec3d(doubleValue32, MathHelper.lerp(doubleValue, box.minY, box.maxY), MathHelper.lerp(doubleValue2, MinecraftClientAccess32.getMinZ(box), MinecraftClientAccess32.getMaxZ(box)));
            break;
         case 2:
            vec3d2 = new Vec3d(MathHelper.lerp(doubleValue, box.minX, box.maxX), doubleValue32, MathHelper.lerp(doubleValue2, MinecraftClientAccess32.getMinZ(box), MinecraftClientAccess32.getMaxZ(box)));
            break;
         case 3:
            vec3d2 = new Vec3d(MathHelper.lerp(doubleValue, MinecraftClientAccess32.getMinX(box), box.maxX), MathHelper.lerp(doubleValue2, MinecraftClientAccess32.getMinY(box), MinecraftClientAccess32.getMaxY(box)), doubleValue32);
            break;
         default:

            throw new MatchException(null, null);
      }

      return vec3d2;
   }

   public static void setLongState3(AutoDrainModule autoDrainModule, long longState32) {
      autoDrainModule.longState3 = longState32;
   }

   private boolean testVec3d(Vec3d vec3d2) {
      Vec3d vec3d3 = vec3d2.subtract(mc.player.getEyePos());
      if (vec3d3.lengthSquared() < 1.0E-8) {
         return true;
      } else {
         Camera camera = MinecraftClientAccess32.getGameRenderer(mc).getCamera();
         Vec3d vec3d4 = RotationMath.computeVec3d(camera.getYaw(), camera.getPitch());
         double doubleValue = vec3d4.dotProduct(vec3d3.normalize());

         double doubleValue2 = Math.toDegrees(Math.acos(MathHelper.clamp(doubleValue, ((-1.0)), 1.0)));
         return (doubleValue2 <= getFOVSetting(this).getValue());
      }
   }

   public static Vec3d getVec3d(AutoDrainModule autoDrainModule) {
      return autoDrainModule.vec3d;
   }

   @Override
   public void onDisable() {
      ActionSchedulers.updateState4(this);
      this.updateState9();
      if (mc.player != null) {
         if (MinecraftClientAccess32.getPlayer(mc) == this.clientPlayerEntity) {
            this.updateState5();
         }
      }

      this.updateState7();
      this.updateState();
   }

   private boolean testVec3d2(Vec3d vec3d2, float floatValue, float floatValue2, BlockPos blockPos2) {
      Vec3d vec3d3 = vec3d2.add(BlockInteractUtils.computeVec3d(floatValue2, floatValue).multiply(MinecraftClientAccess32.getPlayer(mc).getBlockInteractionRange()));
      BlockHitResult blockHitResult = mc.world.raycast(new RaycastContext(vec3d2, vec3d3, ShapeType.OUTLINE, FluidHandling.SOURCE_ONLY, MinecraftClientAccess32.getPlayer(mc)));
      if (blockHitResult.getType() == Type.BLOCK && blockHitResult instanceof BlockHitResult) {
         BlockHitResult blockHitResult2 = blockHitResult;
         if (blockHitResult2.getBlockPos().equals(blockPos2)) {
            return true;
         }
      }

      return false;
   }

   private boolean testBlockPos3(BlockPos blockPos2, long longValue) {
      if (!this.testBlockPos(blockPos2)) {
         return false;
      } else {
         ThreadLocalRandom.current().nextInt(12);
         FluidState fluidState = MinecraftClientAccess32.getWorld(mc).getFluidState(blockPos2);
         if (fluidState.isIn(MinecraftClientAccess32.getWATER())) {
            if (!this.targetWaterSetting.isOn()) {
               return false;
            }
         } else {
            if (!getTargetLavaSetting(this).isOn()) {
               return false;
            }
         }

         Long objectValue = this.longByBlockPos.get(blockPos2);
         if (objectValue != null && objectValue >= getLongByBlockPos22(this).getOrDefault(blockPos2, 0L)) {
            return false;
         } else {
            Long objectValue2 = getLongByBlockPos3(this).get(blockPos2);
            if (objectValue2 != null) {
               if (objectValue2 > longValue) {
                  return false;
               }

               ThreadLocalRandom.current().nextInt(12);
            } else {
               ThreadLocalRandom.current().nextInt(14);
            }

            return true;
         }
      }
   }

   public static BooleanSetting getWebLockSetting(AutoDrainModule autoDrainModule) {
      return autoDrainModule.webLockSetting;
   }

   public static long getTimestampMillis(AutoDrainModule autoDrainModule) {
      return autoDrainModule.timestampMillis;
   }

   private static boolean isOf(Item item3, ItemStack itemStack) {
      return itemStack.isOf(item3);
   }

   private PlacementOwner computePlacementOwnerForBlockPos(BlockPos blockPos2, long longValue) {
      ThreadLocalRandom.current().nextInt(3);
      Vec3d vec3d2 = Vec3d.ofCenter(blockPos2);
      if (this.longState3 > 0L) {
         long longValue2 = longValue - this.longState3;

         if (longValue2 <= 600L) {
            if (vec3d2.distanceTo(mc.player.getEyePos()) <= 5.0) {
               return PlacementOwner.SELF;
            }
         }
      }

      double doubleValue = this.computeDoubleForVec3d(vec3d2);

      if (doubleValue <= (4.0)) {
         return PlacementOwner.ENEMY;
      } else {
         return PlacementOwner.UNKNOWN;
      }
   }

   public static void setBlockPos(AutoDrainModule autoDrainModule, BlockPos blockPos2) {
      autoDrainModule.blockPos = blockPos2;
   }

   public static void setIntState3(AutoDrainModule autoDrainModule, int intState32) {
      autoDrainModule.intState3 = intState32;
   }

   public static BlockPos getBlockPos(AutoDrainModule autoDrainModule) {
      return autoDrainModule.blockPos;
   }

   public static void setBooleanState(AutoDrainModule autoDrainModule, boolean booleanState4) {
      autoDrainModule.booleanState = booleanState4;
   }

   private boolean testItemStack(ItemStack itemStack) {
      label56: {
         if (this.targetWaterSetting.isOn()) {
            if (itemStack.isOf(MinecraftClientAccess32.getWATER_BUCKET())) {
               break label56;
            }

            if (testItem(itemStack.getItem())) {
               break label56;
            }
         }

         if (this.targetLavaSetting.isOn()) {
            if (itemStack.isOf(Items.LAVA_BUCKET)) {
               break label56;
            }
         }

         return false;
      }

      return true;
   }

   private static boolean testBlockPos4(BlockPos blockPos2, List list) {
      for (BlockPos blockPos3 : (java.lang.Iterable<BlockPos>)(java.lang.Iterable<?>)(list)) {
         int intValue = Math.abs(blockPos2.getX() - blockPos3.getX());
         int intValue2 = Math.abs(blockPos2.getY() - blockPos3.getY());
         int intValue3 = Math.abs(blockPos2.getZ() - blockPos3.getZ());
         if (Math.max(intValue, Math.max(intValue2, intValue3)) <= 2) {
            return true;
         }

         ThreadLocalRandom.current().nextInt(3);
      }

      return false;
   }

   @EventHandler
   private void onItemUse(ItemUseEvent itemUseEvent) {
      if (mc.player != null) {
         if (!testItem2(MinecraftClientAccess32.getPlayer(mc).getMainHandStack().getItem())) {
            if (!testItem2(mc.player.getOffHandStack().getItem())) {
               return;
            }
         }

         setLongState3(this, System.currentTimeMillis());
      }
   }

   public static void setIntState2(AutoDrainModule autoDrainModule, int intState22) {
      autoDrainModule.intState2 = intState22;
   }

   public static BooleanSetting getTargetLavaSetting(AutoDrainModule autoDrainModule) {
      return autoDrainModule.targetLavaSetting;
   }

   private static boolean testDirection(Direction direction, Box box, Vec3d vec3d2) {
      double doubleValue = direction.getAxis().choose(MinecraftClientAccess32.getX(vec3d2), vec3d2.y, MinecraftClientAccess32.getZ(vec3d2));
      int intValue;
      if (direction.getDirection() == AxisDirection.POSITIVE) {
         intValue = doubleValue >= box.getMax(direction.getAxis()) ? 1 : 0;
      } else if (doubleValue <= box.getMin(direction.getAxis())) {
         ThreadLocalRandom.current().nextInt(14);

         intValue = 1;
      } else {
         ThreadLocalRandom.current().nextInt(7);

         intValue = 0;
      }

      return (intValue != 0);
   }

   public static DrainAction getPRE_AIM() {
      return DrainAction.PRE_AIM;
   }

   private static void removeIf(Map map, long longValue) {
      map.values().removeIf(objectValue -> checkCondition(longValue, (Long)objectValue));
   }

   public static int getIntState(AutoDrainModule autoDrainModule) {
      return autoDrainModule.intState;
   }

   public static PlacementOwner getENEMY() {
      return PlacementOwner.ENEMY;
   }

   private double computeDouble2(float[] floatArray) {
      float floatValue = Math.abs(RotationMath.wrapDegrees(this.floatState, floatArray[0]));

      return (double)(floatValue + Math.abs(floatArray[1] - this.floatState2));
   }

   private boolean checkCondition2() {
      ClientPlayerEntity player = mc.player;
      if (getBooleanState2(this) && mc.currentScreen == null) {
         if (player.isAlive()) {
            ThreadLocalRandom.current().nextInt(12);

            if (!player.isSpectator() && !player.isUsingItem() && !MinecraftClientAccess32.getInteractionManager(mc).isBreakingBlock() && MinecraftClientAccess32.getAllowModifyWorld(player.getAbilities())) {
               if (getLongState2(this) != ActionSchedulers.getCurrentTick22()) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   public static DrainAction getBUCKET() {
      return DrainAction.BUCKET;
   }

   private List computeList() {
      ArrayList arrayList = new ArrayList();
      Iterator iterator = this.computeIterable().iterator();

      while (true) {
         if (!iterator.hasNext()) {
            return arrayList;
         }

         BlockPos blockPos2 = (BlockPos)iterator.next();
         if (MinecraftClientAccess32.getWorld(mc).getBlockState(blockPos2).isOf(MinecraftClientAccess32.getCOBWEB())) {
            ThreadLocalRandom.current().nextInt(11);
            arrayList.add(blockPos2.toImmutable());
         }
      }
   }

   public static Map<BlockPos, Long> getLongByBlockPos22(AutoDrainModule autoDrainModule) {
      return autoDrainModule.longByBlockPos2;
   }

   public static void setLongState2(AutoDrainModule autoDrainModule, long longState22) {
      autoDrainModule.longState2 = longState22;
   }

   private void updateState5() {
      int intState32 = getIntState3(this);
      int intState4 = this.intState;
      this.intState3 = this.intState = -1;
      if (this.swapBackSetting.isOn()) {
         if (intState4 >= 0 && intState32 >= 0) {
            if (intState32 != intState4) {
               if (mc.interactionManager != null) {
                  if (InventoryUtils.computeInt() == intState4) {
                     if (!CombatTickBudget.checkCondition2()) {
                        CombatTickBudget.updateState6(intState32);
                        return;
                     }

                     InventoryUtils.updateState3(intState32);
                     ((ClientPlayerInteractionManagerMixin.ClientPlayerInteractionManagerAccessor)MinecraftClientAccess32.getInteractionManager(mc)).mochi$syncSelectedSlot();
                     CombatTickBudget.setBooleanState222();
                     return;
                  }
               }
            }
         }
      }
   }

   private void updateState6(long longValue) {
      if (getBooleanState3(this)) {
         this.updateState10(longValue);
      }

      getBooleanByBlockPos(this).clear();
      Iterator iterator = this.computeIterable().iterator();

      while (true) {
         if (!iterator.hasNext()) {
            setBooleanState3(this, true);
            return;
         }

         BlockPos blockPos2 = (BlockPos)iterator.next();
         if (MinecraftClientAccess32.getWorld(mc).getFluidState(blockPos2).isEmpty()) {
            getBooleanByBlockPos(this).put(blockPos2.toImmutable(), Boolean.TRUE);
         }
      }
   }

   public static void setItem2(AutoDrainModule autoDrainModule, Item item22) {
      autoDrainModule.item2 = item22;
   }

   private static boolean checkCondition3(long longValue, Long objectValue) {
      byte byteValue;
      if (objectValue <= longValue) {
         byteValue = 1;

         ThreadLocalRandom.current().nextInt(16);
      } else {
         byteValue = 0;
      }

      return (byteValue != 0);
   }

   private static double squaredDistanceTo(Vec3d vec3d2, BlockPos blockPos2) {
      return vec3d2.squaredDistanceTo(Vec3d.ofCenter(blockPos2));
   }

   private void updateStateForDrainTarget(DrainTarget drainTarget) {
      ClientPlayerEntity player = mc.player;
      ActionResult actionResult;
      if (drainTarget.getKind() == DrainAction.BUCKET) {
         ThreadLocalRandom.current().nextInt(5);

         if (!this.testVec3d2(this.computeVec3d(), player.getYaw(), player.getPitch(), drainTarget.getCell2())) {
            return;
         }

         actionResult = MinecraftClientAccess32.getInteractionManager(mc).interactItem(player, Hand.MAIN_HAND);
         CombatTickBudget.enableBooleanState4();
      } else {
         BlockHitTarget blockHitTarget = this.computeBlockHitTargetForBlockPos(drainTarget.getCell2(), player.getMainHandStack());
         if (blockHitTarget == null) {
            return;
         }

         actionResult = MinecraftClientAccess32.getInteractionManager(mc).interactBlock(player, Hand.MAIN_HAND, blockHitTarget.getHit2());
      }

      if (actionResult instanceof Success var10 && var10.swingSource() == SwingSource.CLIENT) {
         ThreadLocalRandom.current().nextInt(14);
         player.swingHand(MinecraftClientAccess32.getMAIN_HAND());
      }

      long timestampMillis2 = System.currentTimeMillis();
      getLongByBlockPos(this).put(drainTarget.getCell2(), timestampMillis2);
      this.timestampMillis = timestampMillis2;
      this.blockPos = null;
   }

   private DrainTarget computeDrainTarget(long longValue) {
      int intValue = this.computeIntForItem(MinecraftClientAccess32.getCOBWEB2());
      ItemStack itemStack;
      if (intValue >= 0) {
         itemStack = MinecraftClientAccess32.getPlayer(mc).getInventory().getStack(intValue);
      } else {
         itemStack = MinecraftClientAccess32.getEMPTY();
      }

      ItemStack itemStack2 = itemStack;
      int intValue2 = intValue >= 0 ? 1 : 0;
      int intValue3 = this.computeIntForItem(MinecraftClientAccess32.getBUCKET()) >= 0 ? 1 : 0;
      Vec3d vec3d2 = this.computeVec3d();
      double blockInteractionRange = mc.player.getBlockInteractionRange();
      List list = this.computeList();
      if (!list.isEmpty()) {
         if (!(intValue3 == 0 && intValue2 == 0)) {
            ArrayList arrayList = new ArrayList();

            for (BlockPos blockPos2 : this.longByBlockPos2.keySet()) {
               if (this.testBlockPos3(blockPos2, longValue)) {
                  if (testBlockPos4(blockPos2, list)) {
                     if (this.testBlockPos6(blockPos2, vec3d2, blockInteractionRange)) {
                        arrayList.add(blockPos2);
                     }
                  }
               }
            }

            arrayList.sort(Comparator.<Object>comparingInt(objectValue -> this.computeIntForBlockPos((BlockPos)objectValue)).thenComparingDouble(objectValue2 -> squaredDistanceTo(vec3d2, (BlockPos)objectValue2)));

            for (BlockPos blockPos3 : (java.lang.Iterable<BlockPos>)(java.lang.Iterable<?>)(arrayList)) {
               int intValue4 = this.webLockSetting.isOn() && intValue2 != 0 && this.testBlockPos5(blockPos3) ? 1 : 0;
               DrainTarget drainTarget = intValue4 != 0 ? this.computeDrainTargetForBlockPos2(blockPos3, vec3d2, itemStack2, true) : null;
               if (drainTarget == null && intValue3 != 0) {
                  drainTarget = this.computeDrainTargetForBlockPos(blockPos3, vec3d2, true);
               }

               if (drainTarget == null && intValue4 == 0 && intValue2 != 0) {
                  if (this.webFallbackSetting.isOn()) {
                     drainTarget = this.computeDrainTargetForBlockPos2(blockPos3, vec3d2, itemStack2, true);
                  } else {
                     ThreadLocalRandom.current().nextInt(17);
                  }
               }

               if (drainTarget != null) {
                  return drainTarget;
               }
            }
         }
      }

      int intValue5 = intValue2 != 0 && this.webFallbackSetting.isOn() ? 1 : 0;
      if (intValue3 != 0 || intValue5 != 0) {
         ArrayList arrayList2 = new ArrayList();

         for (BlockPos blockPos4 : this.longByBlockPos2.keySet()) {
            if (this.testBlockPos3(blockPos4, longValue) && this.testBlockPos2(blockPos4)) {
               if (this.testBlockPos6(blockPos4, vec3d2, blockInteractionRange)) {
                  arrayList2.add(blockPos4);
               }
            }
         }

         arrayList2.sort(Comparator.comparingDouble(objectValue3 -> squaredDistanceTo2(vec3d2, (BlockPos)objectValue3)));

         for (BlockPos blockPos5 : (java.lang.Iterable<BlockPos>)(java.lang.Iterable<?>)(arrayList2)) {
            DrainTarget drainTarget2;
            if (intValue3 != 0) {
               drainTarget2 = this.computeDrainTargetForBlockPos(blockPos5, vec3d2, false);
            } else {
               drainTarget2 = this.computeDrainTargetForBlockPos2(blockPos5, vec3d2, itemStack2, false);
            }

            DrainTarget drainTarget22 = drainTarget2;
            if (drainTarget22 != null && this.testVec3d(drainTarget22.getAim())) {
               return drainTarget22;
            }
         }
      }

      return this.preAimSetting.isOn() && getSilentRotationSetting(this).isOn() && getWebLockSetting(this).isOn() && intValue2 != 0 && !MinecraftClientAccess32.getAttackKey(mc.options).isPressed() && !MinecraftClientAccess32.getOptions(mc).useKey.isPressed()
         ? this.computeDrainTargetForVec3d(vec3d2, itemStack2, blockInteractionRange)
         : null;
   }

   public static Item getItem2(AutoDrainModule autoDrainModule) {
      return autoDrainModule.item2;
   }

   private void updateStateForMap(Map map, long longValue) {
      Iterator iterator = map.entrySet().iterator();

      ThreadLocalRandom.current().nextInt(12);

      while (iterator.hasNext()) {
         Entry entry = (Entry)iterator.next();
         long longValue2 = longValue - (Long)entry.getValue();

         if (longValue2 <= 30000L) {
            if (!MinecraftClientAccess32.getWorld(mc).getFluidState((BlockPos)entry.getKey()).isEmpty()) {
               continue;
            }
         }

         iterator.remove();
      }
   }

   private void updateState7() {
      this.booleanState = false;
      this.blockPos = null;

      this.longState2 = Long.MIN_VALUE;
      setIntState3(this, this.intState = -1);
      setTimestampMillis(this, 0L);
      this.clientPlayerEntity = null;
   }

   public static long getLongState2(AutoDrainModule autoDrainModule) {
      return autoDrainModule.longState2;
   }

   @EventHandler
   private void onTick(TickEvent tickEvent) {
      if (!this.isWorldUnavailable()) {
         ThreadLocalRandom.current().nextInt(10);
         if (mc.interactionManager != null) {
            if (MinecraftClientAccess32.getPlayer(mc) != getClientPlayerEntity(this)) {
               this.updateState9();
               this.updateState7();
               setClientPlayerEntity(this, mc.player);
            }

            long longValue = System.currentTimeMillis();
            this.updateState4(longValue);
            this.updateState3(longValue);
            this.updateState6(longValue);
            DrainTarget drainTarget;
            if (this.checkCondition2()) {
               drainTarget = this.computeDrainTarget(longValue);
            } else {
               drainTarget = null;
            }

            DrainTarget drainTarget2;
            label52: {
               drainTarget2 = drainTarget;
               if (drainTarget2 != null) {
                  if (drainTarget2.getKind() != DrainAction.PRE_AIM) {
                     break label52;
                  }

                  ThreadLocalRandom.current().nextInt(15);
               }

               this.updateState2(longValue);
            }

            if (drainTarget2 == null) {
               setBlockPos(this, null);
               this.updateState9();
               return;
            }

            this.updateStateForDrainTarget2(drainTarget2, longValue);
            return;
         }
      }

      this.updateState9();
   }

   private double computeDoubleForVec3d(Vec3d vec3d2) {
      double doubleValue = (1.7976931348623157E308);
      Iterator iterator = MinecraftClientAccess32.getWorld(mc).getPlayers().iterator();

      while (iterator.hasNext()) {
         PlayerEntity playerEntity = (PlayerEntity)iterator.next();
         if (playerEntity != mc.player) {
            if (playerEntity.isAlive()) {
               ThreadLocalRandom.current().nextInt(13);
               if (!playerEntity.isSpectator()) {
                  if (!(FriendManager.testPlayerEntity(playerEntity))) {
                     doubleValue = Math.min(doubleValue, playerEntity.getBoundingBox().getCenter().distanceTo(vec3d2));
                  }
               }
            }
         }
      }

      return doubleValue;
   }

   private static boolean testItem(Item item3) {
      if (item3 != Items.COD_BUCKET) {
         if (item3 != Items.SALMON_BUCKET) {
            if (item3 != Items.AXOLOTL_BUCKET && item3 != Items.TADPOLE_BUCKET) {
               if (item3 != Items.TROPICAL_FISH_BUCKET) {
                  if (item3 != MinecraftClientAccess32.getPUFFERFISH_BUCKET()) {
                     return false;
                  }
               }
            }
         }
      }

      return true;
   }

   private void updateStateForClientPlayerEntity(ClientPlayerEntity clientPlayerEntity2, long longValue, int intValue, DrainTarget drainTarget) {
      setLongState2(this, (-9223372036854775808L));
      if (this.isEnabled()) {
         if (MinecraftClientAccess32.getPlayer(mc) == clientPlayerEntity2) {
            if (ActionSchedulers.getCurrentTick22() == longValue && mc.currentScreen == null) {
               ThreadLocalRandom.current().nextInt(10);
               if (mc.interactionManager != null) {
                  if (!clientPlayerEntity2.isUsingItem()) {
                     if (InventoryUtils.computeInt() == intValue) {
                        if (CombatTickBudget.checkCondition4() && this.testDrainTarget(drainTarget, clientPlayerEntity2.getMainHandStack())) {
                           this.updateStateForDrainTarget(drainTarget);
                           return;
                        }
                     }
                  }
               }
            }
         } else {
            ThreadLocalRandom.current().nextInt(8);
         }
      }
   }

   public static int getIntState3(AutoDrainModule autoDrainModule) {
      return autoDrainModule.intState3;
   }

   private void updateState8(int intState4) {
      label31: {
         int intState32 = InventoryUtils.computeInt();
         if (getIntState(this) >= 0) {
            if (intState32 == this.intState) {
               break label31;
            }
         }

         this.intState3 = intState32;
      }

      InventoryUtils.updateState3(intState4);
      ((ClientPlayerInteractionManagerMixin.ClientPlayerInteractionManagerAccessor)MinecraftClientAccess32.getInteractionManager(mc)).mochi$syncSelectedSlot();
      CombatTickBudget.setBooleanState222();
      CombatTickBudget.updateIntState();
      this.intState = intState4;
   }

   private void updateStateForDrainTarget2(DrainTarget drainTarget, long longState4) {
      if (drainTarget.getKind() == DrainAction.PRE_AIM) {
         this.blockPos = null;
      } else {
         ThreadLocalRandom.current().nextInt(4);
         if (!drainTarget.getCell2().equals(getBlockPos(this))) {
            this.blockPos = drainTarget.getCell2();
            this.longState = longState4;
         } else {
            long longValue = longState4 - this.longState;

            if (longValue > (1000L)) {
               Map longByBlockPos32 = this.longByBlockPos3;
               BlockPos blockPos2 = getBlockPos(this);

               longByBlockPos32.put(blockPos2, longState4 + (1500L));
               setBlockPos(this, null);
               this.updateState9();
               return;
            }
         }
      }

      Vec3d aim = drainTarget.getAim();
      ActionPriority actionPriority;
      if (drainTarget.getKind() == DrainAction.PRE_AIM) {
         actionPriority = ActionPriority.LOW;
      } else {
         ThreadLocalRandom.current().nextInt(17);
         actionPriority = ActionPriority.HIGH;
      }

      Supplier supplier = () -> computeVec3dForVec3d(aim);
      RotationProfile rotationProfile = RotationProfile.createRotationProfile();
      double value;
      if (drainTarget.getRescue2()) {
         ThreadLocalRandom.current().nextInt(16);
         value = 3600.0;
      } else {
         value = this.flickSpeedSetting.getValue();
      }

      rotationProfile = rotationProfile.withMaxRotationSpeed(value);

      rotationProfile = rotationProfile.computeRotationProfile10((1.0)).withSilentAim(getSilentRotationSetting(this).isOn()).computeRotationProfile7(true);

      rotationProfile = rotationProfile.computeRotationProfile4((0.0)).computeRotationProfile3(0.0);

      RotationManager.updateStateForActionPriority(this, actionPriority, supplier, rotationProfile.computeRotationProfile9((0L)));
      if (RotationManager.computeVec3d(this) == null) {
         setBooleanState(this, false);
      } else {
         this.booleanState = true;
         if (drainTarget.getKind() != DrainAction.PRE_AIM) {
            this.updateStateForDrainTarget3(drainTarget);
         }

         RotationManager.updateState11(this, this.floatState, getFloatState2(this));
      }
   }

   private DrainTarget computeDrainTargetForBlockPos2(BlockPos blockPos2, Vec3d vec3d2, ItemStack itemStack, boolean booleanValue) {
      Vec3d vec3d3 = this.computeVec3dForBlockPos(blockPos2, vec3d2, itemStack);
      if (vec3d3 == null) {
         return null;
      } else {
         return new DrainTarget(DrainAction.WEB, blockPos2, vec3d3, booleanValue);
      }
   }

   private static boolean testItem2(Item item3) {
      if (item3 != Items.WATER_BUCKET) {
         if (item3 != Items.LAVA_BUCKET) {
            if (!testItem(item3)) {
               return false;
            }
         }
      }

      return true;
   }

   @Override
   public void onEnable() {
      this.updateState();
      this.updateState7();

      this.booleanState2 = false;
   }

   private Vec3d computeVec3d() {
      if (getVec3d(this) != null) {
         return this.vec3d;
      } else {
         return MinecraftClientAccess32.getPlayer(mc).getEyePos();
      }
   }

   private boolean testBlockPos5(BlockPos blockPos2) {
      Direction[] directionArray = Direction.values();
      int length = directionArray.length;

      int intValue = 0;

      while (intValue < length) {
         ThreadLocalRandom.current().nextInt(17);

         ThreadLocalRandom.current().nextInt(10);
         Direction direction = directionArray[intValue];
         if (MinecraftClientAccess32.getWorld(mc).getBlockState(blockPos2.offset(direction)).isOf(MinecraftClientAccess32.getCOBWEB())) {
            return true;
         }

         ThreadLocalRandom.current().nextInt(12);
         intValue++;
      }

      return false;
   }

   private int computeIntForItem(Item item3) {
      return InventoryUtils.computeIntForPredicate2(objectValue -> isOf(item3, (ItemStack)objectValue));
   }

   private boolean testDrainTarget(DrainTarget drainTarget, ItemStack itemStack) {
      if (!this.testBlockPos(drainTarget.getCell2())) {
         return false;
      } else if (drainTarget.getKind() == DrainAction.BUCKET) {
         if (itemStack.isOf(Items.BUCKET)) {
            if (this.testVec3d2(this.computeVec3d(), getFloatState(this), getFloatState2(this), drainTarget.getCell2())) {
               return true;
            }
         }

         return false;
      } else {
         if (itemStack.isOf(Items.COBWEB)) {
            ThreadLocalRandom.current().nextInt(3);

            if (this.computeBlockHitTargetForBlockPos(drainTarget.getCell2(), itemStack) != null) {
               return true;
            }
         }

         return false;
      }
   }

   public static ClientPlayerEntity getClientPlayerEntity(AutoDrainModule autoDrainModule) {
      return autoDrainModule.clientPlayerEntity;
   }

   private boolean testBlockPos6(BlockPos blockPos2, Vec3d vec3d2, double doubleValue) {
      return (new Box(blockPos2).squaredMagnitude(vec3d2) <= doubleValue * doubleValue);
   }

   public static boolean getBooleanState2(AutoDrainModule autoDrainModule) {
      return autoDrainModule.booleanState2;
   }

   private static double squaredDistanceTo2(Vec3d vec3d2, BlockPos blockPos2) {
      return vec3d2.squaredDistanceTo(Vec3d.ofCenter(blockPos2));
   }

   private void updateStateForDrainTarget3(DrainTarget drainTarget) {
      Item item3;
      if (drainTarget.getKind() == DrainAction.BUCKET) {
         item3 = Items.BUCKET;
      } else {
         item3 = Items.COBWEB;
      }

      Item item32 = item3;
      int intState4 = this.computeIntForItem(item32);
      if (intState4 >= 0) {
         if (CombatTickBudget.checkCondition4()) {
            if (!this.testDrainTarget(drainTarget, MinecraftClientAccess32.getPlayer(mc).getInventory().getStack(intState4))) {
               return;
            }

            if (InventoryUtils.computeInt() == intState4) {
               this.updateStateForDrainTarget(drainTarget);
               return;
            }

            ThreadLocalRandom.current().nextInt(6);
            if (!CombatTickBudget.checkCondition2()) {
               return;
            }

            this.updateState8(intState4);
            long currentTick22 = ActionSchedulers.getCurrentTick22();
            ClientPlayerEntity player = mc.player;
            setLongState2(this, currentTick22);
            ActionSchedulers.schedule2(this, () -> this.updateStateForClientPlayerEntity(player, currentTick22, intState4, drainTarget), () -> this.setLongState222());
            return;
         }
      }
   }

   @EventHandler
   private void onWorldChange(WorldChangeEvent worldChangeEvent) {
      ActionSchedulers.updateState4(this);
      this.updateState9();
      this.updateState();
      this.updateState7();

      this.booleanState2 = false;
   }

   private void updateState9() {
      if ((this.booleanState)) {
         setBooleanState(this, false);
         RotationManager.updateState9(this);
      }
   }

   private void updateState10(long longValue) {
      Iterator iterator = this.computeIterable().iterator();

      while (iterator.hasNext()) {
         BlockPos blockPos2 = (BlockPos)iterator.next();
         FluidState fluidState = MinecraftClientAccess32.getWorld(mc).getFluidState(blockPos2);
         if (!fluidState.isEmpty() && fluidState.isStill()) {
            if (!fluidState.isIn(MinecraftClientAccess32.getWATER())) {
               if (!fluidState.isIn(FluidTags.LAVA)) {
                  continue;
               }
            }

            BlockPos blockPos3 = blockPos2.toImmutable();
            if (!this.longByBlockPos4.containsKey(blockPos3)) {
               if (!getLongByBlockPos22(this).containsKey(blockPos3)) {
                  if ((this.booleanByBlockPos.containsKey(blockPos3))) {
                     PlacementOwner placementOwner = this.computePlacementOwnerForBlockPos(blockPos3, longValue);
                     if (placementOwner == PlacementOwner.SELF) {
                        this.longByBlockPos4.put(blockPos3, longValue);
                     } else if (placementOwner == PlacementOwner.ENEMY) {
                        getLongByBlockPos22(this).put(blockPos3, longValue);
                     }
                  }
               } else {
                  ThreadLocalRandom.current().nextInt(15);
               }
            }
         }
      }
   }

   public static void setBooleanState3(AutoDrainModule autoDrainModule, boolean booleanState32) {
      autoDrainModule.booleanState3 = booleanState32;
   }
}
