package cc.mochi;

import java.awt.Color;

public class ClickGuiModuleAccess {
   public static Color getBLACK() {
      return Color.BLACK;
   }

   public static ChoiceSetting getBackdropModeSetting() {
      return ClickGuiModule.backdropModeSetting;
   }

   public static ChoiceSetting getThemeSetting() {
      return ClickGuiModule.themeSetting;
   }

   public static BooleanSetting getReducedMotionSetting() {
      return ClickGuiModule.reducedMotionSetting;
   }

   public static ColorSetting getAccentColorSetting() {
      return ClickGuiModule.accentColorSetting;
   }

   public static ChoiceSetting getAccentSourceSetting() {
      return ClickGuiModule.accentSourceSetting;
   }

   public static BooleanSetting getBackgroundBlurSetting() {
      return ClickGuiModule.backgroundBlurSetting;
   }

   public static DoubleSetting getDoubleSetting2() {
      return ClickGuiModule.legacyBlurStrengthSetting;
   }
}
