package cc.mochi;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.util.math.Direction.Axis;

public class CartAxisSwitchMap {
   static final int[] intArray2 = new int[Axis.values().length];

   static {
      label47: {
         try {
            intArray2[Axis.Y.ordinal()] = 1;
         } catch (NoSuchFieldError failure) {
            break label47;
         }
      }

      label43: {
         try {
            int[] intArray = intArray2;
            int intValue = Axis.X.ordinal();

            intArray[intValue] = 2;
         } catch (NoSuchFieldError failure2) {
            ThreadLocalRandom.current().nextInt(15);

            break label43;
         }
      }

      label39: {
         try {
            intArray2[Axis.Z.ordinal()] = 3;
         } catch (NoSuchFieldError failure3) {
            break label39;
         }
      }
   }
}
