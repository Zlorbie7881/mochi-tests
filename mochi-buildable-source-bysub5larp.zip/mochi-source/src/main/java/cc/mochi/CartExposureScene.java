package cc.mochi;

public record CartExposureScene(CartCollisionScene scene, double exposure) {
   public static double getExposure(CartExposureScene cartExposureScene) {
      return cartExposureScene.exposure;
   }

   public double getExposure2() {
      return getExposure(this);
   }

   public CartCollisionScene getScene() {
      return this.scene;
   }
}
