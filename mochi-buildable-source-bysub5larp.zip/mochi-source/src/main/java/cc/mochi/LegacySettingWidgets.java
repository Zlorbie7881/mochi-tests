package cc.mochi;

import java.awt.Color;
import java.util.Collections;
import java.util.List;
import net.minecraft.client.gui.DrawContext;

public final class LegacySettingWidgets {
   public static void updateStateForDrawContext(DrawContext drawContext, int intValue, int intValue2, int intValue3, int intValue4, List list, List list2, Color color, String string) {
      if (!list.isEmpty()) {
         RenderUtils.updateStateForDrawContext10(drawContext, intValue, intValue2, intValue3, intValue4, 6, LegacyUiColors.color10.getRGB());
         if (string != null && !string.isEmpty()) {
            LegacyWidgets.drawText(drawContext, string, intValue + 8, intValue2 + 4, LegacyUiColors.color3);
            intValue2 += 16;
            intValue4 -= 16;
         }

         float floatValue = (Float)Collections.max(list);
         if (floatValue == 0.0F) {
            floatValue = 1.0F;
         }

         int intValue5 = (intValue3 - 16) / list.size() - 4;
         int intValue6 = intValue + 8;

         for (int intValue7 = 0; intValue7 < list.size(); intValue7++) {
            float floatValue2 = (Float)list.get(intValue7);
            int intValue8 = (int)(floatValue2 / floatValue * (float)(intValue4 - 24));
            int intValue9 = intValue6 + intValue7 * (intValue5 + 4);
            int intValue10 = intValue2 + intValue4 - 20 - intValue8;
            Color color2 = LegacyWidgets.computeColorForColor(color, color.brighter(), floatValue2 / floatValue);
            RenderUtils.updateStateForDrawContext10(drawContext, intValue9, intValue10, intValue5, intValue8, 3, color2.getRGB());
            LegacyWidgets.updateStateForDrawContext13(drawContext, String.format("%.0f", floatValue2), intValue9 + intValue5 / 2, intValue10 - 12, LegacyUiColors.color4);
            if (list2 != null && intValue7 < list2.size()) {
               LegacyWidgets.updateStateForDrawContext13(drawContext, (String)list2.get(intValue7), intValue9 + intValue5 / 2, intValue2 + intValue4 - 12, LegacyUiColors.color4);
            }
         }
      }
   }

   private static void updateStateForDrawContext2(DrawContext drawContext, int intValue, int intValue2, int intValue3, int intValue4, int intValue5, Color color) {
      int intValue6 = Math.abs(intValue3 - intValue);
      int intValue7 = Math.abs(intValue4 - intValue2);
      int intValue8 = intValue < intValue3 ? 1 : -1;
      int intValue9 = intValue2 < intValue4 ? 1 : -1;
      int intValue10 = intValue6 - intValue7;
      int intValue11 = intValue;
      int intValue22 = intValue2;

      while (true) {
         for (int intValue13 = -intValue5 / 2; intValue13 <= intValue5 / 2; intValue13++) {
            for (int intValue14 = -intValue5 / 2; intValue14 <= intValue5 / 2; intValue14++) {
               drawContext.fill(intValue11 + intValue13, intValue22 + intValue14, intValue11 + intValue13 + 1, intValue22 + intValue14 + 1, color.getRGB());
            }
         }

         if (intValue11 == intValue3 && intValue22 == intValue4) {
            return;
         }

         int intValue15 = 2 * intValue10;
         if (intValue15 > -intValue7) {
            intValue10 -= intValue7;
            intValue11 += intValue8;
         }

         if (intValue15 < intValue6) {
            intValue10 += intValue6;
            intValue22 += intValue9;
         }
      }
   }

   public static void updateStateForDrawContext3(DrawContext drawContext, int intValue, int intValue2, int intValue3, List list, Color color) {
      RenderUtils.updateStateForDrawContext10(drawContext, intValue, intValue2, intValue3, intValue3, 6, color.getRGB());
      LegacyWidgets.updateStateForDrawContext(drawContext, intValue, intValue2, intValue3, intValue3, 6, 1, LegacyUiColors.color15);
      int intValue4 = intValue + intValue3 / 2;
      int intValue5 = intValue2 + intValue3 / 2;
      drawContext.fill(intValue4 - 4, intValue5, intValue4 + 4, intValue5 + 1, LegacyUiColors.color3.getRGB());
      drawContext.fill(intValue4, intValue5 - 4, intValue4 + 1, intValue5 + 4, LegacyUiColors.color3.getRGB());

      for (RadarMarker radarMarker : (java.lang.Iterable<RadarMarker>)(java.lang.Iterable<?>)(list)) {
         int intValue6 = intValue4 + (int)(radarMarker.relativeX() * (float)intValue3 / 2.0F);
         int intValue7 = intValue5 + (int)(radarMarker.relativeZ() * (float)intValue3 / 2.0F);
         if (intValue6 >= intValue && intValue6 <= intValue + intValue3 && intValue7 >= intValue2 && intValue7 <= intValue2 + intValue3) {
            RenderUtils.updateStateForDrawContext2(drawContext, intValue6, intValue7, radarMarker.size(), radarMarker.color().getRGB());
         }
      }
   }

   public static void updateStateForDrawContext4(DrawContext drawContext, int intValue, int intValue2, int intValue3, int intValue4, String string, float floatValue, float floatValue2, Color color) {
      RenderUtils.updateStateForDrawContext10(drawContext, intValue, intValue2, intValue3, intValue4, 4, LegacyUiColors.color10.getRGB());
      LegacyWidgets.drawText(drawContext, string, intValue + 6, intValue2 + 4, LegacyUiColors.color3);
      String string2 = String.format("%.0f/%.0f", floatValue, floatValue2);
      int width = LegacyWidgets.getWidth(string2);
      LegacyWidgets.drawText(drawContext, string2, intValue + intValue3 - width - 6, intValue2 + 4, LegacyUiColors.color4);
      int intValue5 = intValue2 + 16;
      int intValue6 = intValue4 - 20;
      float floatValue3 = Math.max(0.0F, Math.min(1.0F, floatValue / floatValue2));
      RenderUtils.updateStateForDrawContext10(drawContext, intValue + 6, intValue5, intValue3 - 12, intValue6, 2, LegacyUiColors.color9.getRGB());
      if (floatValue3 > 0.0F) {
         int intValue7 = (int)((float)(intValue3 - 12) * floatValue3);
         Color color2 = floatValue3 < 0.25F ? LegacyUiColors.color8 : (floatValue3 < 0.5F ? LegacyUiColors.color14 : color);
         RenderUtils.updateStateForDrawContext10(drawContext, intValue + 6, intValue5, intValue7, intValue6, 2, color2.getRGB());
      }
   }

   public static void updateStateForDrawContext5(DrawContext drawContext, int intValue, int intValue2, int intValue3, int intValue4, String string, List list) {
      RenderUtils.updateStateForDrawContext10(drawContext, intValue, intValue2, intValue3, intValue4, 6, LegacyUiColors.color10.getRGB());
      LegacyWidgets.drawText(drawContext, string, intValue + 8, intValue2 + 8, LegacyUiColors.color3);
      drawContext.fill(intValue + 8, intValue2 + 22, intValue + intValue3 - 8, intValue2 + 23, LegacyUiColors.color15.getRGB());
      int intValue5 = intValue2 + 30;

      for (ColoredKeyValue coloredKeyValue : (java.lang.Iterable<ColoredKeyValue>)(java.lang.Iterable<?>)(list)) {
         LegacyWidgets.drawText(drawContext, coloredKeyValue.key(), intValue + 8, intValue5, LegacyUiColors.color4);
         int width = LegacyWidgets.getWidth(coloredKeyValue.value());
         LegacyWidgets.drawText(drawContext, coloredKeyValue.value(), intValue + intValue3 - width - 8, intValue5, coloredKeyValue.color() != null ? coloredKeyValue.color() : LegacyUiColors.color3);
         intValue5 += 14;
      }
   }

   public static void updateStateForDrawContext6(DrawContext drawContext, int intValue, int intValue2, int intValue3, int intValue4, List list, Color color, Color color2, String string) {
      if (!list.isEmpty()) {
         RenderUtils.updateStateForDrawContext10(drawContext, intValue, intValue2, intValue3, intValue4, 6, LegacyUiColors.color10.getRGB());
         if (string != null && !string.isEmpty()) {
            LegacyWidgets.drawText(drawContext, string, intValue + 8, intValue2 + 4, LegacyUiColors.color3);
            intValue2 += 16;
            intValue4 -= 16;
         }

         if (list.size() == 1) {
            float floatValue = (Float)list.get(0);
            int intValue5 = intValue + intValue3 / 2;
            int intValue6 = intValue2 + intValue4 / 2;
            RenderUtils.updateStateForDrawContext2(drawContext, intValue5, intValue6, 4, color.getRGB());
            LegacyWidgets.updateStateForDrawContext13(drawContext, String.format("%.1f", floatValue), intValue5, intValue6 - 15, LegacyUiColors.color3);
         } else {
            float floatValue2 = (Float)Collections.min(list);
            float floatValue3 = (Float)Collections.max(list);
            float floatValue4 = floatValue3 - floatValue2;
            if (floatValue4 == 0.0F) {
               floatValue4 = 1.0F;
            }

            Color color3 = LegacyWidgets.createColor(LegacyUiColors.color15, 60);

            for (int intValue7 = 1; intValue7 < 5; intValue7++) {
               int intValue8 = intValue2 + intValue4 * intValue7 / 5;
               drawContext.fill(intValue + 4, intValue8, intValue + intValue3 - 4, intValue8 + 1, color3.getRGB());
            }

            int[] intArray = new int[list.size()];
            int[] intArray2 = new int[list.size()];

            for (int intValue9 = 0; intValue9 < list.size(); intValue9++) {
               intArray[intValue9] = intValue + 4 + intValue9 * (intValue3 - 8) / (list.size() - 1);
               intArray2[intValue9] = intValue2 + intValue4 - 4 - (int)(((Float)list.get(intValue9) - floatValue2) / floatValue4 * (float)(intValue4 - 8));
            }

            if (color2 != null) {
               for (int intValue10 = 0; intValue10 < list.size() - 1; intValue10++) {
                  int intValue11 = intArray[intValue10];
                  int intValue12 = intArray2[intValue10];
                  int intValue13 = intArray[intValue10 + 1];
                  int intValue14 = intArray2[intValue10 + 1];
                  updateStateForDrawContext9(drawContext, intValue11, intValue12, intValue13, intValue14, intValue2 + intValue4 - 4, color2);
               }
            }

            for (int intValue15 = 0; intValue15 < list.size() - 1; intValue15++) {
               updateStateForDrawContext2(drawContext, intArray[intValue15], intArray2[intValue15], intArray[intValue15 + 1], intArray2[intValue15 + 1], 2, color);
            }

            for (int intValue16 = 0; intValue16 < list.size(); intValue16++) {
               RenderUtils.updateStateForDrawContext2(drawContext, intArray[intValue16], intArray2[intValue16], 3, color.getRGB());
            }

            LegacyWidgets.drawText(drawContext, String.format("%.1f", floatValue3), intValue + intValue3 - 30, intValue2 + 4, LegacyUiColors.color4);
            LegacyWidgets.drawText(drawContext, String.format("%.1f", floatValue2), intValue + intValue3 - 30, intValue2 + intValue4 - 12, LegacyUiColors.color4);
         }
      }
   }

   private LegacySettingWidgets() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }

   public static void updateStateForDrawContext7(DrawContext drawContext, int intValue, int intValue2, int intValue3, float floatValue, float floatValue2, Color color, String string) {
      floatValue = Math.max(0.0F, Math.min(floatValue2, floatValue));
      float floatValue3 = floatValue / floatValue2;
      RenderUtils.updateStateForDrawContext2(drawContext, intValue, intValue2, intValue3, LegacyUiColors.color10.getRGB());
      RenderUtils.updateStateForDrawContext2(drawContext, intValue, intValue2, intValue3 - 6, LegacyUiColors.color.getRGB());
      updateStateForDrawContext8(drawContext, intValue, intValue2, intValue3 - 3, -90, -90 + (int)(270.0F * floatValue3), 6, color);
      String string2 = String.format("%.0f", floatValue);
      LegacyWidgets.updateStateForDrawContext13(drawContext, string2, intValue, intValue2 - 4, LegacyUiColors.color3);
      if (string != null && !string.isEmpty()) {
         LegacyWidgets.updateStateForDrawContext13(drawContext, string, intValue, intValue2 + 8, LegacyUiColors.color4);
      }

      String string3 = String.format("%.0f%%", floatValue3 * 100.0F);
      LegacyWidgets.updateStateForDrawContext13(drawContext, string3, intValue, intValue2 + 20, LegacyUiColors.color4);
   }

   private static void updateStateForDrawContext8(DrawContext drawContext, int intValue, int intValue2, int intValue3, int intValue4, int intValue5, int intValue6, Color color) {
      for (int intValue42 = intValue4; intValue42 <= intValue5; intValue42 += 2) {
         double doubleValue = Math.toRadians((double)intValue42);
         int intValue8 = intValue + (int)((double)intValue3 * Math.cos(doubleValue));
         int intValue9 = intValue2 + (int)((double)intValue3 * Math.sin(doubleValue));

         for (int intValue10 = -intValue6 / 2; intValue10 <= intValue6 / 2; intValue10++) {
            for (int intValue11 = -intValue6 / 2; intValue11 <= intValue6 / 2; intValue11++) {
               if (intValue10 * intValue10 + intValue11 * intValue11 <= intValue6 / 2 * (intValue6 / 2)) {
                  drawContext.fill(intValue8 + intValue10, intValue9 + intValue11, intValue8 + intValue10 + 1, intValue9 + intValue11 + 1, color.getRGB());
               }
            }
         }
      }
   }

   private static void updateStateForDrawContext9(DrawContext drawContext, int intValue, int intValue2, int intValue3, int intValue4, int intValue5, Color color) {
      int intValue6 = Math.abs(intValue3 - intValue);
      if (intValue6 != 0) {
         for (int intValue7 = 0; intValue7 <= intValue6; intValue7++) {
            float floatValue = (float)intValue7 / (float)intValue6;
            int intValue8 = intValue + (int)((float)(intValue3 - intValue) * floatValue);
            int intValue9 = intValue2 + (int)((float)(intValue4 - intValue2) * floatValue);
            drawContext.fill(intValue8, intValue9, intValue8 + 1, intValue5, color.getRGB());
         }
      }
   }
}
