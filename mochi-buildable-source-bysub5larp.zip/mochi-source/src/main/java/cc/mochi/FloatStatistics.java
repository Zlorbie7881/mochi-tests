package cc.mochi;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FloatStatistics {
   private final int capacity;
   private final List<Float> samples;

   public float average() {
      return this.samples.isEmpty() ? 0.0F : (float)this.samples.stream().mapToDouble(objectValue -> objectValue.doubleValue()).average().orElse(0.0);
   }

   public void add(float floatValue) {
      this.samples.add(floatValue);
      if (this.samples.size() > this.capacity) {
         this.samples.remove(0);
      }
   }

   public float minimum() {
      return this.samples.isEmpty() ? 0.0F : Collections.min(this.samples);
   }

   public void clear() {
      this.samples.clear();
   }

   public FloatStatistics(int capacity2) {
      this.capacity = capacity2;
      this.samples = new ArrayList<>();
   }

   public List copySamples() {
      return new ArrayList<>(this.samples);
   }

   public float maximum() {
      return this.samples.isEmpty() ? 0.0F : Collections.max(this.samples);
   }
}
