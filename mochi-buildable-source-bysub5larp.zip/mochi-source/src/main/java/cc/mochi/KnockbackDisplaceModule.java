package cc.mochi;

import cc.mochi.event.impl.network.DisconnectEvent;
import cc.mochi.event.impl.player.MovementSendEvent;
import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.event.impl.world.WorldChangeEvent;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Supplier;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class KnockbackDisplaceModule extends Module implements AttackInputBlocker, AttackTargetBlocker {
   private float floatState;

   private final DoubleSetting customOffsetSetting;

   private float floatState2;

   private float floatState3;

   private static KnockbackDisplaceModule knockbackDisplaceModule;

   private int counter;

   private float floatState4;

   private final BooleanSetting hideFlickSetting;

   private final ChoiceSetting triggerSetting;

   private boolean booleanState;

   private int counter2;
   private KnockbackCandidate knockbackCandidate;

   private int intState;

   private final DoubleSetting predictionTicksSetting;

   private float floatState5;

   private KnockbackDisplaceState knockbackDisplaceState;

   private boolean booleanState2;

   private float floatState6;
   private KnockbackSimulationInput knockbackSimulationInput;

   private final DoubleSetting holdTicksSetting;

   private int intState2;

   private final BooleanSetting powderSnowSetting;

   private final BooleanSetting fireAndCampfiresSetting;

   private final DoubleSetting smoothnessSetting;

   private final KeybindSetting activationKeySetting;

   private final BooleanSetting cobwebsSetting;

   private final BooleanSetting kBHitSetting;

   private PlayerEntity playerEntity;

   private final BooleanSetting waitForChargeSetting;
   private HazardPreferences hazardPreferences;

   private WorldHazardView worldHazardView;

   private final BooleanSetting spearReachSetting;

   private boolean booleanState3;

   private boolean booleanState4;

   private final BooleanSetting voidSetting;

   private float floatState7;

   private RotationProfile rotationProfile;
   private int intState3;

   private final ChoiceSetting smartPrioritySetting;

   private final BooleanSetting contactHazardsSetting;
   private double doubleState;
   private boolean booleanState5;

   private final ChoiceSetting rotationSetting;

   private final HumanizedRandom humanizedRandom;

   private boolean booleanState6;

   private final BooleanSetting lavaSetting;

   private final ChoiceSetting directionSetting;

   private final BooleanSetting damagingFallsSetting;

   private final DoubleSetting flickSpeedSetting;

   private final BooleanSetting weaponOnlySetting;

   public static void setKnockbackSimulationInput(KnockbackDisplaceModule knockbackDisplaceModule2, KnockbackSimulationInput knockbackSimulationInput2) {
      knockbackDisplaceModule2.knockbackSimulationInput = knockbackSimulationInput2;
   }

   @EventHandler
   private void onWorldChange(WorldChangeEvent worldChangeEvent) {
      this.updateState8(true);

      this.booleanState2 = false;
   }

   public static float getFloatState(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.floatState;
   }

   public static BooleanSetting getVoidSetting(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.voidSetting;
   }

   public static float getFloatState7(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.floatState7;
   }

   public static void setBooleanState(KnockbackDisplaceModule knockbackDisplaceModule2, boolean booleanState7) {
      knockbackDisplaceModule2.booleanState = booleanState7;
   }

   private boolean checkCondition() {
      if (mc.player.canSee(this.playerEntity)) {
         if (getKnockbackCandidate(this) != null) {
            if (getWorldHazardView(this) != null) {
               if (!getBooleanState6(this)) {
                  if (!(BlockInteractUtils.computeHitResult(this.computeFloat(), this.floatState3, this.doubleState) instanceof EntityHitResult var2) || var2.getEntity() != getPlayerEntity(this)) {
                     return false;
                  }
               }

               return KnockbackSimulator.testKnockbackSimulationInput(this.computeKnockbackSimulationInput(false), getWorldHazardView(this), getFloatState7(this), this.knockbackCandidate.getHazard2());
            }
         }
      }

      return false;
   }

   public static void setFloatState2(KnockbackDisplaceModule knockbackDisplaceModule2, float floatState22) {
      knockbackDisplaceModule2.floatState2 = floatState22;
   }

   private int computeInt(float floatValue) {
      double floatValue2 = (double)floatValue;
      double doubleValue32 = 0.0;

      int intValue = 0;

      while (true) {
         if (!(floatValue2 > (3.0))) {
            break;
         }

         if (intValue >= 60) {
            break;
         }

         double doubleValue3 = this.computeDouble(floatValue2, doubleValue32, 0.95);
         floatValue2 -= doubleValue3;
         doubleValue32 = doubleValue3;
         intValue++;
      }

      return intValue;
   }

   private void updateState() {
      if (MovementInputOverride.checkCondition(this, MinecraftClientAccess40.getTRUE(), null, null, MinecraftClientAccess40.getTRUE(), null)) {
         ThreadLocalRandom.current().nextInt(4);
         this.intState2 = getIntState(this);
      }
   }

   public static PlayerEntity getPlayerEntity(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.playerEntity;
   }

   private boolean checkCondition2() {
      ItemStack mainHandStack = MinecraftClientAccess40.getPlayer(mc).getMainHandStack();
      if (!mainHandStack.isIn(MinecraftClientAccess40.getSWORDS())) {
         if (!mainHandStack.isIn(MinecraftClientAccess40.getAXES())) {
            return false;
         }
      }

      return true;
   }

   private boolean checkCondition3() {
      if (this.equals3()) {
         if (this.knockbackCandidate != null) {
            if (getKnockbackSimulationInput(this) != null) {
               double bonus = this.knockbackSimulationInput.getBonus();

               if (bonus > (0.0)) {
                  return true;
               }
            }
         }

         return false;
      } else {
         if (!this.equals3()) {
            if (Math.abs(this.floatState2) < 1.0F) {
               return false;
            }
         }

         if (!getBooleanState6(this)) {
            if (!this.checkCondition7()) {
               if (this.kBHitSetting.isOn()) {
                  if (this.checkCondition8()) {
                     return true;
                  }

                  ThreadLocalRandom.current().nextInt(12);
               }

               return false;
            }
         }

         return true;
      }
   }

   public static BooleanSetting getWeaponOnlySetting(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.weaponOnlySetting;
   }

   private boolean testPlayerEntity(PlayerEntity playerEntity2) {
      if (playerEntity2 != null) {
         if (this.booleanState2) {
            ThreadLocalRandom.current().nextInt(8);

            this.booleanState6 = ((getSpearReachSetting(this).isOn() && playerEntity2.getBoundingBox().squaredMagnitude(MinecraftClientAccess40.getPlayer(mc).getEyePos()) > 9.0 ? 1 : 0) != 0);
            double doubleState2;
            if (getBooleanState6(this)) {
               ThreadLocalRandom.current().nextInt(3);

               ThreadLocalRandom.current().nextInt(13);
               doubleState2 = HeldItemOverride.computeDoubleForClientPlayerEntity(MinecraftClientAccess40.getPlayer(mc), 4.5);
            } else {
               doubleState2 = (3.0);
            }

            this.doubleState = doubleState2;
            if (this.testPlayerEntity3(playerEntity2)) {
               ThreadLocalRandom.current().nextInt(6);
               if (CombatActionCoordinator.testCombatActionOwner(CombatActionOwner.KNOCKBACK)) {
                  setFloatState2(this, this.computeFloat2());
                  setPlayerEntity(this, playerEntity2);
                  if (this.equals3()) {
                     ThreadLocalRandom.current().nextInt(17);

                     if (!this.checkCondition6()) {
                        CombatActionCoordinator.updateStateForCombatActionOwner(CombatActionOwner.KNOCKBACK);
                        this.playerEntity = null;
                        this.knockbackCandidate = null;
                        setWorldHazardView(this, null);
                        setKnockbackSimulationInput(this, null);
                        setHazardPreferences(this, null);

                        this.intState3 = -1;
                        this.updateState12();

                        return false;
                     }
                  }

                  if (!this.checkCondition3()) {
                     CombatActionCoordinator.updateStateForCombatActionOwner(CombatActionOwner.KNOCKBACK);
                     this.playerEntity = null;
                     this.updateState12();

                     return false;
                  }

                  setPlayerEntity(this, playerEntity2);
                  this.intState = 0;

                  this.floatState = (0.0F);
                  RotationProfile rotationProfile2 = RotationProfile.createRotationProfile().withMaxRotationSpeed(3600.0);

                  RotationProfile rotationProfile3 = rotationProfile2.computeRotationProfile10((1.0)).withSilentAim(this.rotationSetting.equals("Silent")).computeRotationProfile7(true).computeRotationProfile4(0.0);

                  this.rotationProfile = rotationProfile3.computeRotationProfile3((0.0)).computeRotationProfile9(0L);
                  this.updateStateForKnockbackDisplaceState(KnockbackDisplaceState.ARMED);
                  this.updateState10();

                  return true;
               }
            }

            this.updateState12();
            return false;
         }
      }

      return false;
   }

   public static KnockbackDisplaceState getKnockbackDisplaceState(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.knockbackDisplaceState;
   }

   public static void setWorldHazardView(KnockbackDisplaceModule knockbackDisplaceModule2, WorldHazardView worldHazardView2) {
      knockbackDisplaceModule2.worldHazardView = worldHazardView2;
   }

   public static void setBooleanState5(KnockbackDisplaceModule knockbackDisplaceModule2, boolean booleanState52) {
      knockbackDisplaceModule2.booleanState5 = booleanState52;
   }

   public static int getIntState(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.intState;
   }

   private double computeDouble(double doubleValue, double doubleValue2, double doubleValue3) {
      double doubleValue4 = getFlickSpeedSetting(this).getValue() * 0.05;
      double value = this.smoothnessSetting.getValue();
      double doubleValue5 = Math.min(doubleValue, doubleValue4);

      if (value > (0.0)) {
         double doubleValue6 = doubleValue * ((1.0) - (0.75) * value * doubleValue3);
         double doubleValue7 = doubleValue - doubleValue6;

         if (doubleValue7 > (6.0)) {
            doubleValue5 = Math.min(doubleValue5, doubleValue6);
         }

         double doubleValue8 = Math.max(doubleValue2 * ((1.6) + 2.0 * (1.0 - value)), doubleValue4 * (1.0 - 0.7 * value));
         doubleValue5 = Math.min(doubleValue5, doubleValue8);
      }

      return Math.max(doubleValue5, Math.min(doubleValue, 0.5));
   }

   public static double getDoubleState(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.doubleState;
   }

   public static boolean checkCondition4() {
      KnockbackDisplaceModule knockbackDisplaceModule2 = getKnockbackDisplaceModule();
      if (knockbackDisplaceModule2 != null) {
         if (knockbackDisplaceModule2.isEnabled()) {
            if (getSpearReachSetting(knockbackDisplaceModule2).isOn()) {
               if (knockbackDisplaceModule2.shouldBlockAttackInput()) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   public static BooleanSetting getContactHazardsSetting(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.contactHazardsSetting;
   }

   public static BooleanSetting getCobwebsSetting(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.cobwebsSetting;
   }

   private void updateState2() {
      this.updateState8(false);
   }

   public static void setFloatState4(KnockbackDisplaceModule knockbackDisplaceModule2, float floatState42) {
      knockbackDisplaceModule2.floatState4 = floatState42;
   }

   public static int getCounter(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.counter;
   }

   public static DoubleSetting getHoldTicksSetting(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.holdTicksSetting;
   }

   public static boolean getBooleanState4(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.booleanState4;
   }

   private boolean checkCondition5() {
      return AttackActions.testMinecraftClient4(mc, getPlayerEntity(this), "combat.attack.knockbackDisplace");
   }

   public static float getFloatState4(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.floatState4;
   }

   public static ChoiceSetting getTriggerSetting(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.triggerSetting;
   }

   public static KnockbackDisplaceState getARMED() {
      return KnockbackDisplaceState.ARMED;
   }

   private Boolean equals() {
      return this.triggerSetting.equals("On Key");
   }

   private PlayerEntity computePlayerEntity() {
      PlayerEntity playerEntity2 = this.computePlayerEntity2();
      if (playerEntity2 == null) {
         if (this.spearReachSetting.isOn()) {
            LivingEntity livingEntity = HeldItemOverride.computeLivingEntityForClientPlayerEntity(mc.player, true, 4.5);
            PlayerEntity playerEntity3;
            if (livingEntity instanceof PlayerEntity) {
               PlayerEntity livingEntity2 = (PlayerEntity)livingEntity;
               playerEntity3 = livingEntity2;
            } else {
               playerEntity3 = null;

               ThreadLocalRandom.current().nextInt(8);
            }

            return playerEntity3;
         }
      }

      return playerEntity2;
   }

   public static KnockbackSimulationInput getKnockbackSimulationInput(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.knockbackSimulationInput;
   }

   private float computeFloat() {
      return this.computeFloatForPlayerEntity2(this.playerEntity);
   }

   public static float getFloatState6(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.floatState6;
   }

   private void updateState3() {
      if ((double)getCounter(this) > getHoldTicksSetting(this).getValue()) {
         this.updateState2();
      } else {
         this.updateState6();
      }
   }

   public static KnockbackCandidate getKnockbackCandidate(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.knockbackCandidate;
   }

   public static void setRotationProfile(KnockbackDisplaceModule knockbackDisplaceModule2, RotationProfile rotationProfile2) {
      knockbackDisplaceModule2.rotationProfile = rotationProfile2;
   }

   public static KnockbackDisplaceState getIDLE() {
      return KnockbackDisplaceState.IDLE;
   }

   @Override
   public boolean checkCondition15() {
      return true;
   }

   private KnockbackSimulationInput computeKnockbackSimulationInput(boolean booleanValue) {
      if (this.playerEntity != null && !getPlayerEntity(this).hasVehicle()) {
         if (!getPlayerEntity(this).isGliding()) {
            if (!getPlayerEntity(this).getAbilities().flying && !getPlayerEntity(this).isSpectator() && !MinecraftClientAccess40.getInvulnerable(this.playerEntity.getAbilities())) {
               byte byteValue = 22;
               ThreadLocalRandom.current().nextInt(15);
               if (!getPlayerEntity(this).isBlocking()
                  && !getPlayerEntity(this).isTouchingWater()
                  && !this.playerEntity.isInLava()
                  && !getPlayerEntity(this).isClimbing()
                  && !this.playerEntity.hasStatusEffect(MinecraftClientAccess40.getLEVITATION())) {
                  if (!this.playerEntity.hasStatusEffect(StatusEffects.SLOW_FALLING)) {
                     if (this.playerEntity.hurtTime <= 0 && MinecraftClientAccess40.getPlayer(mc).isAlive()) {
                        if (!this.weaponOnlySetting.isOn() || this.checkCondition2()) {
                           ItemStack itemStack = MinecraftClientAccess40.getPlayer(mc).getMainHandStack();
                           if (getBooleanState6(this)) {
                              int intValue = HeldItemOverride.computeIntForClientPlayerEntity(mc.player);
                              if (intValue < 0) {
                                 return null;
                              }

                              itemStack = mc.player.getInventory().getStack(intValue);
                           }

                           int intValue2;
                           label146: {
                              intValue2 = EnchantmentUtils.computeIntForItemStack(itemStack, MinecraftClientAccess40.getKNOCKBACK());
                              if (booleanValue && this.kBHitSetting.isOn()) {
                                 if (!this.checkCondition7()) {
                                    byteValue = 5;
                                    ThreadLocalRandom.current().nextInt(4);
                                    if (this.checkCondition8()) {
                                       byteValue = 1;
                                       break label146;
                                    }
                                 }
                              }

                              byteValue = 0;
                           }

                           int byteValue2 = byteValue;
                           int intValue4 = getBooleanState6(this) || !mc.player.isSprinting() && byteValue2 == 0 ? 0 : 1;
                           if (!booleanValue) {
                              float attackCooldownProgress = mc.player.getAttackCooldownProgress(0.5F);

                              if (attackCooldownProgress <= (0.9F)) {
                                 intValue4 = 0;
                              }
                           }

                           double doubleValue;
                           label129: {
                              doubleValue = KnockbackSimulator.computeDouble(intValue2, mc.player.getAttributeValue(MinecraftClientAccess40.getATTACK_KNOCKBACK()), (intValue4 != 0), this.booleanState6);
                              if (!getPlayerEntity(this).getAbilities().allowFlying) {
                                 if (!getPlayerEntity(this).hasStatusEffect(MinecraftClientAccess40.getSLOW_FALLING())) {
                                    byteValue = 1;
                                    break label129;
                                 }
                              }

                              byteValue = 0;
                           }

                           int byteValue3 = byteValue;
                           Vec3d vec3d = EntityMotionTracker.computeVec3dForLivingEntity(getPlayerEntity(this));
                           return new KnockbackSimulationInput(
                              this.playerEntity.getBoundingBox(),
                              vec3d,
                              MinecraftClientAccess40.getPlayer(mc).getEntityPos(),
                              getPlayerEntity(this).isOnGround(),
                              this.playerEntity.getAttributeValue(EntityAttributes.KNOCKBACK_RESISTANCE),
                              doubleValue,
                              getPlayerEntity(this).getFinalGravity(),
                              (double)this.playerEntity.getSafeFallDistance(),
                              this.playerEntity.fallDistance,
                              (byteValue3 != 0),
                              this.predictionTicksSetting.intValue()
                           );
                        }
                     }
                  } else {
                     byteValue = 23;
                     ThreadLocalRandom.current().nextInt(16);
                  }
               }
            }
         }
      }

      return null;
   }

   public static ChoiceSetting getDirectionSetting(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.directionSetting;
   }

   public static KnockbackDisplaceModule getKnockbackDisplaceModule() {
      return knockbackDisplaceModule;
   }

   public static HumanizedRandom getHumanizedRandom(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.humanizedRandom;
   }

   private void updateState4() {
      if (this.equals3() && !this.checkCondition6()) {
         this.updateState2();
      } else if (!this.checkCondition3()) {
         this.updateState9();
         this.updateStateForKnockbackDisplaceState(KnockbackDisplaceState.ARMED);
      } else {
         if (!this.equals3()) {
            this.floatState4 = this.computeFloat() + this.floatState2;
         }

         float floatValue;
         int intValue;
         label231: {
            floatValue = MathHelper.wrapDegrees(getFloatState4(this) - getFloatState7(this));
            if (!Float.isNaN(getFloatState5(this))) {
               if (Math.abs(MathHelper.wrapDegrees(getFloatState5(this) - this.floatState7)) <= (3.0F)
                  && Math.abs(floatValue) <= (20.0F)) {
                  intValue = 1;
                  break label231;
               }
            }

            intValue = 0;
         }

         int intValue2 = intValue;
         if (this.booleanState6) {
            intValue = 7;
            ThreadLocalRandom.current().nextInt(5);

            intValue = (HeldItemOverride.testClientPlayerEntity3(mc.player)) ? 1 : 0;
         } else {
            label224: {
               if (this.computeInt2() != 0) {
                  if (getWaitForChargeSetting(this).isOn() && getIntState(this) < 20) {
                     intValue = 0;
                     break label224;
                  }
               }

               intValue = 1;
            }
         }

         int intValue3 = intValue;
         if (getIntState22(this) == getIntState(this) - 1 && !mc.player.isSprinting()) {
            intValue = 1;
         } else {
            intValue = 0;
         }

         int intValue4 = intValue;
         if (intValue2 == 0 || intValue3 == 0 || !this.booleanState6 && !this.checkCondition7() && intValue4 == 0) {
            if (intValue2 == 0) {
               this.counter2++;
            }

            this.floatState5 = getFloatState4(this);
            if (intValue2 == 0) {
               this.updateState11(Math.abs(floatValue));
            }

            float floatValue2 = this.computeFloat3(Math.abs(floatValue));
            float floatValue3 = getFloatState7(this) + Math.signum(floatValue) * floatValue2;
            this.updateStateForSupplier(() -> computeFloat4(floatValue3));
            if (RotationManager.computeVec3d(this) == null) {
               if (!this.booleanState6 && !this.equals3()) {
                  this.checkCondition5();
               }

               this.updateState2();
            } else {
               int intValue5;
               label193: {
                  intValue5 = intValue2 == 0 && !(floatValue2 >= Math.abs(floatValue) - 0.001F) ? 0 : 1;
                  if (this.computeInt2() > 1) {
                     if (getWaitForChargeSetting(this).isOn() && getIntState(this) + 1 < 20) {
                        intValue = 0;
                        break label193;
                     }
                  } else {
                     intValue = 18;
                     ThreadLocalRandom.current().nextInt(15);
                  }

                  intValue = 1;
               }

               int intValue6 = intValue;
               if (!getBooleanState6(this)) {
                  if (this.kBHitSetting.isOn()) {
                     if (intValue5 != 0 && intValue6 != 0 && !this.checkCondition7()) {
                        this.updateState();
                     }
                  }
               }
            }
         } else {
            if (this.equals3()) {
               if (!this.checkCondition()) {
                  if (intValue4 != 0) {
                     this.updateState2();
                  } else {
                     this.updateState9();
                     this.updateStateForKnockbackDisplaceState(KnockbackDisplaceState.ARMED);
                  }

                  return;
               }
            }

            if (getBooleanState6(this) && !this.checkCondition10()) {
               this.updateState9();
               this.updateStateForKnockbackDisplaceState(KnockbackDisplaceState.ARMED);
            } else {
               if (!getBooleanState6(this)) {
                  this.checkCondition5();
               }

               this.updateState9();
               this.updateStateForKnockbackDisplaceState(KnockbackDisplaceState.HOLD);
            }
         }
      }
   }

   public static void setPlayerEntity(KnockbackDisplaceModule knockbackDisplaceModule2, PlayerEntity playerEntity2) {
      knockbackDisplaceModule2.playerEntity = playerEntity2;
   }

   public static boolean getBooleanState6(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.booleanState6;
   }

   @Override
   public void onEnable() {
      this.updateState8(false);
      this.booleanState2 = false;
      setBooleanState(this, this.checkCondition9());
   }

   public static int getIntState22(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.intState2;
   }

   @EventHandler
   private void onDisconnect(DisconnectEvent disconnectEvent) {
      this.updateState8(true);

      this.booleanState2 = false;
   }

   private void updateState5() {
      setFloatState(this, 0.0F);

      this.counter2 = 0;
      setFloatState5(this, Float.NaN);

      setBooleanState3(this, false);
      this.updateStateForKnockbackDisplaceState(KnockbackDisplaceState.TURNING);
      this.updateState4();
   }

   private boolean checkCondition6() {
      KnockbackSimulationInput knockbackSimulationInput2 = this.computeKnockbackSimulationInput(true);
      if (knockbackSimulationInput2 != null) {
         ThreadLocalRandom.current().nextInt(5);

         double bonus = knockbackSimulationInput2.getBonus();

         if (!(bonus <= (0.0))) {
            if (!(knockbackSimulationInput2.getResistance2() >= 1.0)) {
               HazardPreferences hazardPreferences2 = new HazardPreferences(getVoidSetting(this).isOn(), getDamagingFallsSetting(this).isOn(), getCobwebsSetting(this).isOn(), this.lavaSetting.isOn(), this.fireAndCampfiresSetting.isOn(), getContactHazardsSetting(this).isOn(), getPowderSnowSetting(this).isOn(), this.smartPrioritySetting.getSelected());
               if (this.intState == this.intState3) {
                  ThreadLocalRandom.current().nextInt(6);

                  if (knockbackSimulationInput2.equals(getKnockbackSimulationInput(this))) {
                     if (hazardPreferences2.equals(getHazardPreferences(this))) {
                        return ((getKnockbackCandidate(this) != null ? 1 : 0) != 0);
                     }
                  }
               }

               setIntState3(this, getIntState(this));
               setKnockbackSimulationInput(this, knockbackSimulationInput2);
               this.hazardPreferences = hazardPreferences2;

               double doubleValue = knockbackSimulationInput2.getBonus() + 0.2;

               double doubleValue2 = doubleValue * ((1.0) - knockbackSimulationInput2.getResistance2());

               double doubleValue3 = (3.0) + doubleValue2 * (5.0) + knockbackSimulationInput2.getVelocity().horizontalLength() * 4.0;
               this.worldHazardView = new WorldHazardView(mc.world, this.playerEntity, hazardPreferences2, doubleValue3);
               this.knockbackCandidate = KnockbackSimulator.computeKnockbackCandidateForKnockbackSimulationInput(knockbackSimulationInput2, getWorldHazardView(this), this.knockbackCandidate == null ? getFloatState7(this) : getKnockbackCandidate(this).getYaw());
               if (getKnockbackCandidate(this) == null) {
                  return false;
               }

               setFloatState4(this, RotationMath.computeFloat(getKnockbackCandidate(this).getYaw(), this.floatState7));
               setFloatState2(this, MathHelper.wrapDegrees(this.floatState4 - this.computeFloat()));

               return true;
            }
         }
      }

      return false;
   }

   private boolean checkCondition7() {
      ItemStack mainHandStack = mc.player.getMainHandStack();
      if (this.equals3()) {
         if (!mc.player.isSprinting() && EnchantmentUtils.computeIntForItemStack(mainHandStack, Enchantments.KNOCKBACK) <= 0) {
            double attributeValue = MinecraftClientAccess40.getPlayer(mc).getAttributeValue(EntityAttributes.ATTACK_KNOCKBACK);

            if (!(attributeValue > (0.0))) {
               return false;
            }
         }

         return true;
      } else {
         if (!mc.player.isSprinting()) {
            if (!EnchantmentUtils.testItemStack4(mainHandStack, mc.world, MinecraftClientAccess40.getKNOCKBACK())) {
               return false;
            }
         }

         ThreadLocalRandom.current().nextInt(13);
         return true;
      }
   }

   private void updateState6() {
      PlayerEntity playerEntity2 = this.playerEntity;
      this.updateStateForSupplier(() -> this.computeFloatForPlayerEntity(playerEntity2));
   }

   @Override
   public boolean shouldBlockAttackTarget(Entity entity) {
      if (!this.isWorldUnavailable()) {
         if (mc.currentScreen == null) {
            if (getKnockbackDisplaceState(this) != KnockbackDisplaceState.IDLE) {
               return true;
            }

            if (getTriggerSetting(this).equals("On Attack")) {
               if (entity instanceof PlayerEntity) {
                  PlayerEntity entity2 = (PlayerEntity)entity;
                  if (this.testPlayerEntity(entity2)) {
                     return true;
                  }
               }
            } else {
               ThreadLocalRandom.current().nextInt(6);
            }

            return false;
         }
      }

      return false;
   }

   public static BooleanSetting getSpearReachSetting(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.spearReachSetting;
   }

   public static KeybindSetting getActivationKeySetting(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.activationKeySetting;
   }

   public static boolean getBooleanState(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.booleanState;
   }

   public static void setFloatState(KnockbackDisplaceModule knockbackDisplaceModule2, float floatState8) {
      knockbackDisplaceModule2.floatState = floatState8;
   }

   public static WorldHazardView getWorldHazardView(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.worldHazardView;
   }

   private void updateState7() {
      if ((this.booleanState4)) {
         this.booleanState4 = false;
         OutgoingPacketQueue.getINSTANCE2().updateState4(this);
      }
   }

   public static HazardPreferences getHazardPreferences(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.hazardPreferences;
   }

   public static BooleanSetting getPowderSnowSetting(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.powderSnowSetting;
   }

   public static void setBooleanState3(KnockbackDisplaceModule knockbackDisplaceModule2, boolean booleanState32) {
      knockbackDisplaceModule2.booleanState3 = booleanState32;
   }

   private boolean checkCondition8() {
      label59: {
         ClientPlayerEntity player = mc.player;
         int foodLevel = player.getHungerManager().getFoodLevel();

         if (foodLevel <= 6) {
            if (!MinecraftClientAccess40.getAllowFlying(player.getAbilities())) {
               break label59;
            }
         }

         if (!player.isUsingItem()) {
            if (!player.isSneaking() && !player.isGliding() && !player.hasVehicle() && !player.isTouchingWater()) {
               if (!player.hasStatusEffect(StatusEffects.BLINDNESS) && MovementInputOverride.checkCondition4(this)) {
                  return true;
               }
            }
         } else {
            ThreadLocalRandom.current().nextInt(8);
         }
      }

      return false;
   }

   public KnockbackDisplaceModule() {
      super("Knockback Displace", "Flicks the server-facing look off the target for one hit, sending its knockback sideways or back towards you", ModuleCategory.COMBAT);

      this.triggerSetting = new ChoiceSetting("Trigger", "On Attack", "On Attack", "On Key");

      this.activationKeySetting = new KeybindSetting("Activation Key", -1, false);
      String[] stringArray = new String[5];

      stringArray[0] = "Backward";
      stringArray[1] = "Left";
      stringArray[2] = "Right";
      stringArray[3] = "Custom";

      stringArray[4] = "Smart";
      this.directionSetting = new ChoiceSetting("Direction", "Backward", stringArray);

      this.customOffsetSetting = new DoubleSetting("Custom Offset", ((-180.0)), 180.0, 135.0, (1.0));
      String[] stringArray2 = new String[2];

      stringArray2[0] = "Silent";
      stringArray2[1] = "Legit";
      this.rotationSetting = new ChoiceSetting("Rotation", "Silent", stringArray2);

      this.flickSpeedSetting = new DoubleSetting("Flick Speed", (360.0), 3600.0, 1440.0, 30.0);

      this.smoothnessSetting = new DoubleSetting("Smoothness", (0.0), (0.9), (0.5), (0.05));

      this.kBHitSetting = new BooleanSetting("KB Hit", true);

      this.hideFlickSetting = new BooleanSetting("Hide Flick", false);
      this.spearReachSetting = new BooleanSetting("Spear Reach", false);
      this.waitForChargeSetting = new BooleanSetting("Wait For Charge", true);

      this.holdTicksSetting = new DoubleSetting("Hold Ticks", (0.0), (10.0), 2.0, 1.0);
      this.weaponOnlySetting = new BooleanSetting("Weapon Only", true);

      String[] stringArray3 = new String[3];

      stringArray3[0] = "Balanced";
      stringArray3[1] = "Traps";
      stringArray3[2] = "Damage";
      this.smartPrioritySetting = new ChoiceSetting("Smart Priority", "Balanced", stringArray3);
      this.predictionTicksSetting = new DoubleSetting("Prediction Ticks", 0.0, 4.0, 1.0, 1.0);

      this.voidSetting = new BooleanSetting("Void", true);
      this.damagingFallsSetting = new BooleanSetting("Damaging Falls", true);
      this.cobwebsSetting = new BooleanSetting("Cobwebs", true);
      this.lavaSetting = new BooleanSetting("Lava", true);
      this.fireAndCampfiresSetting = new BooleanSetting("Fire And Campfires", true);
      this.contactHazardsSetting = new BooleanSetting("Contact Hazards", true);

      this.powderSnowSetting = new BooleanSetting("Powder Snow", true);
      this.knockbackDisplaceState = KnockbackDisplaceState.IDLE;
      this.floatState5 = (Float.NaN);
      this.intState2 = Integer.MIN_VALUE;

      this.doubleState = (3.0);

      this.intState3 = -1;
      this.humanizedRandom = new HumanizedRandom();
      Setting[] settingArray = new Setting[22];

      settingArray[0] = this.triggerSetting;
      settingArray[1] = this.activationKeySetting;
      settingArray[2] = this.directionSetting;
      settingArray[3] = this.customOffsetSetting;
      settingArray[4] = this.rotationSetting;
      settingArray[5] = this.flickSpeedSetting;
      settingArray[6] = this.smoothnessSetting;
      settingArray[7] = this.kBHitSetting;

      settingArray[8] = this.hideFlickSetting;
      settingArray[9] = this.spearReachSetting;
      settingArray[10] = this.waitForChargeSetting;
      settingArray[11] = this.holdTicksSetting;

      settingArray[12] = this.weaponOnlySetting;

      settingArray[13] = this.smartPrioritySetting;
      settingArray[14] = this.predictionTicksSetting;

      settingArray[15] = this.voidSetting;
      settingArray[16] = this.damagingFallsSetting;
      settingArray[17] = this.cobwebsSetting;
      settingArray[18] = this.lavaSetting;
      settingArray[19] = this.fireAndCampfiresSetting;
      settingArray[20] = this.contactHazardsSetting;
      settingArray[21] = this.powderSnowSetting;
      this.addSettings(settingArray);
      this.activationKeySetting.setVisibility(() -> this.equals());
      this.customOffsetSetting.setVisibility(() -> this.equals2());
      Setting[] settingArray2 = new Setting[]{this.smartPrioritySetting, null, null, null, null, null, null, null, null};

      settingArray2[1] = this.predictionTicksSetting;

      settingArray2[2] = this.voidSetting;
      settingArray2[3] = this.damagingFallsSetting;
      settingArray2[4] = this.cobwebsSetting;
      settingArray2[5] = this.lavaSetting;

      settingArray2[6] = this.fireAndCampfiresSetting;

      settingArray2[7] = this.contactHazardsSetting;
      settingArray2[8] = this.powderSnowSetting;
      Setting[] settingArray22 = settingArray2;
      int length = settingArray22.length;

      for (int intValue = 0; intValue < length; intValue++) {
         Setting setting = settingArray22[intValue];
         setting.setVisibility(() -> this.equals3());
      }

      knockbackDisplaceModule = this;
   }

   private Boolean equals2() {
      return this.directionSetting.equals("Custom");
   }

   private void updateState8(boolean booleanValue) {
      if (RotationManager.computeVec3d(this) != null) {
         if (booleanValue) {
            RotationManager.updateState(this);
         } else {
            RotationManager.updateState9(this);
         }
      }

      if (CombatActionCoordinator.getCombatActionOwner22() == CombatActionOwner.KNOCKBACK) {
         CombatActionCoordinator.updateStateForCombatActionOwner(CombatActionOwner.KNOCKBACK);

         ThreadLocalRandom.current().nextInt(13);
      }

      this.knockbackDisplaceState = KnockbackDisplaceState.IDLE;

      setCounter(this, this.intState = 0);
      this.playerEntity = null;
      setRotationProfile(this, null);
      setFloatState(this, 0.0F);
      setFloatState5(this, Float.NaN);
      this.intState2 = Integer.MIN_VALUE;
      MovementInputOverride.updateState(this);
      this.updateState7();

      this.booleanState3 = false;
      this.updateState12();
      this.knockbackCandidate = null;
      setWorldHazardView(this, null);
      this.knockbackSimulationInput = null;
      this.hazardPreferences = null;
      this.intState3 = -1;
   }

   private void updateState9() {
      long longValue = (long)Math.max(1, this.counter2);

      RotationManager.updateState7(this, longValue * (50L));
      this.updateState6();
   }

   private boolean equals3() {
      return this.directionSetting.equals("Smart");
   }

   public static void setCounter(KnockbackDisplaceModule knockbackDisplaceModule2, int counter3) {
      knockbackDisplaceModule2.counter = counter3;
   }

   private static Vec3d computeVec3dForSupplier(Supplier supplier) {
      if (mc.player == null) {
         return null;
      } else {
         Float objectValue = (Float)supplier.get();
         Vec3d eyePos;
         if (objectValue == null) {
            eyePos = null;
         } else {
            eyePos = MinecraftClientAccess40.getPlayer(mc).getEyePos();
            Vec3d vec3d = RotationMath.computeVec3d(objectValue, mc.player.getPitch());

            eyePos = eyePos.add(vec3d.multiply((10.0)));
         }

         return eyePos;
      }
   }

   private float computeFloat2() {
      String selected = getDirectionSetting(this).getSelected();

      byte byteValue = -1;
      switch (selected.hashCode()) {
         case -2108346365:
            if (selected.equals("Backward")) {
               byteValue = 0;
            }
            break;
         case 2364455:
            if (selected.equals("Left")) {
               byteValue = 1;
            }
            break;
         case 78959100:

            if (selected.equals("Right")) {
               byteValue = 2;
            } else {
               ThreadLocalRandom.current().nextInt(8);
            }
      }

      float value;
      switch (byteValue) {
         case 0:

            value = 180.0F;
            break;
         case 1:
            value = ((-90.0F));
            break;
         case 2:
            value = 90.0F;
            break;
         default:

            value = (float)this.customOffsetSetting.getValue();
      }

      return value;
   }

   private void updateStateForKnockbackDisplaceState(KnockbackDisplaceState knockbackDisplaceState2) {
      setKnockbackDisplaceState(this, knockbackDisplaceState2);

      setCounter(this, 0);
   }

   private PlayerEntity computePlayerEntity2() {
      HitResult crosshairTarget = mc.crosshairTarget;
      if (crosshairTarget != null) {
         if (crosshairTarget.getType() == MinecraftClientAccess40.getENTITY()) {
            if (crosshairTarget instanceof EntityHitResult var3) {
               if (var3.getEntity() instanceof PlayerEntity var2) {
                  return var2;
               }
            }
         }
      }

      return null;
   }

   private void updateStateForSupplier(Supplier supplier) {
      this.updateStateForSupplier2(() -> computeVec3dForSupplier(supplier));
   }

   public static BooleanSetting getWaitForChargeSetting(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.waitForChargeSetting;
   }

   private float computeFloat3(float floatValue) {
      double floatValue2 = (double)floatValue;
      double floatState8 = (double)getFloatState(this);
      HumanizedRandom humanizedRandom2 = getHumanizedRandom(this);

      float floatState9 = (float)this.computeDouble(floatValue2, floatState8, humanizedRandom2.computeDouble5(0.9, (1.0)));
      this.floatState = floatState9;
      return floatState9;
   }

   public static DoubleSetting getFlickSpeedSetting(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.flickSpeedSetting;
   }

   public static void setHazardPreferences(KnockbackDisplaceModule knockbackDisplaceModule2, HazardPreferences hazardPreferences2) {
      knockbackDisplaceModule2.hazardPreferences = hazardPreferences2;
   }

   public static float getFloatState2(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.floatState2;
   }

   private void updateState10() {
      if (this.equals3()) {
         if (!this.checkCondition6()) {
            this.updateState2();
            return;
         }
      } else {
         ThreadLocalRandom.current().nextInt(11);
      }

      if (this.booleanState6) {
         if (!HeldItemOverride.testClientPlayerEntity(mc.player, getPlayerEntity(this), this.floatState7, this.floatState3)) {
            this.updateState6();
         } else {
            if (!this.equals3()) {
               this.floatState4 = this.computeFloat() + getFloatState2(this);
            }

            int intValue = this.computeInt(Math.abs(MathHelper.wrapDegrees(getFloatState4(this) - this.floatState7)));
            if (HeldItemOverride.computeIntForClientPlayerEntity2(MinecraftClientAccess40.getPlayer(mc), 20) > intValue) {
               this.updateState6();
            } else {
               this.updateState5();
            }
         }
      } else {
         int intValue2 = this.intState < 20 && this.waitForChargeSetting.isOn() ? 0 : 1;
         int intValue3 = this.computeInt2();
         if (this.checkCondition3()) {
            if (!this.equals3()) {
               setFloatState4(this, this.computeFloat() + this.floatState2);
            }

            int intValue4 = this.computeInt(Math.abs(MathHelper.wrapDegrees(getFloatState4(this) - this.floatState7)));
            if (intValue2 != 0 || intValue3 <= intValue4) {
               this.updateState5();
            }
         } else {
            if (!(intValue3 != 0 && intValue2 == 0)) {
               this.checkCondition5();
               this.updateState2();
            }
         }
      }
   }

   private void updateState11(float floatValue) {
      if (!this.hideFlickSetting.isOn()) {
         if (!this.booleanState6) {
            return;
         }
      }

      if (!getBooleanState4(this)) {
         if (!this.booleanState3) {
            this.booleanState3 = true;
            this.floatState6 = this.floatState7;
            long longValue;

            longValue = (long)(this.computeInt(floatValue) + 3);

            long longValue2 = Math.min(600L, longValue * 50L);
            this.booleanState4 = OutgoingPacketQueue.getINSTANCE2().checkCondition(this, longValue2);
            return;
         }
      }
   }

   public static void setFloatState5(KnockbackDisplaceModule knockbackDisplaceModule2, float floatState52) {
      knockbackDisplaceModule2.floatState5 = floatState52;
   }

   private boolean testPlayerEntity2(PlayerEntity playerEntity2) {
      Box boundingBox = playerEntity2.getBoundingBox();
      byte byteValue;
      if (boundingBox.squaredMagnitude(mc.player.getEyePos()) <= getDoubleState(this) * getDoubleState(this)) {
         byteValue = 1;
      } else {
         byteValue = 0;

         ThreadLocalRandom.current().nextInt(7);
      }

      return (byteValue != 0);
   }

   private boolean checkCondition9() {
      int keyCode = getActivationKeySetting(this).getKeyCode();

      if (keyCode != -1) {
         if (keyCode != 0) {
            if (MinecraftClientAccess40.getCurrentScreen(mc) == null) {
               return KeybindUtils.checkCondition2(keyCode);
            }
         }
      }

      return false;
   }

   private boolean checkCondition10() {
      if (getBooleanState4(this)) {
         if (OutgoingPacketQueue.getINSTANCE2().checkCondition4(this)) {
            if (HeldItemOverride.testClientPlayerEntity(MinecraftClientAccess40.getPlayer(mc), this.playerEntity, getFloatState6(this), getFloatState3(this))) {
               if (HeldItemOverride.testMinecraftClient(mc, this, SpearReachModule.checkCondition2())) {
                  setBooleanState5(this, true);
                  boolean booleanValue = false /* VF: Semaphore variable */;

                  try {
                     booleanValue = true;
                     AttackActions.testMinecraftClient(mc, "combat.attack.knockbackDisplace");
                     booleanValue = false;
                  } finally {
                     if (booleanValue) {
                        setBooleanState5(this, false);
                     }
                  }

                  setBooleanState5(this, false);
                  return true;
               }
            }
         }
      } else {
         ThreadLocalRandom.current().nextInt(7);
      }

      return false;
   }

   public static KnockbackDisplaceState getTURNING() {
      return KnockbackDisplaceState.TURNING;
   }

   public static float getFloatState5(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.floatState5;
   }

   private boolean testPlayerEntity3(PlayerEntity playerEntity2) {
      if (playerEntity2 != mc.player) {
         if (playerEntity2.isAlive()) {
            if (!playerEntity2.isRemoved()) {
               if (!FriendManager.testPlayerEntity(playerEntity2)) {
                  if (this.testPlayerEntity2(playerEntity2) && !mc.player.isUsingItem()) {
                     if (!MinecraftClientAccess40.getPlayer(mc).hasVehicle()) {
                        if (MinecraftClientAccess40.getInteractionManager(mc) != null) {
                           if (mc.interactionManager.getCurrentGameMode() != MinecraftClientAccess40.getSPECTATOR()) {
                              if (!getWeaponOnlySetting(this).isOn() || this.checkCondition2()) {
                                 return true;
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      return false;
   }

   @EventHandler
   private void onTick(TickEvent tickEvent) {
      boolean booleanState7;
      byte byteValue;
      label81: {
         MovementInputOverride.updateState(this);
         booleanState7 = this.checkCondition9();
         if (booleanState7) {
            if (!getBooleanState(this)) {
               byteValue = 1;
               break label81;
            }
         }

         byteValue = 0;
      }

      int byteValue2 = byteValue;
      setBooleanState(this, booleanState7);
      if (this.knockbackDisplaceState == KnockbackDisplaceState.IDLE) {
         if (byteValue2 != 0 && this.triggerSetting.equals("On Key")) {
            if (!this.isWorldUnavailable()) {
               if (MinecraftClientAccess40.getCurrentScreen(mc) == null) {
                  this.testPlayerEntity(this.computePlayerEntity());
               }
            }
         }
      } else {
         if (!this.isWorldUnavailable() && this.checkCondition11()) {
            this.counter++;
            int intState4 = getIntState(this);

            if ((this.intState = intState4 + 1) > 60) {
               byteValue = 9;
               ThreadLocalRandom.current().nextInt(6);
               this.updateState2();
            } else {
               switch (this.knockbackDisplaceState) {
                  case ARMED:
                     this.updateState10();
                     break;
                  case TURNING:
                     this.updateState4();
                     break;
                  case HOLD:
                     this.updateState3();

                     break;
                  default:
                     this.updateState8(true);
               }
            }
         } else {
            this.updateState8(true);
         }
      }
   }

   public static BooleanSetting getDamagingFallsSetting(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.damagingFallsSetting;
   }

   public static KnockbackDisplaceState getHOLD() {
      return KnockbackDisplaceState.HOLD;
   }

   private Float computeFloatForPlayerEntity(PlayerEntity playerEntity2) {
      if (playerEntity2 != null) {
         if (!playerEntity2.isRemoved()) {
            if (mc.player != null) {
               return this.computeFloatForPlayerEntity2(playerEntity2);
            }
         }
      }

      return null;
   }

   public static void setKnockbackDisplaceState(KnockbackDisplaceModule knockbackDisplaceModule2, KnockbackDisplaceState knockbackDisplaceState2) {
      knockbackDisplaceModule2.knockbackDisplaceState = knockbackDisplaceState2;
   }

   private void updateState12() {
      this.booleanState6 = false;

      this.doubleState = (3.0);
   }

   public static float getFloatState3(KnockbackDisplaceModule knockbackDisplaceModule2) {
      return knockbackDisplaceModule2.floatState3;
   }

   private void updateStateForSupplier2(Supplier supplier) {
      RotationManager.updateStateForActionPriority(this, ActionPriority.HIGH, supplier, this.rotationProfile);
      if (RotationManager.computeVec3d(this) != null) {
         RotationManager.updateState11(this, getFloatState7(this), getFloatState3(this));
      }
   }

   private static Float computeFloat4(float floatValue) {
      return floatValue;
   }

   @Override
   public boolean shouldBlockAttackInput() {
      if (!this.booleanState5) {
         ThreadLocalRandom.current().nextInt(6);
         if (!this.isWorldUnavailable()) {
            ThreadLocalRandom.current().nextInt(13);
            if (MinecraftClientAccess40.getCurrentScreen(mc) == null) {
               if (this.knockbackDisplaceState != KnockbackDisplaceState.IDLE) {
                  return true;
               }

               if (this.triggerSetting.equals("On Attack")) {
                  if (this.testPlayerEntity(this.computePlayerEntity())) {
                     return true;
                  }
               }

               return false;
            }

            ThreadLocalRandom.current().nextInt(6);
         }
      }

      return false;
   }

   @EventHandler
   private void onAfterMovement(MovementSendEvent.After after) {
      this.floatState7 = after.yaw();
      this.floatState3 = after.pitch();

      this.booleanState2 = true;
      if (this.knockbackDisplaceState != KnockbackDisplaceState.TURNING) {
         this.updateState7();
      }
   }

   private boolean checkCondition11() {
      if (mc.currentScreen == null) {
         if (getPlayerEntity(this) != null) {
            ThreadLocalRandom.current().nextInt(9);

            if (getPlayerEntity(this).isAlive()) {
               if (!this.playerEntity.isRemoved()) {
                  if (this.equals3() == (this.knockbackCandidate != null) && mc.world.getEntityById(getPlayerEntity(this).getId()) == getPlayerEntity(this) && !FriendManager.testPlayerEntity(this.playerEntity)) {
                     if (this.testPlayerEntity2(getPlayerEntity(this))) {
                        ThreadLocalRandom.current().nextInt(14);
                        if (!mc.player.isUsingItem()) {
                           if (!MinecraftClientAccess40.getPlayer(mc).hasVehicle()) {
                              if (this.knockbackDisplaceState == KnockbackDisplaceState.ARMED || RotationManager.computeVec3d(this) != null) {
                                 return true;
                              }
                           }
                        }
                     }
                  }
               } else {
                  ThreadLocalRandom.current().nextInt(7);
               }
            }
         } else {
            ThreadLocalRandom.current().nextInt(6);
         }
      }

      return false;
   }

   @Override
   public void onDisable() {
      this.updateState8(true);
   }

   public static void setIntState3(KnockbackDisplaceModule knockbackDisplaceModule2, int intState32) {
      knockbackDisplaceModule2.intState3 = intState32;
   }

   private float computeFloatForPlayerEntity2(PlayerEntity playerEntity2) {
      Vec3d eyePos = MinecraftClientAccess40.getPlayer(mc).getEyePos();
      Vec3d center = playerEntity2.getBoundingBox().getCenter();
      float floatValue = (float)Math.toDegrees(Math.atan2(MinecraftClientAccess40.getZ(center) - MinecraftClientAccess40.getZ(eyePos), center.x - MinecraftClientAccess40.getX(eyePos))) - (90.0F);
      return RotationMath.computeFloat(floatValue, this.floatState7);
   }

   private int computeInt2() {
      int intValue = 0;

      while (true) {
         if (intValue >= 20) {
            ThreadLocalRandom.current().nextInt(4);
            return 20;
         }

         float attackCooldownProgress = mc.player.getAttackCooldownProgress(0.5F + (float)intValue);

         if (attackCooldownProgress >= (1.0F)) {
            return intValue;
         }

         intValue++;
      }
   }

}
