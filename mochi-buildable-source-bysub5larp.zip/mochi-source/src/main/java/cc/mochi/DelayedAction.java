package cc.mochi;

public record DelayedAction(String key, long dueAtMs, Runnable action) {
   public long getDueAtMs() {
      return this.dueAtMs;
   }

   public static String getKey(DelayedAction delayedAction) {
      return delayedAction.key;
   }

   public String getKey2() {
      return getKey(this);
   }

   public Runnable getAction() {
      return this.action;
   }
}
