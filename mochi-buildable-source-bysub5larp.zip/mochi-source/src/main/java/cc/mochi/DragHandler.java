package cc.mochi;

public interface DragHandler {
   void drag(double doubleValue, double doubleValue2);

   default void release(double doubleValue, double doubleValue2) {
   }
}
