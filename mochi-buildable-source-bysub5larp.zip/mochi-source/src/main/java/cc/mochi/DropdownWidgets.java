package cc.mochi;

import java.awt.Color;
import java.util.List;

public final class DropdownWidgets {
   private static void updateStateForDropdownState(DropdownState dropdownState) {
      dropdownState.resetBooleanState();
      ClientSounds.updateState5();
   }

   private static void updateState(int intValue, double doubleValue, double doubleValue2) {
   }

   public static Rect computeRectForUiContext(UiContext uiContext, String string, DropdownState dropdownState, List list, Rect rect, float floatValue) {
      String string2 = string + "." + dropdownState.getLongState();
      float progress = uiContext.getAnimations().exponential(string2, 0.0F, dropdownState.getBooleanState() ? 1.0F : 0.0F, 0.04F);
      if (progress <= 0.01F && !dropdownState.getBooleanState()) {
         return null;
      } else {
         ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
         float floatState32 = dropdownState.getFloatState32();
         float floatValue2 = computeFloatForList(list);
         Rect rect2 = new Rect(dropdownState.getFloatState22(), dropdownState.getFloatState4(), floatState32, floatValue2).clampInside(rect.insetUniform(4.0F));
         float floatValue3 = floatValue * UiContext.clampUnit(progress * 1.4F);
         float scale = 0.94F + 0.06F * AnimatedFloat.outBack(progress);
         if (dropdownState.getBooleanState()) {
            uiContext.getInputRouter().addModalCatcher(UiLayer.POPOVER, () -> updateStateForDropdownState(dropdownState));
         }

         uiContext.getUiRenderContext().pushTransform();
         uiContext.getUiRenderContext().scaleAroundPoint(scale, rect2.getX() + Math.min(18.0F, rect2.getWidth() / 2.0F), rect2.getY());
         PanelRenderer.drawCard2(uiContext, rect2, floatValue3);
         if (dropdownState.getBooleanState()) {
            uiContext.getInputRouter().addPressRegion(rect2, UiLayer.POPOVER, (intValue, doubleValue, doubleValue2) -> updateState(intValue, doubleValue, doubleValue2));
         }

         float floatValue5 = rect2.getY() + 4.0F;
         boolean booleanValue = progress > 0.7F && dropdownState.getBooleanState();

         for (int intValue2 = 0; intValue2 < list.size(); intValue2++) {
            MenuAction menuAction = (MenuAction)list.get(intValue2);
            if (menuAction.checkCondition()) {
               PanelRenderer.updateStateForUiContext3(uiContext, rect2.getX() + 8.0F, floatValue5 + 3.0F, rect2.right() - 8.0F, floatValue3);
               floatValue5 += 7.0F;
            } else {
               Rect rect3 = new Rect(rect2.getX() + 4.0F, floatValue5, rect2.getWidth() - 8.0F, 20.0F);
               boolean booleanValue2 = menuAction.getAction2() != null;
               boolean hovered = booleanValue && booleanValue2 && uiContext.isHovered(rect3, UiLayer.POPOVER);
               float floatValue6 = uiContext.animateHover(string2 + ".row" + intValue2, hovered);
               if (menuAction.getTone2() == ControlTone.DANGER) {
                  uiContext.getUiRenderContext().fillRoundedRect(rect3.getX(), rect3.getY(), rect3.getWidth(), rect3.getHeight(), 6.0F, UiContext.multiplyAlpha(themeSnapshot2.getDanger(), 0.16F * floatValue6 * floatValue3));
               } else {
                  PanelRenderer.updateStateForUiContext4(uiContext, rect3, 6.0F, floatValue6, floatValue3);
               }

               float x = rect3.getX() + 7.0F;
               Color disabledText2 = menuAction.getTone2() == ControlTone.DANGER ? themeSnapshot2.getDanger() : UiContext.blendColors(themeSnapshot2.getPrimaryText(), themeSnapshot2.getAccentText2(), floatValue6 * 0.5F);
               if (!booleanValue2) {
                  disabledText2 = themeSnapshot2.getDisabledText2();
               }

               if (menuAction.getIcon() != null || menuAction.getChecked2()) {
                  UiShapeRenderer.updateStateForUiRenderContext3(uiContext.getUiRenderContext(), menuAction.getChecked2() ? Icon.CHECK : menuAction.getIcon(), x + 4.5F, rect3.centerY(), 9.0F, UiContext.multiplyAlpha(menuAction.getChecked2() ? themeSnapshot2.getAccent2() : disabledText2, floatValue3));
                  x += 15.0F;
               }

               uiContext.drawVerticallyCenteredText(uiContext.ellipsize(menuAction.getLabel2(), TextStyle.LABEL, rect3.right() - x - 30.0F), x, rect3.centerY(), TextStyle.LABEL, UiContext.multiplyAlpha(disabledText2, floatValue3));
               if (menuAction.getDetail() != null) {
                  uiContext.drawRightAlignedText(menuAction.getDetail(), rect3.right() - 7.0F, rect3.centerY(), TextStyle.CAPTION, UiContext.multiplyAlpha(themeSnapshot2.getDisabledText2(), floatValue3));
               }

               if (booleanValue && booleanValue2) {
                  uiContext.getInputRouter().addClickRegion(rect3, UiLayer.POPOVER, () -> updateStateForDropdownState2(dropdownState, menuAction));
               }

               floatValue5 += 20.0F;
            }
         }

         uiContext.getUiRenderContext().popTransform();
         return rect2;
      }
   }

   private DropdownWidgets() {
   }

   public static float computeFloatForList(List list) {
      float floatValue = 8.0F;

      for (MenuAction menuAction : (java.lang.Iterable<MenuAction>)(java.lang.Iterable<?>)(list)) {
         floatValue += menuAction.checkCondition() ? 7.0F : 20.0F;
      }

      return floatValue;
   }

   private static void updateStateForDropdownState2(DropdownState dropdownState, MenuAction menuAction) {
      dropdownState.resetBooleanState();
      if (menuAction.getTone2() == ControlTone.DANGER) {
         ClientSounds.updateState2();
      } else {
         ClientSounds.updateState4();
      }

      menuAction.getAction2().run();
   }
}
