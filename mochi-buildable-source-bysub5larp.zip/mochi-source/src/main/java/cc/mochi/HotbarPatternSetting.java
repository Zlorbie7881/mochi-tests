package cc.mochi;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.BooleanSupplier;
import java.util.function.Predicate;

public final class HotbarPatternSetting extends Setting {
   private Predicate<HotbarItemPattern> importFilter;

   private final List<HotbarItemPattern> slots = new ArrayList<>(Collections.nCopies(9, (HotbarItemPattern)null));

   private String importLabel;
   private BooleanSupplier allowTotemImport = () -> allowInitialImport();

   public void deserialize(String string) {
      this.clear();
      if (string != null) {
         ThreadLocalRandom.current().nextInt(4);
         if (!string.isEmpty()) {
            String[] stringArray = string.split(";", -1);

            int intValue = 0;

            while (true) {
               if (intValue < stringArray.length) {
                  getHotbarItemPatternList(this).set(intValue, parsePattern(stringArray[intValue]));
                  intValue++;

                  if (intValue < 9) {
                     continue;
                  }
                  break;
               }

               break;
            }

            return;
         }
      }
   }

   public void setPatterns(List list) {
      int intValue = 0;

      do {
         this.slots.set(intValue, list != null && intValue < list.size() ? (HotbarItemPattern)list.get(intValue) : null);
         intValue++;
      } while (intValue < 9);
   }

   public void setPredicate(Predicate importFilter2) {
      this.importFilter = importFilter2;
   }

   public void clear() {
      Collections.fill(this.slots, null);
   }

   public HotbarPatternSetting(String name) {
      super(name);
      this.importLabel = "Import";
   }

   public static Predicate<HotbarItemPattern> getPredicate(HotbarPatternSetting hotbarPatternSetting) {
      return hotbarPatternSetting.importFilter;
   }

   public static List<HotbarItemPattern> getHotbarItemPatternList(HotbarPatternSetting hotbarPatternSetting) {
      return hotbarPatternSetting.slots;
   }

   public String computeString() {
      StringBuilder stringBuilder = new StringBuilder();
      int intValue = 0;

      while (true) {
         HotbarItemPattern hotbarItemPattern = this.slots.get(intValue);
         if ((hotbarItemPattern != null)) {
            stringBuilder.append(hotbarItemPattern.getItem())
               .append("|")
               .append(hotbarItemPattern.getCount())
               .append("|")
               .append(hotbarItemPattern.getPotion())
               .append("|")
               .append(hotbarItemPattern.getEffects2())
               .append("|")
               .append(hotbarItemPattern.getColor2())
               .append("|")
               .append(hotbarItemPattern.getGlint2() ? 1 : 0);
         }

         intValue++;

         if (intValue >= 9) {
            ThreadLocalRandom.current().nextInt(5);

            return stringBuilder.toString();
         }

         if (intValue > 0) {
            stringBuilder.append(";");
         }
      }
   }

   public void setImportLabel(String string) {
      setString(this, string != null && !string.isBlank() ? string : "Import");
   }

   private static boolean allowInitialImport() {
      return true;
   }

   public boolean hasPatterns() {
      Iterator iterator = getHotbarItemPatternList(this).iterator();

      while (true) {
         if (!iterator.hasNext()) {
            ThreadLocalRandom.current().nextInt(12);
            return false;
         }

         HotbarItemPattern hotbarItemPattern = (HotbarItemPattern)iterator.next();
         if (hotbarItemPattern != null) {
            return true;
         }
      }
   }

   public boolean canImportSlot(int intValue) {
      HotbarItemPattern pattern = this.getPattern(intValue);
      if (pattern == null) {
         return false;
      } else if (getPredicate(this) != null) {
         return getPredicate(this).test(pattern);
      } else {
         label56: {
            String patternKey = pattern.buildPatternKey();
            int intValue2 = patternKey.indexOf(35);
            if (intValue2 > 0) {
               if (patternKey.substring(0, intValue2).endsWith("potion")) {
                  break label56;
               }
            }

            if (!"minecraft:totem_of_undying".equals(patternKey)) {
               return false;
            }

            if (!this.getAsBoolean()) {
               return false;
            }
         }

         return true;
      }
   }

   public boolean getAsBoolean() {
      return this.allowTotemImport.getAsBoolean();
   }

   @Override
   public boolean isDefault() {
      return (!this.hasPatterns());
   }

   private static boolean allowDefaultImport() {
      return true;
   }

   public static void setString(HotbarPatternSetting hotbarPatternSetting, String importLabel2) {
      hotbarPatternSetting.importLabel = importLabel2;
   }

   public void setTotemImportCondition(BooleanSupplier booleanSupplier) {
      this.allowTotemImport = booleanSupplier != null ? booleanSupplier : () -> allowDefaultImport();
   }

   public String getPatternKey(int intValue) {
      HotbarItemPattern pattern = this.getPattern(intValue);
      if (pattern == null) {
         return "";
      } else {
         return pattern.buildPatternKey();
      }
   }

   public static String buildPatternKey(String string, String string2, String string3) {
      if (string != null) {
         if (!string.isEmpty()) {
            if (string3 != null) {
               if (!string3.isEmpty()) {
                  return string + "#" + string3;
               }
            }

            if (string2 != null) {
               if (!string2.isEmpty()) {
                  return string + "#base:" + string2;
               }
            }

            return string;
         }
      }

      return "";
   }

   public String getString() {
      return this.importLabel;
   }

   @Override
   public void reset() {
      this.clear();
   }

   private static HotbarItemPattern parsePattern(String string) {
      if (string != null) {
         if (!string.isEmpty()) {
            String[] stringArray = string.split("\\|", -1);
            if (stringArray.length == 6) {
               if (!stringArray[0].isEmpty()) {
                  try {
                     String string2 = stringArray[0];

                     int intValue = Integer.parseInt(stringArray[1]);

                     String string3 = stringArray[2];
                     String string4 = stringArray[3];

                     return new HotbarItemPattern(string2, intValue, string3, string4, Integer.parseInt(stringArray[4]), "1".equals(stringArray[5]));
                  } catch (NumberFormatException failure) {
                     return null;
                  }
               }
            }

            return null;
         }
      }

      return null;
   }

   public HotbarItemPattern getPattern(int intValue) {
      if (intValue >= 0) {
         if (intValue < 9) {
            return getHotbarItemPatternList(this).get(intValue);
         }
      }

      return null;
   }
}
