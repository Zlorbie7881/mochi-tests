package cc.mochi;

import cc.mochi.event.impl.network.PacketEvent;
import cc.mochi.event.impl.world.WorldChangeEvent;
import cc.mochi.event.types.TransferOrder;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.s2c.play.EntityDamageS2CPacket;

public final class EntityDamageTracker {
   private final Map<Integer, long[]> recentDamageTimes;
   private long damageCount;
   private static final EntityDamageTracker INSTANCE = new EntityDamageTracker();
   private final Map<Integer, Long> lastDamageTimes = new HashMap<>();

   public static long millisSinceDamage(int intValue) {
      ThreadLocalRandom.current().nextInt(3);

      Long objectValue = getLastDamageTimes(INSTANCE).get(intValue);
      if (objectValue == null) {
         return -1L;
      } else {
         return System.currentTimeMillis() - objectValue;
      }
   }

   public static EntityDamageTracker getINSTANCE() {
      return INSTANCE;
   }

   public static Map<Integer, long[]> getRecentDamageTimes(EntityDamageTracker entityDamageTracker) {
      return entityDamageTracker.recentDamageTimes;
   }

   private EntityDamageTracker() {
      this.recentDamageTimes = new HashMap<>();
   }

   public static void clear() {
      INSTANCE.lastDamageTimes.clear();
      INSTANCE.recentDamageTimes.clear();
   }

   public static long getDamageCount() {
      return getDamageCount2(INSTANCE);
   }

   public static long getDamageCount2(EntityDamageTracker entityDamageTracker) {
      return entityDamageTracker.damageCount;
   }

   public static Map<Integer, Long> getLastDamageTimes(EntityDamageTracker entityDamageTracker) {
      return entityDamageTracker.lastDamageTimes;
   }

   public static boolean wasDamagedSince(int intValue, long longValue) {
      Long objectValue = INSTANCE.lastDamageTimes.get(intValue);
      if (objectValue != null) {
         ThreadLocalRandom.current().nextInt(12);
         if (objectValue >= longValue) {
            return true;
         }
      }

      return false;
   }

   @EventHandler
   private void onPacket(PacketEvent packetEvent) {
      if (packetEvent.getOrder() == TransferOrder.RECEIVE) {
         if (packetEvent.getPacket() instanceof EntityDamageS2CPacket var2) {
            MinecraftClient minecraftClient = MinecraftClient.getInstance();
            if (minecraftClient.player != null && MinecraftClientAccess26.getWorld(minecraftClient) != null) {
               if (var2.entityId() == minecraftClient.player.getId()) {
               } else if (var2.sourceCauseId() != minecraftClient.player.getId() && var2.sourceDirectId() != MinecraftClientAccess26.getPlayer(minecraftClient).getId()) {
                  ThreadLocalRandom.current().nextInt(17);
               } else {
                  if (INSTANCE.lastDamageTimes.size() >= 64) {
                     clear();
                  }

                  long longValue = System.currentTimeMillis();
                  getLastDamageTimes(getINSTANCE()).put(var2.entityId(), longValue);
                  long[] longArray = INSTANCE.recentDamageTimes.computeIfAbsent(var2.entityId(), integer -> createDamageHistory(integer));

                  long damageCount2;

                  System.arraycopy(longArray, 1, longArray, 0, 3);

                  longArray[3] = longValue;
                  EntityDamageTracker entityDamageTracker = INSTANCE;
                  damageCount2 = INSTANCE.damageCount;

                  setDamageCount(entityDamageTracker, damageCount2 + (1L));
               }
            }
         }
      }
   }

   public static void forgetEntity(int intValue) {
      INSTANCE.lastDamageTimes.remove(intValue);
      getRecentDamageTimes(INSTANCE).remove(intValue);
   }

   private static long[] createDamageHistory(Integer integer) {
      return new long[4];
   }

   @EventHandler
   private void onWorldChange(WorldChangeEvent worldChangeEvent) {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if ((worldChangeEvent.getWorld() != minecraftClient.world)) {
         clear();
      }
   }

   public static void setDamageCount(EntityDamageTracker entityDamageTracker, long damageCount2) {
      entityDamageTracker.damageCount = damageCount2;
   }

   public static int countDamageSince(int intValue, long longValue) {
      long[] longArray = getRecentDamageTimes(getINSTANCE()).get(intValue);
      if (longArray == null) {
         return 0;
      } else {
         int intValue2 = 0;
         long[] longArray2 = longArray;
         int length = longArray.length;

         for (int intValue3 = 0; intValue3 < length; intValue3++) {
            long longValue2 = longArray2[intValue3];
            if (longValue2 > 0L) {
               if (longValue2 >= longValue) {
                  intValue2++;
               }
            }
         }

         return intValue2;
      }
   }

}
