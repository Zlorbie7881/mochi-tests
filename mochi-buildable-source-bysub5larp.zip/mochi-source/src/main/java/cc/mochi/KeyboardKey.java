package cc.mochi;

public record KeyboardKey(int code, String label, float units, boolean spacer) {
   public int getCode() {
      return this.code;
   }

   public String getLabel() {
      return this.label;
   }

   public boolean getSpacer2() {
      return getSpacer(this);
   }

   public static boolean getSpacer(KeyboardKey keyboardKey) {
      return keyboardKey.spacer;
   }

   public float getUnits() {
      return this.units;
   }
}
