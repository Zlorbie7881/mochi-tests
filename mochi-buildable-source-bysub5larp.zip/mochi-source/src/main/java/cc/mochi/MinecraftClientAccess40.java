package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerAbilities;
import net.minecraft.item.Item;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.GameMode;

public class MinecraftClientAccess40 {
   public static double getZ(Vec3d vec3d) {
      return vec3d.z;
   }

   public static RegistryKey<Enchantment> getKNOCKBACK() {
      return Enchantments.KNOCKBACK;
   }

   public static Type getENTITY() {
      return Type.ENTITY;
   }

   public static CombatActionOwner getKNOCKBACK3() {
      return CombatActionOwner.KNOCKBACK;
   }

   public static boolean getInvulnerable(PlayerAbilities playerAbilities) {
      return playerAbilities.invulnerable;
   }

   public static Boolean getTRUE() {
      return Boolean.TRUE;
   }

   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static double getX(Vec3d vec3d) {
      return vec3d.x;
   }

   public static Screen getCurrentScreen(MinecraftClient minecraftClient) {
      return minecraftClient.currentScreen;
   }

   public static TagKey<Item> getAXES() {
      return ItemTags.AXES;
   }

   public static ActionPriority getHIGH() {
      return ActionPriority.HIGH;
   }

   public static TagKey<Item> getSWORDS() {
      return ItemTags.SWORDS;
   }

   public static RegistryEntry<StatusEffect> getLEVITATION() {
      return StatusEffects.LEVITATION;
   }

   public static RegistryEntry<StatusEffect> getSLOW_FALLING() {
      return StatusEffects.SLOW_FALLING;
   }

   public static boolean getAllowFlying(PlayerAbilities playerAbilities) {
      return playerAbilities.allowFlying;
   }

   public static ClientPlayerInteractionManager getInteractionManager(MinecraftClient minecraftClient) {
      return minecraftClient.interactionManager;
   }

   public static GameMode getSPECTATOR() {
      return GameMode.SPECTATOR;
   }

   public static RegistryEntry<EntityAttribute> getATTACK_KNOCKBACK() {
      return EntityAttributes.ATTACK_KNOCKBACK;
   }

}
