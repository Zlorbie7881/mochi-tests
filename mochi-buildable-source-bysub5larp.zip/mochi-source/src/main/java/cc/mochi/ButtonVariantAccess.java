package cc.mochi;

public class ButtonVariantAccess {
   public static ButtonVariant getSECONDARY() {
      return ButtonVariant.SECONDARY;
   }

   public static ButtonVariant getGHOST() {
      return ButtonVariant.GHOST;
   }
}
