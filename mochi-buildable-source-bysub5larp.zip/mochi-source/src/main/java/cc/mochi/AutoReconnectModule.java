package cc.mochi;

import cc.mochi.event.impl.network.DisconnectEvent;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;

public class AutoReconnectModule extends Module {
   private final BooleanSetting notifySetting;

   private final DoubleSetting delaySSetting;
   private volatile boolean booleanState;

   public static BooleanSetting getNotifySetting(AutoReconnectModule autoReconnectModule) {
      return autoReconnectModule.notifySetting;
   }

   @EventHandler
   private void onDisconnect(DisconnectEvent disconnectEvent) {
      if (!this.booleanState) {
         ServerInfo currentServerEntry = mc.getCurrentServerEntry();
         if (currentServerEntry != null) {
            if (!currentServerEntry.isLocal()) {
               this.booleanState = true;
               double value = this.delaySSetting.getValue();

               long longValue = (long)(value * (1000.0));
               Thread thread = new Thread(() -> this.updateStateForServerInfo2(longValue, currentServerEntry), ClientText.RECONNECT_THREAD.toString());

               thread.setDaemon(true);
               thread.start();
               return;
            }
         } else {
            ThreadLocalRandom.current().nextInt(5);
         }
      }
   }

   public static void setBooleanState(AutoReconnectModule autoReconnectModule, boolean booleanState2) {
      autoReconnectModule.booleanState = booleanState2;
   }

   private void updateStateForServerInfo(ServerInfo serverInfo) {
      setBooleanState(this, false);
      if (this.isEnabled()) {
         if (mc.world == null) {
            if (getNotifySetting(this).getValue()) {
               String address = serverInfo.address;
               ChatMessages.updateState6("Reconnecting to " + address + "...");
            }

            Screen currentScreen = MinecraftClientAccess16.getCurrentScreen(mc);
            MinecraftClient mc2 = mc;
            ServerAddress serverAddress = ServerAddress.parse(MinecraftClientAccess16.getAddress(serverInfo));

            ConnectScreen.connect(currentScreen, mc2, serverAddress, serverInfo, false, null);
            return;
         }
      }
   }

   private void updateStateForServerInfo2(long longValue, ServerInfo serverInfo) {
      try {
         Thread.sleep(longValue);
      } catch (InterruptedException failure) {
         Thread.currentThread().interrupt();
         setBooleanState(this, false);
         return;
      }

      mc.execute(() -> this.updateStateForServerInfo(serverInfo));
   }

   @Override
   public void onDisable() {
      this.booleanState = false;
   }

   public AutoReconnectModule() {
      super("Auto Reconnect", "Reconnects to the last server after being disconnected.", ModuleCategory.PLAYER);

      this.delaySSetting = new DoubleSetting("Delay (s)", 1.0, (60.0), (5.0), (1.0));
      this.notifySetting = new BooleanSetting("Notify", true);

      Setting[] settingArray = new Setting[2];

      settingArray[0] = this.delaySSetting;
      settingArray[1] = this.notifySetting;
      this.addSettings(settingArray);
   }
}
