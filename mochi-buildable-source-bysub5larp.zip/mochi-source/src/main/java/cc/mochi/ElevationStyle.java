package cc.mochi;

public enum ElevationStyle {
   FLAT(0.0F, 0.0F, 0.0F),
   LOW(10.0F, 2.0F, 0.35F),
   MID(22.0F, 6.0F, 0.45F),
   HIGH(40.0F, 14.0F, 0.6F);

   private static final ElevationStyle[] ENUM_VALUES = {FLAT, LOW, MID, HIGH};

   public final float opacity;

   public final float blur;
   public final float offsetY;

   private static ElevationStyle[] createValues() {
      return new ElevationStyle[]{FLAT, LOW, MID, HIGH};
   }

   public static ElevationStyle[] getENUM_VALUES() {
      return ENUM_VALUES;
   }

   private ElevationStyle(float blur2, float offsetY2, float opacity2) {
      this.blur = blur2;
      this.offsetY = offsetY2;
      this.opacity = opacity2;
   }
}
