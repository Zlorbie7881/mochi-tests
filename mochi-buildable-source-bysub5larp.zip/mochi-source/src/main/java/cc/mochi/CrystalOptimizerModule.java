package cc.mochi;

import cc.mochi.event.impl.player.DoAttackEvent;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult.Type;

public final class CrystalOptimizerModule extends Module {
   public CrystalOptimizerModule() {
      super("Crystal Optimizer", "Makes crystals disappear faster client-side for quicker placement.", -1, ModuleCategory.COMBAT);
   }

   @EventHandler
   private void onAttackEvent(DoAttackEvent doAttackEvent) {
      if (this.isWorldUnavailable()) {
      } else if (CrystalRemovalAccess.getCrosshairTarget(mc) != null) {
         if (mc.crosshairTarget.getType() != Type.ENTITY) {
            ThreadLocalRandom.current().nextInt(5);
         } else if (mc.crosshairTarget instanceof EntityHitResult var2) {
            Entity entity = var2.getEntity();
            if (entity instanceof EndCrystalEntity) {
               EndCrystalEntity entity2;
               byte byteValue;
               label85: {
                  entity2 = (EndCrystalEntity)entity;
                  StatusEffectInstance statusEffect = mc.player.getStatusEffect(StatusEffects.WEAKNESS);
                  StatusEffectInstance statusEffect2 = CrystalRemovalAccess.getPlayer(mc).getStatusEffect(CrystalRemovalAccess.getSTRENGTH());
                  ItemStack mainHandStack = mc.player.getMainHandStack();
                  if (statusEffect != null) {
                     if (statusEffect2 != null && statusEffect2.getAmplifier() > statusEffect.getAmplifier()) {
                        byteValue = 10;
                        ThreadLocalRandom.current().nextInt(8);
                     } else if (!mainHandStack.isIn(ItemTags.PICKAXES)) {
                        if (!mainHandStack.isIn(ItemTags.AXES)) {
                           if (!mainHandStack.isIn(CrystalRemovalAccess.getSHOVELS())) {
                              if (!mainHandStack.isIn(CrystalRemovalAccess.getHOES())) {
                                 if (!mainHandStack.isIn(ItemTags.SWORDS)) {
                                    byteValue = 0;
                                    break label85;
                                 }
                              } else {
                                 byteValue = 12;
                                 ThreadLocalRandom.current().nextInt(11);
                              }
                           }
                        }
                     }
                  }

                  byteValue = 1;
               }

               byte byteValue2 = byteValue;
               if (byteValue2 != 0) {
                  entity2.setRemoved(CrystalRemovalAccess.getKILLED());
                  entity2.onRemoved();
               }
            }
         }
      }
   }
}
