package cc.mochi;

import cc.mochi.event.types.TransferOrder;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

public class MinecraftClientAccess48 {
   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static ClientWorld getWorld(MinecraftClient minecraftClient) {
      return minecraftClient.world;
   }

   public static BooleanSetting getAutoOpenGUISetting() {
      return HoverTotemModule.autoOpenGUISetting;
   }

   public static Screen getCurrentScreen(MinecraftClient minecraftClient) {
      return minecraftClient.currentScreen;
   }

   public static int getSyncId(ScreenHandler screenHandler) {
      return screenHandler.syncId;
   }

   public static ClientPlayerInteractionManager getInteractionManager(MinecraftClient minecraftClient) {
      return minecraftClient.interactionManager;
   }

   public static BooleanSetting getIgnoreOffhandSetting() {
      return HoverTotemModule.ignoreOffhandSetting;
   }

   public static TransferOrder getSEND() {
      return TransferOrder.SEND;
   }

   public static SlotActionType getQUICK_MOVE() {
      return SlotActionType.QUICK_MOVE;
   }

   public static SlotActionType getSWAP() {
      return SlotActionType.SWAP;
   }

   public static Item getTOTEM_OF_UNDYING() {
      return Items.TOTEM_OF_UNDYING;
   }

   public static TransferOrder getRECEIVE() {
      return TransferOrder.RECEIVE;
   }
}
