package cc.mochi;

public final class ClickGuiOverlayScreen extends ClickGuiScreen {
}
