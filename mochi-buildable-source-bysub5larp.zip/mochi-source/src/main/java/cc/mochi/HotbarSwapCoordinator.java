package cc.mochi;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;

public final class HotbarSwapCoordinator implements MinecraftAccess {
   private static Object object;

   private static int intState;

   private static ItemStack itemStack;
   private static long deadlineNanos;

   private static int intState2;
   private static float floatState;
   private static int age;
   private static ClientPlayerEntity clientPlayerEntity;
   private static float handEquippingProgress;

   private static ClientWorld clientWorld;

   private static boolean booleanState;
   private static ItemStack itemStack2;
   private static long deadlineNanos2;

   private static ClientPlayerEntity clientPlayerEntity2;

   public static int computeIntForPlayerInventory(PlayerInventory playerInventory, int intValue) {
      return clientPlayerEntity2 != null && playerInventory == clientPlayerEntity2.getInventory() && checkCondition() ? intState : intValue;
   }

   public static void updateState(Object objectValue) {
      if (object == objectValue) {
         object = null;
         clientPlayerEntity2 = null;
         clientWorld = null;
         itemStack = null;
         booleanState = false;
      }
   }

   public static void updateStateForClientPlayerEntity(Object object2, ClientPlayerEntity clientPlayerEntity3, ClientWorld clientWorld2, int intValue) {
      if (object2 != null && clientPlayerEntity3 != null && clientWorld2 != null && intValue >= 0 && intValue <= 8) {
         if (object == null || object == object2 || !checkCondition()) {
            object = object2;
            clientPlayerEntity2 = clientPlayerEntity3;
            clientWorld = clientWorld2;
            itemStack = clientPlayerEntity3.getInventory().getStack(intValue);
            intState2 = intValue;
            intState = intValue;
            booleanState = false;
            if (clientPlayerEntity != clientPlayerEntity3 || itemStack2 != itemStack) {
               clientPlayerEntity = clientPlayerEntity3;
               itemStack2 = itemStack;
               handEquippingProgress = clientPlayerEntity3.getHandEquippingProgress(0.0F);
               floatState = Math.max(1.0F, clientPlayerEntity3.getAttackCooldownProgressPerTick());
               age = clientPlayerEntity3.age;
            }

            deadlineNanos = System.nanoTime() + 3000000000L;
         }
      }
   }

   private HotbarSwapCoordinator() {
   }

   private static void updateState2() {
      clientPlayerEntity = null;
      itemStack2 = null;
   }

   public static ItemStack computeItemStackForLivingEntity(LivingEntity livingEntity, ItemStack itemStack3) {
      return livingEntity == clientPlayerEntity2 && checkCondition() ? itemStack : itemStack3;
   }

   public static void updateState3(Object objectValue, int intState22) {
      if (object == objectValue && intState22 >= 0 && intState22 < 9) {
         intState2 = intState22;
      }
   }

   public static float computeFloatForClientPlayerEntity(ClientPlayerEntity clientPlayerEntity3, float floatValue, float floatValue2) {
      if (clientPlayerEntity == null || clientPlayerEntity3 != clientPlayerEntity) {
         return floatValue2;
      } else if (mc.player == clientPlayerEntity3 && clientPlayerEntity3.isAlive()) {
         float floatValue3 = MathHelper.clamp(handEquippingProgress + ((float)(clientPlayerEntity3.age - age) + floatValue) / floatState, 0.0F, 1.0F);
         if (checkCondition()) {
            deadlineNanos = System.nanoTime() + 3000000000L;
            return floatValue3;
         } else {
            ItemStack mainHandStack = clientPlayerEntity3.getMainHandStack();
            if ((mainHandStack == itemStack2 || ItemStack.areEqual(mainHandStack, itemStack2)) && !(floatValue2 >= floatValue3) && System.nanoTime() < deadlineNanos) {
               return floatValue3;
            } else {
               updateState2();
               return floatValue2;
            }
         }
      } else {
         updateState2();
         return floatValue2;
      }
   }

   public static void updateState4(Object objectValue) {
      if (object == objectValue) {
         booleanState = true;
         deadlineNanos2 = System.nanoTime() + 1000000000L;
         deadlineNanos = System.nanoTime() + 3000000000L;
         if (mc.player != clientPlayerEntity2 || mc.world != clientWorld || clientPlayerEntity2.getInventory().getSelectedSlot() == intState) {
            updateState(objectValue);
         }
      }
   }

   public static ItemStack computeItemStackForPlayerInventory(PlayerInventory playerInventory, ItemStack itemStack3) {
      return clientPlayerEntity2 != null && playerInventory == clientPlayerEntity2.getInventory() && checkCondition() ? itemStack : itemStack3;
   }

   private static boolean checkCondition() {
      if (object == null) {
         return false;
      } else if (mc.player == clientPlayerEntity2 && mc.world == clientWorld && clientPlayerEntity2.isAlive() && (!booleanState || System.nanoTime() < deadlineNanos2 && clientPlayerEntity2.getInventory().getSelectedSlot() != intState)) {
         return mc.currentScreen == null && clientPlayerEntity2.getInventory().getSelectedSlot() == intState2;
      } else {
         updateState(object);
         return false;
      }
   }
}
