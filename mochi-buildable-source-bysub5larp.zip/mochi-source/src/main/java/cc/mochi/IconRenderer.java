package cc.mochi;

import java.awt.Color;

public final class IconRenderer {
   public static void drawTextureFromResource15(UiRenderContext uiRenderContext, float floatValue, float floatValue2, float floatValue3, Color color) {
      drawTextureFromResource(uiRenderContext, "plus", floatValue, floatValue2, floatValue3, color);
   }

   public static void drawTextureFromResource16(UiRenderContext uiRenderContext, float floatValue, float floatValue2, float floatValue3, Color color) {
      drawTextureFromResource(uiRenderContext, "folder", floatValue, floatValue2, floatValue3, color);
   }

   public static void drawTextureFromResource17(UiRenderContext uiRenderContext, float floatValue, float floatValue2, float floatValue3, Color color) {
      drawTextureFromResource(uiRenderContext, "x", floatValue, floatValue2, floatValue3, color);
   }

   private IconRenderer() {
   }

   private static void drawTextureFromResource(UiRenderContext uiRenderContext, String string, float floatValue, float floatValue2, float floatValue3, Color color) {
      uiRenderContext.drawTextureFromResource("assets/mochi/textures/icons/lucide/" + string + ".png", floatValue - floatValue3 / 2.0F, floatValue2 - floatValue3 / 2.0F, floatValue3, floatValue3, color);
   }

   public static int[] getIntArray() {
      return ModuleCategorySwitchMap.intArray;
   }

   public static void drawTextureFromResource2(UiRenderContext uiRenderContext, float floatValue, float floatValue2, float floatValue3, Color color, boolean booleanValue) {
      drawTextureFromResource(uiRenderContext, booleanValue ? "chevron-down" : "chevron-up", floatValue, floatValue2, floatValue3, color);
   }

   public static void drawTextureFromResource3(UiRenderContext uiRenderContext, float floatValue, float floatValue2, float floatValue3, Color color) {
      drawTextureFromResource(uiRenderContext, "layout-dashboard", floatValue, floatValue2, floatValue3, color);
   }

   public static void drawTextureFromResource4(UiRenderContext uiRenderContext, float floatValue, float floatValue2, float floatValue3, Color color) {
      drawTextureFromResource(uiRenderContext, "wrench", floatValue, floatValue2, floatValue3, color);
   }

   public static void drawTextureFromResource5(UiRenderContext uiRenderContext, float floatValue, float floatValue2, float floatValue3, Color color) {
      drawTextureFromResource(uiRenderContext, "settings-2", floatValue, floatValue2, floatValue3, color);
   }

   public static void drawTextureFromResource6(UiRenderContext uiRenderContext, float floatValue, float floatValue2, float floatValue3, Color color) {
      drawTextureFromResource(uiRenderContext, "trash", floatValue, floatValue2, floatValue3, color);
   }

   public static void drawTextureFromResource7(UiRenderContext uiRenderContext, float floatValue, float floatValue2, float floatValue3, Color color) {
      drawTextureFromResource(uiRenderContext, "bolt", floatValue, floatValue2, floatValue3, color);
   }

   public static FontFace getMEDIUM() {
      return FontFace.MEDIUM;
   }

   public static void updateStateForUiRenderContext(UiRenderContext uiRenderContext, ModuleCategory moduleCategory, float floatValue, float floatValue2, float floatValue3, Color color) {
      String string;
      switch (getIntArray()[moduleCategory.ordinal()]) {
         case 1:
            string = "assets/mochi/textures/icons/sword.png";
            break;
         case 2:
            string = "assets/mochi/textures/icons/accessibility.png";
            break;
         case 3:
            string = "assets/mochi/textures/icons/user.png";
            break;
         case 4:
            string = "assets/mochi/textures/icons/eye.png";
            break;
         case 5:
            string = "assets/mochi/textures/icons/computer.png";
            break;
         case 6:
            string = "assets/mochi/textures/icons/lucide/sliders-horizontal.png";
            break;
         case 7:
            string = "assets/mochi/textures/icons/lucide/folder.png";
            break;
         default:
            throw new MatchException(null, null);
      }

      String string2 = string;
      uiRenderContext.drawTextureFromResource(string2, floatValue - floatValue3 / 2.0F, floatValue2 - floatValue3 / 2.0F, floatValue3, floatValue3, color);
   }

   public static void drawTextureFromResource8(UiRenderContext uiRenderContext, float floatValue, float floatValue2, float floatValue3, Color color) {
      drawTextureFromResource(uiRenderContext, "palette", floatValue, floatValue2, floatValue3, color);
   }

   public static void drawTextureFromResource9(UiRenderContext uiRenderContext, float floatValue, float floatValue2, float floatValue3, Color color) {
      drawTextureFromResource(uiRenderContext, "copy", floatValue, floatValue2, floatValue3, color);
   }

   public static void drawTextureFromResource10(UiRenderContext uiRenderContext, float floatValue, float floatValue2, float floatValue3, Color color) {
      drawTextureFromResource(uiRenderContext, "mouse", floatValue, floatValue2, floatValue3, color);
   }

   public static void drawTextureFromResource11(UiRenderContext uiRenderContext, float floatValue, float floatValue2, float floatValue3, Color color) {
      drawTextureFromResource(uiRenderContext, "keyboard", floatValue, floatValue2, floatValue3, color);
   }

   public static void drawTextureFromResource12(UiRenderContext uiRenderContext, float floatValue, float floatValue2, float floatValue3, Color color) {
      drawTextureFromResource(uiRenderContext, "search", floatValue, floatValue2, floatValue3, color);
   }

   public static void drawTextureFromResource13(UiRenderContext uiRenderContext, float floatValue, float floatValue2, float floatValue3, Color color) {
      drawTextureFromResource(uiRenderContext, "sliders-horizontal", floatValue, floatValue2, floatValue3, color);
   }

   public static void drawTextureFromResource14(UiRenderContext uiRenderContext, float floatValue, float floatValue2, float floatValue3, Color color) {
      drawTextureFromResource(uiRenderContext, "key-round", floatValue, floatValue2, floatValue3, color);
   }
}
