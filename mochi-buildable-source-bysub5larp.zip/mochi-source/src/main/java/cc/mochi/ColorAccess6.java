package cc.mochi;

import java.awt.Color;

public class ColorAccess6 {
   public static Color createColor(Color color, Color color2, double doubleValue, double doubleValue2, double doubleValue3, double doubleValue4) {
      return new Color(
         (float)(((double)color.getRed() + (double)(color2.getRed() - color.getRed()) * doubleValue) / 255.0),
         (float)(((double)color.getGreen() + (double)(color2.getGreen() - color.getGreen()) * doubleValue2) / 255.0),
         (float)(((double)color.getBlue() + (double)(color2.getBlue() - color.getBlue()) * doubleValue3) / 255.0),
         (float)(((double)color.getAlpha() + (double)(color2.getAlpha() - color.getAlpha()) * doubleValue4) / 255.0)
      );
   }

   public static Color createColor2(Color color, Color color2, double doubleValue) {
      return createColor(color, color2, doubleValue, doubleValue, doubleValue, doubleValue);
   }
}
