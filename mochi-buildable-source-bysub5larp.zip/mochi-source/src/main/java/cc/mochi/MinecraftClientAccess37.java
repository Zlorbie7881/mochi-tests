package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.registry.tag.TagKey;

public class MinecraftClientAccess37 {
   public static GameOptions getOptions(MinecraftClient minecraftClient) {
      return minecraftClient.options;
   }

   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static TagKey<Item> getSWORDS() {
      return ItemTags.SWORDS;
   }

   public static Item getTOTEM_OF_UNDYING() {
      return Items.TOTEM_OF_UNDYING;
   }

   public static KeyBinding getAttackKey(GameOptions gameOptions) {
      return gameOptions.attackKey;
   }

}
