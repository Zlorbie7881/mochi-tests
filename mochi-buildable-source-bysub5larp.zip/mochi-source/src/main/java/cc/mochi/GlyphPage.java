package cc.mochi;

import it.unimi.dsi.fastutil.chars.Char2ObjectArrayMap;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;

class GlyphPage {
   boolean booleanState;
   final int intState;
   final char charState;
   private final Char2ObjectArrayMap<Glyph> char2ObjectArrayMap = new Char2ObjectArrayMap();
   int width;

   int height;
   final char charState2;

   final Font[] fontArray;
   final Identifier identifier;

   public void updateState() {
      if (!this.booleanState) {
         int intValue = this.charState - this.charState2 - 1;
         int intValue2 = (int)(Math.ceil(Math.sqrt((double)intValue)) * 1.5);
         this.char2ObjectArrayMap.clear();
         int intValue3 = 0;
         int intValue4 = 0;
         int intValue5 = 0;
         int intValue6 = 0;
         int intValue7 = 0;
         int intValue8 = 0;
         int intValue9 = 0;
         ArrayList arrayList = new ArrayList();
         AffineTransform affineTransform = new AffineTransform();

         for (FontRenderContext fontRenderContext = new FontRenderContext(affineTransform, true, false); intValue3 <= intValue; intValue4++) {
            char charValue = (char)(this.charState2 + intValue3);
            Font font = this.computeFont(charValue);
            Rectangle2D stringBounds = font.getStringBounds(String.valueOf(charValue), fontRenderContext);
            int intValue10 = (int)Math.ceil(stringBounds.getWidth());
            int intValue11 = (int)Math.ceil(stringBounds.getHeight());
            intValue3++;
            intValue5 = Math.max(intValue5, intValue7 + intValue10);
            intValue6 = Math.max(intValue6, intValue8 + intValue11);
            if (intValue4 >= intValue2) {
               intValue7 = 0;
               intValue8 += intValue9 + this.intState;
               intValue4 = 0;
               intValue9 = 0;
            }

            intValue9 = Math.max(intValue9, intValue11);
            arrayList.add(new Glyph(intValue7, intValue8, intValue10, intValue11, charValue, this));
            intValue7 += intValue10 + this.intState;
         }

         BufferedImage bufferedImage = new BufferedImage(Math.max(intValue5 + this.intState, 1), Math.max(intValue6 + this.intState, 1), 2);
         this.width = bufferedImage.getWidth();
         this.height = bufferedImage.getHeight();
         Graphics2D graphics = bufferedImage.createGraphics();
         graphics.setColor(new Color(255, 255, 255, 0));
         graphics.fillRect(0, 0, this.width, this.height);
         graphics.setColor(Color.WHITE);
         graphics.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
         graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
         graphics.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

         for (Glyph glyph : (java.lang.Iterable<Glyph>)(java.lang.Iterable<?>)(arrayList)) {
            graphics.setFont(this.computeFont(glyph.getValue()));
            FontMetrics fontMetrics = graphics.getFontMetrics();
            graphics.drawString(String.valueOf(glyph.getValue()), glyph.getU(), glyph.getV() + fontMetrics.getAscent());
            this.char2ObjectArrayMap.put(glyph.getValue(), glyph);
         }

         ClientRenderHelpers.updateStateForIdentifier(this.identifier, bufferedImage);
         this.booleanState = true;
      }
   }

   public void updateState2() {
      MinecraftClient.getInstance().getTextureManager().destroyTexture(this.identifier);
      this.char2ObjectArrayMap.clear();
      this.width = -1;
      this.height = -1;
      this.booleanState = false;
   }

   private Font computeFont(char charValue) {
      for (Font font : this.fontArray) {
         if (font.canDisplay(charValue)) {
            return font;
         }
      }

      return this.fontArray[0];
   }

   public boolean checkCondition(char charValue) {
      return charValue >= this.charState2 && charValue < this.charState;
   }

   public GlyphPage(char charState22, char charState3, Font[] fontArray2, Identifier identifier2, int intState2) {
      this.booleanState = false;
      this.charState2 = charState22;
      this.charState = charState3;
      this.fontArray = fontArray2;
      this.identifier = identifier2;
      this.intState = intState2;
   }

   public Glyph computeGlyph(char charValue) {
      if (!this.booleanState) {
         this.updateState();
      }

      return (Glyph)this.char2ObjectArrayMap.get(charValue);
   }
}
