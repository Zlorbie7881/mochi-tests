package cc.mochi;

import cc.mochi.event.impl.render.Render2DEvent;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;

public class ArmorModule extends Module implements HudElement {
   private final DoubleSetting paddingSetting;

   private final BooleanSetting percentageSetting;

   private final BooleanSetting shadowSetting;

   private final BooleanSetting offhandSetting;

   private final DoubleSetting sizeSetting;

   private final BooleanSetting camoSetting;

   private final BooleanSetting durabilitySetting;

   private final HudLayout hudLayout;

   private final DoubleSetting bGAlphaSetting;

   private static final FontFace fontFace = FontFace.MEDIUM;

   private final BooleanSetting emptySlotsSetting;

   private final ChoiceSetting layoutSetting = new ChoiceSetting("Layout", "Horizontal", "Horizontal", "Vertical");

   @Override
   public HudLayout computeHudLayout() {
      return this.hudLayout;
   }

   @EventHandler
   private void onRender2D(Render2DEvent render2DEvent) {
      if (mc.player != null && mc.world != null) {
         if (mc.currentScreen == null || mc.currentScreen instanceof ChatScreen) {
            if (!GlCapabilities.checkCondition3()) {
               this.updateState8();
               List list = this.computeList();
               if (!list.isEmpty()) {
                  ThemeSnapshot themeSnapshot = ClickGuiModule.computeThemeSnapshot();
                  float value = (float)this.sizeSetting.getValue();
                  float size = value * 0.85F;
                  float value2 = (float)this.paddingSetting.getValue();
                  boolean booleanValue = this.layoutSetting.equals("Horizontal");
                  boolean value3 = this.durabilitySetting.getValue();

                  try (UiRenderBackend uiRenderBackend = HudBloomRenderer.computeUiRenderBackendForRender2DEvent(render2DEvent)) {
                     float floatValue = LegacyUiTheme.measureFontHeight(value, LegacyUiTheme.fontFace2);
                     float floatValue2 = this.percentageSetting.getValue() ? LegacyUiTheme.measureFontHeight(size, fontFace) : 0.0F;
                     String text = this.computeStringForList(list);
                     float floatValue3 = LegacyUiTheme.measureText2("Armor", value) + (text == null ? 0.0F : 14.0F + LegacyUiTheme.measureText(text, value, fontFace));
                     float width;
                     float height;
                     if (booleanValue) {
                        float floatValue4 = (float)list.size() * this.computeFloat() + (float)(list.size() - 1) * 5.0F;
                        width = 10.0F + Math.max(floatValue4, floatValue3) + value2;
                        height = value2 * 2.0F + floatValue + 5.0F + this.computeFloat() + (value3 ? 4.0F + (floatValue2 > 0.0F ? floatValue2 + 1.0F : 0.0F) : 0.0F);
                     } else {
                        float floatValue5 = 0.0F;

                        for (ItemStack itemStack : (java.lang.Iterable<ItemStack>)(java.lang.Iterable<?>)(list)) {
                           String text2 = this.computeStringForItemStack(itemStack);
                           if (text2 != null) {
                              floatValue5 = Math.max(floatValue5, LegacyUiTheme.measureText(text2, size, fontFace));
                           }
                        }

                        float floatValue6 = this.computeFloat() + (value3 ? 38.0F + floatValue5 : 0.0F);
                        width = 10.0F + Math.max(floatValue6, floatValue3) + value2;
                        height = value2 * 2.0F + floatValue + 5.0F + (float)list.size() * this.computeFloat() + (float)(list.size() - 1) * 5.0F;
                     }

                     this.updateState4(width, height);
                     float x = this.hudLayout.getX();
                     float y = this.hudLayout.getY();
                     LegacyUiTheme.updateStateForThemeSnapshot(x, y, width, height, (int)this.bGAlphaSetting.getValue(), true, this.shadowSetting.getValue(), this.camoSetting.getValue(), true, themeSnapshot);
                     LegacyUiTheme.computeFloat("Armor", x + 10.0F, y + value2, value);
                     if (text != null) {
                        LegacyUiTheme.drawText3(text, x + width - value2, y + value2, value, LegacyUiTheme.color5, fontFace);
                     }

                     float floatValue7 = y + value2 + floatValue + 5.0F;

                     for (int intValue = 0; intValue < list.size(); intValue++) {
                        ItemStack itemStack2 = (ItemStack)list.get(intValue);
                        float x2 = booleanValue ? x + 10.0F + (float)intValue * (this.computeFloat() + 5.0F) : x + 10.0F;
                        float floatValue8 = booleanValue ? floatValue7 : floatValue7 + (float)intValue * (this.computeFloat() + 5.0F);
                        this.updateStateForRender2DEvent(render2DEvent, itemStack2, x2, floatValue8, size, themeSnapshot, booleanValue);
                     }
                  }
               }
            }
         }
      }
   }

   private static float computeFloatForItemStack(ItemStack itemStack) {
      int maxDamage = itemStack.getMaxDamage();
      if (maxDamage <= 0) {
         return 1.0F;
      } else {
         int intValue = maxDamage - itemStack.getDamage();
         return MathHelper.clamp((float)intValue / (float)maxDamage, 0.0F, 1.0F);
      }
   }

   private List computeList() {
      ArrayList arrayList = new ArrayList(5);

      for (EquipmentSlot equipmentSlot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
         ItemStack equippedStack = mc.player.getEquippedStack(equipmentSlot);
         if (!equippedStack.isEmpty() || this.emptySlotsSetting.getValue()) {
            arrayList.add(equippedStack);
         }
      }

      ItemStack offHandStack = mc.player.getOffHandStack();
      if (this.offhandSetting.getValue() && (!offHandStack.isEmpty() || this.emptySlotsSetting.getValue())) {
         arrayList.add(offHandStack);
      }

      return arrayList;
   }

   public ArmorModule() {
      super("Armor", "Worn armour and offhand with durability", -1, ModuleCategory.RENDER);
      this.durabilitySetting = new BooleanSetting("Durability", true);
      this.percentageSetting = new BooleanSetting("Percentage", true);
      this.offhandSetting = new BooleanSetting("Offhand", true);
      this.emptySlotsSetting = new BooleanSetting("Empty Slots", false);
      this.sizeSetting = new DoubleSetting("Size", 6.0, 24.0, 11.0, 0.5);
      this.paddingSetting = new DoubleSetting("Padding", 2.0, 14.0, 8.0, 1.0);
      this.bGAlphaSetting = new DoubleSetting("BG Alpha", 0.0, 255.0, 150.0, 5.0);
      this.shadowSetting = new BooleanSetting("Shadow", true);
      this.camoSetting = new BooleanSetting("Camo", false);
      this.hudLayout = new HudLayout(4.0F, 4.0F, 120.0F, 56.0F);
      this.addSettings(new Setting[]{this.layoutSetting, this.durabilitySetting, this.percentageSetting, this.offhandSetting, this.emptySlotsSetting, this.sizeSetting, this.paddingSetting, this.bGAlphaSetting, this.shadowSetting, this.camoSetting});
   }

   private String computeStringForItemStack(ItemStack itemStack) {
      if (itemStack.isEmpty() || itemStack.getMaxDamage() <= 0) {
         return null;
      } else {
         return this.percentageSetting.getValue() ? Math.round(computeFloatForItemStack(itemStack) * 100.0F) + "%" : "";
      }
   }

   private String computeStringForList(List list) {
      if (!this.percentageSetting.getValue()) {
         return null;
      } else {
         float floatValue = 2.0F;

         for (ItemStack itemStack : (java.lang.Iterable<ItemStack>)(java.lang.Iterable<?>)(list)) {
            if (!itemStack.isEmpty() && itemStack.getMaxDamage() > 0) {
               floatValue = Math.min(floatValue, computeFloatForItemStack(itemStack));
            }
         }

         return floatValue > 1.0F ? null : "min " + Math.round(floatValue * 100.0F) + "%";
      }
   }

   @Override
   public float getFloatConstant() {
      return 56.0F;
   }

   @Override
   public void updateState() {
      this.hudLayout.setAlignmentAndInsets(HudHorizontalAlignment.LEFT, HudVerticalAlignment.BOTTOM, HudLayoutMetrics.computeFloat3(4.0F, CoordinatesModule.class), 4.0F);
   }

   @Override
   public String computeString() {
      return this.getName();
   }

   private void updateStateForRender2DEvent(Render2DEvent render2DEvent, ItemStack itemStack, float x, float floatValue, float size, ThemeSnapshot themeSnapshot, boolean booleanValue) {
      HudBloomRenderer.fillRoundedRect(x - 1.0F, floatValue - 1.0F, this.computeFloat() + 2.0F, this.computeFloat() + 2.0F, 4.0F, LegacyUiTheme.createColor(Color.WHITE, 0.05F));
      if (!itemStack.isEmpty()) {
         HudItemRenderer.updateStateForRender2DEvent(render2DEvent, itemStack, x, floatValue, this.computeFloat());
      }

      if (this.durabilitySetting.getValue() && !itemStack.isEmpty() && itemStack.getMaxDamage() > 0) {
         float floatValue2 = computeFloatForItemStack(itemStack);
         Color color = LegacyUiTheme.computeColorForThemeSnapshot(themeSnapshot, floatValue2);
         float floatValue3 = floatValue2 < 0.15F ? 0.55F + 0.45F * (float)Math.sin((double)System.nanoTime() / 1.5E8) : 1.0F;
         String text = this.computeStringForItemStack(itemStack);
         Color color2 = LegacyUiTheme.createColor(floatValue2 > 0.3F ? LegacyUiTheme.color3 : color, floatValue3);
         if (booleanValue) {
            float y = floatValue + this.computeFloat() + 2.5F;
            LegacyUiTheme.updateStateForColor(x, y, this.computeFloat(), 1.6F, floatValue2, color, floatValue3);
            if (text != null && !text.isEmpty()) {
               LegacyUiTheme.drawText22(text, x + this.computeFloat() / 2.0F, y + 2.6F + LegacyUiTheme.measureFontHeight(size, fontFace) / 2.0F, size, color2, fontFace);
            }
         } else {
            float floatValue4 = floatValue + this.computeFloat() / 2.0F;
            LegacyUiTheme.updateStateForColor(x + this.computeFloat() + 6.0F, floatValue4 - 0.8F, 26.0F, 1.6F, floatValue2, color, floatValue3);
            if (text != null && !text.isEmpty()) {
               LegacyUiTheme.drawText2(text, x + this.computeFloat() + 6.0F + 26.0F + 6.0F, floatValue4, size, color2, fontFace);
            }
         }
      }
   }

   @Override
   public boolean checkCondition() {
      return false;
   }

   @Override
   public float getFloatConstant2() {
      return 120.0F;
   }

   private float computeFloat() {
      return 16.0F * (float)this.sizeSetting.getValue() / 8.0F;
   }
}
