package cc.mochi;

import java.util.Comparator;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.BiPredicate;
import java.util.function.Predicate;
import net.minecraft.block.AbstractPressurePlateBlock;
import net.minecraft.block.AnvilBlock;
import net.minecraft.block.BedBlock;
import net.minecraft.block.BellBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.ButtonBlock;
import net.minecraft.block.CactusBlock;
import net.minecraft.block.CakeBlock;
import net.minecraft.block.CobwebBlock;
import net.minecraft.block.ComposterBlock;
import net.minecraft.block.CraftingTableBlock;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.FallingBlock;
import net.minecraft.block.FenceGateBlock;
import net.minecraft.block.FlowerPotBlock;
import net.minecraft.block.HoneyBlock;
import net.minecraft.block.LeavesBlock;
import net.minecraft.block.LeverBlock;
import net.minecraft.block.MagmaBlock;
import net.minecraft.block.NoteBlock;
import net.minecraft.block.ObserverBlock;
import net.minecraft.block.PistonBlock;
import net.minecraft.block.PowderSnowBlock;
import net.minecraft.block.RedstoneOreBlock;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.block.ScaffoldingBlock;
import net.minecraft.block.SlimeBlock;
import net.minecraft.block.SoulSandBlock;
import net.minecraft.block.TntBlock;
import net.minecraft.block.TrapdoorBlock;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.util.math.Direction.AxisDirection;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.EmptyBlockView;
import net.minecraft.world.World;

public final class BlockPlacementUtils {
   private static final Direction[] directionArray;

   private static final Direction[] directionArray2;

   public static Direction[] getDirectionArray() {
      return directionArray;
   }

   static Vec3d computeVec3dForVec3d(Vec3d vec3d, Box box, Direction direction, double doubleValue, long longValue) {
      long longValue2 = computeLong(longValue);

      double doubleValue2 = (double)(longValue2 & 65535L);

      double doubleValue3 = (doubleValue2 / (65535.0) * 2.0 - 1.0) * 0.1;

      long longValue3 = longValue2 >>> 16;

      doubleValue2 = (double)(longValue3 & (65535L));

      double doubleValue4 = (doubleValue2 / (65535.0) * 2.0 - 1.0) * 0.1;
      double x3 = BoxAccess2.getX(vec3d);
      double y3 = BoxAccess2.getY(vec3d);
      double z = vec3d.z;
      switch (getAXIS_CASES()[direction.getAxis().ordinal()]) {
         case 1:

            y3 = computeDouble(y3 + doubleValue3, box.minY, box.maxY, doubleValue);
            z = computeDouble(z + doubleValue4, box.minZ, BoxAccess2.getMaxZ(box), doubleValue);
            break;
         case 2:

            x3 = computeDouble(x3 + doubleValue3, box.minX, BoxAccess2.getMaxX(box), doubleValue);
            z = computeDouble(z + doubleValue4, box.minZ, BoxAccess2.getMaxZ(box), doubleValue);
            break;
         case 3:

            x3 = computeDouble(x3 + doubleValue3, BoxAccess2.getMinX(box), box.maxX, doubleValue);
            y3 = computeDouble(y3 + doubleValue4, box.minY, BoxAccess2.getMaxY(box), doubleValue);
            break;
         default:
      }

      return new Vec3d(x3, y3, z);
   }

   public static int[] getAXIS_CASES() {
      return PlacementDirectionSwitchMap.AXIS_CASES;
   }

   public static ScaffoldPlacement computeScaffoldPlacementForWorld(
      World world, ClientPlayerEntity clientPlayerEntity, Vec3d vec3d, BlockPos blockPos, ItemStack itemStack, float floatValue, float floatValue2, double doubleValue, long longValue, float floatValue3
   ) {
      if (!isReplaceable(world, blockPos)) {
         return null;
      } else {
         double blockInteractionRange = clientPlayerEntity.getBlockInteractionRange();
         double doubleValue2 = blockInteractionRange + 2.5;
         Vec3d vec3d2 = RotationMath.computeVec3d(floatValue, floatValue2);
         ScaffoldPlacement scaffoldPlacement = null;
         double maxValue = Double.MAX_VALUE;
         ScaffoldPlacement scaffoldPlacement2 = null;
         double maxValue2 = Double.MAX_VALUE;
         Direction[] directionArray3 = getDirectionArray();
         int length = directionArray3.length;
         int intValue = 0;

         while (true) {
            if (intValue >= length) {
               return scaffoldPlacement != null ? scaffoldPlacement : scaffoldPlacement2;
            }

            ThreadLocalRandom.current().nextInt(14);
            Direction direction = directionArray3[intValue];
            BlockPos blockPos2 = blockPos.offset(direction);
            BlockState blockState = world.getBlockState(blockPos2);
            if (!blockState.isAir() && !blockState.isReplaceable()) {
               if (!(testBlockState(blockState))) {
                  VoxelShape outlineShape = blockState.getOutlineShape(world, blockPos2);
                  if (!outlineShape.isEmpty()) {
                     Box box = outlineShape.getBoundingBox().offset(blockPos2);
                     Direction opposite = direction.getOpposite();
                     Vec3d vec3d3 = computeVec3dForVec3d2(vec3d, vec3d2, box, opposite, doubleValue);
                     long longValue2 = blockPos2.asLong();

                     Vec3d vec3d4 = computeVec3dForVec3d(vec3d3, box, opposite, doubleValue, longValue ^ longValue2 * (31L) + (long)opposite.ordinal());
                     if (!(vec3d.squaredDistanceTo(vec3d4) > doubleValue2 * doubleValue2)) {
                        List list = computeListForVec3d(vec3d, box, opposite, doubleValue, floatValue3, vec3d4);
                        if (testVec3d(vec3d, box, opposite)) {
                           ArrayList arrayList = new ArrayList(list);
                           arrayList.addAll(computeListForVec3d2(vec3d4, box, opposite, doubleValue));
                           Iterator iterator = arrayList.iterator();

                           while (iterator.hasNext()) {
                              Vec3d vec3d5 = (Vec3d)iterator.next();
                              if (!(vec3d.squaredDistanceTo(vec3d5) > blockInteractionRange * blockInteractionRange)) {
                                 float[] floatArray = RotationMath.computeFloatArrayForVec3d(vec3d, vec3d5, floatValue);
                                 double doubleValue3 = computeDouble2(floatValue, floatValue2, floatArray, floatValue3);
                                 if (!(doubleValue3 >= maxValue)) {
                                    float floatValue4 = floatArray[0];

                                    longValue2 = 400522455L;
                                    BlockHitTarget blockHitTarget = InteractionActions.computeBlockHitTargetForWorld(world, clientPlayerEntity, vec3d, floatValue4, floatArray[1], itemStack);
                                    if (blockHitTarget != null) {
                                       if (blockHitTarget.getCell().equals(blockPos) && testWorld2(world, blockHitTarget.getState2(), blockPos)) {
                                          maxValue = doubleValue3;

                                          scaffoldPlacement = new ScaffoldPlacement(blockPos, blockPos2, opposite, vec3d5, floatArray[0], floatArray[1], true);
                                       }
                                    }
                                 }
                              }
                           }
                        }

                        ArrayList arrayList2 = new ArrayList(list);
                        arrayList2.add(vec3d4);

                        for (Vec3d vec3d6 : (java.lang.Iterable<Vec3d>)(java.lang.Iterable<?>)(arrayList2)) {
                           float[] floatArray2 = RotationMath.computeFloatArrayForVec3d(vec3d, vec3d6, floatValue);
                           double doubleValue4 = computeDouble2(floatValue, floatValue2, floatArray2, floatValue3);
                           if (doubleValue4 < maxValue2) {
                              maxValue2 = doubleValue4;
                              float floatValue5 = floatArray2[0];
                              float floatValue6 = floatArray2[1];

                              scaffoldPlacement2 = new ScaffoldPlacement(blockPos, blockPos2, opposite, vec3d6, floatValue5, floatValue6, false);
                           }
                        }
                     }
                  }
               }
            }

            intValue++;
         }
      }
   }

   public static boolean testItemStack(ItemStack itemStack, boolean booleanValue, boolean booleanValue2) {
      if (!itemStack.isEmpty()) {
         if (itemStack.getItem() instanceof BlockItem var3) {
            Block block = var3.getBlock();
            BlockState defaultState = block.getDefaultState();
            if (!(block instanceof FallingBlock)) {
               if (!(block instanceof TntBlock) && !(block instanceof MagmaBlock) && !(block instanceof CactusBlock)) {
                  if (!(block instanceof PowderSnowBlock)) {
                     if (!(block instanceof CobwebBlock)) {
                        int intValue = 16;
                        ThreadLocalRandom.current().nextInt(14);

                        if (!(block instanceof SlimeBlock) && !(block instanceof HoneyBlock)) {
                           if (!(block instanceof SoulSandBlock)
                              && !(block instanceof ScaffoldingBlock)
                              && !(block instanceof LeavesBlock)
                              && !(block instanceof PistonBlock)
                              && !(block instanceof ObserverBlock)
                              && !testBlockState(defaultState)) {
                              if (testBlock(block) && !booleanValue) {
                                 return false;
                              }

                              if (!defaultState.getFluidState().isEmpty()) {
                                 return false;
                              }

                              label167: {
                                 label168: {
                                    VoxelShape collisionShape;
                                    try {
                                       collisionShape = defaultState.getCollisionShape(EmptyBlockView.INSTANCE, BlockPos.ORIGIN);
                                       if (collisionShape.isEmpty()) {
                                          break label168;
                                       }
                                    } catch (RuntimeException failure) {
                                       break label167;
                                    }

                                    label134: {
                                       label170: {
                                          label131:
                                          try {
                                             if (!booleanValue2) {
                                                break label131;
                                             }
                                             break label170;
                                          } catch (RuntimeException failure2) {
                                             break label167;
                                          }

                                          try {
                                             if (Block.isShapeFullCube(collisionShape)) {
                                                break label170;
                                             }
                                          } catch (RuntimeException failure3) {
                                             break label167;
                                          }

                                          try {
                                             intValue = (((byte)0));
                                             break label134;
                                          } catch (RuntimeException failure4) {
                                             break label167;
                                          }
                                       }

                                       try {
                                          intValue = (((byte)1));
                                       } catch (RuntimeException failure5) {
                                          break label167;
                                       }
                                    }

                                    try {
                                       return (intValue != 0);
                                    } catch (RuntimeException failure6) {
                                       break label167;
                                    }
                                 }

                                 try {
                                    return false;
                                 } catch (RuntimeException failure7) {
                                 }
                              }

                              intValue = -455102876;

                              return false;
                           }
                        }
                     }
                  }
               }
            }

            return false;
         }
      } else {
         ThreadLocalRandom.current().nextInt(13);
      }

      return false;
   }

   public static boolean testBlockState(BlockState blockState) {
      Block block = blockState.getBlock();
      if (!(block instanceof BlockWithEntity) && !(block instanceof CraftingTableBlock)) {
         if (!(block instanceof AnvilBlock) && !(block instanceof DoorBlock) && !(block instanceof TrapdoorBlock)) {
            if (!(block instanceof FenceGateBlock)) {
               if (!(block instanceof ButtonBlock)) {
                  if (!(block instanceof LeverBlock) && !(block instanceof BedBlock)) {
                     if (!(block instanceof NoteBlock)) {
                        if (!(block instanceof CakeBlock)) {
                           if (!(block instanceof BellBlock)
                              && !(block instanceof ComposterBlock)
                              && !(block instanceof FlowerPotBlock)
                              && !(block instanceof RespawnAnchorBlock)) {
                              if (!(block instanceof RedstoneOreBlock)) {
                                 if (!(block instanceof AbstractPressurePlateBlock)) {
                                    if (!block.getClass().getSimpleName().contains("Repeater") && !block.getClass().getSimpleName().contains("Comparator")) {
                                       return false;
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               } else {
                  ThreadLocalRandom.current().nextInt(5);
               }
            }
         }
      }

      return true;
   }

   static {
      Direction[] directionArray3 = new Direction[6];

      directionArray3[0] = Direction.DOWN;

      directionArray3[1] = Direction.NORTH;
      directionArray3[2] = Direction.SOUTH;
      directionArray3[3] = Direction.WEST;
      directionArray3[4] = Direction.EAST;
      directionArray3[5] = Direction.UP;
      directionArray = directionArray3;
      directionArray3 = new Direction[]{Direction.NORTH, Direction.SOUTH, null, null, null};

      directionArray3[2] = Direction.WEST;
      directionArray3[3] = Direction.EAST;

      directionArray3[4] = Direction.DOWN;
      directionArray2 = directionArray3;
   }

   public static int computeInt(int intValue, int intValue2, int intValue3, int intValue4, int intValue5, int intValue6) {
      int intValue7;
      if (intValue3 <= 0) {
         intValue7 = 0;
      } else {
         intValue7 = intValue3 + (intValue3 - 1) * Math.max(0, intValue4);
      }

      int intValue72 = intValue7;
      return intValue - (intValue2 + intValue72 + intValue5 + intValue6);
   }

   public static boolean testWorld(World world, BlockPos blockPos) {
      BlockState blockState = world.getBlockState(blockPos);
      if (blockState.isAir()) {
         ThreadLocalRandom.current().nextInt(12);

         return false;
      } else {
         return testWorld2(world, blockState, blockPos);
      }
   }

   public static boolean testWorld2(World world, BlockState blockState, BlockPos blockPos) {
      VoxelShape collisionShape = blockState.getCollisionShape(world, blockPos);
      if (!collisionShape.isEmpty()) {
         if (collisionShape.getMax(BoxAccess2.getY5()) >= 0.999) {
            if (blockState.isSideSolidFullSquare(world, blockPos, Direction.UP)) {
               return true;
            }
         }
      }

      return false;
   }

   public static Vec3d computeVec3d(float floatValue, int intValue, int intValue2) {
      if (intValue == 0) {
         ThreadLocalRandom.current().nextInt(3);

         if (intValue2 == 0) {
            return Vec3d.ZERO;
         }
      }

      double doubleValue = Math.sqrt((double)(intValue * intValue + intValue2 * intValue2));
      double doubleValue2 = (double)intValue2 / doubleValue;
      double doubleValue3 = (double)intValue / doubleValue;
      float floatValue2 = MathHelper.sin((double)(floatValue * (float) (Math.PI / 180.0)));

      float floatValue3 = MathHelper.cos((double)(floatValue * (0.017453292F)));
      double doubleValue4 = doubleValue2 * (double)floatValue3 - doubleValue3 * (double)floatValue2;

      return new Vec3d(doubleValue4, (0.0), doubleValue3 * (double)floatValue3 + doubleValue2 * (double)floatValue2);
   }

   private static long computeLong(long longValue) {
      long longValue2 = longValue + -7046029254386353131L;

      long longValue3 = longValue2 ^ longValue2 >>> 30;

      longValue2 = longValue3 * (-4658895280553007687L);
      longValue3 = longValue2 ^ longValue2 >>> 27;

      longValue2 = longValue3 * (-7723592293110705685L);
      return longValue2 ^ longValue2 >>> 31;
   }

   public static int floor(double doubleValue) {
      return MathHelper.floor(doubleValue - (0.5));
   }

   public static boolean testWorld3(World world, BlockPos blockPos) {
      for (Direction direction : directionArray) {
         BlockState blockState = world.getBlockState(blockPos.offset(direction));
         if (!blockState.isAir()) {
            if (!blockState.isReplaceable()) {
               if (!testBlockState(blockState)) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   public static int max(float floatValue, float floatValue2, float floatValue3, float floatValue4, double doubleValue) {
      return Math.max(computeInt2((double)Math.abs(RotationMath.wrapDegrees(floatValue, floatValue3)), doubleValue), computeInt2((double)Math.abs(floatValue4 - floatValue2), doubleValue * 0.9));
   }

   public static Vec3d computeVec3dForVec3d2(Vec3d vec3d, Vec3d vec3d2, Box box, Direction direction, double doubleValue) {
      Axis axis = direction.getAxis();
      double doubleValue2;
      if (direction.getDirection() == AxisDirection.POSITIVE) {
         doubleValue2 = box.getMax(axis);
      } else {
         doubleValue2 = box.getMin(axis);
      }

      double doubleValue22 = doubleValue2;
      double componentAlongAxis = vec3d2.getComponentAlongAxis(axis);
      doubleValue2 = Math.abs(componentAlongAxis);

      if (doubleValue2 < (1.0E-6)) {
         doubleValue2 = ((-1.0));
      } else {
         doubleValue2 = (doubleValue22 - vec3d.getComponentAlongAxis(axis)) / componentAlongAxis;
      }

      double doubleValue23 = doubleValue2;

      Vec3d center;
      if (doubleValue23 > (0.0)) {
         center = vec3d.add(vec3d2.multiply(doubleValue23));
      } else {
         center = box.getCenter();
      }

      Vec3d center2 = center;
      double doubleValue5 = computeDouble(center2.x, BoxAccess2.getMinX(box), box.maxX, doubleValue);
      double doubleValue6 = computeDouble(center2.y, box.minY, BoxAccess2.getMaxY(box), doubleValue);
      double doubleValue7 = computeDouble(center2.z, box.minZ, BoxAccess2.getMaxZ(box), doubleValue);
      Vec3d vec3d4;
      switch (PlacementDirectionSwitchMap.AXIS_CASES[axis.ordinal()]) {
         case 1:

            vec3d4 = new Vec3d(doubleValue22, doubleValue6, doubleValue7);
            break;
         case 2:
            vec3d4 = new Vec3d(doubleValue5, doubleValue22, doubleValue7);
            break;
         case 3:
            vec3d4 = new Vec3d(doubleValue5, doubleValue6, doubleValue22);
            break;
         default:
            throw new MatchException(null, null);
      }

      return vec3d4;
   }

   public static int computeInt2(double doubleValue, double doubleValue2) {
      if (doubleValue <= 0.5) {
         return 0;
      } else if (doubleValue2 <= 0.0) {
         return 536870911;
      } else {
         return (int)Math.ceil(doubleValue / doubleValue2);
      }
   }

   public static PredictedEntityPath computePredictedEntityPathForClientPlayerEntity(ClientPlayerEntity clientPlayerEntity, World world, Vec3d vec3d, boolean booleanValue, boolean booleanValue2, float floatValue, double doubleValue, int intValue) {
      int intValue2;
      float slipperiness;
      int intValue3;

      ArrayList arrayList = new ArrayList(intValue + 1);
      Box boundingBox = clientPlayerEntity.getBoundingBox();
      arrayList.add(boundingBox);
      Vec3d vec3d4 = clientPlayerEntity.getVelocity();
      int intValue22 = (clientPlayerEntity.isOnGround()) ? 1 : 0;
      int intValue5 = intValue22 == 0 ? 1 : 0;

      int intValue6 = -1;
      double finalGravity = clientPlayerEntity.getFinalGravity();
      float movementSpeed = clientPlayerEntity.getMovementSpeed();
      int intValue7 = !Double.isNaN(doubleValue) ? 1 : 0;

      for (int intValue8 = 0; intValue8 < intValue; intValue8++) {
         label194: {
            ThreadLocalRandom.current().nextInt(15);
            if (booleanValue2 && intValue22 != 0 && intValue8 == 0) {
               float floatValue2 = (float)clientPlayerEntity.getAttributeValue(EntityAttributes.JUMP_STRENGTH) + clientPlayerEntity.getJumpBoostVelocityModifier();
               vec3d4 = new Vec3d(vec3d4.x, Math.max((double)floatValue2, vec3d4.y), BoxAccess2.getZ(vec3d4));
               if (booleanValue) {
                  float floatValue3 = floatValue * (float) (Math.PI / 180.0);
                  double doubleValue2 = (double)(-MathHelper.sin((double)floatValue3));

                  vec3d4 = vec3d4.add(doubleValue2 * (0.2), 0.0, (double)MathHelper.cos((double)floatValue3) * 0.2);
               }

               intValue22 = 0;
               intValue5 = 1;
            } else if (intValue22 != 0) {
               double x = boundingBox.getCenter().x;
               double minY = boundingBox.minY;

               slipperiness = world.getBlockState(BlockPos.ofFloored(x, minY - (0.5000001), BoxAccess2.getZ(boundingBox.getCenter())))
                  .getBlock()
                  .getSlipperiness();
               break label194;
            }

            slipperiness = 1.0F;
         }

         float slipperiness2 = slipperiness;
         float floatValue4 = intValue22 != 0
            ? movementSpeed * (0.21600002F / (slipperiness2 * slipperiness2 * slipperiness2))
            : (booleanValue ? (0.025999999F) : (0.02F));
         double x2 = BoxAccess2.getX(vec3d);

         double doubleValue3 = x2 * (0.98) * (double)floatValue4;
         double z = vec3d.z;

         vec3d4 = vec3d4.add(doubleValue3, 0.0, z * (0.98) * (double)floatValue4);
         Vec3d vec3d2 = Entity.adjustMovementForCollisions(clientPlayerEntity, vec3d4, boundingBox, world, List.of());

         byte byteValue = 0;
         if (intValue7 != 0) {
            if (BoxAccess2.getMinY(boundingBox) >= doubleValue - 1.0E-6) {
               ThreadLocalRandom.current().nextInt(5);
               if (BoxAccess2.getMinY(boundingBox) + vec3d2.y < doubleValue && BoxAccess2.getY(vec3d2) < 0.0) {
                  vec3d2 = new Vec3d(BoxAccess2.getX(vec3d2), doubleValue - boundingBox.minY, BoxAccess2.getZ(vec3d2));
                  byteValue = 1;
               }
            } else {
               ThreadLocalRandom.current().nextInt(7);
            }
         }

         label172: {
            boundingBox = boundingBox.offset(vec3d2);
            arrayList.add(boundingBox);
            if (byteValue == 0) {
               double doubleValue4 = Math.abs(vec3d2.y - vec3d4.y);

               if (!(doubleValue4 > (1.0E-7))) {
                  intValue3 = 0;
                  break label172;
               }
            }

            intValue3 = 1;
         }

         int intValue32;
         int intValue10;
         label166: {
            intValue32 = intValue3;
            intValue10 = intValue22 == 0 ? 1 : 0;
            if (intValue32 != 0) {
               if (BoxAccess2.getY(vec3d4) < 0.0) {
                  intValue2 = 1;
                  break label166;
               }
            }

            intValue2 = 0;
         }

         intValue22 = intValue2;
         if (intValue22 != 0) {
            if (intValue10 != 0) {
               if (intValue5 != 0 && intValue6 < 0) {
                  intValue6 = intValue8 + 1;
               }
            }
         }

         float floatValue5 = slipperiness2 * 0.91F;
         Vec3d vec3d3;
         double doubleValue5 = Math.abs(vec3d2.x - vec3d4.x) > 1.0E-7 ? 0.0 : BoxAccess2.getX(vec3d4) * (double)floatValue5;
         double y;
         if (intValue32 != 0) {
            y = (0.0);
         } else {
            y = vec3d4.y;
         }

         vec3d3 = new Vec3d(
            doubleValue5, (y - finalGravity) * 0.98, Math.abs(BoxAccess2.getZ(vec3d2) - BoxAccess2.getZ(vec3d4)) > 1.0E-7 ? 0.0 : BoxAccess2.getZ(vec3d4) * (double)floatValue5
         );
         vec3d4 = vec3d3;
         if (intValue6 >= 0) {
            int intValue11 = intValue8 + 1;

            if (intValue11 >= intValue6 + 1) {
               break;
            }
         }
      }

      return new PredictedEntityPath(arrayList, intValue6, (intValue5 != 0));
   }

   static List computeListForVec3d(Vec3d vec3d, Box box, Direction direction, double doubleValue, float floatValue, Vec3d vec3d2) {
      ArrayList arrayList = new ArrayList(2);
      if (!Float.isNaN(floatValue)) {
         ThreadLocalRandom.current().nextInt(13);
         if (direction.getAxis() != Axis.Y) {
            Axis axis = direction.getAxis();
            double doubleValue2;
            if (direction.getDirection() == BoxAccess2.getPOSITIVE()) {
               doubleValue2 = box.getMax(axis);
            } else {
               doubleValue2 = box.getMin(axis);
            }

            double doubleValue22 = doubleValue2;
            double doubleValue4 = computeDouble(BoxAccess2.getY(vec3d2), BoxAccess2.getMinY(box), BoxAccess2.getMaxY(box), doubleValue);

            int intValue = 0;

            do {
               float floatValue2 = floatValue + (float)intValue * (45.0F);
               double doubleValue5 = -Math.sin(Math.toRadians((double)floatValue2));
               double doubleValue6 = Math.cos(Math.toRadians((double)floatValue2));
               double doubleValue7;
               if (axis == Axis.X) {
                  doubleValue7 = doubleValue5;
               } else {
                  doubleValue7 = doubleValue6;
               }

               double doubleValue72 = doubleValue7;
               double doubleValue9 = Math.abs(doubleValue72);

               if (!(doubleValue9 < (1.0E-6))) {
                  double doubleValue10 = (doubleValue22 - (axis == BoxAccess2.getX6() ? BoxAccess2.getX(vec3d) : BoxAccess2.getZ(vec3d))) / doubleValue72;
                  if (!(doubleValue10 <= 0.0)) {
                     if (axis == BoxAccess2.getX6()) {
                        double doubleValue11 = vec3d.z + doubleValue6 * doubleValue10;
                        if (doubleValue11 >= box.minZ + doubleValue && doubleValue11 <= BoxAccess2.getMaxZ(box) - doubleValue) {
                           arrayList.add(new Vec3d(doubleValue22, doubleValue4, doubleValue11));
                        }
                     } else {
                        double doubleValue12 = vec3d.x + doubleValue5 * doubleValue10;
                        if (doubleValue12 >= box.minX + doubleValue && doubleValue12 <= BoxAccess2.getMaxX(box) - doubleValue) {
                           arrayList.add(new Vec3d(doubleValue12, doubleValue4, doubleValue22));
                        }
                     }
                  }
               }
            } while (++intValue < 8);

            return arrayList;
         }
      }

      return arrayList;
   }

   static List computeListForVec3d2(Vec3d vec3d, Box box, Direction direction, double doubleValue) {
      Axis axis = direction.getAxis();
      double componentAlongAxis = vec3d.getComponentAlongAxis(axis);
      ArrayList arrayList = new ArrayList(10);
      arrayList.add(vec3d);
      double[] doubleArray = computeDoubleArray(box.minX, BoxAccess2.getMaxX(box), doubleValue);
      double[] doubleArray2 = computeDoubleArray(box.minY, BoxAccess2.getMaxY(box), doubleValue);
      double[] doubleArray3 = computeDoubleArray(box.minZ, box.maxZ, doubleValue);

      ArrayList arrayList2 = new ArrayList(9);
      switch (PlacementDirectionSwitchMap.AXIS_CASES[axis.ordinal()]) {
         case 1:
            double[] doubleArray22 = doubleArray2;
            int length = doubleArray2.length;
            long longValue = -4924568424870775832L;
            longValue = -4924568424870775832L;
            long longValue2 = 1355847923L;
            int intValue = 0;

            while (intValue < length) {
               double doubleValue2 = doubleArray22[intValue];
               double[] doubleArray32 = doubleArray3;
               int length2 = doubleArray3.length;
               longValue = 1274809649212391577L;
               longValue = 1274809649212391577L;
               longValue2 = 3351607289L;
               int intValue2 = 0;

               while (intValue2 < length2) {
                  double doubleValue3 = doubleArray32[intValue2];
                  arrayList2.add(new Vec3d(componentAlongAxis, doubleValue2, doubleValue3));
                  intValue2++;
               }

               intValue++;
            }

            break;
         case 2:
            double[] doubleArray4 = doubleArray;
            int length3 = doubleArray.length;

            for (int intValue3 = 0; intValue3 < length3; intValue3++) {
               double doubleValue4 = doubleArray4[intValue3];

               for (double doubleValue5 : doubleArray3) {
                  arrayList2.add(new Vec3d(doubleValue4, componentAlongAxis, doubleValue5));
               }
            }

            break;
         case 3:
            double[] doubleArray5 = doubleArray;
            int length4 = doubleArray.length;
            int intValue4 = 0;

            while (true) {
               if (intValue4 >= length4) {
                  break;
               }

               double doubleValue6 = doubleArray5[intValue4];
               double[] doubleArray23 = doubleArray2;
               int length5 = doubleArray2.length;

               for (int intValue5 = 0; intValue5 < length5; intValue5++) {
                  double doubleValue7 = doubleArray23[intValue5];
                  arrayList2.add(new Vec3d(doubleValue6, doubleValue7, componentAlongAxis));
               }

               ThreadLocalRandom.current().nextInt(14);
               intValue4++;
            }
      }

      arrayList2.sort(Comparator.<Vec3d>comparingDouble(vec3d::squaredDistanceTo));
      arrayList.addAll(arrayList2);
      return arrayList;
   }

   private static boolean testWorld4(World world, BlockPos blockPos, Set set) {
      if (testWorld3(world, blockPos)) {
         return true;
      } else {
         Direction[] directionArray3 = Direction.values();
         int length = directionArray3.length;
         int intValue = 0;

         while (intValue < length) {
            Direction direction = directionArray3[intValue];
            if (set.contains(blockPos.offset(direction))) {
               return true;
            }

            intValue++;
         }

         return false;
      }
   }

   public static BlockPos createBlockPos(double doubleValue, double doubleValue2, double doubleValue3) {
      return new BlockPos(MathHelper.floor(doubleValue), floor(doubleValue3), MathHelper.floor(doubleValue2));
   }

   private static double[] computeDoubleArray(double doubleValue, double doubleValue2, double doubleValue3) {
      double[] doubleArray = new double[3];

      doubleArray[0] = computeDouble(doubleValue, doubleValue, doubleValue2, doubleValue3);
      double doubleValue4 = doubleValue + doubleValue2;

      doubleArray[1] = doubleValue4 / (2.0);
      doubleArray[2] = computeDouble(doubleValue2, doubleValue, doubleValue2, doubleValue3);
      return doubleArray;
   }

   public static boolean testBlock(Block block) {
      byte byteValue;
      if (block.getSlipperiness() > 0.65F) {
         byteValue = 23;
         ThreadLocalRandom.current().nextInt(16);

         byteValue = 1;
      } else {
         byteValue = 0;
      }

      return (byteValue != 0);
   }

   public static boolean isReplaceable(World world, BlockPos blockPos) {
      return world.getBlockState(blockPos).isReplaceable();
   }

   public static List computeListForWorld(World world, BlockPos blockPos, int intValue, Predicate predicate, Set set) {
      if (!predicate.test(blockPos)) {
         return List.of();
      } else {
         if (testWorld4(world, blockPos, set)) {
            return List.of(blockPos);
         } else {
            HashMap hashMap = new HashMap();
            HashMap hashMap2 = new HashMap();
            ArrayDeque arrayDeque = new ArrayDeque();
            hashMap.put(blockPos, blockPos);
            hashMap2.put(blockPos, 0);
            arrayDeque.add(blockPos);

            while (!arrayDeque.isEmpty()) {
               BlockPos blockPos2 = (BlockPos)arrayDeque.poll();
               int intValue2 = (Integer)hashMap2.get(blockPos2);
               if (!(intValue2 >= intValue)) {
                  Direction[] directionArray22 = directionArray2;
                  int length = directionArray22.length;

                  for (int intValue3 = 0; intValue3 < length; intValue3++) {
                     Direction direction = directionArray22[intValue3];
                     BlockPos blockPos3 = blockPos2.offset(direction);
                     if (!hashMap.containsKey(blockPos3) && predicate.test(blockPos3)) {
                        ThreadLocalRandom.current().nextInt(13);
                        hashMap.put(blockPos3, blockPos2);

                        hashMap2.put(blockPos3, intValue2 + 1);
                        if (testWorld4(world, blockPos3, set)) {
                           ArrayList arrayList = new ArrayList();
                           BlockPos blockPos32 = blockPos3;

                           while (true) {
                              arrayList.add(blockPos32);
                              if (blockPos32.equals(blockPos)) {
                                 return arrayList;
                              }

                              blockPos32 = (BlockPos)hashMap.get(blockPos32);
                           }
                        }

                        arrayDeque.add(blockPos3);
                     }
                  }
               }
            }

            return List.of();
         }
      }
   }

   private BlockPlacementUtils() {
   }

   public static boolean testWorld5(World world, Box box, double doubleValue) {
      int intValue = floor(doubleValue);

      double doubleValue2 = (double)(intValue + 1);
      double doubleValue3 = Math.min(doubleValue2, doubleValue) - 0.03;
      double doubleValue4 = Math.max(doubleValue2, doubleValue) - 1.0E-4;
      double minX = box.minX;

      double doubleValue5 = minX + (0.001);
      double doubleValue6 = BoxAccess2.getMinZ(box) + 0.001;
      double doubleValue7 = box.maxX - 0.001;
      double maxZ6 = BoxAccess2.getMaxZ(box);

      Box box2 = new Box(doubleValue5, doubleValue3, doubleValue6, doubleValue7, doubleValue4, maxZ6 - (0.001));
      Iterator iterator = world.getBlockCollisions(null, box2).iterator();
      if (iterator.hasNext()) {
         ThreadLocalRandom.current().nextInt(17);
         VoxelShape voxelShape = (VoxelShape)iterator.next();

         return true;
      } else {
         return false;
      }
   }

   public static List computeListForBiPredicate(double doubleValue, double doubleValue2, double doubleValue3, double doubleValue4, BiPredicate biPredicate) {
      if (biPredicate == null) {
         return computeList2(doubleValue, doubleValue2, doubleValue3, doubleValue4);
      } else {
         ArrayList arrayList = new ArrayList();
         int intValue = MathHelper.floor(doubleValue);
         int intValue2 = MathHelper.floor(doubleValue2);
         int intValue3 = MathHelper.floor(doubleValue3);
         int intValue4 = MathHelper.floor(doubleValue4);

         int[] intArray = new int[2];

         intArray[0] = intValue;

         intArray[1] = intValue2;
         arrayList.add(intArray);
         double doubleValue5 = doubleValue3 - doubleValue;
         double doubleValue6 = doubleValue4 - doubleValue2;
         int intValue72;
         if (intValue3 > intValue) {
            intValue72 = 1;
         } else {
            intValue72 = -1;
         }

         byte byteValue = (byte)intValue72;
         if (intValue4 > intValue2) {
            intValue72 = (((byte)1));
         } else {
            intValue72 = (((byte)-1));
         }

         int intValue5 = intValue72;
         double doubleValue7;
         if (doubleValue5 == 0.0) {
            doubleValue7 = (1.7976931348623157E308);
         } else {
            doubleValue7 = Math.abs(1.0 / doubleValue5);
         }

         double doubleValue72 = doubleValue7;

         double maxValue;
         if (doubleValue6 == (0.0)) {
            maxValue = Double.MAX_VALUE;
         } else {
            maxValue = Math.abs((1.0) / doubleValue6);
         }

         double maxValue3 = maxValue;
         double maxValue2;
         if (doubleValue5 == 0.0) {
            intValue72 = (((byte)20));
            ThreadLocalRandom.current().nextInt(12);
            maxValue2 = Double.MAX_VALUE;
         } else {
            double doubleValue9;
            if (doubleValue5 > (0.0)) {
               doubleValue9 = (double)(intValue + 1) - doubleValue;
            } else {
               doubleValue9 = doubleValue - (double)intValue;
            }

            maxValue2 = doubleValue9 * doubleValue72;
         }

         double maxValue22 = maxValue2;

         double doubleValue10;
         if (doubleValue6 == (0.0)) {
            doubleValue10 = (1.7976931348623157E308);
         } else {
            double doubleValue11;
            if (doubleValue6 > (0.0)) {
               doubleValue11 = (double)(intValue2 + 1) - doubleValue2;
            } else {
               intValue72 = (((byte)15));
               ThreadLocalRandom.current().nextInt(11);
               doubleValue11 = doubleValue2 - (double)intValue2;
            }

            doubleValue10 = doubleValue11 * maxValue3;
         }

         for (double doubleValue102 = doubleValue10; intValue != intValue3 || intValue2 != intValue4; arrayList.add(new int[]{intValue, intValue2})) {
            if ((intValue != intValue3)) {
               label132: {
                  if ((intValue2 != intValue4)) {
                     int intValue7 = (biPredicate.test(intValue + byteValue, intValue2)) ? 1 : 0;
                     int intValue8 = (biPredicate.test(intValue, intValue2 + intValue5)) ? 1 : 0;
                     if (intValue7 != intValue8) {
                        intValue72 = intValue7;
                     } else {
                        intValue72 = maxValue22 < doubleValue102 ? 1 : 0;
                     }

                     int intValue6 = intValue72;
                     if (intValue6 == 0) {
                        break label132;
                     }
                  }

                  intValue += byteValue;
                  maxValue22 += doubleValue72;
                  continue;
               }
            }

            intValue2 += intValue5;
            doubleValue102 += maxValue3;
         }

         return arrayList;
      }
   }

   public static List computeList(double doubleValue, double doubleValue2, double doubleValue3, double doubleValue4) {
      return computeListForBiPredicate(doubleValue, doubleValue2, doubleValue3, doubleValue4, null);
   }

   static double computeDouble(double doubleValue, double doubleValue2, double doubleValue3, double doubleValue4) {
      double doubleValue5 = Math.min(doubleValue4, (doubleValue3 - doubleValue2) / 2.0);
      return MathHelper.clamp(doubleValue, doubleValue2 + doubleValue5, doubleValue3 - doubleValue5);
   }

   public static boolean testVec3d(Vec3d vec3d, Box box, Direction direction) {
      int intValue;
      switch (PlacementDirectionSwitchMap.DIRECTION_CASES[direction.ordinal()]) {
         case 1:

            intValue = vec3d.y > box.maxY ? 1 : 0;
            break;
         case 2:
            intValue = vec3d.y < BoxAccess2.getMinY(box) ? 1 : 0;
            break;
         case 3:
            if (BoxAccess2.getZ(vec3d) < BoxAccess2.getMinZ(box)) {
               intValue = 1;
            } else {
               intValue = 0;
            }
            break;
         case 4:
            byte byteValue = 9;
            ThreadLocalRandom.current().nextInt(7);
            if (vec3d.z > BoxAccess2.getMaxZ(box)) {
               intValue = 1;
            } else {
               intValue = 0;
            }
            break;
         case 5:

            intValue = vec3d.x < BoxAccess2.getMinX(box) ? 1 : 0;
            break;
         case 6:
            byte byteValue2 = 6;
            ThreadLocalRandom.current().nextInt(3);
            if (vec3d.x > BoxAccess2.getMaxX(box)) {
               intValue = 1;
            } else {
               byteValue2 = 18;
               ThreadLocalRandom.current().nextInt(14);
               intValue = 0;
            }
            break;
         default:
            throw new MatchException(null, null);
      }

      return (intValue != 0);
   }

   private static List computeList2(double doubleValue, double doubleValue2, double doubleValue3, double doubleValue4) {
      ArrayList arrayList = new ArrayList();
      int intValue = MathHelper.floor(doubleValue);
      int intValue2 = MathHelper.floor(doubleValue2);
      int intValue3 = MathHelper.floor(doubleValue3);
      int intValue4 = MathHelper.floor(doubleValue4);

      int[] intArray = new int[]{intValue, 0};

      intArray[1] = intValue2;
      arrayList.add(intArray);
      double doubleValue5 = doubleValue3 - doubleValue;
      double doubleValue6 = doubleValue4 - doubleValue2;

      byte byteValue;
      if (doubleValue5 > (0.0)) {
         byteValue = 1;
      } else {
         byteValue = -1;
      }

      byte byteValue2 = byteValue;

      int intValue5 = doubleValue6 > (0.0) ? 1 : -1;

      double maxValue;
      if (doubleValue5 == (0.0)) {
         maxValue = Double.MAX_VALUE;
      } else {
         maxValue = Math.abs((1.0) / doubleValue5);
      }

      double maxValue3 = maxValue;

      double doubleValue7;
      if (doubleValue6 == (0.0)) {
         doubleValue7 = (1.7976931348623157E308);
      } else {
         doubleValue7 = Math.abs(1.0 / doubleValue6);
      }

      double doubleValue72 = doubleValue7;
      double doubleValue9;
      if (doubleValue5 == 0.0) {
         doubleValue9 = (1.7976931348623157E308);
      } else {
         doubleValue9 = (doubleValue5 > 0.0 ? (double)(intValue + 1) - doubleValue : doubleValue - (double)intValue) * maxValue3;
      }

      double doubleValue92 = doubleValue9;
      double maxValue2;
      if (doubleValue6 == 0.0) {
         maxValue2 = Double.MAX_VALUE;
      } else {
         maxValue2 = (doubleValue6 > (0.0) ? (double)(intValue2 + 1) - doubleValue2 : doubleValue2 - (double)intValue2) * doubleValue72;
      }

      double maxValue22 = maxValue2;
      int intValue6 = Math.abs(intValue3 - intValue) + Math.abs(intValue4 - intValue2) + 2;

      while (intValue != intValue3 || intValue2 != intValue4) {
         if (intValue6-- <= 0) {
            byteValue = 14;
            ThreadLocalRandom.current().nextInt(13);
            break;
         }

         if (doubleValue92 < maxValue22) {
            intValue += byteValue2;
            doubleValue92 += maxValue3;
         } else {
            intValue2 += intValue5;
            maxValue22 += doubleValue72;
         }

         int[] intArray2 = new int[2];

         intArray2[0] = intValue;
         intArray2[1] = intValue2;
         arrayList.add(intArray2);
      }

      return arrayList;
   }

   public static double computeDouble2(float floatValue, float floatValue2, float[] floatArray, float floatValue3) {
      double doubleValue = hypot(floatValue, floatValue2, floatArray);

      return doubleValue + (2.0) * computeDouble3(floatArray[0], floatValue3);
   }

   public static double computeDouble3(float floatValue, float floatValue2) {
      if (Float.isNaN(floatValue2)) {
         return 0.0;
      } else {
         double doubleValue = (double)Math.abs(MathHelper.wrapDegrees(floatValue2 - floatValue)) % 45.0;
         return Math.min(doubleValue, 45.0 - doubleValue);
      }
   }

   public static double hypot(float floatValue, float floatValue2, float[] floatArray) {
      return Math.hypot((double)RotationMath.wrapDegrees(floatValue, floatArray[0]), (double)(floatArray[1] - floatValue2));
   }
}
