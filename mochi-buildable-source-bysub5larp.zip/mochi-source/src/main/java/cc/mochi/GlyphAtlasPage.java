package cc.mochi;

import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import net.minecraft.client.gl.GpuSampler;

final class GlyphAtlasPage {
   private int intState;
   public final TextureHandle textureHandle;

   private int intState2;
   private int intState3;
   public final GpuTexture gpuTexture;
   public final GpuTextureView gpuTextureView;

   public GlyphAtlasPage(int intValue) {
      this.gpuTexture = RenderSystem.getDevice().createTexture("Mochi glyphs " + intValue, 13, TextureFormat.RED8, 2048, 2048, 1, 1);
      this.gpuTextureView = RenderSystem.getDevice().createTextureView(this.gpuTexture);
      CommandEncoder commandEncoder = RenderSystem.getDevice().createCommandEncoder();
      commandEncoder.clearColorTexture(this.gpuTexture, 0);
      GpuSampler gpuSampler = RenderSystem.getSamplerCache().get(FilterMode.LINEAR);
      this.textureHandle = new TextureHandle(this.gpuTextureView, gpuSampler, 2048, 2048, true, false);
   }

   public int[] computeIntArray(int intValue, int intValue2) {
      if (intValue + 1 <= 2048 && intValue2 + 1 <= 2048) {
         if (this.intState3 + intValue + 1 > 2048) {
            this.intState = this.intState + this.intState2 + 1;
            this.intState3 = 0;
            this.intState2 = 0;
         }

         if (this.intState + intValue2 + 1 > 2048) {
            return null;
         } else {
            int[] intArray = new int[]{this.intState3, this.intState};
            this.intState3 += intValue + 1;
            this.intState2 = Math.max(this.intState2, intValue2);
            return intArray;
         }
      } else {
         return null;
      }
   }
}
