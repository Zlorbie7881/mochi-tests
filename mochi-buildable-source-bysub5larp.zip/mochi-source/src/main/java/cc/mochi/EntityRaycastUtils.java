package cc.mochi;

import java.util.Iterator;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public final class EntityRaycastUtils {
   private static boolean testLivingEntity(LivingEntity livingEntity, Entity entity) {
      byte byteValue;
      if (entity == livingEntity) {
         byteValue = 18;
         ThreadLocalRandom.current().nextInt(17);
         byteValue = 1;
      } else {
         byteValue = 0;
      }

      return (byteValue != 0);
   }

   public static boolean testMinecraftClient(MinecraftClient minecraftClient, Vec3d vec3d) {
      if (minecraftClient != null) {
         if (minecraftClient.player != null) {
            if (MinecraftClientAccess7.getWorld(minecraftClient) != null && vec3d != null) {
               Entity entity = minecraftClient.getCameraEntity() != null ? minecraftClient.getCameraEntity() : MinecraftClientAccess7.getPlayer(minecraftClient);

               Vec3d cameraPosVec = entity.getCameraPosVec((1.0F));
               BlockHitResult blockHitResult = MinecraftClientAccess7.getWorld(minecraftClient).raycast(new RaycastContext(cameraPosVec, vec3d, ShapeType.OUTLINE, FluidHandling.NONE, (Entity)entity));
               if (blockHitResult != null) {
                  if (blockHitResult.getType() != MinecraftClientAccess7.getMISS()) {
                     double doubleValue = cameraPosVec.squaredDistanceTo(blockHitResult.getPos());
                     double doubleValue2 = cameraPosVec.squaredDistanceTo(vec3d);

                     byte byteValue;
                     if (doubleValue >= doubleValue2 - (1.0E-4)) {
                        ThreadLocalRandom.current().nextInt(6);

                        byteValue = 1;
                     } else {
                        byteValue = 0;
                     }

                     return (byteValue != 0);
                  }
               }

               return true;
            }
         }
      }

      return false;
   }

   public static EntityHitResult computeEntityHitResultForMinecraftClient(MinecraftClient minecraftClient, double doubleValue) {
      if (minecraftClient != null) {
         if (MinecraftClientAccess7.getPlayer(minecraftClient) != null) {
            if (MinecraftClientAccess7.getWorld(minecraftClient) != null) {
               Object objectValue;
               if (minecraftClient.getCameraEntity() != null) {
                  objectValue = minecraftClient.getCameraEntity();
               } else {
                  objectValue = minecraftClient.player;
               }

               Entity entity = (Entity)objectValue;
               Vec3d cameraPosVec = entity.getCameraPosVec(1.0F);
               Vec3d rotationVec = entity.getRotationVec(1.0F);
               Vec3d vec3d = cameraPosVec.add(rotationVec.multiply(doubleValue));
               objectValue = entity.getBoundingBox().stretch(rotationVec.multiply(doubleValue));

               Box box = ((Box)objectValue).expand((1.0), 1.0, 1.0);
               EntityHitResult entityHitResult = ProjectileUtil.raycast((Entity)entity, cameraPosVec, vec3d, box, entity2 -> testEntity((Entity)entity2), doubleValue * doubleValue);
               if (entityHitResult == null) {
                  return null;
               }

               HitResult hitResult = entity.raycast(doubleValue, 1.0F, false);
               if (hitResult != null) {
                  if (hitResult.getType() != Type.MISS && cameraPosVec.squaredDistanceTo(hitResult.getPos()) < cameraPosVec.squaredDistanceTo(entityHitResult.getPos())) {
                     return null;
                  }
               }

               return entityHitResult;
            }
         }
      } else {
         ThreadLocalRandom.current().nextInt(3);
      }

      return null;
   }

   public static EntityHitResult computeEntityHitResultForMinecraftClient2(MinecraftClient minecraftClient, double doubleValue) {
      if (minecraftClient != null) {
         ThreadLocalRandom.current().nextInt(3);
         if (MinecraftClientAccess7.getPlayer(minecraftClient) != null) {
            if (minecraftClient.world != null) {
               if (!(doubleValue <= 0.0)) {
                  Entity entity = minecraftClient.getCameraEntity() != null ? minecraftClient.getCameraEntity() : MinecraftClientAccess7.getPlayer(minecraftClient);

                  Vec3d cameraPosVec = entity.getCameraPosVec((1.0F));
                  Vec3d rotationVec = entity.getRotationVec((1.0F));
                  EntityHitResult entityHitResult = computeEntityHitResultForMinecraftClient(minecraftClient, doubleValue);
                  if (entityHitResult != null) {
                     ThreadLocalRandom.current().nextInt(7);
                     return entityHitResult;
                  }

                  ThreadLocalRandom.current().nextInt(16);
                  Box box = entity.getBoundingBox().stretch(rotationVec.multiply(doubleValue)).expand(doubleValue);
                  EntityHitResult entityHitResult32 = null;

                  double doubleValue42 = (1.7976931348623157E308);
                  Iterator iterator = minecraftClient.world.getOtherEntities((Entity)entity, box, entity2 -> testEntity2((Entity)entity2)).iterator();

                  while (iterator.hasNext()) {
                     Entity entity3 = (Entity)iterator.next();
                     if (entity3 instanceof LivingEntity var13) {
                        double doubleValue3 = cameraPosVec.distanceTo(var13.getEntityPos());

                        if (!(doubleValue3 > doubleValue + (1.0))) {
                           Vec3d[] vec3dArray = computeVec3dArrayForLivingEntity(var13);
                           int length = vec3dArray.length;

                           for (int intValue = 0; intValue < length; intValue++) {
                              Vec3d vec3d = vec3dArray[intValue];
                              EntityHitResult entityHitResult3 = computeEntityHitResultForMinecraftClient3(minecraftClient, (Entity)entity, var13, cameraPosVec, rotationVec, vec3d, doubleValue);
                              if (entityHitResult3 != null) {
                                 ThreadLocalRandom.current().nextInt(11);
                                 double doubleValue4 = cameraPosVec.squaredDistanceTo(entityHitResult3.getPos());
                                 if (doubleValue4 < doubleValue42) {
                                    doubleValue42 = doubleValue4;
                                    entityHitResult32 = entityHitResult3;
                                 }
                              }
                           }
                        }
                     }
                  }

                  return entityHitResult32;
               }
            }
         }
      } else {
         ThreadLocalRandom.current().nextInt(3);
      }

      return null;
   }

   private static EntityHitResult computeEntityHitResultForMinecraftClient3(MinecraftClient minecraftClient, Entity entity, LivingEntity livingEntity, Vec3d vec3d, Vec3d vec3d2, Vec3d vec3d3, double doubleValue) {
      Vec3d vec3d22 = vec3d3.subtract(vec3d);
      double doubleValue2 = vec3d22.lengthSquared();

      if (doubleValue2 < (1.0E-8)) {
         vec3d22 = vec3d2;
      }

      vec3d22 = vec3d22.normalize();
      Vec3d vec3d5 = vec3d.add(vec3d22.multiply(doubleValue));
      Box boundingBox = livingEntity.getBoundingBox();

      Box box = boundingBox.expand((0.15));

      Box box2 = box.offset((0.0), 0.05, (0.0));
      EntityHitResult entityHitResult = ProjectileUtil.raycast(entity, vec3d, vec3d5, box2, entity2 -> testLivingEntity(livingEntity, (Entity)entity2), doubleValue * doubleValue);
      if (entityHitResult == null) {
         return null;
      } else {
         HitResult hitResult = entity.raycast(doubleValue, (1.0F), false);
         if (hitResult != null && hitResult.getType() != Type.MISS) {
            if (vec3d.squaredDistanceTo(hitResult.getPos()) < vec3d.squaredDistanceTo(entityHitResult.getPos())) {
               return null;
            }
         }

         return entityHitResult;
      }
   }

   private static boolean testEntity(Entity entity) {
      if (entity instanceof LivingEntity) {
         LivingEntity entity2 = (LivingEntity)entity;
         if (testEntity2(entity2)) {
            ThreadLocalRandom.current().nextInt(8);

            return true;
         }
      }

      return false;
   }

   private EntityRaycastUtils() {
   }

   private static boolean testEntity2(Entity entity) {
      if (entity instanceof LivingEntity var2) {
         if (!var2.isSpectator()) {
            if (var2.isAlive()) {
               if (var2 instanceof PlayerEntity var1) {
                  if (FriendManager.testPlayerEntity(var1)) {
                     return false;
                  }

                  ThreadLocalRandom.current().nextInt(15);
               }

               return true;
            }
         }
      }

      return false;
   }

   private static Vec3d[] computeVec3dArrayForLivingEntity(LivingEntity livingEntity) {
      Box boundingBox = livingEntity.getBoundingBox();
      Vec3d[] vec3dArray = new Vec3d[3];

      vec3dArray[0] = new Vec3d(livingEntity.getX(), livingEntity.getEyeY(), livingEntity.getZ());
      vec3dArray[1] = new Vec3d(livingEntity.getX(), boundingBox.minY + boundingBox.getLengthY() * 0.65, livingEntity.getZ());
      vec3dArray[2] = new Vec3d(livingEntity.getX(), MinecraftClientAccess7.getMinY(boundingBox) + boundingBox.getLengthY() * 0.25, livingEntity.getZ());
      return vec3dArray;
   }
}
