package cc.mochi;

public enum EasingType {
   LINEAR,
   EASE_IN,
   EASE_OUT,
   EASE_IN_OUT,
   BOUNCE,
   ELASTIC;

   private static EasingType[] createValues() {
      return new EasingType[]{LINEAR, EASE_IN, EASE_OUT, EASE_IN_OUT, BOUNCE, ELASTIC};
   }
}
