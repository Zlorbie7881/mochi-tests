package cc.mochi;

import cc.mochi.event.impl.player.TickEndEvent;
import cc.mochi.event.impl.render.Render2DEvent;
import cc.mochi.event.impl.world.WorldChangeEvent;
import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.concurrent.locks.LockSupport;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.MinecraftClient;

public final class ActionSchedulers {
   private final TickActionScheduler tickActionScheduler;

   private final TickActionScheduler tickActionScheduler2;
   private static final ActionSchedulers INSTANCE = new ActionSchedulers();
   private final ArrayDeque<DelayedAction> delayedActionArrayDeque = new ArrayDeque<>();
   private final TickActionScheduler tickActionScheduler3;

   @EventHandler
   private void onRender2D(Render2DEvent render2DEvent) {
      this.updateState(false);
   }

   @EventHandler
   private void onWorldChange(WorldChangeEvent worldChangeEvent) {
      if (worldChangeEvent.getWorld() != MinecraftClient.getInstance().world) {
         updateState5();
      }
   }

   private void removeIf(String string) {
      getDelayedActionArrayDeque(this).removeIf(delayedAction -> equals(string, delayedAction));
   }

   private void updateState(boolean booleanValue) {
      getTickActionScheduler(this).runDueActions();
      if (!(this.delayedActionArrayDeque.isEmpty())) {
         long longValue = System.currentTimeMillis();
         Iterator iterator = this.delayedActionArrayDeque.iterator();

         while (iterator.hasNext()) {
            DelayedAction delayedAction = (DelayedAction)iterator.next();
            if (!booleanValue) {
               if (longValue < delayedAction.dueAtMs()) {
                  continue;
               }
            }

            iterator.remove();

            try {
               delayedAction.action().run();
            } catch (Throwable failure) {
            }
         }
      }
   }

   public static void updateStateForRunnable(String string, long longValue, Runnable runnable) {
      if (runnable != null) {
         ActionSchedulers instance3 = getINSTANCE();
         long longValue2 = System.currentTimeMillis();
         long longValue3 = Math.max(0L, longValue);

         long longValue4 = Math.min(longValue3, 50L);
         if (string != null) {
            instance3.removeIf(string);
         }

         getDelayedActionArrayDeque(instance3).addLast(new DelayedAction(string, longValue2 + longValue4, runnable));
      }
   }

   public static TickActionScheduler getTickActionScheduler3(ActionSchedulers actionSchedulers) {
      return actionSchedulers.tickActionScheduler3;
   }

   public static TickActionScheduler getTickActionScheduler2(ActionSchedulers actionSchedulers) {
      return actionSchedulers.tickActionScheduler2;
   }

   private ActionSchedulers() {
      this.tickActionScheduler = new TickActionScheduler(() -> System.nanoTime());
      this.tickActionScheduler3 = new TickActionScheduler(() -> System.nanoTime());
      this.tickActionScheduler2 = new TickActionScheduler(() -> System.nanoTime());
   }

   public static ActionSchedulers getINSTANCE() {
      return INSTANCE;
   }

   public static void schedule(Object objectValue, Runnable runnable, Runnable runnable2) {
      INSTANCE.tickActionScheduler2.schedule(objectValue, 1L, runnable, runnable2);
   }

   @EventHandler
   private void onTickEnd(TickEndEvent tickEndEvent) {
      this.updateState(true);
   }

   public static boolean checkCondition(String string) {
      if (string == null) {
         return false;
      } else {
         Iterator iterator = getINSTANCE().delayedActionArrayDeque.iterator();

         while (iterator.hasNext()) {
            DelayedAction delayedAction = (DelayedAction)iterator.next();
            if (string.equals(delayedAction.key())) {
               return true;
            }
         }

         return false;
      }
   }

   public static void schedule2(Object objectValue, Runnable runnable, Runnable runnable2) {
      INSTANCE.tickActionScheduler3.schedule(objectValue, 1L, runnable, runnable2);
   }

   public static ArrayDeque<DelayedAction> getDelayedActionArrayDeque(ActionSchedulers actionSchedulers) {
      return actionSchedulers.delayedActionArrayDeque;
   }

   public static long getCurrentTick22() {
      return getTickActionScheduler(getINSTANCE()).getCurrentTick22();
   }

   public static TickActionScheduler getTickActionScheduler(ActionSchedulers actionSchedulers) {
      return actionSchedulers.tickActionScheduler;
   }

   public static void finishTick() {
      INSTANCE.tickActionScheduler3.finishTick(longValue -> LockSupport.parkNanos(longValue));
   }

   public static void updateState2(String string) {
      if ((string != null)) {
         INSTANCE.removeIf(string);
      }
   }

   public static void updateState3() {
      INSTANCE.tickActionScheduler.beginTick();
      INSTANCE.tickActionScheduler3.beginTick();
      INSTANCE.tickActionScheduler2.beginTick();
   }

   public static String key(DelayedAction delayedAction) {
      return delayedAction.key();
   }

   public static void schedule3(Object objectValue, long longValue, Runnable runnable, Runnable runnable2) {
      INSTANCE.tickActionScheduler.schedule(objectValue, longValue, runnable, runnable2);
   }

   private static boolean equals(String string, DelayedAction delayedAction) {
      return string.equals(key(delayedAction));
   }

   public static void finishTick2() {
      getTickActionScheduler2(getINSTANCE()).finishTick(longValue -> LockSupport.parkNanos(longValue));
   }

   public static void updateState4(Object objectValue) {
      INSTANCE.tickActionScheduler.cancel(objectValue);
      getTickActionScheduler3(INSTANCE).cancel(objectValue);
      getTickActionScheduler2(INSTANCE).cancel(objectValue);
   }

   public static void updateState5() {
      getDelayedActionArrayDeque(INSTANCE).clear();
      getINSTANCE().tickActionScheduler.clear();
      getTickActionScheduler3(INSTANCE).clear();
      getTickActionScheduler2(INSTANCE).clear();
   }

}
