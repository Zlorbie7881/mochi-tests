package cc.mochi;

import cc.mochi.mixin.RenderLayerAccessor;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.client.model.Model;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.RenderSetup.Texture;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.render.model.BakedQuad;
import net.minecraft.client.texture.GlTexture;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.entity.Entity;
import org.joml.Matrix4fc;

public final class ItemMeshRenderer {
   private static volatile EntityFlagProvider entityFlagProvider;

   public static final ItemMeshContext itemMeshContext3 = new ItemMeshContext();
   private static final ItemMeshContext itemMeshContext2 = new ItemMeshContext();
   private static int counter;

   private static final VertexCollector vertexCollector = new VertexCollector();

   private static ItemMeshContext itemMeshContext = ItemMeshRenderer.itemMeshContext3;

   private static boolean booleanState;
   private static volatile boolean booleanState2;

   private static boolean booleanState3;
   private static final Map<EntityRenderState, Integer> integerByEntityRenderState = new IdentityHashMap<>();

   private static final Map<RenderLayer, Integer> integerByRenderLayer = new IdentityHashMap<>();

   private static int intState;

   private static boolean testRenderLayer(RenderLayer renderLayer) {
      if (renderLayer == null) {
         return false;
      } else {
         Integer integer = integerByRenderLayer.get(renderLayer);
         if (integer == null) {
            integer = computeIntForRenderLayer(renderLayer);
            integerByRenderLayer.put(renderLayer, integer);
         }

         if (integer < 0) {
            return false;
         } else {
            vertexCollector.updateState2();
            itemMeshContext.mesh.updateState(integer);
            return true;
         }
      }
   }

   public static Matrix4fc getTransform() {
      return itemMeshContext2.transform;
   }

   public static void updateStateForEntity(Entity entity, EntityRenderState entityRenderState) {
      EntityFlagProvider entityFlagProvider2 = entityFlagProvider;
      if (booleanState && entityFlagProvider2 != null && entity != null && entityRenderState != null) {
         int intValue;
         try {
            intValue = entityFlagProvider2.flags(entity);
         } catch (RuntimeException failure) {
            return;
         }

         if ((intValue & 1) != 0) {
            integerByEntityRenderState.put(entityRenderState, intValue);
         }
      }
   }

   public static MeshBuffer computeMeshBuffer() {
      return itemMeshContext3.glint ? itemMeshContext3.mesh : null;
   }

   private static VertexConsumer computeVertexConsumerForSprite(Sprite sprite) {
      return (VertexConsumer)(sprite == null ? vertexCollector : sprite.getTextureSpecificVertexConsumer(vertexCollector));
   }

   public static void updateState() {
      if (booleanState3) {
         vertexCollector.updateState();
         itemMeshContext2.mesh.updateState6();
         booleanState3 = false;
         intState = 0;
         counter = 0;
         integerByRenderLayer.clear();
         updateStateForItemMeshContext(itemMeshContext3);
         itemMeshContext2.glint = entityFlagProvider != null && itemMeshContext2.mesh.getCounter() > 0;
      }
   }

   private static int computeIntForRenderLayer(RenderLayer renderLayer) {
      if (renderLayer.getDrawMode() != DrawMode.QUADS) {
         return -1;
      } else {
         try {
            RenderLayerAccessor renderLayer2 = (RenderLayerAccessor)renderLayer;
            String string = renderLayer2.mochi$getName();
            string = string == null ? "" : string.toLowerCase(Locale.ROOT);
            if (!string.contains("glint")
               && !string.contains("energy_swirl")
               && !string.contains("shadow")
               && !string.contains("crumbling")
               && !string.startsWith("outline")) {
               RenderSetup renderSetup = renderLayer2.mochi$getRenderSetup();
               Texture texture = (Texture)renderSetup.resolveTextures().get("Sampler0");
               if (texture == null) {
                  return 0;
               } else {
                  GpuTextureView gpuTextureView = texture.textureView();
                  return gpuTextureView != null && gpuTextureView.texture() instanceof GlTexture var6 ? var6.getGlId() : -1;
               }
            } else {
               return -1;
            }
         } catch (RuntimeException failure) {
            return -1;
         }
      }
   }

   public static void updateStateForEntityRenderState(EntityRenderState entityRenderState) {
      if (booleanState) {
         updateState6();
         Integer integer = integerByEntityRenderState.get(entityRenderState);
         if (integer != null) {
            intState = integer;
            counter = 0;
            itemMeshContext3.mesh.updateState5();
         }
      }
   }

   private static boolean checkCondition() {
      if (intState == 0) {
         return false;
      } else {
         return booleanState3 ? counter > 0 : counter == 0 || (intState & 2) != 0;
      }
   }

   private ItemMeshRenderer() {
   }

   public static Matrix4fc getTransform2() {
      return itemMeshContext3.transform;
   }

   public static void updateStateForEntityFlagProvider(EntityFlagProvider entityFlagProvider2) {
      entityFlagProvider = entityFlagProvider2;
      if (entityFlagProvider2 == null && RenderSystem.isOnRenderThread()) {
         updateState2();
         itemMeshContext2.reset();
      }
   }

   public static void reset() {
      itemMeshContext3.reset();
   }

   public static void updateStateForModelPart(ModelPart modelPart, MatrixStack matrixStack, RenderLayer renderLayer, int intValue, int intValue2, Sprite sprite) {
      if (checkCondition() && testRenderLayer(renderLayer)) {
         try {
            modelPart.render(matrixStack, computeVertexConsumerForSprite(sprite), intValue, intValue2);
         } catch (RuntimeException failure) {
         } finally {
            vertexCollector.updateState();
         }
      }
   }

   public static void updateStateForModel(Model model, Object objectValue, MatrixStack matrixStack, RenderLayer renderLayer, int intValue, int intValue2, Sprite sprite) {
      if (checkCondition() && testRenderLayer(renderLayer)) {
         try {
            model.setAngles(objectValue);
            model.render(matrixStack, computeVertexConsumerForSprite(sprite), intValue, intValue2, -1);
         } catch (RuntimeException failure) {
         } finally {
            vertexCollector.updateState();
         }
      }
   }

   public static void updateStateForMatrixStack(MatrixStack matrixStack, List list, RenderLayer renderLayer, int intValue, int intValue2) {
      if (checkCondition() && list != null && !list.isEmpty() && testRenderLayer(renderLayer)) {
         try {
            Entry entry = matrixStack.peek();

            for (BakedQuad bakedQuad : (java.lang.Iterable<BakedQuad>)(java.lang.Iterable<?>)(list)) {
               vertexCollector.quad(entry, bakedQuad, 1.0F, 1.0F, 1.0F, 1.0F, intValue, intValue2);
               vertexCollector.updateState();
            }
         } catch (RuntimeException failure) {
         } finally {
            vertexCollector.updateState();
         }
      }
   }

   private static void updateState2() {
      booleanState = false;
      booleanState3 = false;
      intState = 0;
      counter = 0;
      integerByEntityRenderState.clear();
      integerByRenderLayer.clear();
      vertexCollector.updateState2();
      itemMeshContext3.reset();
      updateStateForItemMeshContext(itemMeshContext3);
   }

   public static void updateState3() {
      if (booleanState) {
         vertexCollector.updateState();
         itemMeshContext3.mesh.updateState6();
         booleanState = false;
         intState = 0;
         counter = 0;
         integerByEntityRenderState.clear();
         integerByRenderLayer.clear();
         itemMeshContext3.glint = entityFlagProvider != null && itemMeshContext3.mesh.getCounter() > 0;
      }
   }

   public static void updateStateForMatrix4fc(Matrix4fc matrix4fc, Matrix4fc matrix4fc2) {
      itemMeshContext2.reset();
      if (entityFlagProvider != null && booleanState2 && !booleanState) {
         matrix4fc2.mul(matrix4fc, itemMeshContext2.transform);
         updateStateForItemMeshContext(itemMeshContext2);
         booleanState3 = true;
         intState = 3;
         counter = 0;
         itemMeshContext2.mesh.updateState5();
      }
   }

   public static void updateStateForMatrix4fc2(Matrix4fc matrix4fc, Matrix4fc matrix4fc2) {
      updateState2();
      itemMeshContext2.reset();
      if (entityFlagProvider != null) {
         matrix4fc2.mul(matrix4fc, itemMeshContext3.transform);
         updateStateForItemMeshContext(itemMeshContext3);
         booleanState = true;
      }
   }

   public static void updateState4() {
      if (intState != 0 && counter > 0) {
         counter--;
      }
   }

   public static void setBooleanState2(boolean booleanState22) {
      booleanState2 = booleanState22;
   }

   private static void updateStateForItemMeshContext(ItemMeshContext itemMeshContext4) {
      vertexCollector.updateState();
      itemMeshContext = itemMeshContext4;
      vertexCollector.meshBuffer = itemMeshContext4.mesh;
   }

   public static void updateState5() {
      if (intState != 0) {
         counter++;
      }
   }

   public static void reset2() {
      itemMeshContext2.reset();
   }

   public static void updateState6() {
      if (booleanState && intState != 0) {
         vertexCollector.updateState();
         itemMeshContext3.mesh.updateState6();
         intState = 0;
      }
   }

   public static MeshBuffer computeMeshBuffer2() {
      return itemMeshContext2.glint ? itemMeshContext2.mesh : null;
   }
}
