package cc.mochi;

public final class JumpCircleInstance {
   public final float[] floatArray;
   public float floatState;

   public float floatState2;
   public float floatState3;

   public final float[] floatArray2 = new float[3];

   public float floatState4;

   public float floatState5;
   public float floatState6;

   public float floatState7;

   public final float[] floatArray3 = new float[3];
   public float floatState8;

   public float floatState9;

   public float floatState10;

   public float floatState11;
   public float floatState12;
   public float floatState13;

   public int intState;

   public float floatState14;
   public float floatState15;

   public float floatState16;

   public float floatState17;
   public float floatState18;

   public JumpCircleInstance() {
      this.floatArray = new float[3];
   }
}
