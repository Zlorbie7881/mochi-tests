package cc.mochi;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.MinecraftClient;

public final class KeybindsScreen extends UiScreen {
   private final TextInputModel textInputModel = new TextInputModel(32);

   private static final int[] MOUSE_BUTTON_ORDER;

   private boolean booleanState;
   private String string;

   private static final String[] MOUSE_BUTTON_LABELS;
   private final ScrollModel scrollModel;

   private KeyboardKey keyboardKey;
   private Module module3;
   private static final List<String> KEYBOARD_LAYOUTS = List.of("Full", "TKL", "60%");
   private final ConfirmationDialog confirmationDialog;

   private static String selectedKeyboardLayout;

   private final KeybindCapture keybindCapture = new KeybindCapture();
   private Module module4;

   private void updateStateForModule(Module module32) {
      ThreadLocalRandom.current().nextInt(3);

      KeybindSetting keybind = module32.getKeybind();
      if (keybind == null) {
         ThreadLocalRandom.current().nextInt(8);
      } else {
         ThreadLocalRandom.current().nextInt(3);
         this.module3 = module32;
         getKeybindCapture(this).updateStateForKeybindSetting(keybind, module32.getName());
      }
   }

   public static TextInputModel getTextInputModel(KeybindsScreen keybindsScreen) {
      return keybindsScreen.textInputModel;
   }

   public static List<String> getStringList() {
      return KEYBOARD_LAYOUTS;
   }

   private void updateStateForUiContext(UiContext uiContext2, Rect rect, float opacity) {
      uiContext2.getThemeSnapshot();
      float x62 = rect.getX() + 8.0F;
      float y5 = rect.getY();

      Rect rect2 = new Rect(x62, y5 + (8.0F), rect.getWidth() - 16.0F, 22.0F);
      TextInputWidget.updateStateForUiContext(uiContext2, "binds.search", rect2, UiLayer.BASE, getTextInputModel(this), "Find an action", Icon.SEARCH, opacity);
      x62 = rect.getX();

      Rect rect3 = new Rect(x62 + (4.0F), rect2.bottom() + 6.0F, rect.getWidth() - 8.0F, rect.bottom() - rect2.bottom() - 10.0F);
      List list = this.computeListForUiContext(uiContext2);
      if (list.isEmpty()) {
         EmptyStateWidget.updateStateForUiContext(uiContext2, rect3, Icon.SEARCH, "No actions match", "Try another name.", opacity);
      } else {
         float contentHeight = 0.0F;

         for (GroupedModule groupedModule : (java.lang.Iterable<GroupedModule>)(java.lang.Iterable<?>)(list)) {
            contentHeight += groupedModule.module() == null ? (20.0F) : 26.0F;
         }

         float floatValue3 = this.scrollModel.update(uiContext2, contentHeight, rect3.getHeight());
         uiContext2.getInputRouter().addScrollRegion(rect3, UiLayer.BASE, wheelDelta -> this.scrollModel.scroll(wheelDelta));
         uiContext2.getUiRenderContext().pushClip(rect3.getX(), rect3.getY(), rect3.getWidth(), rect3.getHeight());
         float floatValue4 = rect3.getY() - floatValue3;
         Iterator iterator = list.iterator();

         while (iterator.hasNext()) {
            GroupedModule groupedModule2 = (GroupedModule)iterator.next();
            if (groupedModule2.module() == null) {
               String[] stringArray = groupedModule2.group().split("\u0000");
               if (floatValue4 + 20.0F >= rect3.getY()) {
                  if (floatValue4 <= rect3.bottom()) {
                     float x = rect3.getX() + 6.0F;
                     x62 = floatValue4 + 10.0F;

                     x62 += (1.0F);
                     y5 = rect3.getWidth() - 12.0F;

                     SectionHeaderWidget.updateStateForUiContext(uiContext2, x, x62, y5, stringArray[0], stringArray[1], opacity);
                  }
               }

               floatValue4 += (20.0F);
            } else {
               x62 = rect3.getX();

               x62 += (2.0F);
               float floatValue6 = rect3.getWidth() - 4.0F;

               Rect rect4 = new Rect(x62, floatValue4, floatValue6, (24.0F));
               if (rect4.bottom() >= rect3.getY() && rect4.getY() <= rect3.bottom()) {
                  this.updateStateForUiContext5(uiContext2, groupedModule2.module(), rect4, rect3, opacity);
               }

               floatValue4 += 26.0F;
            }
         }

         uiContext2.getUiRenderContext().popClip();
         getScrollModel(this).drawScrollbar(uiContext2, rect3, contentHeight, opacity);
      }
   }

   private void updateState() {
      getKeybindCapture(this).updateState();
      if (MochiClient.INSTANCE != null) {
         UiControlAccess.getINSTANCE().getProfileManager().updateState3("default", true);
      }

      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (minecraftClient != null) {
         minecraftClient.setScreen(new ClickGuiScreen());
      }
   }

   public static Module module(GroupedModule groupedModule) {
      return groupedModule.module();
   }

   private static void updateState2(int intValue, double doubleValue, double doubleValue2) {
   }

   public static ScrollModel getScrollModel(KeybindsScreen keybindsScreen) {
      return keybindsScreen.scrollModel;
   }

   public static Module getModule3(KeybindsScreen keybindsScreen) {
      return keybindsScreen.module3;
   }

   public static Module module2(GroupedModule groupedModule) {
      return groupedModule.module();
   }

   private static List computeList() {
      ModuleManager moduleManager;
      if (MochiClient.INSTANCE == null) {
         moduleManager = null;
      } else {
         moduleManager = MochiClient.INSTANCE.getModuleManager();
      }

      ModuleManager moduleManager2 = moduleManager;
      if (moduleManager2 != null) {
         if (moduleManager2.getModules() != null) {
            return moduleManager2.getModules();
         }
      }

      return List.of();
   }

   public static boolean getBooleanState(KeybindsScreen keybindsScreen) {
      return keybindsScreen.booleanState;
   }

   @Override
   protected boolean checkCondition(int keyCode, boolean booleanValue, boolean booleanValue2) {
      if (getKeybindCapture(this).checkCondition3(keyCode)) {
         setModule3(this, null);
         return true;
      } else if (this.confirmationDialog.getBooleanState2()) {
         if (keyCode == 256) {
            getConfirmationDialog(this).updateState2();
         }

         return true;
      } else if (this.textInputModel.getBooleanState2()) {
         if (keyCode == 256) {
            if (!getTextInputModel(this).isEmpty()) {
               getTextInputModel(this).updateState2();
            } else {
               this.textInputModel.updateState3(false);
            }

            return true;
         } else {
            if (keyCode != 257) {
               if (keyCode != 335) {
                  getTextInputModel(this).checkCondition(keyCode, booleanValue);
                  return true;
               }
            }

            for (GroupedModule groupedModule : (java.lang.Iterable<GroupedModule>)(java.lang.Iterable<?>)(this.computeListForUiContext(this.uiContext))) {
               if (module2(groupedModule) != null) {
                  this.updateStateForModule(module(groupedModule));
                  break;
               }
            }

            this.textInputModel.updateState3(false);

            return true;
         }
      } else if (keyCode == 256) {
         this.updateState();
         return true;
      } else {
         label115: {
            if (booleanValue) {
               if (keyCode == 70) {
                  break label115;
               }
            }

            if (keyCode != 47) {
               return false;
            }
         }

         getTextInputModel(this).updateState3(true);
         setBooleanState(this, ((keyCode == 47 ? 1 : 0) != 0));

         return true;
      }
   }

   private void updateStateForModule2(Module module42) {
      setModule4(this, module42);
      getTextInputModel(this).updateState2();
      List list = this.computeListForUiContext(this.uiContext);

      float floatValue = (0.0F);
      Iterator iterator = list.iterator();

      while (iterator.hasNext()) {
         GroupedModule groupedModule = (GroupedModule)iterator.next();
         if (groupedModule.module() == module42) {
            ThreadLocalRandom.current().nextInt(17);

            this.scrollModel.ensureVisible(floatValue - (20.0F), floatValue + 26.0F + 20.0F, 200.0F);
            break;
         }

         ThreadLocalRandom.current().nextInt(17);

         floatValue += groupedModule.module() == null ? (20.0F) : 26.0F;
      }

      UiAnimations uiAnimations5 = this.uiContext.getAnimations();
      String name = module42.getName();
      uiAnimations5.setValueForId("binds.flash." + name, 1.0F);
   }

   private void updateStateForUiContext2(UiContext uiContext2, String string2, List list, int intValue, double doubleValue, double doubleValue2) {
      ThreadLocalRandom.current().nextInt(13);
      UiAnimations uiAnimations5 = uiContext2.getAnimations();
      String string3 = string2 + ".p";

      uiAnimations5.setValueForId(string3, (1.0F));
      if (intValue != 1) {
         if (!list.isEmpty()) {
            this.updateStateForModule2((Module)list.get(0));
            ClientSounds.updateState5();
         } else {
            ClientSounds.updateState();
         }
      } else {
         if (!list.isEmpty()) {
            for (Module module : (java.lang.Iterable<Module>)(java.lang.Iterable<?>)(list)) {
               module.setKeyCode(-1);
            }

            ClientSounds.updateState2();
         }
      }
   }

   public static KeybindCapture getKeybindCapture(KeybindsScreen keybindsScreen) {
      return keybindsScreen.keybindCapture;
   }

   private static void updateState3() {
      Iterator iterator = computeList().iterator();

      while (true) {
         if (!iterator.hasNext()) {
            return;
         }

         Module module = (Module)iterator.next();
         module.setKeyCode(-1);
      }
   }

   public static void setKeyboardKey(KeybindsScreen keybindsScreen, KeyboardKey keyboardKey2) {
      keybindsScreen.keyboardKey = keyboardKey2;
   }

   public static ConfirmationDialog getConfirmationDialog(KeybindsScreen keybindsScreen) {
      return keybindsScreen.confirmationDialog;
   }

   public static void setModule4(KeybindsScreen keybindsScreen, Module module42) {
      keybindsScreen.module4 = module42;
   }

   @Override
   protected void updateStateForUiContext6(UiContext uiContext2, float floatValue, float floatValue2, float opacity) {
      ThemeSnapshot themeSnapshot2 = uiContext2.getThemeSnapshot();
      if (!getKeybindCapture(this).checkCondition2()) {
         setModule3(this, null);
      }

      float centerX = floatValue / 2.0F;
      float floatValue5 = floatValue2 / 2.0F;

      floatValue5 += (10.0F);

      float width2 = Math.min(floatValue - (20.0F), 860.0F);

      float floatValue7 = floatValue2 - (50.0F);

      Rect rect = Rect.centered(centerX, floatValue5, width2, Math.min(floatValue7, (440.0F)));
      uiContext2.getUiRenderContext().pushTransform();
      uiContext2.getUiRenderContext().translate(0.0F, ((1.0F) - opacity) * 10.0F);
      PanelRenderer.updateStateForUiContext5(uiContext2, rect, 18.0F, opacity);
      uiContext2.getInputRouter().addPressRegion(rect, UiLayer.BASE, (intValue, doubleValue, doubleValue2) -> updateState2(intValue, doubleValue, doubleValue2));
      float centerY = rect.getY() + 24.0F;

      int intValue2 = 0;
      Iterator iterator = computeList().iterator();

      while (iterator.hasNext()) {
         Module module = (Module)iterator.next();
         if (KeybindCapture.checkCondition5(module.getKeyCode())) {
            intValue2++;
         }
      }

      UiRenderContext uiRenderContext = uiContext2.getUiRenderContext();
      floatValue5 = rect.getX() + 14.0F;

      uiRenderContext.fillRoundedRect(
         floatValue5,
         centerY - (11.0F),
         (22.0F),
         22.0F,
         (7.0F),
         UiContext.multiplyAlpha(themeSnapshot2.getAccentSoft2(), 1.4F * opacity)
      );
      UiRenderContext uiRenderContext2 = uiContext2.getUiRenderContext();
      Icon keyboard = Icon.KEYBOARD;
      float x62 = rect.getX();

      UiShapeRenderer.updateStateForUiRenderContext3(uiRenderContext2, keyboard, x62 + (25.0F), centerY, 12.0F, UiContext.multiplyAlpha(themeSnapshot2.getAccentText2(), opacity));
      float x = rect.getX() + (44.0F);

      uiContext2.drawVerticallyCenteredText("Key binds", x, centerY - (5.0F), TextStyle.TITLE, UiContext.multiplyAlpha(themeSnapshot2.getPrimaryText(), opacity));

      String string2 = intValue2 == 1 ? " bind" : " binds";
      String text = intValue2 + string2 + "  ·  click an action, then press a key";
      float x2 = rect.getX() + 44.0F;

      uiContext2.drawVerticallyCenteredText(text, x2, centerY + (8.0F), TextStyle.CAPTION, UiContext.multiplyAlpha(themeSnapshot2.getSecondaryText2(), opacity));
      float floatValue11 = rect.right() - 36.0F;

      float floatValue12 = centerY - (11.0F);

      Rect rect2 = new Rect(floatValue11, floatValue12, (22.0F), 22.0F);
      ButtonWidgets.updateStateForUiContext2(uiContext2, "binds.close", rect2, UiLayer.BASE, Icon.CLOSE, opacity, () -> this.updateState());
      float floatValue13 = ButtonWidgets.computeFloatForUiContext(uiContext2, "Clear all", Icon.RESET);
      float x622 = rect2.getX();

      Rect rect3 = new Rect(x622 - (8.0F) - floatValue13, centerY - 10.0F, floatValue13, (20.0F));
      int intValue22 = intValue2;
      ButtonWidgets.updateStateForUiContext(uiContext2, "binds.reset", rect3, UiLayer.BASE, ButtonVariant.GHOST, "Clear all", Icon.RESET, ((intValue22 > 0 ? 1 : 0) != 0), opacity, () -> this.updateState4(intValue22));
      float floatValue14 = rect3.getX() - (12.0F);

      Rect rect4 = new Rect(floatValue14 - (150.0F), centerY - (10.0F), 150.0F, (20.0F));
      cc.mochi.ChoiceDropdown.updateStateForUiContext(uiContext2, "binds.layout", rect4, UiLayer.BASE, getStringList(), KEYBOARD_LAYOUTS.indexOf(getString2()), opacity, intValue4 -> updateSelectedKeyboardLayout(intValue4));
      float x623 = rect.getX();

      Rect rect5 = new Rect(x623 + (10.0F), rect.getY() + (50.0F), rect.getWidth() - 20.0F, rect.getHeight() - 60.0F);
      Rect rect6 = new Rect(rect5.getX(), rect5.getY(), rect5.getWidth() - 236.0F - (8.0F), rect5.getHeight());
      float floatValue15 = rect6.right() + 8.0F;
      float y5 = rect5.getY();

      Rect rect7 = new Rect(floatValue15, y5, (236.0F), rect5.getHeight());
      PanelRenderer.updateStateForUiContext9(uiContext2, rect6, 12.0F, opacity);
      PanelRenderer.updateStateForUiContext9(uiContext2, rect7, 12.0F, opacity);
      this.updateStateForUiContext4(uiContext2, rect6, opacity);
      this.updateStateForUiContext(uiContext2, rect7, opacity);
      uiContext2.getUiRenderContext().popTransform();
      if (this.keybindCapture.checkCondition2()) {
         String string4 = this.keybindCapture.getString();
         this.string = "Binding " + string4 + "  ·  press a key or mouse button  ·  Esc clears";
      }

      if (this.string != null) {
         uiContext2.getUiRenderContext().flushBloom();
         float floatValue16 = floatValue / (2.0F);

         ToggleWidget.updateStateForUiContext(
            uiContext2,
            "binds.banner",
            floatValue16,
            Math.max((6.0F), rect.getY() - (30.0F)),
            this.string,
            ControlTone.ACCENT,
            this.keybindCapture.checkCondition2(),
            opacity
         );
      }

      getConfirmationDialog(this).updateStateForUiContext(uiContext2, "binds.dialog", floatValue, floatValue2, opacity);
   }

   public static String[] getStringArray() {
      return MOUSE_BUTTON_LABELS;
   }

   private void updateStateForUiContext3(UiContext uiContext2, KeyboardKey keyboardKey2, Rect rect, float floatValue) {
      ThemeSnapshot themeSnapshot2;
      List list;
      int intValue;
      byte byteValue;
      label118: {
         themeSnapshot2 = uiContext2.getThemeSnapshot();
         list = computeList2(keyboardKey2.getCode());
         intValue = !list.isEmpty() ? 1 : 0;
         if (this.module3 != null) {
            if (list.contains(this.module3)) {
               byteValue = 1;
               break label118;
            }
         }

         byteValue = 0;
      }

      byte byteValue2 = byteValue;
      boolean hovered = uiContext2.isHovered(rect, UiLayer.BASE);
      if (hovered) {
         setKeyboardKey(this, keyboardKey2);
      }

      int code = keyboardKey2.getCode();
      String string2 = "binds.cap." + code;
      float progress = uiContext2.animateHover(string2, hovered);
      String string3 = string2 + ".lit";

      float progress2 = uiContext2.animateToggle(string3, (intValue != 0), (0.045F));
      UiAnimations uiAnimations5 = uiContext2.getAnimations();
      string3 = string2 + ".p";

      float floatValue4 = uiAnimations5.animateTo(string3, (0.0F), (0.05F));

      Rect rect2 = rect.translate((0.0F), floatValue4 * (1.2F));
      uiContext2.getUiRenderContext()
         .fillRoundedRect(
            rect.getX(),
            rect.getY() + 1.6F,
            rect.getWidth(),
            rect.getHeight(),
            (4.5F),
            UiContext.multiplyAlpha(Color.BLACK, (themeSnapshot2.getLight4() ? (0.1F) : (0.32F)) * floatValue)
         );
      Color surfaceRaised = themeSnapshot2.getSurfaceRaised();
      Color surfaceSunken = themeSnapshot2.getSurfaceSunken();

      Color color = UiContext.blendColors(UiContext.blendColors(surfaceRaised, surfaceSunken, (0.4F)), themeSnapshot2.getSurfaceRaised(), progress);
      Color accent2 = UiContext.blendColors(color, UiContext.blendColors(themeSnapshot2.getSurfaceRaised(), themeSnapshot2.getAccent2(), (0.32F) + 0.1F * progress), progress2);
      if (byteValue2 != 0) {
         accent2 = themeSnapshot2.getAccent2();
      }

      label122: {
         uiContext2.getUiRenderContext().fillRoundedRect(rect2.getX(), rect2.getY(), rect2.getWidth(), rect2.getHeight(), (4.5F), UiContext.multiplyAlpha(accent2, floatValue));
         UiRenderContext uiRenderContext = uiContext2.getUiRenderContext();
         float x62 = rect2.getX();
         float y5 = rect2.getY();
         float w22 = rect2.getWidth();
         float height2 = rect2.getHeight() * 0.55F;

         Color topColor = UiContext.multiplyAlpha(UiControlAccess.getWHITE(), (themeSnapshot2.getLight4() ? 0.16F : (0.05F)) * floatValue);

         uiRenderContext.fillVerticalGradient(x62, y5, w22, height2, (4.5F), topColor, UiContext.multiplyAlpha(Color.WHITE, (0.0F)));
         if (!(progress2 > 0.01F)) {
            if (byteValue2 == 0) {
               uiContext2.getUiRenderContext()
                  .strokeRoundedRect(
                     rect2.getX(),
                     rect2.getY(),
                     rect2.getWidth(),
                     rect2.getHeight(),
                     4.5F,
                     1.0F,
                     UiContext.multiplyAlpha(UiContext.blendColors(themeSnapshot2.getHairline2(), themeSnapshot2.getAccent2(), (0.4F) * progress), floatValue)
                  );
               break label122;
            }
         }

         uiContext2.getUiRenderContext().pushBloom(themeSnapshot2.computeFloat3(byteValue2 != 0 ? 1.8F : 0.6F) * Math.max(progress2, byteValue2 != 0 ? 1.0F : 0.0F) * floatValue);
         uiContext2.getUiRenderContext()
            .strokeRoundedRect(
               rect2.getX(),
               rect2.getY(),
               rect2.getWidth(),
               rect2.getHeight(),
               (4.5F),
               (1.1F),
               UiContext.multiplyAlpha(themeSnapshot2.getAccent2(), (0.85F * progress2 + (byteValue2 != 0 ? 0.15F : 0.0F)) * floatValue)
            );
         uiContext2.getUiRenderContext().popBloom();
      }

      Color color3 = byteValue2 != 0 ? themeSnapshot2.getOnAccent() : UiContext.blendColors(UiContext.blendColors(themeSnapshot2.getSecondaryText2(), themeSnapshot2.getPrimaryText(), progress), themeSnapshot2.getPrimaryText(), progress2);
      TextStyle textStyle;
      if (rect.getHeight() < 20.0F) {
         byteValue = 18;
         ThreadLocalRandom.current().nextInt(10);
         byteValue = 6;
         ThreadLocalRandom.current().nextInt(5);
         textStyle = TextStyle.CAPTION;
      } else {
         textStyle = TextStyle.SMALL;
      }

      TextStyle textStyle2 = textStyle;
      String label = keyboardKey2.getLabel();
      float w222 = rect2.getWidth();

      uiContext2.drawText(uiContext2.ellipsize(label, textStyle2, w222 - (6.0F)), rect2.getX() + 4.0F, rect2.getY() + 3.0F, textStyle2, UiContext.multiplyAlpha(color3, floatValue));
      if (list.size() > 1) {
         uiContext2.drawRightAlignedText(String.valueOf(list.size()), rect2.right() - 3.5F, rect2.bottom() - (5.0F), TextStyle.OVERLINE, UiContext.multiplyAlpha(color3, 0.8F * floatValue));
      }

      uiContext2.getInputRouter().addPressRegion(rect, UiLayer.BASE, (intValue2, doubleValue, doubleValue2) -> this.updateStateForUiContext2(uiContext2, string2, list, intValue2, doubleValue, doubleValue2));
   }

   static {
      int[] mouseButtonOrder = new int[5];

      mouseButtonOrder[0] = 0;
      mouseButtonOrder[1] = 2;

      mouseButtonOrder[2] = 1;

      mouseButtonOrder[3] = 3;
      mouseButtonOrder[4] = 4;
      MOUSE_BUTTON_ORDER = mouseButtonOrder;
      String[] mouseButtonLabels = new String[5];

      mouseButtonLabels[0] = "LMB";

      mouseButtonLabels[1] = "MMB";
      mouseButtonLabels[2] = "RMB";

      mouseButtonLabels[3] = "M4";

      mouseButtonLabels[4] = "M5";
      MOUSE_BUTTON_LABELS = mouseButtonLabels;
      selectedKeyboardLayout = "Full";
   }

   private List computeListForUiContext(UiContext uiContext2) {
      String string2 = this.textInputModel.toString().trim().toLowerCase(Locale.ROOT);
      ArrayList arrayList = new ArrayList();
      ArrayList arrayList2 = new ArrayList();

      for (Module module : (java.lang.Iterable<Module>)(java.lang.Iterable<?>)(computeList())) {
         if (module.getKeybind() != null) {
            if (!string2.isEmpty()) {
               if (!module.getName().toLowerCase(Locale.ROOT).contains(string2)) {
                  continue;
               }
            }

            (KeybindCapture.checkCondition5(module.getKeyCode()) ? arrayList : arrayList2).add(module);
         }
      }

      Comparator comparator = Comparator.comparing(objectValue -> ((Module)objectValue).getName(), UiControlAccess.getCASE_INSENSITIVE_ORDER());
      arrayList.sort(comparator);
      arrayList2.sort(comparator);
      ArrayList arrayList3 = new ArrayList();
      if (!arrayList.isEmpty()) {
         int intValue = arrayList.size();
         arrayList3.add(new GroupedModule(null, "Bound\u0000" + intValue));
         Iterator iterator = arrayList.iterator();

         while (iterator.hasNext()) {
            Module module2 = (Module)iterator.next();
            arrayList3.add(new GroupedModule(module2, null));
         }
      }

      if (!arrayList2.isEmpty()) {
         int intValue2 = arrayList2.size();
         arrayList3.add(new GroupedModule(null, "Not bound\u0000" + intValue2));

         for (Module module5 : (java.lang.Iterable<Module>)(java.lang.Iterable<?>)(arrayList2)) {
            arrayList3.add(new GroupedModule(module5, null));
         }

         ThreadLocalRandom.current().nextInt(14);
      }

      return arrayList3;
   }

   public static void setModule3(KeybindsScreen keybindsScreen, Module module32) {
      keybindsScreen.module3 = module32;
   }

   private void updateState4(int intValue) {
      String string2 = intValue == 1 ? " module loses its key." : " modules lose their keys.";
      this.confirmationDialog.updateStateForControlTone("Clear every bind?", intValue + string2 + " You can bind them again here at any time.", "Clear all", ControlTone.DANGER, () -> updateState3());
   }

   public static KeyboardKey getKeyboardKey(KeybindsScreen keybindsScreen) {
      return keybindsScreen.keyboardKey;
   }

   public static String getString2() {
      return selectedKeyboardLayout;
   }

   @Override
   protected boolean checkCondition2(double doubleValue, double doubleValue2, int intValue) {
      if (this.keybindCapture.checkCondition4(intValue)) {
         this.module3 = null;
         return true;
      } else {
         this.textInputModel.updateState3(false);
         return false;
      }
   }

   public static void setBooleanState(KeybindsScreen keybindsScreen, boolean booleanState2) {
      keybindsScreen.booleanState = booleanState2;
   }

   private void updateStateForUiContext4(UiContext uiContext2, Rect rect, float floatValue) {
      ThemeSnapshot themeSnapshot2 = uiContext2.getThemeSnapshot();
      setKeyboardKey(this, null);
      List list = KeyboardLayout.computeList4(getString2());
      boolean booleanValue = "Full".equals(selectedKeyboardLayout);
      float floatValue2 = 0.0F;

      int intValue = 0;

      for (List list2 : (java.lang.Iterable<List>)(java.lang.Iterable<?>)(list)) {
         floatValue2 = Math.max(floatValue2, KeyboardLayout.computeFloatForList(list2));
         int intValue2 = 0;

         for (KeyboardKey keyboardKey2 : (java.lang.Iterable<KeyboardKey>)(java.lang.Iterable<?>)(list2)) {
            if (!keyboardKey2.getSpacer2()) {
               intValue2++;
            }
         }

         intValue = Math.max(intValue, intValue2);
      }

      float floatValue3 = floatValue2 + (booleanValue ? 5.0F : (0.0F));
      float floatValue4 = rect.getWidth() - 32.0F;
      float floatValue5 = Math.max(12.0F, Math.min(34.0F, (floatValue4 - (float)intValue * 3.0F - (booleanValue ? 12.0F : (0.0F))) / floatValue3));

      float floatValue6 = Math.min((26.0F), floatValue5 * 0.92F);

      float floatValue7 = floatValue3 * floatValue5 + (float)(intValue + (booleanValue ? 4 : 0)) * 3.0F;
      float floatValue8 = (float)list.size() * floatValue6;
      int intValue3 = list.size();

      float floatValue9 = floatValue8 + (float)(intValue3 - 1) * 4.0F;

      float floatValue10 = floatValue9 + (12.0F) + floatValue6;
      float floatValue11 = rect.getX() + (rect.getWidth() - floatValue7) / (2.0F);
      float y5 = rect.getY();

      float floatValue12 = y5 + Math.max((12.0F), (rect.getHeight() - 30.0F - floatValue10) / 2.0F);

      for (int intValue4 = 0; intValue4 < list.size(); intValue4++) {
         float floatValue13 = floatValue12 + (float)intValue4 * (floatValue6 + 4.0F);
         float floatValue112 = floatValue11;
         Iterator iterator = ((List)list.get(intValue4)).iterator();

         while (iterator.hasNext()) {
            KeyboardKey keyboardKey3 = (KeyboardKey)iterator.next();
            if (keyboardKey3.getSpacer2()) {
               floatValue112 += keyboardKey3.getUnits() * floatValue5;
            } else {
               float floatValue15 = keyboardKey3.getUnits() * floatValue5 + (keyboardKey3.getUnits() - 1.0F) * 3.0F;
               this.updateStateForUiContext3(uiContext2, keyboardKey3, new Rect(floatValue112, floatValue13, floatValue15, floatValue6), floatValue);
               floatValue112 += floatValue15 + (3.0F);
            }
         }

         if (booleanValue && intValue4 < KeyboardLayout.listList.size() + 1) {
            if (intValue4 >= 1) {
               float floatValue16 = floatValue11 + (floatValue2 + (1.0F)) * floatValue5 + (float)intValue * (3.0F);

               for (KeyboardKey keyboardKey4 : KeyboardLayout.listList.get(intValue4 - 1)) {
                  if (keyboardKey4.getSpacer2()) {
                     floatValue16 += keyboardKey4.getUnits() * floatValue5 + (3.0F);
                  } else {
                     float floatValue17 = keyboardKey4.getUnits() * floatValue5 + (keyboardKey4.getUnits() - (1.0F)) * (3.0F);
                     this.updateStateForUiContext3(uiContext2, keyboardKey4, new Rect(floatValue16, floatValue13, floatValue17, floatValue6), floatValue);
                     floatValue16 += floatValue17 + (3.0F);
                  }
               }
            }
         }
      }

      float floatValue18 = floatValue12 + (float)list.size() * (floatValue6 + 4.0F) + (8.0F);

      float floatValue19 = floatValue5 * (2.4F);
      float floatValue113 = floatValue11;

      int intValue5 = 0;

      while (intValue5 < MOUSE_BUTTON_ORDER.length) {
         KeyboardKey keyboardKey5 = new KeyboardKey(KeybindUtils.computeInt(MOUSE_BUTTON_ORDER[intValue5]), getStringArray()[intValue5], 2.4F, false);
         this.updateStateForUiContext3(uiContext2, keyboardKey5, new Rect(floatValue113, floatValue18, floatValue19, floatValue6), floatValue);
         floatValue113 += floatValue19 + 6.0F;
         intValue5++;
      }

      float y = rect.bottom() - 15.0F;
      PanelRenderer.updateStateForUiContext3(uiContext2, rect.getX() + (12.0F), y - (12.0F), rect.right() - 12.0F, floatValue * 0.6F);
      if (this.keyboardKey != null) {
         List list3 = computeList2(this.keyboardKey.getCode());
         String string2 = KeybindCapture.computeString(getKeyboardKey(this).getCode());
         float x = rect.getX() + 14.0F;
         x += LabelWidgets.computeFloatForUiContext2(uiContext2, x, y, string2 == null ? this.keyboardKey.getLabel() : string2, floatValue) + 8.0F;
         String string42;
         if (list3.isEmpty()) {
            String string4;
            if (getModule3(this) != null) {
               String name = getModule3(this).getName();
               string4 = "Click to bind " + name + " to the mouse";
            } else {
               string4 = "Free";
            }

            string42 = string4;
         } else {
            StringBuilder stringBuilder = new StringBuilder();

            for (Module module : (java.lang.Iterable<Module>)(java.lang.Iterable<?>)(list3)) {
               if (!stringBuilder.isEmpty()) {
                  stringBuilder.append(", ");
               }

               stringBuilder.append(module.getName());
            }

            String string5 = String.valueOf(stringBuilder);
            string42 = string5 + "  ·  right-click clears";
         }

         uiContext2.drawVerticallyCenteredText(uiContext2.ellipsize(string42, TextStyle.SMALL, rect.right() - x - 14.0F), x, y, TextStyle.SMALL, UiContext.multiplyAlpha(list3.isEmpty() ? themeSnapshot2.getSecondaryText2() : themeSnapshot2.getPrimaryText(), floatValue));
      } else {
         uiContext2.drawVerticallyCenteredText("Lit keys are bound. Click one to find its action; right-click it to clear it.", rect.getX() + 14.0F, y, TextStyle.SMALL, UiContext.multiplyAlpha(themeSnapshot2.getDisabledText2(), floatValue));
      }
   }

   private void updateStateForUiContext5(UiContext uiContext2, Module module32, Rect rect, Rect rect2, float floatValue) {
      ThemeSnapshot themeSnapshot2 = uiContext2.getThemeSnapshot();
      String name = module32.getName();
      String string2 = "binds.action." + name;
      Rect rect3 = rect.intersection(rect2);
      boolean hovered = uiContext2.isHovered(rect3, UiLayer.BASE);
      float floatValue2 = uiContext2.animateHover(string2, hovered);
      byte byteValue;
      if (this.module3 == module32) {
         byteValue = 1;
      } else {
         byteValue = 0;
      }

      byte byteValue2 = byteValue;
      float floatValue3;
      if (module32 == this.module4) {
         UiAnimations uiAnimations5 = uiContext2.getAnimations();
         String name2 = module32.getName();
         String string3 = "binds.flash." + name2;

         floatValue3 = uiAnimations5.animateTo(string3, (0.0F), (0.35F));
      } else {
         floatValue3 = (0.0F);
      }

      float floatValue32 = floatValue3;
      PanelRenderer.updateStateForUiContext(uiContext2, rect, (7.0F), floatValue2, floatValue);
      PanelRenderer.updateStateForUiContext4(uiContext2, rect, 7.0F, Math.max(floatValue32, byteValue2 != 0 ? 1.0F : 0.0F), floatValue);
      float centerX = rect.getX() + (9.0F);
      if (module32.isEnabled()) {
         uiContext2.getUiRenderContext().pushBloom(themeSnapshot2.computeFloat3(0.6F) * floatValue);
         uiContext2.getUiRenderContext().fillCircle(centerX, rect.centerY(), 2.2F, UiContext.multiplyAlpha(themeSnapshot2.getAccent2(), floatValue));
         uiContext2.getUiRenderContext().popBloom();
      } else {
         uiContext2.getUiRenderContext().fillCircle(centerX, rect.centerY(), 2.2F, UiContext.multiplyAlpha(themeSnapshot2.getDisabledText2(), (0.6F) * floatValue));
      }

      KeybindSetting keybind = module32.getKeybind();
      String string4 = KeybindCapture.computeString(module32.getKeyCode());
      KeybindCaptureState keybindCaptureState = this.keybindCapture.testKeybindSetting(keybind) ? KeybindCaptureState.CAPTURING : (string4 == null ? KeybindCaptureState.EMPTY : KeybindCaptureState.BOUND);
      float floatValue6 = LabelWidgets.max2(uiContext2, string4 == null ? "Bind" : string4);
      float floatValue7 = rect.right();

      floatValue7 = floatValue7 - (6.0F) - floatValue6;
      float floatValue8 = rect.centerY();

      Rect rect4 = new Rect(floatValue7, floatValue8 - (7.5F), floatValue6, 15.0F);
      LabelWidgets.updateStateForUiContext(uiContext2, rect4, string4, keybindCaptureState, Math.max(floatValue2, byteValue2 != 0 ? 1.0F : (0.0F)), floatValue);
      float floatValue9 = rect4.getX() - 6.0F;
      if (keybind != null && keybind.isHoldMode()) {
         if (string4 != null) {
            float floatValue10 = uiContext2.measureText("hold", TextStyle.CAPTION);
            uiContext2.drawVerticallyCenteredText("hold", rect4.getX() - (4.0F) - floatValue10, rect.centerY(), TextStyle.CAPTION, UiContext.multiplyAlpha(themeSnapshot2.getDisabledText2(), floatValue));
            floatValue9 -= floatValue10 + 4.0F;
         } else {
            byteValue = 15;
            ThreadLocalRandom.current().nextInt(7);
         }
      }

      uiContext2.drawVerticallyCenteredText(
         uiContext2.ellipsize(module32.getName(), TextStyle.LABEL, floatValue9 - rect.getX() - 18.0F), rect.getX() + 17.0F, rect.centerY(), TextStyle.LABEL, UiContext.multiplyAlpha(module32.isEnabled() ? themeSnapshot2.getPrimaryText() : themeSnapshot2.getSecondaryText2(), floatValue)
      );
      uiContext2.getInputRouter().addPressRegion(rect3, UiLayer.BASE, (intValue, doubleValue, doubleValue2) -> this.updateStateForModule3(module32, intValue, doubleValue, doubleValue2));
   }

   private void updateStateForModule3(Module module32, int intValue, double doubleValue, double doubleValue2) {
      if (intValue == 1) {
         module32.setKeyCode(-1);
         if (getModule3(this) == module32) {
            getKeybindCapture(this).updateState();
         }

         ClientSounds.updateState2();
      } else if (intValue == 0) {
         if (getModule3(this) == module32) {
            this.keybindCapture.updateState();
            this.module3 = null;
            ClientSounds.updateState5();
         } else {
            this.updateStateForModule(module32);
         }
      }
   }

   public static void setScreen() {
      MinecraftClient.getInstance().setScreen(new KeybindsScreen());
   }

   public void close() {
      this.updateState();
   }

   public KeybindsScreen() {
      super("Key Binds");
      this.confirmationDialog = new ConfirmationDialog();
      this.scrollModel = new ScrollModel();
   }

   private static void updateSelectedKeyboardLayout(int intValue) {
      selectedKeyboardLayout = KEYBOARD_LAYOUTS.get(intValue);
   }

   private static List computeList2(int intValue) {
      ArrayList arrayList = new ArrayList();
      Iterator iterator = computeList().iterator();

      for (; iterator.hasNext(); ) {
         Module module = (Module)iterator.next();
         if (module.getKeyCode() == intValue) {
            if (KeybindCapture.checkCondition5(intValue)) {
               arrayList.add(module);
            }
         }
      }

      ThreadLocalRandom.current().nextInt(11);

      return arrayList;
   }

   @Override
   protected boolean checkCondition4(char charValue) {
      if (getKeybindCapture(this).checkCondition()) {
         return true;
      } else {
         if (getBooleanState(this)) {
            setBooleanState(this, false);
            if (charValue == '/') {
               return true;
            }
         }

         if (getConfirmationDialog(this).getBooleanState2()) {
            return true;
         } else {
            if (!getTextInputModel(this).getBooleanState2()) {
               if (!Character.isISOControl(charValue)) {
                  getTextInputModel(this).updateState3(true);
               }
            }

            return getTextInputModel(this).checkCondition3(charValue);
         }
      }
   }
}
