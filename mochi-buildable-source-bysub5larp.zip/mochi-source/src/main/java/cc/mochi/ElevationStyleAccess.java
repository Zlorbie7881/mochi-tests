package cc.mochi;

import java.awt.Color;

public class ElevationStyleAccess {
   public static float getOpacity(ElevationStyle elevationStyle) {
      return elevationStyle.opacity;
   }

   public static float getBlur(ElevationStyle elevationStyle) {
      return elevationStyle.blur;
   }

   public static Color getWHITE() {
      return Color.WHITE;
   }

   public static float getOffsetY(ElevationStyle elevationStyle) {
      return elevationStyle.offsetY;
   }
}
