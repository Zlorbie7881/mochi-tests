package cc.mochi;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public final class HumanizedRandom {
   private final Random random;

   private final FractalNoise fractalNoise;
   private double doubleState;

   public double computeDouble(double doubleValue3, double doubleValue2, double doubleValue4) {
      if (doubleValue3 > doubleValue4) {
         double doubleValue = doubleValue3;
         doubleValue3 = doubleValue4;
         doubleValue4 = doubleValue;
      }

      if (doubleValue4 == doubleValue3) {
         return doubleValue3;
      } else {
         double doubleValue5 = Math.max(doubleValue3, Math.min(doubleValue4, doubleValue2));
         double doubleValue6 = (doubleValue5 - doubleValue3) / (doubleValue4 - doubleValue3);
         double doubleValue7 = this.random.nextDouble();
         return doubleValue7 < doubleValue6 ? doubleValue3 + Math.sqrt(doubleValue7 * (doubleValue4 - doubleValue3) * (doubleValue5 - doubleValue3)) : doubleValue4 - Math.sqrt((1.0 - doubleValue7) * (doubleValue4 - doubleValue3) * (doubleValue4 - doubleValue5));
      }
   }

   public long computeLong(long longValue, long longValue2, long longValue3) {
      long longValue4 = Math.min(longValue2, longValue3);
      long longValue5 = Math.max(longValue2, longValue3);
      if (longValue <= 0L) {
         return Math.max(0L, longValue4);
      } else {
         double doubleValue = -Math.log(1.0 - this.random.nextDouble()) * (double)longValue;
         return Math.max(longValue4, Math.min(longValue5, Math.round(doubleValue)));
      }
   }

   public HumanizedRandom() {
      this(ThreadLocalRandom.current().nextLong());
   }

   public double computeDouble2(double doubleValue, double doubleValue2) {
      return MathUtils.computeDouble4(doubleValue, doubleValue2);
   }

   public double computeDouble3(double doubleValue, double doubleValue2) {
      return !(doubleValue <= 0.0) && !(doubleValue2 <= 0.0) ? doubleValue * Math.exp(doubleValue2 * this.random.nextGaussian()) : Math.max(doubleValue, 0.0);
   }

   public int computeInt(double... doubleArray) {
      if (doubleArray != null && doubleArray.length != 0) {
         double doubleValue = 0.0;

         for (double doubleValue2 : doubleArray) {
            if (doubleValue2 > 0.0) {
               doubleValue += doubleValue2;
            }
         }

         if (doubleValue <= 0.0) {
            return this.computeInt2(0, doubleArray.length);
         } else {
            double doubleValue3 = this.random.nextDouble() * doubleValue;

            for (int intValue = 0; intValue < doubleArray.length; intValue++) {
               if (!(doubleArray[intValue] <= 0.0)) {
                  doubleValue3 -= doubleArray[intValue];
                  if (doubleValue3 <= 0.0) {
                     return intValue;
                  }
               }
            }

            return doubleArray.length - 1;
         }
      } else {
         return -1;
      }
   }

   public double computeDouble4(double doubleState2, double doubleValue, double doubleValue2) {
      if (doubleValue <= doubleState2) {
         this.doubleState = doubleState2;
         return doubleState2;
      } else {
         double doubleValue3 = this.doubleState + this.random.nextGaussian() * doubleValue2;
         if (doubleValue3 > doubleValue) {
            doubleValue3 = doubleValue - (doubleValue3 - doubleValue);
         } else if (doubleValue3 < doubleState2) {
            doubleValue3 = doubleState2 + (doubleState2 - doubleValue3);
         }

         this.doubleState = Math.max(doubleState2, Math.min(doubleValue, doubleValue3));
         return this.doubleState;
      }
   }

   public boolean checkCondition(double doubleValue) {
      if (doubleValue <= 0.0) {
         return false;
      } else {
         return doubleValue >= 1.0 ? true : this.random.nextDouble() < doubleValue;
      }
   }

   public HumanizedRandom(long longValue) {
      this.random = new Random(longValue);
      this.fractalNoise = new FractalNoise((int)(longValue ^ longValue >>> 32));
   }

   public float computeFloat(float floatValue, float floatValue2) {
      return (float)this.computeDouble5((double)floatValue, (double)floatValue2);
   }

   public double computeDouble5(double doubleValue2, double doubleValue3) {
      if (doubleValue2 > doubleValue3) {
         double doubleValue = doubleValue2;
         doubleValue2 = doubleValue3;
         doubleValue3 = doubleValue;
      }

      return doubleValue2 == doubleValue3 ? doubleValue2 : doubleValue2 + this.random.nextDouble() * (doubleValue3 - doubleValue2);
   }

   public long computeLong2(long longValue, long longValue2) {
      return longValue >= longValue2 ? longValue : longValue + (long)(this.random.nextDouble() * (double)(longValue2 - longValue));
   }

   public double computeDouble6(double doubleValue, double doubleValue2) {
      return doubleValue2 == 0.0 ? doubleValue : doubleValue + this.random.nextGaussian() * doubleValue2;
   }

   public double computeDouble7(double doubleValue) {
      if (doubleValue <= 0.0) {
         return 0.0;
      } else {
         return this.random.nextBoolean() ? doubleValue : -doubleValue;
      }
   }

   public double sample(double doubleValue) {
      return this.fractalNoise.sample(doubleValue);
   }

   public long computeLong3(double doubleValue, double doubleValue2) {
      double doubleValue3 = Math.min(doubleValue, doubleValue2);
      double doubleValue4 = Math.max(doubleValue, doubleValue2);
      if (doubleValue4 <= doubleValue3) {
         return Math.round(doubleValue3);
      } else {
         double doubleValue5 = doubleValue3 + (doubleValue4 - doubleValue3) * 0.35;
         double doubleValue6 = doubleValue5 * Math.exp(0.45 * this.random.nextGaussian());
         return Math.round(Math.max(doubleValue3, Math.min(doubleValue4, doubleValue6)));
      }
   }

   public double computeDouble8(double doubleValue) {
      if (doubleValue <= 0.0) {
         return 0.0;
      } else {
         double doubleValue2 = this.random.nextGaussian() * (doubleValue / 3.0);
         return Math.max(-doubleValue, Math.min(doubleValue, doubleValue2));
      }
   }

   public double sampleOctaves(double doubleValue, int intValue) {
      return this.fractalNoise.sampleOctaves(doubleValue, intValue);
   }

   public double computeDouble9(double doubleValue, double doubleValue2, double doubleValue4, double doubleValue5) {
      if (doubleValue4 > doubleValue5) {
         double doubleValue3 = doubleValue4;
         doubleValue4 = doubleValue5;
         doubleValue5 = doubleValue3;
      }

      return Math.max(doubleValue4, Math.min(doubleValue5, this.computeDouble6(doubleValue, doubleValue2)));
   }

   public int computeInt2(int intValue, int intValue2) {
      return intValue >= intValue2 ? intValue : intValue + this.random.nextInt(intValue2 - intValue);
   }
}
