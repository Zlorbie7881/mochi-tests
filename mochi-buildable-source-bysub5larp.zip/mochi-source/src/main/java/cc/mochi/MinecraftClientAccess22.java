package cc.mochi;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.state.property.IntProperty;
import net.minecraft.util.hit.HitResult;

public class MinecraftClientAccess22 {
   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static Block getRESPAWN_ANCHOR() {
      return Blocks.RESPAWN_ANCHOR;
   }

   public static HitResult getCrosshairTarget(MinecraftClient minecraftClient) {
      return minecraftClient.crosshairTarget;
   }

   public static IntProperty getCHARGES() {
      return RespawnAnchorBlock.CHARGES;
   }
}
