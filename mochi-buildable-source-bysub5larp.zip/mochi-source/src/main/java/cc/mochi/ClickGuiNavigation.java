package cc.mochi;

import java.awt.Color;
import java.util.List;
import java.util.function.Consumer;

public final class ClickGuiNavigation {
   private static void accept(Consumer consumer, ClickGuiTab clickGuiTab) {
      consumer.accept(clickGuiTab);
   }

   private ClickGuiNavigation() {
   }

   private static void updateStateForModuleBrowser(boolean booleanValue, ModuleBrowser moduleBrowser, ModuleCategory moduleCategory) {
      if (!booleanValue) {
         moduleBrowser.updateStateForModuleCategory(moduleCategory);
         UiLayerAccess3.getTextInputModel(moduleBrowser).updateState3(false);
         ClientSounds.updateState4();
      }
   }

   static void updateStateForUiContext(UiContext uiContext, ModuleBrowser moduleBrowser, Rect rect, float floatValue, Consumer consumer, Runnable runnable) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      float floatValue2 = rect.getX() + 6.0F;
      float floatValue3 = rect.getWidth() - 12.0F;
      float y = rect.getY() + 16.0F;
      uiContext.getUiRenderContext().fillAngledGradient(floatValue2 - 6.0F, y - 16.0F, 32.0F, 32.0F, 16.0F, UiContext.multiplyAlpha(themeSnapshot2.getAccent2(), 0.35F * floatValue), UiContext.multiplyAlpha(themeSnapshot2.getAccent2(), 0.0F), 1.4F);
      uiContext.getUiRenderContext().drawTextureFromResource("assets/mochi/icon.png", floatValue2 + 1.0F, y - 8.0F, 16.0F, 16.0F, UiContext.multiplyAlpha(UiLayerAccess3.getWHITE(), floatValue));
      uiContext.drawVerticallyCenteredText("mochi", floatValue2 + 22.0F, y, TextStyle.TITLE, UiContext.multiplyAlpha(themeSnapshot2.getPrimaryText(), floatValue));
      String version = UiLayerAccess3.getVERSION();
      if (version != null && !version.isBlank()) {
         String text = uiContext.ellipsize(version.split("[+-]")[0], TextStyle.CAPTION, floatValue3 - 80.0F);
         uiContext.drawRightAlignedText(text, floatValue2 + floatValue3 - 2.0F, y + 0.5F, TextStyle.CAPTION, UiContext.multiplyAlpha(themeSnapshot2.getDisabledText2(), floatValue));
      }

      float floatValue5 = rect.getY() + 34.0F;
      if (ClickGuiModule.getValue3()) {
         Rect rect2 = new Rect(floatValue2, floatValue5, floatValue3, 22.0F);
         String text2 = moduleBrowser.checkCondition() ? String.valueOf(moduleBrowser.computeInt()) : null;
         TextInputWidget.updateStateForUiContext2(uiContext, "nav.search", rect2, UiLayer.BASE, moduleBrowser.textInputModel, "Search", Icon.SEARCH, text2, floatValue);
         floatValue5 += 30.0F;
      }

      List list = ModuleBrowser.computeList2();
      SectionHeaderWidget.updateStateForUiContext(uiContext, floatValue2 + 4.0F, floatValue5 + 6.0F, floatValue3 - 4.0F, "Modules", null, floatValue);
      floatValue5 += 14.0F;
      int intValue = moduleBrowser.checkCondition() ? -1 : list.indexOf(moduleBrowser.moduleCategory);
      float floatValue6 = uiContext.getAnimations().springDefault("nav.pill", floatValue5 + (float)Math.max(0, intValue) * 24.0F, floatValue5 + (float)Math.max(0, intValue) * 24.0F);
      float floatValue7 = uiContext.animateToggle("nav.pill.show", intValue >= 0, 0.035F);
      if (floatValue7 > 0.01F) {
         Rect rect3 = new Rect(floatValue2, floatValue6, floatValue3, 22.0F);
         uiContext.getUiRenderContext().fillRoundedRect(rect3.getX(), rect3.getY(), rect3.getWidth(), rect3.getHeight(), 7.0F, UiContext.multiplyAlpha(themeSnapshot2.getAccentSoft2(), 1.3F * floatValue7 * floatValue));
         uiContext.getUiRenderContext().pushBloom(themeSnapshot2.computeFloat3(1.0F) * floatValue7 * floatValue);
         uiContext.getUiRenderContext().fillRoundedRect(rect3.getX() + 1.5F, rect3.centerY() - 5.0F, 2.2F, 10.0F, 1.1F, UiContext.multiplyAlpha(themeSnapshot2.getAccent2(), floatValue7 * floatValue));
         uiContext.getUiRenderContext().popBloom();
      }

      for (int intValue2 = 0; intValue2 < list.size(); intValue2++) {
         ModuleCategory moduleCategory = (ModuleCategory)list.get(intValue2);
         Rect rect4 = new Rect(floatValue2, floatValue5, floatValue3, 22.0F);
         boolean active = intValue2 == intValue;
         boolean hovered = uiContext.isHovered(rect4, UiLayer.BASE);
         float progress = uiContext.animateHover("nav.cat." + moduleCategory, hovered && !active);
         float progress2 = uiContext.animateToggle("nav.cat.on." + moduleCategory, active, 0.035F);
         float floatValue10 = uiContext.getAnimations().exponential("nav.enter." + moduleCategory, 0.0F, 1.0F, 0.06F + (float)intValue2 * 0.07F * 0.2F);
         float floatValue11 = floatValue * floatValue10;
         float floatValue12 = (1.0F - floatValue10) * ((-6.0F));
         PanelRenderer.updateStateForUiContext(uiContext, rect4, 7.0F, progress, floatValue11);
         Color color = UiContext.blendColors(UiContext.blendColors(themeSnapshot2.getSecondaryText2(), themeSnapshot2.getPrimaryText(), progress), themeSnapshot2.getPrimaryText(), progress2);
         UiShapeRenderer.updateStateForUiRenderContext2(uiContext.getUiRenderContext(), moduleCategory, rect4.getX() + 14.0F + floatValue12, rect4.centerY(), 11.0F, UiContext.multiplyAlpha(UiContext.blendColors(color, themeSnapshot2.getAccentText2(), progress2), floatValue11));
         uiContext.drawVerticallyCenteredText(moduleCategory.getName(), rect4.getX() + 27.0F + floatValue12, rect4.centerY(), progress2 > 0.5F ? TextStyle.STRONG : TextStyle.LABEL, UiContext.multiplyAlpha(color, floatValue11));
         uiContext.getInputRouter().addClickRegion(rect4, UiLayer.BASE, () -> updateStateForModuleBrowser(active, moduleBrowser, moduleCategory));
         floatValue5 += 24.0F;
      }

      floatValue5 += 8.0F;
      SectionHeaderWidget.updateStateForUiContext(uiContext, floatValue2 + 4.0F, floatValue5 + 6.0F, floatValue3 - 4.0F, "Tools", null, floatValue);
      floatValue5 += 14.0F;
      float floatValue13 = rect.bottom() - 30.0F;
      ClickGuiTab[] clickGuiTabArray = ClickGuiTab.values();
      float floatValue14 = Math.min(22.0F, (floatValue13 - 6.0F - floatValue5) / (float)clickGuiTabArray.length);

      for (ClickGuiTab clickGuiTab : clickGuiTabArray) {
         Rect rect5 = new Rect(floatValue2, floatValue5, floatValue3, Math.max(14.0F, floatValue14 - 2.0F));
         boolean hovered2 = uiContext.isHovered(rect5, UiLayer.BASE);
         float progress3 = uiContext.animateHover("nav.tool." + clickGuiTab, hovered2);
         boolean booleanValue2 = clickGuiTab == ClickGuiTab.SELF_DESTRUCT;
         if (booleanValue2) {
            uiContext.getUiRenderContext().fillRoundedRect(rect5.getX(), rect5.getY(), rect5.getWidth(), rect5.getHeight(), 7.0F, UiContext.multiplyAlpha(themeSnapshot2.getDanger(), 0.12F * progress3 * floatValue));
         } else {
            PanelRenderer.updateStateForUiContext(uiContext, rect5, 7.0F, progress3, floatValue);
         }

         Color color2 = booleanValue2 ? UiContext.blendColors(themeSnapshot2.getSecondaryText2(), themeSnapshot2.getDanger(), 0.35F + 0.65F * progress3) : UiContext.blendColors(themeSnapshot2.getSecondaryText2(), themeSnapshot2.getPrimaryText(), progress3);
         float floatValue16 = progress3 * 1.5F;
         UiShapeRenderer.updateStateForUiRenderContext3(uiContext.getUiRenderContext(), UiLayerAccess3.getIcon(clickGuiTab), rect5.getX() + 14.0F + floatValue16, rect5.centerY(), 10.0F, UiContext.multiplyAlpha(color2, floatValue));
         uiContext.drawVerticallyCenteredText(clickGuiTab.label, rect5.getX() + 27.0F + floatValue16, rect5.centerY(), TextStyle.LABEL, UiContext.multiplyAlpha(color2, floatValue));
         if (progress3 > 0.02F) {
            UiShapeRenderer.updateStateForUiRenderContext3(uiContext.getUiRenderContext(), Icon.CHEVRON_RIGHT, rect5.right() - 9.0F - 2.0F * (1.0F - progress3), rect5.centerY(), 7.0F, UiContext.multiplyAlpha(color2, progress3 * floatValue));
         }

         uiContext.getInputRouter().addClickRegion(rect5, UiLayer.BASE, () -> accept(consumer, clickGuiTab));
         floatValue5 += floatValue14;
      }

      Rect rect6 = new Rect(floatValue2, rect.bottom() - 28.0F, floatValue3, 22.0F);
      boolean hovered3 = uiContext.isHovered(rect6, UiLayer.BASE);
      float progress4 = uiContext.animateHover("nav.palette", hovered3);
      uiContext.getUiRenderContext().fillRoundedRect(rect6.getX(), rect6.getY(), rect6.getWidth(), rect6.getHeight(), 7.0F, UiContext.multiplyAlpha(UiContext.blendColors(themeSnapshot2.getSurfaceSunken(), themeSnapshot2.getSurfaceRaised(), progress4), floatValue));
      uiContext.getUiRenderContext().strokeRoundedRect(rect6.getX(), rect6.getY(), rect6.getWidth(), rect6.getHeight(), 7.0F, 1.0F, UiContext.multiplyAlpha(UiContext.blendColors(themeSnapshot2.getHairline2(), themeSnapshot2.getAccent2(), 0.4F * progress4), floatValue));
      UiShapeRenderer.updateStateForUiRenderContext3(uiContext.getUiRenderContext(), Icon.SPARK, rect6.getX() + 11.0F, rect6.centerY(), 8.0F, UiContext.multiplyAlpha(UiContext.blendColors(themeSnapshot2.getSecondaryText2(), themeSnapshot2.getAccentText2(), progress4), floatValue));
      float floatValue18 = LabelWidgets.computeFloatForUiContext3(uiContext, "Ctrl", "K");
      uiContext.drawVerticallyCenteredText(uiContext.ellipsize("Quick actions", TextStyle.SMALL, rect6.getWidth() - floatValue18 - 30.0F), rect6.getX() + 21.0F, rect6.centerY(), TextStyle.SMALL, UiContext.multiplyAlpha(themeSnapshot2.getSecondaryText2(), floatValue));
      LabelWidgets.computeFloatForUiContext6(uiContext, rect6.right() - 5.0F - floatValue18, rect6.centerY(), floatValue, "Ctrl", "K");
      uiContext.getInputRouter().addClickRegion(rect6, UiLayer.BASE, runnable);
   }
}
