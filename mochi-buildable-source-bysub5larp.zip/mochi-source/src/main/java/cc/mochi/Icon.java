package cc.mochi;

public enum Icon {
   CHEVRON_LEFT,

   CHEVRON_RIGHT,

   CHEVRON_UP,

   CHEVRON_DOWN,

   CHECK,

   PLUS,

   MINUS,

   CLOSE,

   SEARCH,

   RESET,

   GRIP,

   POWER,

   USERS,

   CLIPBOARD,

   COPY,

   TRASH,

   FOLDER,

   PALETTE,

   LAYOUT,

   KEYBOARD,

   SLIDERS,

   SETTINGS,
   WRENCH,
   MOUSE,
   KEY,
   BOLT,
   GRID,
   COMMAND,
   MAGNET,
   EYE,

   ARROW_RIGHT,

   DOT,

   SPARK;

   private static final Icon[] ENUM_VALUES = {CHEVRON_LEFT, CHEVRON_RIGHT, CHEVRON_UP, CHEVRON_DOWN, CHECK, PLUS, MINUS, CLOSE, SEARCH, RESET, GRIP, POWER, USERS, CLIPBOARD, COPY, TRASH, FOLDER, PALETTE, LAYOUT, KEYBOARD, SLIDERS, SETTINGS, WRENCH, MOUSE, KEY, BOLT, GRID, COMMAND, MAGNET, EYE, ARROW_RIGHT, DOT, SPARK};

   public static Icon[] getENUM_VALUES() {
      return ENUM_VALUES;
   }

   private static Icon[] createValues() {
      return new Icon[]{
         CHEVRON_LEFT,
         CHEVRON_RIGHT,
         CHEVRON_UP,
         CHEVRON_DOWN,
         CHECK,
         PLUS,
         MINUS,
         CLOSE,
         SEARCH,
         RESET,
         GRIP,
         POWER,
         USERS,
         CLIPBOARD,
         COPY,
         TRASH,
         FOLDER,
         PALETTE,
         LAYOUT,
         KEYBOARD,
         SLIDERS,
         SETTINGS,
         WRENCH,
         MOUSE,
         KEY,
         BOLT,
         GRID,
         COMMAND,
         MAGNET,
         EYE,
         ARROW_RIGHT,
         DOT,
         SPARK
      };
   }
}
