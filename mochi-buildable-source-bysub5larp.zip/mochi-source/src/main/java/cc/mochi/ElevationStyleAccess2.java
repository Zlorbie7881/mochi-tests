package cc.mochi;

public class ElevationStyleAccess2 {
   public static ElevationStyle getHIGH() {
      return ElevationStyle.HIGH;
   }
}
