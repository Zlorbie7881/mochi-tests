package cc.mochi;

public class ClickGuiTabAccess3 {
   public static ClickGuiTab getCONFIGS() {
      return ClickGuiTab.CONFIGS;
   }
}
