package cc.mochi;

public enum CrystalPlacementState {
   IDLE,
   OBSIDIAN,
   PLACE,
   BREAK;

   private static CrystalPlacementState[] computeCrystalPlacementStateArray() {
      CrystalPlacementState[] crystalPlacementStateArray = new CrystalPlacementState[4];

      crystalPlacementStateArray[0] = getIDLE();

      crystalPlacementStateArray[1] = getOBSIDIAN();

      crystalPlacementStateArray[2] = getPLACE();
      crystalPlacementStateArray[3] = BREAK;
      return crystalPlacementStateArray;
   }

   public static CrystalPlacementState getOBSIDIAN() {
      return OBSIDIAN;
   }

   public static CrystalPlacementState getPLACE() {
      return PLACE;
   }

   public static CrystalPlacementState getIDLE() {
      return IDLE;
   }
}
