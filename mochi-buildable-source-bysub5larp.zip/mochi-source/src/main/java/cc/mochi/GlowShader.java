package cc.mochi;

import com.mojang.blaze3d.opengl.GlStateManager;
import java.awt.Color;
import net.minecraft.client.util.math.MatrixStack;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

public class GlowShader {
   private static int vertexArrayId = -1;
   private static int vertexBufferId = -1;
   private static int indexBufferId = -1;
   private static boolean initialized = false;
   private static final float[] QUAD_VERTICES = new float[]{((-1.0F)), ((-1.0F)), 1.0F, ((-1.0F)), 1.0F, 1.0F, ((-1.0F)), 1.0F};

   private static final int[] QUAD_INDICES = new int[]{0, 1, 2, 2, 3, 0};

   public static void drawPulsing(MatrixStack matrices, float x, float y, float width, float height, float radius, Color color, double time) {
      float intensity = (float)(0.7F + 0.3F * Math.sin(time * 2.0));
      drawConfigured(matrices, x, y, width, height, radius, color, intensity, 10.0F, 15.0F);
   }

   public static void destroy() {
      if (vertexArrayId != -1) {
         GL30.glDeleteVertexArrays(vertexArrayId);
         vertexArrayId = -1;
      }

      if (vertexBufferId != -1) {
         GL20.glDeleteBuffers(vertexBufferId);
         vertexBufferId = -1;
      }

      if (indexBufferId != -1) {
         GL20.glDeleteBuffers(indexBufferId);
         indexBufferId = -1;
      }

      initialized = false;
   }

   public static void drawWithIntensity(MatrixStack matrices, float x, float y, float width, float height, float radius, Color color, float intensity) {
      drawConfigured(matrices, x, y, width, height, radius, color, intensity, 10.0F, 15.0F);
   }

   public static void initialize() {
      if (!initialized) {
         int intValue = ShaderProgramCache.loadProgram("glow", "shaders/post/glow.vsh", "shaders/post/glow.fsh");
         if (intValue != 0) {
            vertexArrayId = GL30.glGenVertexArrays();
            vertexBufferId = GL20.glGenBuffers();
            indexBufferId = GL20.glGenBuffers();
            GL30.glBindVertexArray(vertexArrayId);
            GL20.glBindBuffer(org.lwjgl.opengl.GL15.GL_ARRAY_BUFFER, vertexBufferId);
            GL20.glBufferData(org.lwjgl.opengl.GL15.GL_ARRAY_BUFFER, QUAD_VERTICES, org.lwjgl.opengl.GL15.GL_STATIC_DRAW);
            GL20.glBindBuffer(org.lwjgl.opengl.GL15.GL_ELEMENT_ARRAY_BUFFER, indexBufferId);
            GL20.glBufferData(org.lwjgl.opengl.GL15.GL_ELEMENT_ARRAY_BUFFER, QUAD_INDICES, org.lwjgl.opengl.GL15.GL_STATIC_DRAW);
            GL20.glVertexAttribPointer(0, 2, GL11.GL_FLOAT, false, 8, 0L);
            GL20.glEnableVertexAttribArray(0);
            GL20.glBindBuffer(org.lwjgl.opengl.GL15.GL_ARRAY_BUFFER, 0);
            GL30.glBindVertexArray(0);
            initialized = true;
         }
      }
   }

   public static void draw(MatrixStack matrices, float x, float y, float width, float height, float radius, Color color) {
      drawConfigured(matrices, x, y, width, height, radius, color, 1.0F, 10.0F, 15.0F);
   }

   public static void drawConfigured(MatrixStack matrices, float x, float y, float width, float height, float radius, Color color, float intensity, float thickness, float bloomRadius) {
      if (!initialized) {
         initialize();
      }

      Integer integer = ShaderProgramCache.get("glow");
      if (integer != null && integer != 0) {
         if (vertexArrayId != -1 && vertexBufferId != -1) {
            int width2 = UiViewport.getWidth();
            int height2 = UiViewport.getHeight();
            int[] intArray = new int[1];
            GL11.glGetIntegerv(GL30.GL_VERTEX_ARRAY_BINDING, intArray);
            int[] intArray2 = new int[1];
            GL11.glGetIntegerv(GL20.GL_CURRENT_PROGRAM, intArray2);
            boolean booleanValue = GL11.glIsEnabled(GL11.GL_BLEND);
            boolean booleanValue2 = GL11.glIsEnabled(GL11.GL_DEPTH_TEST);
            boolean booleanValue3 = GL11.glGetBoolean(GL11.GL_DEPTH_WRITEMASK);
            boolean booleanValue4 = GL11.glIsEnabled(GL11.GL_CULL_FACE);
            int intValue = GL11.glGetInteger(org.lwjgl.opengl.GL14.GL_BLEND_SRC_RGB);
            int intValue2 = GL11.glGetInteger(org.lwjgl.opengl.GL14.GL_BLEND_DST_RGB);
            int intValue3 = GL11.glGetInteger(org.lwjgl.opengl.GL14.GL_BLEND_SRC_ALPHA);
            int intValue4 = GL11.glGetInteger(org.lwjgl.opengl.GL14.GL_BLEND_DST_ALPHA);

            try {
               GlStateManager._enableBlend();
               GlStateManager._blendFuncSeparate(770, 771, 1, 771);
               GlStateManager._disableDepthTest();
               GlStateManager._depthMask(false);
               GlStateManager._disableCull();
               GL30.glBindVertexArray(vertexArrayId);
               ShaderProgramCache.bind("glow");
               ShaderProgramCache.uniform2f("glow", "u_resolution", (float)width2, (float)height2);
               ShaderProgramCache.uniform2f("glow", "u_position", x, y);
               ShaderProgramCache.uniform2f("glow", "u_size", width, height);
               ShaderProgramCache.uniform1f("glow", "u_radius", radius);
               ShaderProgramCache.uniform4f(
                  "glow",
                  "u_color",
                  (float)color.getRed() / 255.0F,
                  (float)color.getGreen() / 255.0F,
                  (float)color.getBlue() / 255.0F,
                  (float)color.getAlpha() / 255.0F
               );
               ShaderProgramCache.uniform1f("glow", "u_glowIntensity", intensity);
               ShaderProgramCache.uniform1f("glow", "u_glowThickness", thickness);
               ShaderProgramCache.uniform1f("glow", "u_bloomRadius", bloomRadius);
               GL20.glDrawElements(GL11.GL_TRIANGLES, 6, GL11.GL_UNSIGNED_INT, 0L);
            } finally {
               GL30.glBindVertexArray(intArray[0]);
               GL20.glUseProgram(intArray2[0]);
               GlStateManager._depthMask(booleanValue3);
               if (booleanValue2) {
                  GlStateManager._enableDepthTest();
               } else {
                  GlStateManager._disableDepthTest();
               }

               if (booleanValue4) {
                  GlStateManager._enableCull();
               } else {
                  GlStateManager._disableCull();
               }

               GlStateManager._blendFuncSeparate(intValue, intValue2, intValue3, intValue4);
               if (!booleanValue) {
                  GlStateManager._disableBlend();
               }
            }
         }
      }
   }

   public static void drawLayeredGlow(MatrixStack matrices, float x, float y, float width, float height, float radius, Color color) {
      drawConfigured(matrices, x, y, width, height, radius, color, 0.8F, 8.0F, 12.0F);
      drawConfigured(matrices, x, y, width, height, radius, color, 0.6F, 12.0F, 20.0F);
      drawConfigured(matrices, x, y, width, height, radius, color, 0.4F, 16.0F, 28.0F);
   }
}
