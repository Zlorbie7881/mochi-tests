package cc.mochi;

public class FramebufferSizeMath {
   public static PixelSize computePixelSizeForPixelSize(PixelSize pixelSize, int intValue, int intValue2) {
      float floatValue = (float)intValue / 1920.0F;
      float floatValue2 = (float)intValue2 / 1080.0F;
      float floatValue3 = Math.min(floatValue, floatValue2);
      return new PixelSize(Math.round((float)pixelSize.width() * floatValue3), Math.round((float)pixelSize.height() * floatValue3));
   }

   public static int computeInt(int intValue, int intValue2, int intValue3) {
      return intValue * intValue3 / intValue2;
   }

   public static int round(int intValue, float floatValue) {
      return Math.round((float)intValue * floatValue);
   }

   public static int computeInt2(int intValue, int intValue2) {
      if (intValue2 <= 1366) {
         return intValue - 2;
      } else if (intValue2 <= 1920) {
         return intValue;
      } else {
         return intValue2 <= 2560 ? intValue + 2 : intValue + 4;
      }
   }
}
