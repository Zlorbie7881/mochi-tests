package cc.mochi;

import cc.mochi.utils.platform.ClipboardUtil;
import java.util.List;

public final class ConfigPanel extends UiPanel {
   private final TextInputModel textInputModel = new TextInputModel(24);
   private List<String> stringList;

   private final ConfirmationDialog confirmationDialog;
   private final ScrollModel scrollModel = new ScrollModel();

   public static void setStringList(ConfigPanel configPanel, List stringList2) {
      configPanel.stringList = stringList2;
   }

   public ConfigPanel(ConfirmationDialog confirmationDialog2) {
      super("Configs", "Click a config to load it");
      this.stringList = List.of();
      this.confirmationDialog = confirmationDialog2;
      this.updateState11();
   }

   public static TextInputModel getTextInputModel(ConfigPanel configPanel) {
      return configPanel.textInputModel;
   }

   @Override
   protected float computeFloatForUiContext(UiContext uiContext, float floatValue, float floatValue2, boolean booleanValue, float floatValue3) {
      float floatValue4 = ButtonWidgets.computeFloatForUiContext(uiContext, "Reset all", Icon.RESET);
      Rect rect = new Rect(floatValue - floatValue4, floatValue2 - 10.0F, floatValue4, 20.0F);
      ButtonWidgets.updateStateForUiContext4(uiContext, "configs.reset", rect, UiLayer.MODAL, ButtonVariant.GHOST, "Reset all", Icon.RESET, floatValue3, booleanValue ? () -> this.updateState8() : null);
      return rect.getX();
   }

   @Override
   public boolean checkCondition() {
      if (this.textInputModel.getBooleanState2()) {
         getTextInputModel(this).updateState3(false);
         return true;
      } else {
         return false;
      }
   }

   private void updateState(String string) {
      getConfirmationDialog(this).updateStateForControlTone("Delete ‘" + string + "’?", "The config file is removed from disk. This cannot be undone.", "Delete", ControlTone.DANGER, () -> this.updateState9(string));
   }

   private static ConfigManager computeConfigManager() {
      return MochiClient.INSTANCE != null ? CommandPaletteAccess.getINSTANCE().getConfigManager() : null;
   }

   public static ScrollModel getScrollModel(ConfigPanel configPanel) {
      return configPanel.scrollModel;
   }

   public static ConfirmationDialog getConfirmationDialog(ConfigPanel configPanel) {
      return configPanel.confirmationDialog;
   }

   @Override
   protected float computeFloat() {
      return 360.0F;
   }

   private void updateState2() {
      ConfigManager configManager = computeConfigManager();
      if (configManager != null) {
         configManager.updateState3();
         this.updateState14("Reset to defaults", false);
         this.updateState11();
      }
   }

   private void updateState3() {
      ConfigManager configManager = computeConfigManager();
      if (configManager != null) {
         String string = ClipboardUtil.paste();
         if (string != null && !string.isBlank()) {
            String string2 = this.textInputModel.toString().trim();
            String string3 = configManager.computeString2(string2.isEmpty() ? null : string2, string);
            if (string3 != null) {
               this.updateState14("Imported ‘" + string3 + "’", false);
               getTextInputModel(this).updateState2();
               this.updateState11();
            } else {
               this.updateState14("Couldn't import  ·  the clipboard is not a Mochi config", true);
               ClientSounds.updateState2();
            }
         } else {
            this.updateState14("The clipboard is empty  ·  copy a config first", true);
            ClientSounds.updateState2();
         }
      }
   }

   private void updateState4() {
      ConfigManager configManager = computeConfigManager();
      String string = getTextInputModel(this).toString().trim();
      if (configManager != null && !string.isEmpty()) {
         configManager.updateState2(string);
         this.updateState14("Saved ‘" + string + "’", false);
         this.textInputModel.updateState2();
         this.textInputModel.updateState3(false);
         this.updateState11();
      }
   }

   private void updateState5(String string) {
      this.updateState10(string);
   }

   @Override
   protected float computeFloat2(float floatValue) {
      return Math.min(floatValue - 60.0F, 330.0F);
   }

   @Override
   public void updateState6() {
      this.textInputModel.updateState3(false);
   }

   private void updateState7(String string) {
      this.updateState12(string);
   }

   private void updateState8() {
      getConfirmationDialog(this)
         .updateStateForControlTone(
            "Reset every module?",
            "Every module goes back to its default settings and binds. Save a config first if you want to keep this setup.",
            "Reset",
            ControlTone.DANGER,
            () -> this.updateState2()
         );
   }

   private void updateState9(String string) {
      ConfigManager configManager = computeConfigManager();
      if (configManager != null) {
         configManager.updateState5(string);
         this.updateState14("Deleted ‘" + string + "’", false);
         this.updateState11();
      }
   }

   private void updateState10(String string) {
      ConfigManager configManager = computeConfigManager();
      if (configManager != null) {
         String string2 = configManager.computeString(string);
         if (string2 != null) {
            ClipboardUtil.copy(string2);
            this.updateState14("Copied ‘" + string + "’  ·  paste it anywhere to share", false);
         } else {
            this.updateState14("Couldn't copy ‘" + string + "’  ·  the file could not be read", true);
            ClientSounds.updateState2();
         }
      }
   }

   @Override
   public boolean checkCondition2(char charValue) {
      return this.textInputModel.checkCondition3(charValue);
   }

   @Override
   protected void updateStateForUiContext(UiContext uiContext, Rect rect, boolean booleanValue, float opacity) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      float floatValue2 = ButtonWidgets.computeFloatForUiContext(uiContext, "Paste", Icon.CLIPBOARD);
      float floatValue3 = ButtonWidgets.computeFloatForUiContext(uiContext, "Save", null);
      Rect rect2 = new Rect(rect.getX(), rect.getY(), rect.getWidth() - floatValue3 - floatValue2 - 12.0F, 24.0F);
      TextInputWidget.updateStateForUiContext(uiContext, "configs.name", rect2, UiLayer.MODAL, getTextInputModel(this), "Name a new config", Icon.PLUS, opacity);
      Rect rect3 = new Rect(rect2.right() + 6.0F, rect.getY(), floatValue3, 24.0F);
      Rect rect4 = new Rect(rect3.right() + 6.0F, rect.getY(), floatValue2, 24.0F);
      ButtonWidgets.updateStateForUiContext(uiContext, "configs.save", rect3, UiLayer.MODAL, ButtonVariant.PRIMARY, "Save", null, !getTextInputModel(this).toString().isBlank(), opacity, booleanValue ? () -> this.updateState4() : null);
      ButtonWidgets.updateStateForUiContext4(uiContext, "configs.paste", rect4, UiLayer.MODAL, ButtonVariant.SECONDARY, "Paste", Icon.CLIPBOARD, opacity, booleanValue ? () -> this.updateState3() : null);
      Rect rect5 = new Rect(rect.getX(), rect.getY() + 24.0F + 10.0F, rect.getWidth(), rect.getHeight() - 24.0F - 10.0F);
      if (this.stringList.isEmpty()) {
         EmptyStateWidget.updateStateForUiContext(uiContext, rect5, Icon.FOLDER, "No configs yet", "Name your current setup above and save it, or paste one a friend copied.", opacity);
      } else {
         float floatValue4 = this.scrollModel.update(uiContext, (float)this.stringList.size() * 30.0F, rect5.getHeight());
         uiContext.getInputRouter().addScrollRegion(rect5, UiLayer.MODAL, getScrollModel(this)::scroll);
         uiContext.getUiRenderContext().pushClip(rect5.getX() - 2.0F, rect5.getY(), rect5.getWidth() + 4.0F, rect5.getHeight());

         for (int intValue = 0; intValue < this.stringList.size(); intValue++) {
            String text = this.stringList.get(intValue);
            Rect rect6 = new Rect(rect5.getX(), rect5.getY() + (float)intValue * 30.0F - floatValue4, rect5.getWidth(), 27.0F);
            if (!(rect6.bottom() < rect5.getY()) && !(rect6.getY() > rect5.bottom())) {
               Rect rect7 = rect6.intersection(rect5);
               boolean hovered = booleanValue && uiContext.isHovered(rect7, UiLayer.MODAL);
               float progress = uiContext.animateHover("configs.row." + text, hovered);
               float floatValue6 = uiContext.getAnimations().exponential("configs.enter." + text, 0.0F, 1.0F, 0.06F + (float)intValue * 0.01F);
               float floatValue7 = opacity * floatValue6;
               PanelRenderer.updateStateForUiContext7(uiContext, rect6, 8.0F, progress, floatValue7);
               uiContext.getUiRenderContext().fillRoundedRect(rect6.getX() + 7.0F, rect6.centerY() - 8.0F, 16.0F, 16.0F, 5.0F, UiContext.multiplyAlpha(UiContext.blendColors(themeSnapshot2.getSurfaceSunken(), themeSnapshot2.getAccentSoft2(), progress), floatValue7));
               UiShapeRenderer.updateStateForUiRenderContext3(uiContext.getUiRenderContext(), Icon.FOLDER, rect6.getX() + 15.0F, rect6.centerY(), 9.0F, UiContext.multiplyAlpha(UiContext.blendColors(themeSnapshot2.getSecondaryText2(), themeSnapshot2.getAccentText2(), progress), floatValue7));
               uiContext.drawVerticallyCenteredText(uiContext.ellipsize(text, TextStyle.STRONG, rect6.getWidth() - 100.0F), rect6.getX() + 30.0F, rect6.centerY(), TextStyle.STRONG, UiContext.multiplyAlpha(themeSnapshot2.getPrimaryText(), floatValue7));
               if (booleanValue) {
                  uiContext.getInputRouter().addClickRegion(rect7, UiLayer.MODAL, () -> this.updateState7(text));
               }

               Rect rect8 = new Rect(rect6.right() - 24.0F, rect6.centerY() - 9.0F, 18.0F, 18.0F);
               Rect rect9 = new Rect(rect8.getX() - 20.0F, rect6.centerY() - 9.0F, 18.0F, 18.0F);
               float floatValue8 = Math.max(progress, 0.35F);
               ButtonWidgets.updateStateForUiContext2(uiContext, "configs.copy." + text, rect9, UiLayer.MODAL, Icon.COPY, floatValue7 * floatValue8, booleanValue ? () -> this.updateState5(text) : null);
               ButtonWidgets.updateStateForUiContext2(uiContext, "configs.delete." + text, rect8, UiLayer.MODAL, Icon.TRASH, floatValue7 * floatValue8, booleanValue ? () -> this.updateState(text) : null);
            }
         }

         uiContext.getUiRenderContext().popClip();
         getScrollModel(this).drawScrollbar(uiContext, rect5, (float)this.stringList.size() * 30.0F, opacity);
      }
   }

   @Override
   public boolean checkCondition3(int intValue, boolean booleanValue) {
      if (!this.textInputModel.getBooleanState2()) {
         return false;
      } else if (intValue != 257 && intValue != 335) {
         if (intValue == 256) {
            getTextInputModel(this).updateState3(false);
            return true;
         } else {
            return this.textInputModel.checkCondition(intValue, booleanValue);
         }
      } else {
         if (!this.textInputModel.toString().isBlank()) {
            ClientSounds.updateState3();
            this.updateState4();
         }

         return true;
      }
   }

   private void updateState11() {
      ConfigManager configManager = computeConfigManager();
      setStringList(this, configManager == null ? List.of() : List.copyOf(configManager.computeList()));
   }

   private void updateState12(String string) {
      ConfigManager configManager = computeConfigManager();
      if (configManager != null) {
         configManager.updateState6(string);
         this.updateState14("Loaded ‘" + string + "’", false);
         ClientSounds.updateState3();
         this.updateState11();
      }
   }
}
