package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public class EntityBoundsAccess {
   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static double getMinX(Box box) {
      return box.minX;
   }

   public static double getX(Vec3d vec3d) {
      return vec3d.x;
   }

   public static boolean getBooleanState() {
      return AutoStunModule.booleanState;
   }

   public static Item getSHIELD() {
      return Items.SHIELD;
   }

   public static double getMinZ(Box box) {
      return box.minZ;
   }

   public static ClientWorld getWorld(MinecraftClient minecraftClient) {
      return minecraftClient.world;
   }

   public static void setBooleanState(boolean booleanState) {
      AutoStunModule.booleanState = booleanState;
   }

   public static double getY(Vec3d vec3d) {
      return vec3d.y;
   }

   public static double getMinY(Box box) {
      return box.minY;
   }

   public static HitResult getCrosshairTarget(MinecraftClient minecraftClient) {
      return minecraftClient.crosshairTarget;
   }

}
