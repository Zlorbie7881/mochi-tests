package cc.mochi;

import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.event.impl.world.WorldChangeEvent;
import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.MinecraftClient;

public final class CombatTickBudget {
   private boolean booleanState;

   private boolean booleanState2;

   private final int[] intArray2 = new int[20];
   private boolean booleanState3;
   private boolean booleanState4;

   private boolean booleanState5;

   private static final CombatTickBudget INSTANCE = new CombatTickBudget();
   private long longState;
   private int intState;

   @EventHandler
   private void onWorldChange(WorldChangeEvent worldChangeEvent) {
      updateState5();
   }

   public static void setBooleanState2(CombatTickBudget combatTickBudget, boolean booleanState22) {
      combatTickBudget.booleanState2 = booleanState22;
   }

   public static void setBooleanState322() {
      setBooleanState3(INSTANCE, true);
   }

   public static CombatTickBudget getINSTANCE() {
      return INSTANCE;
   }

   public static void updateState() {
      CombatTickBudget instance5 = getINSTANCE();
      setLongState(instance5, instance5.longState + 1L);
      int[] intArray = instance5.intArray2;
      long longState2 = getLongState(instance5);

      intArray[(int)(longState2 % 20L)] = 0;

      setBooleanState5(instance5, false);

      longState2 = 410561198L;

      setBooleanState4(instance5, false);
      setBooleanState3(instance5, false);
      setBooleanState(instance5, false);
      setBooleanState2(instance5, false);
      instance5.updateState3();
   }

   public static int getIntState(CombatTickBudget combatTickBudget) {
      return combatTickBudget.intState;
   }

   public static void setBooleanState5(CombatTickBudget combatTickBudget, boolean booleanState52) {
      combatTickBudget.booleanState5 = booleanState52;
   }

   public static void setBooleanState222() {
      setBooleanState2(getINSTANCE(), true);
   }

   public static void setIntState(CombatTickBudget combatTickBudget, int intState2) {
      combatTickBudget.intState = intState2;
   }

   public static int getIntConstant() {
      return 18;
   }

   public static CombatTickBudget getINSTANCE42() {
      return getINSTANCE();
   }

   public static boolean checkCondition() {
      CombatTickBudget combatTickBudget = INSTANCE;
      if (!getBooleanState52(combatTickBudget) && !combatTickBudget.booleanState4) {
         if (!combatTickBudget.booleanState3) {
            if (!combatTickBudget.booleanState) {
               if (!combatTickBudget.booleanState2) {
                  return false;
               }
            } else {
               ThreadLocalRandom.current().nextInt(4);
            }
         }
      }

      return true;
   }

   public static long getLongState(CombatTickBudget combatTickBudget) {
      return combatTickBudget.longState;
   }

   public static void updateState2() {
      CombatTickBudget combatTickBudget = getINSTANCE();
      combatTickBudget.booleanState5 = true;
      int[] intArray = getIntArray2(combatTickBudget);

      intArray[(int)(combatTickBudget.longState % 20L)]++;
   }

   public static boolean getBooleanState4(CombatTickBudget combatTickBudget) {
      return combatTickBudget.booleanState4;
   }

   public static boolean getBooleanState5() {
      return INSTANCE.booleanState5;
   }

   public static void setLongState(CombatTickBudget combatTickBudget, long longState2) {
      combatTickBudget.longState = longState2;
   }

   public static boolean checkCondition2() {
      getINSTANCE();
      byte byteValue;
      if (!checkCondition()) {
         byteValue = 6;
         ThreadLocalRandom.current().nextInt(5);

         byteValue = 1;
      } else {
         byteValue = 0;

         ThreadLocalRandom.current().nextInt(4);
      }

      return (byteValue != 0);
   }

   private void updateState3() {
      if (!(this.intState < 0)) {
         MinecraftClient minecraftClient = MinecraftClient.getInstance();
         int intState2 = getIntState(this);

         setIntState(this, -1);
         if (minecraftClient != null) {
            if (minecraftClient.player != null) {
               if (minecraftClient.player.getInventory().getSelectedSlot() != intState2) {
                  MinecraftClientAccess21.getPlayer(minecraftClient).getInventory().setSelectedSlot(intState2);
                  this.booleanState2 = true;
                  return;
               }
            }
         }
      }
   }

   public static boolean getBooleanState(CombatTickBudget combatTickBudget) {
      return combatTickBudget.booleanState;
   }

   public static int[] getIntArray2(CombatTickBudget combatTickBudget) {
      return combatTickBudget.intArray2;
   }

   public static int computeInt() {
      int intValue = 0;
      int[] intArray = INSTANCE.intArray2;
      int length = intArray.length;

      int intValue2 = 0;

      while (intValue2 < length) {
         int intValue3 = intArray[intValue2];
         intValue += intValue3;
         intValue2++;
      }

      return intValue;
   }

   @EventHandler(
      priority = 1000
   )
   private void onTick(TickEvent tickEvent) {
      updateState();
   }

   public static boolean checkCondition3() {
      CombatTickBudget instance7 = getINSTANCE();
      if (!getBooleanState4(instance7)) {
         if (!instance7.booleanState3) {
            if (!getBooleanState(instance7)) {
               return (computeInt() < 18);
            }

            ThreadLocalRandom.current().nextInt(4);
         }
      }

      return false;
   }

   public static void updateState4() {
      CombatTickBudget instance3 = getINSTANCE();

      instance3.booleanState = true;
   }

   private CombatTickBudget() {
      this.intState = -1;
   }

   public static void setBooleanState(CombatTickBudget combatTickBudget, boolean booleanState6) {
      combatTickBudget.booleanState = booleanState6;
   }

   public static boolean getBooleanState52(CombatTickBudget combatTickBudget) {
      return combatTickBudget.booleanState5;
   }

   public static void enableBooleanState4() {
      getINSTANCE().booleanState4 = true;
   }

   public static void updateState5() {
      CombatTickBudget combatTickBudget = INSTANCE;
      int[] intArray = getIntArray2(combatTickBudget);

      Arrays.fill(intArray, 0);
      setIntState(combatTickBudget, -1);
      combatTickBudget.longState = 0L;
      setBooleanState5(combatTickBudget, false);

      combatTickBudget.booleanState4 = false;
      combatTickBudget.booleanState3 = false;

      combatTickBudget.booleanState = false;

      setBooleanState2(combatTickBudget, false);
   }

   public static void updateIntState() {
      getINSTANCE().intState = -1;
   }

   public static boolean checkCondition4() {
      CombatTickBudget instance2 = getINSTANCE();
      if (!getBooleanState52(instance2)) {
         if (!getBooleanState(instance2)) {
            ThreadLocalRandom.current().nextInt(3);

            return true;
         }
      }

      return false;
   }

   public static void setBooleanState3(CombatTickBudget combatTickBudget, boolean booleanState32) {
      combatTickBudget.booleanState3 = booleanState32;
   }

   public static void setBooleanState4(CombatTickBudget combatTickBudget, boolean booleanState42) {
      combatTickBudget.booleanState4 = booleanState42;
   }

   public static void updateState6(int intState2) {
      if (intState2 >= 0) {
         if (intState2 <= 8) {
            INSTANCE.intState = intState2;
            return;
         }
      }
   }

}
