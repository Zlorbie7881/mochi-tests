package cc.mochi;

public class ClickGuiActionSwitchMap {
   static final int[] intArray3 = new int[ClickGuiTab.values().length];

   static {
      try {
         int[] intArray = intArray3;
         int intValue = ClickGuiTab.KEYBINDS.ordinal();

         intArray[intValue] = 1;
      } catch (NoSuchFieldError failure) {
      }

      label42: {
         try {
            intArray3[ClickGuiTab.HUD_EDITOR.ordinal()] = 2;
         } catch (NoSuchFieldError failure2) {
            break label42;
         }
      }

      label38: {
         try {
            int[] intArray2 = intArray3;
            int intValue2 = ClickGuiTab.SELF_DESTRUCT.ordinal();

            intArray2[intValue2] = 3;
         } catch (NoSuchFieldError failure3) {
            break label38;
         }
      }
   }
}
