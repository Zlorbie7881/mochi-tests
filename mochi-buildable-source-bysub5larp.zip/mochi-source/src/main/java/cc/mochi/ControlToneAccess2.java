package cc.mochi;

public class ControlToneAccess2 {
   public static ControlTone getNEUTRAL() {
      return ControlTone.NEUTRAL;
   }

   public static ControlTone getDANGER() {
      return ControlTone.DANGER;
   }

}
