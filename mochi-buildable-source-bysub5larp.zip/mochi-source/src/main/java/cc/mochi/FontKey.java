package cc.mochi;

import org.jetbrains.annotations.NotNull;

record FontKey(int size, FontFamily type) {
   public FontFamily getType() {
      return this.type;
   }

   public int getSize() {
      return this.size;
   }

   @NotNull
   @Override
   public String toString() {
      return "FontKey[size=" + this.size + ", type=" + this.type + "]";
   }
}
