package cc.mochi;

import java.awt.Color;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.util.math.MathHelper;

public final class LegacyUiTheme {
   public static final FontFace fontFace3 = FontFace.REGULAR;

   public static final FontFace fontFace = FontFace.MEDIUM;
   public static final FontFace fontFace2 = FontFace.SEMIBOLD;

   public static final Color color3 = new Color(244, 244, 244);
   public static final Color color5 = new Color(180, 180, 180);
   public static final Color color4 = new Color(145, 145, 145);

   public static final Color color = new Color(9, 11, 16);
   private static final Color color2 = new Color(0, 0, 0, 0);

   public static Color createColor(Color color6, float floatValue) {
      return new Color(color6.getRed(), color6.getGreen(), color6.getBlue(), MathHelper.clamp(Math.round((255.0F) * floatValue), 0, 255));
   }

   public static void updateStateForThemeSnapshot(float x, float y, float width, float height, int intValue, boolean booleanValue, boolean booleanValue2, boolean booleanValue3, boolean booleanValue4, ThemeSnapshot themeSnapshot) {
      float floatValue = (float)MathHelper.clamp(intValue, 0, 255) / 255.0F;
      if (booleanValue2 && floatValue > (0.05F)) {
         HudBloomRenderer.drawGlowOutline(x, y, width, height, (8.0F), (12.0F), 3.0F, createColor(Color.BLACK, 0.22F * floatValue));
      }

      if (booleanValue && HudBloomRenderer.checkCondition()) {
         BlurQualityAccess.checkCondition(x, y, width, height, 8.0F, ClickGuiModule.floatValue2(), ClickGuiModule.getSelected());
      }

      label66: {
         if (booleanValue3) {
            if (HudBloomRenderer.checkCondition()) {
               cc.mochi.CamouflageRenderer.checkCondition6((float)System.nanoTime() / (1.0E9F), ClickGuiModule.computeColorArrayForThemeSnapshot(themeSnapshot));
               HudBloomRenderer.drawCamouflage(x, y, width, height, 8.0F);

               break label66;
            }
         }

         if (floatValue > 0.0F) {
            HudBloomRenderer.fillRoundedRect(x, y, width, height, (8.0F), createColor(ColorAccess7.getColor(), floatValue));
         }
      }

      if (floatValue > (0.05F)) {
         float x2 = x + (0.5F);
         float y2 = y + 0.5F;
         float width2 = width - 1.0F;

         HudBloomRenderer.fillVerticalGradient(
            x2, y2, width2, Math.min(height * (0.5F), (10.0F)), 7.5F, createColor(ColorAccess7.getWHITE(), 0.045F * floatValue), color2
         );

         HudBloomRenderer.strokeRoundedRect(x, y, width, height, 8.0F, (1.0F), createColor(ColorAccess7.getWHITE(), 0.07F * floatValue));
      }

      if (booleanValue4) {
         Color color6 = computeColorForThemeSnapshot2(themeSnapshot);
         HudBloomRenderer.pushClip(x, y, (3.0F), height);
         updateStateForRunnable2(() -> fillRoundedRect(x, y, height, color6));
         HudBloomRenderer.popClip();
      }
   }

   public static void updateStateForRunnable(float intensity, Runnable runnable) {
      HudBloomRenderer.pushBloom(intensity);

      boolean booleanValue = false /* VF: Semaphore variable */;

      try {
         booleanValue = true;
         runnable.run();
         booleanValue = false;
      } finally {
         if (booleanValue) {
            HudBloomRenderer.popBloom();
         }
      }

      HudBloomRenderer.popBloom();
   }

   private static void fillRoundedRect(float x, float y, float height, Color color6) {
      HudBloomRenderer.fillRoundedRect(x, y, (11.0F), height, (8.0F), color6);
   }

   public static Color computeColorForThemeSnapshot(ThemeSnapshot themeSnapshot, float floatValue) {
      Color color6 = computeColorForThemeSnapshot2(themeSnapshot);

      Color color7 = new Color(255, 196, 84);
      Color color8 = ThemeSnapshot.computeColorForColor(themeSnapshot.getDanger());

      if (floatValue >= (0.55F)) {
         return color6;
      } else {
         if (floatValue >= (0.3F)) {
            return computeColorForColor(color7, color6, (floatValue - 0.3F) / (0.25F));
         } else {
            return computeColorForColor(color8, color7, Math.max(0.0F, floatValue) / (0.3F));
         }
      }
   }

   public static Color computeColorForColor(Color color6, Color color7, float floatValue) {
      floatValue = MathHelper.clamp(floatValue, 0.0F, 1.0F);
      return new Color(
         Math.round((float)color6.getRed() + (float)(color7.getRed() - color6.getRed()) * floatValue),
         Math.round((float)color6.getGreen() + (float)(color7.getGreen() - color6.getGreen()) * floatValue),
         Math.round((float)color6.getBlue() + (float)(color7.getBlue() - color6.getBlue()) * floatValue)
      );
   }

   public static void drawText(String text, float x, float y, float size, Color color6, FontFace font) {
      HudBloomRenderer.drawText(text, x, y, size, color6, font);
   }

   public static float measureFontHeight(float size, FontFace font) {
      return HudBloomRenderer.measureFontHeight(size, font);
   }

   public static float computeFloat(String string, float x, float y, float size) {
      String text = string.toUpperCase(Locale.ROOT);
      HudBloomRenderer.drawText(text, x, y, size, ColorAccess7.getColor5(), ColorAccess7.getFontFace2());
      return HudBloomRenderer.measureText(text, size, fontFace2);
   }

   public static void drawText22(String text, float floatValue, float floatValue2, float size, Color color6, FontFace font) {
      drawText2(text, floatValue - measureText(text, size, font) / 2.0F, floatValue2, size, color6, font);
   }

   public static void updateStateForRunnable2(Runnable runnable) {
      updateStateForRunnable((0.8F), runnable);
   }

   public static float measureText(String text, float size, FontFace font) {
      return HudBloomRenderer.measureText(text, size, font);
   }

   public static Color computeColorForThemeSnapshot2(ThemeSnapshot themeSnapshot) {
      return ThemeSnapshot.computeColorForColor(themeSnapshot.getAccent2());
   }

   private LegacyUiTheme() {
   }

   public static String computeStringForFontFace(String text, float size, FontFace font, float floatValue) {
      if (text == null) {
         return "";
      } else {
         if (measureText(text, size, font) <= floatValue) {
            ThreadLocalRandom.current().nextInt(13);

            return text;
         } else {
            ThreadLocalRandom.current().nextInt(17);
            String string = text;

            while (true) {
               if (string.length() > 1) {
                  ThreadLocalRandom.current().nextInt(12);
                  if (measureText(string + "…", size, font) > floatValue) {
                     string = string.substring(0, string.length() - 1);
                     continue;
                  }

                  ThreadLocalRandom.current().nextInt(3);
                  break;
               }

               break;
            }

            return string + "…";
         }
      }
   }

   public static void updateStateForColor(float x, float y, float width, float height, float floatValue, Color color6, float floatValue2) {
      float radius = height / 2.0F;
      HudBloomRenderer.fillRoundedRect(x, y, width, height, radius, createColor(ColorAccess7.getWHITE(), (0.1F) * floatValue2));
      float floatValue3 = width * MathHelper.clamp(floatValue, 0.0F, 1.0F);
      if (floatValue3 > 0.5F) {
         updateStateForRunnable((0.6F), () -> fillRoundedRect2(x, y, height, floatValue3, radius, color6, floatValue2));
      }
   }

   private static void fillRoundedRect2(float x, float y, float height, float floatValue, float radius, Color color6, float floatValue2) {
      HudBloomRenderer.fillRoundedRect(x, y, Math.max(height, floatValue), height, radius, createColor(color6, floatValue2));
   }

   public static float measureText2(String string, float size) {
      return HudBloomRenderer.measureText(string.toUpperCase(ColorAccess7.getROOT()), size, ColorAccess7.getFontFace2());
   }

   public static float computeFloat2(float floatValue, float floatValue2) {
      return (1.0F) - (float)Math.exp((double)(-floatValue2 * Math.max(0.0F, floatValue)));
   }

   public static void drawText2(String text, float x, float floatValue, float size, Color color6, FontFace font) {
      HudBloomRenderer.drawText(text, x, floatValue - measureFontHeight(size, font) / (2.0F), size, color6, font);
   }

   public static void drawText3(String text, float floatValue, float y, float size, Color color6, FontFace font) {
      HudBloomRenderer.drawText(text, floatValue - measureText(text, size, font), y, size, color6, font);
   }
}
