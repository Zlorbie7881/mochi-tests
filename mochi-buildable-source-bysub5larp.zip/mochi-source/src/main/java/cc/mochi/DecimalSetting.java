package cc.mochi;

import java.math.BigDecimal;
import java.util.concurrent.ThreadLocalRandom;

public class DecimalSetting extends Setting {
   private final double maximum;
   private final double minimum;
   private final double defaultValue;
   private double value;

   private final int decimalPlaces;

   public static double getDefaultValue2(DecimalSetting decimalSetting) {
      return decimalSetting.defaultValue;
   }

   public double getMaximum() {
      return getMaximum2(this);
   }

   public double getValue() {
      return getValue2(this);
   }

   @Override
   public boolean isDefault() {
      return (this.value == this.defaultValue);
   }

   public static void setValue2(DecimalSetting decimalSetting, double value2) {
      decimalSetting.value = value2;
   }

   public static double getMaximum2(DecimalSetting decimalSetting) {
      return decimalSetting.maximum;
   }

   public int getDecimalPlaces() {
      return getDecimalPlaces2(this);
   }

   public static double getMinimum2(DecimalSetting decimalSetting) {
      return decimalSetting.minimum;
   }

   public static double getValue2(DecimalSetting decimalSetting) {
      return decimalSetting.value;
   }

   public static int getDecimalPlaces2(DecimalSetting decimalSetting) {
      return decimalSetting.decimalPlaces;
   }

   public double getMinimum() {
      return getMinimum2(this);
   }

   public DecimalSetting(String name, double doubleValue, double minimum2, double maximum2, int decimalPlaces2) {
      super(name);
      this.minimum = minimum2;
      this.maximum = maximum2;
      this.decimalPlaces = decimalPlaces2;
      this.setValue(doubleValue);
      this.defaultValue = this.value;
   }

   public String formatValue() {
      int decimalPlaces2 = this.decimalPlaces;
      String string = "%." + decimalPlaces2 + "f";

      return String.format(string, this.getRoundedValue());
   }

   public double getRoundedValue() {
      return this.roundValue(this.value);
   }

   private double roundValue(double doubleValue) {
      if (this.decimalPlaces <= 0) {
         ThreadLocalRandom.current().nextInt(8);
         return (double)Math.round(doubleValue);
      } else {
         return new BigDecimal(doubleValue).setScale(getDecimalPlaces2(this), RoundingModeAccess.getHALF_UP()).doubleValue();
      }
   }

   @Override
   public void reset() {
      setValue2(this, getDefaultValue2(this));
   }

   public void setValue(double doubleValue) {
      double value2 = Math.max(this.minimum, Math.min(this.maximum, doubleValue));
      if (Double.compare(this.value, value2) != 0) {
         setValue2(this, value2);
      } else {
         this.value = value2;
      }
   }

   public double getDefaultValue() {
      return getDefaultValue2(this);
   }

}
