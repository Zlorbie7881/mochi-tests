package cc.mochi;

import net.minecraft.util.math.Box;

public record HazardVolume(HazardKind danger, Box box, double value) {
   public double getValue() {
      return this.value;
   }

   public Box getBox2() {
      return getBox(this);
   }

   public HazardKind getDanger2() {
      return getDanger(this);
   }

   public static HazardKind getDanger(HazardVolume hazardVolume) {
      return hazardVolume.danger;
   }

   public static Box getBox(HazardVolume hazardVolume) {
      return hazardVolume.box;
   }
}
