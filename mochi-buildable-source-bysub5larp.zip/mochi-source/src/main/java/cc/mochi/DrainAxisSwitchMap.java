package cc.mochi;

import net.minecraft.util.math.Direction.Axis;

public class DrainAxisSwitchMap {
   static final int[] intArray2 = new int[Axis.values().length];

   static {
      try {
         int[] intArray = intArray2;
         int intValue = Axis.X.ordinal();

         intArray[intValue] = 1;
      } catch (NoSuchFieldError failure) {
      }

      label42: {
         try {
            intArray2[Axis.Y.ordinal()] = 2;
         } catch (NoSuchFieldError failure2) {
            break label42;
         }
      }

      label38: {
         try {
            intArray2[Axis.Z.ordinal()] = 3;
         } catch (NoSuchFieldError failure3) {
            break label38;
         }
      }
   }
}
