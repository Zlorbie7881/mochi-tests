package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil.Type;
import net.minecraft.screen.slot.Slot;

public class MinecraftClientAccess51 {
   public static GameOptions getOptions(MinecraftClient minecraftClient) {
      return minecraftClient.options;
   }

   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static Screen getCurrentScreen(MinecraftClient minecraftClient) {
      return minecraftClient.currentScreen;
   }

   public static KeyBinding getRightKey(GameOptions gameOptions) {
      return gameOptions.rightKey;
   }

   public static KeyBinding getForwardKey(GameOptions gameOptions) {
      return gameOptions.forwardKey;
   }

   public static KeyBinding getInventoryKey(GameOptions gameOptions) {
      return gameOptions.inventoryKey;
   }

   public static ClientPlayerInteractionManager getInteractionManager(MinecraftClient minecraftClient) {
      return minecraftClient.interactionManager;
   }

   public static KeyBinding getJumpKey(GameOptions gameOptions) {
      return gameOptions.jumpKey;
   }

   public static KeyBinding getPickItemKey(GameOptions gameOptions) {
      return gameOptions.pickItemKey;
   }

   public static int getY(Slot slot) {
      return slot.y;
   }

   public static KeyBinding getLeftKey(GameOptions gameOptions) {
      return gameOptions.leftKey;
   }

   public static KeyBinding getDropKey(GameOptions gameOptions) {
      return gameOptions.dropKey;
   }

   public static Type getSCANCODE() {
      return Type.SCANCODE;
   }

   public static int getX(Slot slot) {
      return slot.x;
   }

   public static int getId(Slot slot) {
      return slot.id;
   }

   public static KeyBinding getSwapHandsKey(GameOptions gameOptions) {
      return gameOptions.swapHandsKey;
   }

   public static KeyBinding[] getHotbarKeys(GameOptions gameOptions) {
      return gameOptions.hotbarKeys;
   }
}
