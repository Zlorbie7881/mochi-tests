package cc.mochi;

public final class HudEditorModule extends Module {
   public void setScreen() {
      mc.setScreen(new HudEditorScreen());
   }

   public HudEditorModule() {
      super("Hud Editor", "Opens the HUD editor to reposition HUD elements", -1, ModuleCategory.CLIENT);
   }

   @Override
   public void onEnable() {
      this.setScreen();

      this.setEnabled(false);
   }
}
