package cc.mochi;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL33;

public final class GlTextureBindings implements AutoCloseable {
   private final int[] intArray2;
   private final int[] intArray3;

   private final int intState;

   private GlTextureBindings(int[] intArray) {
      this.intArray3 = (int[])intArray.clone();
      this.intArray2 = new int[intArray.length];
      this.intState = GL11.glGetInteger(GL13.GL_ACTIVE_TEXTURE);

      for (int intValue = 0; intValue < intArray.length; intValue++) {
         GL13.glActiveTexture(33984 + intArray[intValue]);
         this.intArray2[intValue] = GL11.glGetInteger(GL33.GL_SAMPLER_BINDING);
         GL33.glBindSampler(intArray[intValue], 0);
      }

      GL13.glActiveTexture(this.intState);
   }

   public static GlTextureBindings createGlTextureBindings(int... intArray) {
      return new GlTextureBindings(intArray);
   }

   @Override
   public void close() {
      for (int intValue = 0; intValue < this.intArray3.length; intValue++) {
         GL33.glBindSampler(this.intArray3[intValue], this.intArray2[intValue]);
      }

      GL13.glActiveTexture(this.intState);
   }
}
