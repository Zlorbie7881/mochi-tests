package cc.mochi;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class AnimationRegistry {
   private static final Map<String, FloatAnimation> floatAnimationByString = new ConcurrentHashMap<>();

   public static float computeFloat(String string, float floatState3, long longValue) {
      return computeFloatForEasingFunction(string, floatState3, longValue, EasingFunctionAccess.OUT_CUBIC);
   }

   public static boolean checkCondition(String string) {
      FloatAnimation floatAnimation = floatAnimationByString.get(string);
      return floatAnimation == null || floatAnimation.getBooleanState();
   }

   public static float computeFloat2(String string, float floatValue) {
      float floatValue2 = (float)System.currentTimeMillis() * 0.001F * floatValue;
      return 0.5F + 0.5F * (float)Math.sin((double)floatValue2);
   }

   private AnimationRegistry() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }

   public static void remove(String string) {
      floatAnimationByString.remove(string);
   }

   public static void clear() {
      floatAnimationByString.clear();
   }

   public static float computeFloatForEasingFunction(String string, float floatState3, long longValue, EasingFunction easingFunction) {
      FloatAnimation floatAnimation = floatAnimationByString.get(string);
      if (floatAnimation == null) {
         floatAnimation = new FloatAnimation(0.0F, floatState3, longValue, easingFunction);
         floatAnimationByString.put(string, floatAnimation);
      } else if (floatAnimation.floatState3 != floatState3) {
         floatAnimation.updateState(floatState3);
      }

      return floatAnimation.computeFloat();
   }

   public static float computeFloat3(String string, float floatValue, float floatValue2, float floatValue3) {
      float floatValue4 = (float)System.currentTimeMillis() * 0.001F * floatValue + floatValue3;
      return floatValue2 * (float)Math.sin((double)floatValue4);
   }
}
