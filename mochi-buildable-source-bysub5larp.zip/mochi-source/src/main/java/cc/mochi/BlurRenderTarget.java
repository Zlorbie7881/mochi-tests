package cc.mochi;

record BlurRenderTarget(int fbo, int texture, int width, int height) {
   public int getHeight() {
      return this.height;
   }

   public int getFbo() {
      return this.fbo;
   }

   public int getWidth() {
      return this.width;
   }

   public int getTexture() {
      return this.texture;
   }
}
