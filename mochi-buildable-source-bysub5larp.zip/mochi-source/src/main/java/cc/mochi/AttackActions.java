package cc.mochi;

import cc.mochi.mixin.MinecraftClientAccessor;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.world.GameMode;

public class AttackActions {
   private static boolean booleanState = false;

   public static boolean testMinecraftClient(MinecraftClient minecraftClient, String string) {
      if (MinecraftClientAccess28.getPlayer(minecraftClient) != null && MinecraftClientAccess28.getWorld(minecraftClient) != null) {
         if (MinecraftClientAccess28.getInteractionManager(minecraftClient) != null) {
            if (getAttackCooldown(minecraftClient) > 0) {
               ThreadLocalRandom.current().nextInt(16);
               return false;
            }

            if (minecraftClient.crosshairTarget == null) {
               return false;
            }

            ItemStack stackInHand = minecraftClient.player.getStackInHand(Hand.MAIN_HAND);
            if (!stackInHand.isEmpty() && !stackInHand.isItemEnabled(MinecraftClientAccess28.getWorld(minecraftClient).getEnabledFeatures())) {
               return false;
            }

            if (MinecraftClientAccess28.getInteractionManager(minecraftClient).getCurrentGameMode() == MinecraftClientAccess28.getSPECTATOR()) {
               return false;
            }

            if (minecraftClient.crosshairTarget.getType() == Type.ENTITY && !((EntityHitResult)minecraftClient.crosshairTarget).getEntity().isAlive()) {
               return false;
            }

            if (!CombatTickBudget.checkCondition3()) {
               return false;
            }

            if ((minecraftClient.crosshairTarget.getType() == Type.ENTITY ? ((EntityHitResult)MinecraftClientAccess28.getCrosshairTarget(minecraftClient)).getEntity() : null) instanceof PlayerEntity var6
               && FriendManager.testPlayerEntity(var6)) {
               return false;
            }

            booleanState = true;

            try {
               ((MinecraftClientAccessor)minecraftClient).invokeDoAttack();
            } catch (Throwable failure) {
               Throwable throwable = failure;

               Throwable throwable2;
               while (true) {
                  try {
                     throwable2 = throwable;
                     break;
                  } catch (Throwable failure2) {
                     throwable = failure2;

                     continue;
                  }
               }

               booleanState = false;
               throw UncheckedExceptions.rethrow(throwable2);
            }

            setBooleanState(false);
            return true;
         }
      }

      return false;
   }

   public static boolean testMinecraftClient2(MinecraftClient minecraftClient, Entity entity, String string, double doubleValue) {
      java.lang.Throwable throwable;

      if (minecraftClient.player != null && MinecraftClientAccess28.getWorld(minecraftClient) != null && minecraftClient.interactionManager != null) {
         if (entity != null) {
            if (minecraftClient.attackCooldown <= 0) {
               if (entity.isAlive()) {
                  if (entity.isAttackable()) {
                     double doubleValue2 = Math.max((3.0), doubleValue);

                     double doubleValue3 = doubleValue2 + (0.001);
                     if (entity.getBoundingBox().squaredMagnitude(MinecraftClientAccess28.getPlayer(minecraftClient).getEyePos()) > doubleValue3 * doubleValue3) {
                        return false;
                     }

                     ItemStack stackInHand = minecraftClient.player.getStackInHand(Hand.MAIN_HAND);
                     if (!stackInHand.isEmpty()) {
                        if (!stackInHand.isItemEnabled(MinecraftClientAccess28.getWorld(minecraftClient).getEnabledFeatures())) {
                           return false;
                        }
                     }

                     if (minecraftClient.interactionManager.getCurrentGameMode() == GameMode.SPECTATOR) {
                        return false;
                     }

                     if (entity instanceof PlayerEntity var8) {
                        if (FriendManager.testPlayerEntity(var8)) {
                           return false;
                        }
                     }

                     setBooleanState(true);

                     label239: {
                        label219: {
                           try {
                              minecraftClient.interactionManager.attackEntity(MinecraftClientAccess28.getPlayer(minecraftClient), entity);
                              if (minecraftClient.player.isSpectator()) {
                                 break label239;
                              }
                           } catch (Throwable failure) {
                              throwable = failure;

                              break label219;
                           }

                           label216:
                           try {
                              minecraftClient.player.swingHand(MinecraftClientAccess28.getMAIN_HAND());
                              break label239;
                           } catch (Throwable failure2) {
                              throwable = failure2;

                              break label216;
                           }
                        }

                        Throwable throwable2;
                        while (true) {
                           try {
                              throwable2 = throwable;
                              break;
                           } catch (Throwable failure3) {
                              throwable = failure3;

                              continue;
                           }
                        }

                        setBooleanState(false);
                        throw UncheckedExceptions.rethrow(throwable2);
                     }

                     setBooleanState(false);
                     return true;
                  }

                  ThreadLocalRandom.current().nextInt(15);
               } else {
                  ThreadLocalRandom.current().nextInt(17);
               }
            }

            return false;
         }
      }

      return false;
   }

   public static int getAttackCooldown(MinecraftClient minecraftClient) {
      return minecraftClient.attackCooldown;
   }

   public static boolean getBooleanState2() {
      return getBooleanState();
   }

   public static void setBooleanState(boolean booleanState2) {
      booleanState = booleanState2;
   }

   public static boolean getBooleanState() {
      return booleanState;
   }

   public static boolean testMinecraftClient3(MinecraftClient minecraftClient) {
      if (minecraftClient.player != null) {
         if (minecraftClient.world != null) {
            if (minecraftClient.interactionManager != null) {
               if (getAttackCooldown(minecraftClient) > 0) {
                  return false;
               }

               if (minecraftClient.crosshairTarget == null) {
                  return false;
               }

               if (MinecraftClientAccess28.getPlayer(minecraftClient).isUsingItem()) {
                  return false;
               }

               ItemStack stackInHand = minecraftClient.player.getStackInHand(Hand.MAIN_HAND);
               if (!stackInHand.isEmpty() && !stackInHand.isItemEnabled(MinecraftClientAccess28.getWorld(minecraftClient).getEnabledFeatures())) {
                  return false;
               }

               if (minecraftClient.interactionManager.getCurrentGameMode() == GameMode.SPECTATOR) {
                  return false;
               }

               if (minecraftClient.crosshairTarget.getType() != MinecraftClientAccess28.getENTITY()) {
                  return true;
               }

               Entity entity = ((EntityHitResult)minecraftClient.crosshairTarget).getEntity();
               return !(!entity.isAlive() || entity instanceof PlayerEntity var4 && FriendManager.testPlayerEntity(var4));
            }
         }
      } else {
         ThreadLocalRandom.current().nextInt(6);
      }

      return false;
   }

   public static boolean testMinecraftClient4(MinecraftClient minecraftClient, Entity entity, String string) {
      return testMinecraftClient2(minecraftClient, entity, string, 3.0);
   }

   public static boolean testMinecraftClient5(MinecraftClient minecraftClient) {
      return testMinecraftClient(minecraftClient, "combat.attack.generic");
   }
}
