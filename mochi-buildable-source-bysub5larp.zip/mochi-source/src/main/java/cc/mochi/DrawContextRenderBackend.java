package cc.mochi;

import java.awt.Color;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.joml.Matrix3x2fStack;

final class DrawContextRenderBackend implements UiRenderBackend {
   private boolean scissorEnabled;
   private boolean closed;
   private final DrawContext drawContext;

   @Override
   public void drawTextureFromResource(String string, float x, float y, float width, float height, Color color) {
      String string2 = string.replace('\\', '/');
      String string3 = "assets/mochi/";
      if (string2.startsWith(string3)) {
         string2 = string2.substring(string3.length());
      }

      int intValue = Math.max(1, Math.round(width));
      int intValue2 = Math.max(1, Math.round(height));
      this.drawContext
         .drawTexture(
            RenderPipelines.GUI_TEXTURED,
            Identifier.of("mochi", string2),
            Math.round(x),
            Math.round(y),
            0.0F,
            0.0F,
            intValue,
            intValue2,
            intValue,
            intValue2,
            intValue,
            intValue2,
            color.getRGB()
         );
   }

   @Override
   public float measureText(String text, float size, FontFace font) {
      return text == null ? 0.0F : (float)MinecraftClient.getInstance().textRenderer.getWidth(text) * size / 9.0F;
   }

   @Override
   public float measureFontHeight(float size, FontFace font) {
      return Math.max(size, 1.0F);
   }

   @Override
   public void pushTransform() {
      this.drawContext.getMatrices().pushMatrix();
   }

   @Override
   public void rotate(float angle) {
      this.drawContext.getMatrices().rotate(angle);
   }

   @Override
   public void fillRoundedRect(float x, float y, float width, float height, float radius, Color color) {
      if (!(width <= 0.0F) && !(height <= 0.0F) && color.getAlpha() > 0) {
         int intValue = Math.max(0, Math.min(Math.round(radius), Math.min(Math.round(width), Math.round(height)) / 2));
         if (intValue == 0) {
            this.fillRect(x, y, width, height, color);
         } else {
            RenderUtils.updateStateForDrawContext11(this.drawContext, floor(x), floor(y), Math.max(1, Math.round(width)), Math.max(1, Math.round(height)), intValue, color.getRGB());
         }
      }
   }

   @Override
   public void drawCamouflage(float x, float y, float width, float height, float radius) {
   }

   @Override
   public void drawText(String text, float x, float y, float size, Color color, FontFace font) {
      if (text != null && !text.isEmpty() && !(size <= 0.0F)) {
         float floatValue = size / 9.0F;
         Matrix3x2fStack matrices = this.drawContext.getMatrices();
         matrices.pushMatrix();
         matrices.translate(x, y);
         matrices.scale(floatValue, floatValue);
         this.drawContext.drawText(MinecraftClient.getInstance().textRenderer, Text.literal(text), 0, 0, color.getRGB(), false);
         matrices.popMatrix();
      }
   }

   @Override
   public void applyClip() {
      if (this.scissorEnabled) {
         this.drawContext.disableScissor();
         this.scissorEnabled = false;
      }
   }

   @Override
   public void close() {
      if (!this.closed) {
         this.closed = true;
         this.applyClip();
         this.drawContext.getMatrices().popMatrix();
      }
   }

   @Override
   public void strokeRoundedRect(float x, float y, float width, float height, float radius, float thickness, Color color) {
      float floatValue4 = Math.max(1.0F, thickness);
      this.fillRoundedRect(x, y, width, floatValue4, Math.min(radius, floatValue4), color);
      this.fillRoundedRect(x, y + height - floatValue4, width, floatValue4, Math.min(radius, floatValue4), color);
      this.fillRect(x, y + floatValue4, floatValue4, Math.max(0.0F, height - floatValue4 * 2.0F), color);
      this.fillRect(x + width - floatValue4, y + floatValue4, floatValue4, Math.max(0.0F, height - floatValue4 * 2.0F), color);
   }

   @Override
   public void setClip(float x, float y, float width, float height) {
      if (this.scissorEnabled) {
         this.drawContext.disableScissor();
      }

      this.drawContext.enableScissor(floor(x), floor(y), ceil(x + width), ceil(y + height));
      this.scissorEnabled = true;
   }

   @Override
   public void fillRect(float x, float y, float width, float height, Color color) {
      if (!(width <= 0.0F) && !(height <= 0.0F) && color.getAlpha() > 0) {
         this.drawContext.fill(floor(x), floor(y), ceil(x + width), ceil(y + height), color.getRGB());
      }
   }

   @Override
   public void fillVerticalGradient(float x, float y, float width, float height, float radius, Color topColor, Color bottomColor) {
      if (!(width <= 0.0F) && !(height <= 0.0F)) {
         RenderUtils.updateStateForDrawContext5(
            this.drawContext, floor(x), floor(y), Math.max(1, Math.round(width)), Math.max(1, Math.round(height)), Math.max(0, Math.round(radius)), topColor.getRGB(), bottomColor.getRGB()
         );
      }
   }

   @Override
   public void drawTextureRegion(
      Identifier identifier,
      float floatValue,
      float floatValue2,
      float floatValue3,
      float floatValue4,
      float floatValue5,
      float floatValue6,
      int intValue,
      int intValue2,
      int intValue3,
      int intValue4,
      float floatValue7,
      Color color
   ) {
      this.drawContext
         .drawTexture(
            RenderPipelines.GUI_TEXTURED,
            identifier,
            Math.round(floatValue),
            Math.round(floatValue2),
            floatValue5,
            floatValue6,
            Math.round(floatValue3),
            Math.round(floatValue4),
            intValue,
            intValue2,
            intValue3,
            intValue4,
            color.getRGB()
         );
   }

   @Override
   public void drawRoundedTexture(String string, float x, float y, float width, float height, float radius, Color color) {
      this.drawTextureFromResource(string, x, y, width, height, color);
   }

   @Override
   public void drawLine(float startX, float startY, float endX, float endY, float thickness, Color color) {
      float floatValue = endX - startX;
      float floatValue2 = endY - startY;
      int intValue = Math.max(1, (int)Math.ceil((double)Math.max(Math.abs(floatValue), Math.abs(floatValue2))));
      float floatValue3 = Math.max(1.0F, thickness);

      for (int intValue2 = 0; intValue2 <= intValue; intValue2++) {
         float floatValue4 = (float)intValue2 / (float)intValue;
         this.fillRect(startX + floatValue * floatValue4 - floatValue3 / 2.0F, startY + floatValue2 * floatValue4 - floatValue3 / 2.0F, floatValue3, floatValue3, color);
      }
   }

   @Override
   public void popTransform() {
      this.drawContext.getMatrices().popMatrix();
   }

   private static int ceil(float floatValue) {
      return (int)Math.ceil((double)floatValue);
   }

   @Override
   public void fillCircle(float centerX, float centerY, float radius, Color color) {
      int intValue = Math.max(1, Math.round(radius));

      for (int intValue2 = -intValue; intValue2 <= intValue; intValue2++) {
         int intValue3 = (int)Math.sqrt((double)Math.max(0, intValue * intValue - intValue2 * intValue2));
         this.drawContext.fill(Math.round(centerX) - intValue3, Math.round(centerY) + intValue2, Math.round(centerX) + intValue3 + 1, Math.round(centerY) + intValue2 + 1, color.getRGB());
      }
   }

   @Override
   public boolean isFallback() {
      return true;
   }

   @Override
   public void translate(float offsetX, float offsetY) {
      this.drawContext.getMatrices().translate(offsetX, offsetY);
   }

   @Override
   public void fillGlowingRoundedRect(float x, float y, float width, float height, float radius, Color color, Color color2, float blur, float spread) {
      this.fillRoundedRect(x + spread, y + spread, width, height, radius, color2);
      this.fillRoundedRect(x, y, width, height, radius, color);
   }

   public DrawContextRenderBackend(DrawContext drawContext2, float floatValue, float floatValue2) {
      this.drawContext = drawContext2;
      drawContext2.getMatrices().pushMatrix();
      drawContext2.getMatrices().scale(floatValue, floatValue2);
   }

   private static int floor(float floatValue) {
      return (int)Math.floor((double)floatValue);
   }

   @Override
   public void scale(float scaleX, float scaleY) {
      this.drawContext.getMatrices().scale(scaleX, scaleY);
   }
}
