package cc.mochi;

public record CartRefillSlotMove(int hotbar, int source) {
   public int getSource() {
      return this.source;
   }

   public int getHotbar() {
      return this.hotbar;
   }
}
