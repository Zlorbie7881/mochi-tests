package cc.mochi;

import net.minecraft.client.input.Input;
import net.minecraft.util.PlayerInput;

public class InputAccess {
   public static void setPlayerInput(Input input, PlayerInput playerInput) {
      input.playerInput = playerInput;
   }
}
