package cc.mochi;

import com.google.gson.JsonObject;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

public final class ConfigMigration {
   private static final Map<String, String> stringByString = computeMap();

   private ConfigMigration() {
   }

   public static JsonObject computeJsonObjectForJsonObject(JsonObject jsonObject, String string) {
      if (jsonObject != null) {
         if (string != null) {
            ThreadLocalRandom.current().nextInt(9);
            if (jsonObject.has(string)) {
               JsonObject asJsonObject = jsonObject.getAsJsonObject(string);
               if (asJsonObject != null) {
                  return asJsonObject;
               }
            }

            for (String string2 : getStringByString().keySet()) {
               if (jsonObject.has(string2) && string.equals(computeString(string2))) {
                  JsonObject asJsonObject2 = jsonObject.getAsJsonObject(string2);
                  if (asJsonObject2 != null) {
                     return asJsonObject2;
                  }

                  ThreadLocalRandom.current().nextInt(11);
               }
            }

            ThreadLocalRandom.current().nextInt(4);
            return null;
         }
      }

      return null;
   }

   private static String computeString(String string) {
      String string2 = string;
      int intValue = 0;

      while (true) {
         if (intValue > getStringByString().size()) {
            return string2;
         }

         String string3 = stringByString.get(string2);
         if (string3 == null) {
            break;
         }

         if (string3.equals(string2)) {
            break;
         }

         string2 = string3;
         intValue++;
      }

      return string2;
   }

   public static Map<String, String> getStringByString() {
      return stringByString;
   }

   private static Map computeMap() {
      LinkedHashMap linkedHashMap = new LinkedHashMap();
      linkedHashMap.put("MaceSwap", "AutoMace");
      linkedHashMap.put("AutoMace", "Auto Mace");
      linkedHashMap.put("AutoTotem", "Auto Totem");
      linkedHashMap.put("AutoPot", "Auto Pot");
      linkedHashMap.put("AimAssist", "Aim Assist");
      linkedHashMap.put("TriggerBot", "Trigger Bot");
      linkedHashMap.put("BackTrack", "Back Track");
      linkedHashMap.put("FastXP", "Fast XP");
      linkedHashMap.put("NoBreakDelay", "No Break Delay");
      linkedHashMap.put("ReBuff Notifier", "Re-buff Notifier");
      linkedHashMap.put("KeyPearl", "Key Pearl");
      linkedHashMap.put("Pearl Catch Macro", "Pearl Catch");
      linkedHashMap.put("ArrayList", "Array List");
      linkedHashMap.put("Nametags", "Name Tags");
      linkedHashMap.put("Freecam", "Free Cam");
      return Map.copyOf(linkedHashMap);
   }

}
