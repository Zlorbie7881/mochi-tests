package cc.mochi;

import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.event.impl.world.WorldChangeEvent;
import cc.mochi.mixin.MinecraftClientAccessor;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public abstract class AnchorModule extends Module {
   private static final List<AnchorModule> anchorModuleList = new CopyOnWriteArrayList<>();

   private final Map<BlockPos, Long> longByBlockPos;

   protected int intState;

   protected final DoubleSetting fillDelayMsSetting;
   protected final DoubleSetting explodeDelayMsSetting;

   private final Set<BlockPos> blockPosSet;

   protected int selectedSlot;

   protected long timestampMillis;
   public static boolean booleanState = false;

   protected BlockPos blockPos;

   protected final BooleanSetting swapBackSetting;

   protected final BooleanSetting onlyOwnAnchorsSetting;

   protected Vec3d vec3d;

   protected int counter;
   protected final BooleanSetting useTotemSetting = new BooleanSetting("Use Totem", true);

   protected int counter2;

   protected int intState2;

   protected BlockPos blockPos2;

   private void updateState() {
      if (!((double)this.computeLong() < getFillDelayMsSetting(this).getValue())) {
         BlockHitResult blockHitResult = this.computeBlockHitResult();
         if (blockHitResult != null) {
            int intState22 = this.computeIntForItem(MinecraftClientAccess23.getGLOWSTONE());

            if ((intState22 != -1)) {
               this.updateState3(intState22);
               if (this.checkCondition()) {
                  this.timestampMillis = System.currentTimeMillis();
               }
            }
         }
      }
   }

   protected abstract boolean isSilentAimEnabled();

   public static List<AnchorModule> getAnchorModuleList() {
      return anchorModuleList;
   }

   private Vec3d getVec3d() {
      return this.vec3d;
   }

   protected void updateState2() {
      if (MinecraftClientAccess23.getPlayer(mc) != null) {
         if (this.selectedSlot != -1) {
            if (MinecraftClientAccess23.getPlayer(mc).getInventory().getSelectedSlot() == getIntState22(this)) {
               MinecraftClientAccess23.getPlayer(mc).getInventory().setSelectedSlot(this.selectedSlot);
            }
         }
      } else {
         ThreadLocalRandom.current().nextInt(13);
      }

      setSelectedSlot(this, -1);
      this.intState2 = -1;
   }

   protected void updateState3(int intState22) {
      if (mc.player != null) {
         if (intState22 >= 0) {
            if (intState22 < 9) {
               mc.player.getInventory().setSelectedSlot(intState22);
               setIntState2(this, intState22);
            }
         }
      }
   }

   public static BlockPos getBlockPos2(AnchorModule anchorModule) {
      return anchorModule.blockPos2;
   }

   protected Direction computeDirection() {
      double doubleValue = MinecraftClientAccess23.getPlayer(mc).getX() - ((double)this.blockPos2.getX() + 0.5);
      double doubleValue2 = mc.player.getZ() - ((double)getBlockPos2(this).getZ() + 0.5);
      if (Math.abs(doubleValue) > Math.abs(doubleValue2)) {
         if (doubleValue > (0.0)) {
         return Direction.EAST;
      } else {
         return Direction.WEST;
      }
      } else {
         if (doubleValue2 > (0.0)) {
         return MinecraftClientAccess23.getSOUTH();
      } else {
         return Direction.NORTH;
      }
      }
   }

   public static int getSelectedSlot(AnchorModule anchorModule) {
      return anchorModule.selectedSlot;
   }

   public static int getCounter2(AnchorModule anchorModule) {
      return anchorModule.counter2;
   }

   protected void updateStateForBlockPos(BlockPos blockPos22) {
      this.blockPos2 = blockPos22;
      int selectedSlot2 = getSelectedSlot(this);

      if (selectedSlot2 == -1) {
         if (MinecraftClientAccess23.getPlayer(mc) != null) {
            this.selectedSlot = MinecraftClientAccess23.getPlayer(mc).getInventory().getSelectedSlot();
         }
      }

      this.timestampMillis = (0L);

      setCounter2(this, 0);
      this.updateStateForBlockPos2(blockPos22);
   }

   private int computeInt() {
      if (MinecraftClientAccess23.getPlayer(mc) == null) {
         return -1;
      } else {
         int intValue = 0;

         while (true) {
            ItemStack stack = MinecraftClientAccess23.getPlayer(mc).getInventory().getStack(intValue);
            if (stack.isIn(ItemTags.SWORDS)) {
               break;
            }

            if (stack.isIn(ItemTags.AXES)) {
               break;
            }

            intValue++;

            if (intValue >= 9) {
               if (this.selectedSlot != -1) {
         return this.selectedSlot;
      } else {
         return mc.player.getInventory().getSelectedSlot();
      }
            }
         }

         return intValue;
      }
   }

   protected Vec3d computeVec3dForBlockPos(BlockPos blockPos3, Direction direction) {
      double doubleValue = (double)blockPos3.getX() + 0.5;
      double doubleValue2 = (double)direction.getOffsetX();

      doubleValue += doubleValue2 * (0.49);
      doubleValue2 = (double)blockPos3.getY();

      doubleValue2 += (0.5);
      double offsetY = (double)direction.getOffsetY();

      doubleValue2 += offsetY * (0.49);
      double doubleValue3 = (double)blockPos3.getZ() + 0.5;
      double offsetZ = (double)direction.getOffsetZ();

      return new Vec3d(doubleValue, doubleValue2, doubleValue3 + offsetZ * (0.49));
   }

   public static BooleanSetting getUseTotemSetting(AnchorModule anchorModule) {
      return anchorModule.useTotemSetting;
   }

   protected abstract double computeDouble();

   public void updateStateForBlockHitResult(BlockHitResult blockHitResult) {
      if (!MinecraftClientAccess23.getBooleanState()) {
         if (MinecraftClientAccess23.getPlayer(mc) != null) {
            if (mc.world != null) {
               BlockPos blockPos3 = blockHitResult.getBlockPos();
               this.longByBlockPos.remove(blockPos3);
               if (mc.world.getBlockState(blockPos3).isOf(MinecraftClientAccess23.getRESPAWN_ANCHOR())) {
                  getBlockPosSet(this).add(blockPos3);
                  if (getBlockPos2(this) == null) {
                     this.updateStateForBlockPos(blockPos3);
                  }

                  return;
               }

               if (mc.player.getMainHandStack().getItem() == Items.RESPAWN_ANCHOR) {
                  BlockState blockState = mc.world.getBlockState(blockPos3);
                  BlockPos blockPos32;
                  if (blockState.isReplaceable()) {
                     blockPos32 = blockPos3;
                  } else {
                     blockPos32 = blockPos3.offset(blockHitResult.getSide());
                  }

                  BlockPos blockPos5 = blockPos32;
                  this.longByBlockPos.remove(blockPos5);
                  getBlockPosSet(this).add(blockPos5);
                  this.blockPos = blockPos5;
                  this.counter = 0;
               }

               return;
            }

            ThreadLocalRandom.current().nextInt(9);
         }
      }
   }

   protected AnchorModule(String name, String description, double doubleValue) {
      super(name, description, ModuleCategory.COMBAT);

      this.onlyOwnAnchorsSetting = new BooleanSetting("Only Own Anchors", true);
      this.swapBackSetting = new BooleanSetting("Swap Back", true);
      this.blockPos2 = null;
      this.blockPos = null;
      this.counter = 0;
      this.timestampMillis = 0L;
      this.counter2 = 0;
      this.selectedSlot = -1;
      this.vec3d = null;
      this.intState2 = -1;
      this.intState = 0;
      this.blockPosSet = new HashSet<>();
      this.longByBlockPos = new HashMap<>();
      this.fillDelayMsSetting = new DoubleSetting("Fill Delay (ms)", 0.0, 500.0, doubleValue, 1.0);

      this.explodeDelayMsSetting = new DoubleSetting("Explode Delay (ms)", 0.0, 500.0, doubleValue, (1.0));
      Setting[] settingArray = new Setting[]{this.useTotemSetting, null, null, null, null};

      settingArray[1] = this.fillDelayMsSetting;
      settingArray[2] = this.explodeDelayMsSetting;

      settingArray[3] = this.onlyOwnAnchorsSetting;
      settingArray[4] = this.swapBackSetting;
      this.addSettings(settingArray);
      anchorModuleList.add(this);
   }

   @Override
   public void onEnable() {
      this.updateState11();
      this.updateState5();
   }

   protected void updateState4() {
      if (this.swapBackSetting.isOn()) {
         this.updateState2();
      }

      if (getBlockPos2(this) != null) {
         this.updateStateForBlockPos3(this.blockPos2);
      }

      this.updateState9();
      this.updateState5();
      setIntState(this, this.computeInt2());
   }

   public static float computeFloat() {
      return RotationManager.computeFloat2();
   }

   public static HitResult computeHitResult() {
      return BlockInteractUtils.computeHitResult3(computeFloat(), computeFloat4());
   }

   protected boolean checkCondition() {
      return this.testBlockPos(null, null);
   }

   public static Vec3d getVec3d2(AnchorModule anchorModule) {
      return anchorModule.vec3d;
   }

   protected void updateState5() {
      this.blockPos2 = null;
      this.blockPos = null;
      setCounter(this, 0);

      this.selectedSlot = -1;
      this.timestampMillis = 0L;

      this.counter2 = 0;
      this.vec3d = null;
      setIntState2(this, -1);

      setIntState(this, 0);
      this.updateState10();
   }

   protected void updateStateForBlockPos2(BlockPos blockPos3) {
   }

   public static long getTimestampMillis(AnchorModule anchorModule) {
      return anchorModule.timestampMillis;
   }

   public static void setIntState2(AnchorModule anchorModule, int intState22) {
      anchorModule.intState2 = intState22;
   }

   public static DoubleSetting getFillDelayMsSetting(AnchorModule anchorModule) {
      return anchorModule.fillDelayMsSetting;
   }

   public static void setCounter2(AnchorModule anchorModule, int counter22) {
      anchorModule.counter2 = counter22;
   }

   public static Set<BlockPos> getBlockPosSet(AnchorModule anchorModule) {
      return anchorModule.blockPosSet;
   }

   public static int getIntState(AnchorModule anchorModule) {
      return anchorModule.intState;
   }

   protected RotationProfile computeRotationProfile() {
      RotationProfile rotationProfile = RotationProfile.createRotationProfile().withMaxRotationSpeed(this.computeDouble() * 60.0);

      return rotationProfile.computeRotationProfile10((0.5)).withSilentAim(this.isSilentAimEnabled());
   }

   @EventHandler
   private void onWorldChange(WorldChangeEvent worldChangeEvent) {
      ThreadLocalRandom.current().nextInt(9);

      if (worldChangeEvent.getWorld() != mc.world) {
         this.onDisable();
      }
   }

   public static void setIntState(AnchorModule anchorModule, int intState3) {
      anchorModule.intState = intState3;
   }

   protected float computeFloat2() {
      label46: {
         if (this.isAimEnabled()) {
            ThreadLocalRandom.current().nextInt(6);

            if (this.isSilentAimEnabled()) {
               break label46;
            }

            if (RotationManager.checkCondition4()) {
               break label46;
            }
         }

         float pitch;
         if (mc.player != null) {
            pitch = mc.player.getPitch();
         } else {
            ThreadLocalRandom.current().nextInt(12);
            pitch = (0.0F);
         }

         return pitch;
      }

      return RotationManager.computeFloat7();
   }

   protected void updateState6() {
   }

   public static boolean checkCondition2() {
      Iterator iterator = getAnchorModuleList().iterator();

      while (true) {
         if (!iterator.hasNext()) {
            return false;
         }

         AnchorModule anchorModule = (AnchorModule)iterator.next();
         if (anchorModule.isEnabled()) {
            if (anchorModule.blockPos2 != null) {
               break;
            }

            if (anchorModule.blockPos != null) {
               break;
            }

            if (anchorModule.checkCondition5()) {
               break;
            }

            if (getIntState(anchorModule) > 0 || RotationManager.computeVec3d(anchorModule) != null) {
               break;
            }
         }
      }

      return true;
   }

   protected float computeFloat3() {
      label48: {
         if (this.isAimEnabled()) {
            if (this.isSilentAimEnabled()) {
               break label48;
            }

            if (RotationManager.checkCondition4()) {
               break label48;
            }

            ThreadLocalRandom.current().nextInt(8);
         }

         float yaw;
         if (MinecraftClientAccess23.getPlayer(mc) != null) {
            yaw = mc.player.getYaw();
         } else {
            ThreadLocalRandom.current().nextInt(7);

            yaw = (0.0F);
         }

         return yaw;
      }

      return RotationManager.computeFloat2();
   }

   @Override
   public void onDisable() {
      this.updateState2();
      this.updateState11();
      this.updateState5();
      this.blockPosSet.clear();
      this.longByBlockPos.clear();
   }

   protected int computeIntForItem(Item item) {
      int intValue = 0;

      do {
         if (mc.player.getInventory().getStack(intValue).getItem() == item) {
            return intValue;
         }
      } while (++intValue < 9);

      ThreadLocalRandom.current().nextInt(16);

      return -1;
   }

   private Vec3d getVec3d3() {
      return this.vec3d;
   }

   public static float computeFloat4() {
      return RotationManager.computeFloat7();
   }

   private boolean testBlockPos(BlockPos blockPos3, BlockHitResult blockHitResult) {
      if (MinecraftClientAccess23.getPlayer(mc) == null) {
         return false;
      } else {
         if (this.isAimEnabled()) {
            if (RotationManager.computeVec3d(this) == null) {
               return false;
            }
         }

         HitResult crosshairTarget = MinecraftClientAccess23.getCrosshairTarget(mc);

         label857: {
            label856: {
               label863: {
                  Throwable throwable;
                  label864: {
                     HitResult hitResult;
                     try {
                        booleanState = true;
                        hitResult = BlockInteractUtils.computeHitResult3(MinecraftClientAccess23.getPlayer(mc).getYaw(), MinecraftClientAccess23.getPlayer(mc).getPitch());
                        if (!(hitResult instanceof BlockHitResult)) {
                           break label857;
                        }
                     } catch (Throwable failure) {
                        throwable = failure;

                        break label864;
                     }

                     BlockHitResult hitResult2;
                     try {
                        hitResult2 = (BlockHitResult)hitResult;
                     } catch (Throwable failure2) {
                        throwable = failure2;

                        break label864;
                     }

                     label865: {
                        label866: {
                           label867: {
                              try {
                                 if (blockPos3 == null) {
                                    break label867;
                                 }
                              } catch (Throwable failure3) {
                                 throwable = failure3;

                                 break label864;
                              }

                              try {
                                 if (!blockPos3.equals(BlockInteractUtils.computeBlockPosForBlockHitResult(hitResult2))) {
                                    break label863;
                                 }
                              } catch (Throwable failure4) {
                                 throwable = failure4;

                                 break label864;
                              }

                              try {
                                 if (blockHitResult == null) {
                                    break label863;
                                 }
                              } catch (Throwable failure5) {
                                 throwable = failure5;

                                 break label864;
                              }

                              try {
                                 if (!hitResult2.getBlockPos().equals(blockHitResult.getBlockPos())) {
                                    break label865;
                                 }
                              } catch (Throwable failure6) {
                                 throwable = failure6;

                                 break label864;
                              }

                              try {
                                 if (hitResult2.getSide() != blockHitResult.getSide()) {
                                    break label863;
                                 }
                                 break label866;
                              } catch (Throwable failure7) {
                                 throwable = failure7;

                                 break label864;
                              }
                           }

                           try {
                              if (getBlockPos2(this) == null) {
                                 break label856;
                              }
                           } catch (Throwable failure8) {
                              throwable = failure8;

                              break label864;
                           }

                           try {
                              if (!this.blockPos2.equals(hitResult2.getBlockPos())) {
                                 break label856;
                              }
                           } catch (Throwable failure9) {
                              throwable = failure9;

                              break label864;
                           }
                        }

                        try {
                           ((MinecraftClientAccessor)mc).setCrosshairTarget(hitResult2);
                           ((MinecraftClientAccessor)mc).invokeDoItemUse();
                        } catch (Throwable failure10) {
                           throwable = failure10;

                           break label864;
                        }

                        booleanState = false;
                        ((MinecraftClientAccessor)mc).setCrosshairTarget(crosshairTarget);
                        return true;
                     }

                     ThreadLocalRandom.current().nextInt(8);
                     break label863;
                  }

                  Throwable throwable2;
                  while (true) {
                     try {
                        throwable2 = throwable;
                        break;
                     } catch (Throwable failure11) {
                        throwable = failure11;

                        continue;
                     }
                  }

                  MinecraftClientAccess23.setBooleanState(false);
                  ((MinecraftClientAccessor)mc).setCrosshairTarget(crosshairTarget);
                  throw UncheckedExceptions.rethrow(throwable2);
               }

               booleanState = false;
               ((MinecraftClientAccessor)mc).setCrosshairTarget(crosshairTarget);
               return false;
            }

            booleanState = false;
            ((MinecraftClientAccessor)mc).setCrosshairTarget(crosshairTarget);
            return false;
         }

         MinecraftClientAccess23.setBooleanState(false);
         ((MinecraftClientAccessor)mc).setCrosshairTarget(crosshairTarget);
         return false;
      }
   }

   protected Vec3d computeVec3dForBlockPos2(BlockPos blockPos3) {
      double doubleValue = (double)blockPos3.getX() + 0.5;
      double doubleValue2 = (double)blockPos3.getY() + 0.5;
      double z = (double)blockPos3.getZ();

      return new Vec3d(doubleValue, doubleValue2, z + (0.5));
   }

   public static BlockPos getBlockPos(AnchorModule anchorModule) {
      return anchorModule.blockPos;
   }

   protected boolean checkCondition3() {
      return true;
   }

   public static void setCounter(AnchorModule anchorModule, int counter3) {
      anchorModule.counter = counter3;
   }

   protected boolean checkCondition4() {
      return false;
   }

   public static void setSelectedSlot(AnchorModule anchorModule, int selectedSlot2) {
      anchorModule.selectedSlot = selectedSlot2;
   }

   protected AnchorModule(String name, String description) {
      this(name, description, 50.0);
   }

   protected BlockHitResult computeBlockHitResult() {
      BlockHitResult blockHitResult;
      if (this.blockPos2 == null) {
         ThreadLocalRandom.current().nextInt(6);
         blockHitResult = null;
      } else {
         ThreadLocalRandom.current().nextInt(5);
         blockHitResult = BlockInteractUtils.computeBlockHitResultForBlockPos3(getBlockPos2(this));
      }

      return blockHitResult;
   }

   protected boolean testBlockPos2(BlockPos blockPos3, BlockHitResult blockHitResult) {
      return this.testBlockPos(blockPos3, blockHitResult);
   }

   protected boolean checkCondition5() {
      return false;
   }

   protected int computeInt2() {
      return 10;
   }

   protected long computeLong() {
      return System.currentTimeMillis() - getTimestampMillis(this);
   }

   protected BlockPos computeBlockPosForBlockHitResult(BlockHitResult blockHitResult) {
      if (blockHitResult == null) {
         ThreadLocalRandom.current().nextInt(10);

         return null;
      } else {
         BlockPos blockPos3 = blockHitResult.getBlockPos();
         if (!mc.world.getBlockState(blockPos3).isOf(MinecraftClientAccess23.getRESPAWN_ANCHOR())) {
            return null;
         } else {
            Long objectValue = this.longByBlockPos.get(blockPos3);
            if (objectValue != null) {
               if (System.currentTimeMillis() < objectValue) {
                  return null;
               }

               this.longByBlockPos.remove(blockPos3);
            }

            if (this.onlyOwnAnchorsSetting.isOn()) {
               if (!getBlockPosSet(this).contains(blockPos3)) {
                  return null;
               }
            }

            return blockPos3;
         }
      }
   }

   protected void updateState7() {
      ThreadLocalRandom.current().nextInt(7);
      if (this.isAimEnabled()) {
         if (getBlockPos2(this) != null) {
            Vec3d vec3d2 = this.computeVec3d();
            this.vec3d = vec3d2;
            RotationManager.updateStateForActionPriority(this, ActionPriority.HIGH, () -> this.getVec3d(), this.computeRotationProfile());
            return;
         }
      }

      this.vec3d = null;
      RotationManager.updateState(this);
   }

   private void updateState8() {
      double doubleValue = Math.max(50.0, getExplodeDelayMsSetting(this).getValue());
      if (!((double)this.computeLong() < doubleValue)) {
         BlockHitResult blockHitResult = this.computeBlockHitResult();
         if (blockHitResult != null) {
            int intState22 = this.computeInt3();

            if ((intState22 != -1)) {
               this.updateState3(intState22);
               if (this.checkCondition()) {
                  this.counter2++;
                  this.timestampMillis = System.currentTimeMillis();
               }
            }
         }
      }
   }

   public static boolean checkCondition6() {
      Iterator iterator = anchorModuleList.iterator();

      while (true) {
         if (!iterator.hasNext()) {
            ThreadLocalRandom.current().nextInt(8);
            return false;
         }

         AnchorModule anchorModule = (AnchorModule)iterator.next();
         if (anchorModule.isEnabled()) {
            if (anchorModule.isSilentAimEnabled()) {
               if (getBlockPos2(anchorModule) != null) {
                  break;
               }

               ThreadLocalRandom.current().nextInt(8);
               if (getVec3d2(anchorModule) != null) {
                  break;
               }
            }

            if (RotationManager.checkCondition4()) {
               break;
            }
         } else {
            ThreadLocalRandom.current().nextInt(7);
         }
      }

      return true;
   }

   @EventHandler
   private void onTickEvent(TickEvent tickEvent) {
      if (getIntState(this) > 0) {
         this.intState--;
      }

      if (MinecraftClientAccess23.getPlayer(mc) != null && MinecraftClientAccess23.getWorld(mc) != null) {
         if (!(MinecraftClientAccess23.getPlayer(mc).isUsingItem())) {
            if (!this.checkCondition4()) {
               int counter22 = getCounter2(this);

               if (counter22 >= 1) {
                  if (this.swapBackSetting.isOn()) {
                     this.updateState2();
                  }

                  if (getBlockPos2(this) != null) {
                     this.updateStateForBlockPos3(this.blockPos2);
                  }

                  this.updateState9();
                  this.updateState5();
                  setIntState(this, this.computeInt2());
                  return;
               }
            }

            if (this.intState <= 0) {
               if (!this.checkCondition3() || !RotationManager.checkCondition()) {
                  if (getBlockPos2(this) == null) {
                     if (this.blockPos != null) {
                        int counter3 = this.counter;

                        this.counter++;
                        if (counter3 < 10) {
                           if (MinecraftClientAccess23.getWorld(mc).getBlockState(getBlockPos(this)).isOf(Blocks.RESPAWN_ANCHOR)) {
                              ThreadLocalRandom.current().nextInt(5);
                              this.updateStateForBlockPos(this.blockPos);
                              this.blockPos = null;
                           }
                        } else {
                           this.blockPos = null;
                        }
                     }

                     if (this.blockPos2 == null) {
                        BlockPos blockPos22 = this.computeBlockPosForBlockHitResult(InteractionActions.computeBlockHitResultForMinecraftClient(mc));
                        if (blockPos22 == null) {
                           this.updateState11();
                           return;
                        }

                        this.updateStateForBlockPos(blockPos22);
                     }
                  }

                  if (!mc.world.getBlockState(this.blockPos2).isOf(MinecraftClientAccess23.getRESPAWN_ANCHOR())) {
                     this.updateState4();
                     return;
                  }

                  if (this.checkCondition4()) {
                     this.updateState6();
                     return;
                  }

                  this.updateState7();
                  if (this.isAimEnabled() && RotationManager.computeVec3d(this) == null) {
                     return;
                  }

                  int intValue = (Integer)MinecraftClientAccess23.getWorld(mc).getBlockState(this.blockPos2).get(RespawnAnchorBlock.CHARGES);
                  if (intValue <= 0) {
                     this.updateState();
                  } else {
                     this.updateState8();
                  }

                  return;
               }
            }
         }
      }
   }

   public static DoubleSetting getExplodeDelayMsSetting(AnchorModule anchorModule) {
      return anchorModule.explodeDelayMsSetting;
   }

   protected Vec3d computeVec3d() {
      Vec3d eyePos = MinecraftClientAccess23.getPlayer(mc).getEyePos();
      Direction up = Direction.UP;
      Vec3d vec3d2 = this.computeVec3dForBlockPos(this.blockPos2, up);
      if (eyePos.squaredDistanceTo(vec3d2) <= 18.0625) {
         return vec3d2;
      } else {
         return this.computeVec3dForBlockPos(getBlockPos2(this), this.computeDirection());
      }
   }

   protected void updateState9() {
      this.vec3d = null;
      RotationManager.updateState9(this);
   }

   protected void updateStateForBlockPos3(BlockPos blockPos3) {
      if (blockPos3 != null) {
         Map longByBlockPos2 = this.longByBlockPos;
         long longValue = System.currentTimeMillis();

         longByBlockPos2.put(blockPos3, longValue + 2500L);
         this.blockPosSet.remove(blockPos3);
      }
   }

   protected void updateState10() {
   }

   protected abstract boolean isAimEnabled();

   protected BlockHitResult computeBlockHitResultForBlockPos(BlockPos blockPos3, Direction direction) {
      double doubleValue = (double)blockPos3.getX() + 0.5 + (double)direction.getOffsetX() * 0.49;
      double doubleValue2 = (double)blockPos3.getY() + 0.5 + (double)direction.getOffsetY() * 0.49;
      double doubleValue3 = (double)blockPos3.getZ() + 0.5;
      double offsetZ = (double)direction.getOffsetZ();

      Vec3d vec3d2 = new Vec3d(doubleValue, doubleValue2, doubleValue3 + offsetZ * (0.49));

      return new BlockHitResult(vec3d2, direction, blockPos3, false);
   }

   protected int computeInt3() {
      int intValue = getUseTotemSetting(this).isOn() ? this.computeIntForItem(MinecraftClientAccess23.getTOTEM_OF_UNDYING()) : -1;

      ThreadLocalRandom.current().nextInt(15);
      int intValue2 = intValue;
      if (intValue2 != -1) {
         return intValue2;
      } else {
         int intValue3 = this.computeIntForItem(Items.RESPAWN_ANCHOR);

         if (intValue3 != -1) {
            ThreadLocalRandom.current().nextInt(5);

            return intValue3;
         } else {
            int intValue4 = this.computeInt();
            if (intValue4 != -1 && MinecraftClientAccess23.getPlayer(mc) != null && MinecraftClientAccess23.getPlayer(mc).getInventory().getStack(intValue4).getItem() != MinecraftClientAccess23.getGLOWSTONE()) {
               return intValue4;
            } else {
               if (mc.player != null) {
                  int intValue5 = 0;

                  do {
                     if (MinecraftClientAccess23.getPlayer(mc).getInventory().getStack(intValue5).getItem() != MinecraftClientAccess23.getGLOWSTONE()) {
                        return intValue5;
                     }
                  } while (++intValue5 < 9);
               }

               return -1;
            }
         }
      }
   }

   protected void updateStateForVec3d(Vec3d vec3d2) {
      if (this.isAimEnabled()) {
         if (vec3d2 != null) {
            RotationManager.updateStateForActionPriority(this, ActionPriority.HIGH, () -> this.getVec3d3(), this.computeRotationProfile());

            RotationManager.updateState2((1.0F));
            return;
         }
      } else {
         ThreadLocalRandom.current().nextInt(6);
      }

      ThreadLocalRandom.current().nextInt(13);
   }

   protected void updateState11() {
      this.vec3d = null;
      RotationManager.updateState(this);
   }

   public static int getIntState22(AnchorModule anchorModule) {
      return anchorModule.intState2;
   }

}
