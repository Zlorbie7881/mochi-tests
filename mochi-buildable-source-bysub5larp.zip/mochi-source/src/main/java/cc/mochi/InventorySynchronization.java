package cc.mochi;

import cc.mochi.mixin.KeyBindingAccessor;
import cc.mochi.mixin.MinecraftClientAccessor;
import cc.mochi.utils.keybinding.simulation.SimulatedClicks;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;

public final class InventorySynchronization {
   private static volatile long longState;

   public static void updateStateForMinecraftClient(MinecraftClient minecraftClient) {
      updateStateForMinecraftClient3(minecraftClient, false);
   }

   public static boolean checkCondition() {
      ClickSimulationModule clickSimulationModule = (ClickSimulationModule)ModuleLookup.computeModuleForClass(ClickSimulationModule.class);
      if (clickSimulationModule != null) {
         if (clickSimulationModule.isEnabled()) {
            if (clickSimulationModule.getValue2()) {
               return true;
            }
         }
      }

      return false;
   }

   public static void updateStateForMinecraftClient2(MinecraftClient minecraftClient) {
      updateStateForMinecraftClient8(minecraftClient, false);
   }

   public static boolean checkCondition2() {
      long longState2 = longState;

      if (longState2 != (0L)) {
         long longValue = System.currentTimeMillis() - longState2;

         if (longValue <= 250L) {
            longState = 0L;
            return true;
         }
      }

      return false;
   }

   static {
      longState = (0L);
   }

   public static void updateStateForMinecraftClient3(MinecraftClient minecraftClient, boolean booleanValue) {
      if (minecraftClient != null) {
         ThreadLocalRandom.current().nextInt(11);

         if (minecraftClient.options != null) {
            setLongState2();
            if (!booleanValue) {
               if (!checkCondition5()) {
                  ThreadLocalRandom.current().nextInt(16);
                  KeyBinding attackKey = MinecraftClientAccess10.getOptions(minecraftClient).attackKey;
                  if (attackKey instanceof KeyBindingAccessor) {
                     KeyBindingAccessor attackKey2 = (KeyBindingAccessor)attackKey;
                     attackKey2.setTimesPressed(attackKey2.getTimesPressed() + 1);
                  }

                  return;
               }
            }

            SimulatedClicks.tap(minecraftClient, 0);
            return;
         }
      }
   }

   public static void updateStateForMinecraftClient4(MinecraftClient minecraftClient) {
      updateStateForMinecraftClient6(minecraftClient, false);
   }

   public static void updateStateForMinecraftClient5(MinecraftClient minecraftClient) {
      updateStateForMinecraftClient7(minecraftClient, false);
   }

   public static boolean checkCondition3() {
      long longState2 = longState;
      if (longState2 != 0L) {
         long longValue = System.currentTimeMillis() - longState2;

         if (longValue <= 250L) {
            return true;
         }
      }

      return false;
   }

   public static boolean checkCondition4() {
      ClickSimulationModule clickSimulationModule = (ClickSimulationModule)ModuleLookup.computeModuleForClass(ClickSimulationModule.class);
      if (clickSimulationModule != null) {
         if (clickSimulationModule.isEnabled()) {
            return true;
         }
      }

      return false;
   }

   public static void setLongState2() {
      setLongState(System.currentTimeMillis());
   }

   public static void updateStateForMinecraftClient6(MinecraftClient minecraftClient, boolean booleanValue) {
      if ((minecraftClient != null)) {
         if (!booleanValue) {
            if (!checkCondition()) {
               ((MinecraftClientAccessor)minecraftClient).invokeDoItemUse();
               return;
            }

            ThreadLocalRandom.current().nextInt(15);
         }

         SimulatedClicks.tap(minecraftClient, 1);
      }
   }

   public static void updateStateForMinecraftClient7(MinecraftClient minecraftClient, boolean booleanValue) {
      if (minecraftClient != null) {
         if (minecraftClient.options != null) {
            if (!booleanValue) {
               if (!checkCondition()) {
                  ThreadLocalRandom.current().nextInt(10);
                  KeyBinding useKey = MinecraftClientAccess10.getUseKey(MinecraftClientAccess10.getOptions(minecraftClient));
                  if (useKey instanceof KeyBindingAccessor) {
                     KeyBindingAccessor useKey2 = (KeyBindingAccessor)useKey;
                     useKey2.setTimesPressed(useKey2.getTimesPressed() + 1);
                  } else {
                     ThreadLocalRandom.current().nextInt(17);
                  }

                  return;
               }

               ThreadLocalRandom.current().nextInt(12);
            }

            SimulatedClicks.tap(minecraftClient, 1);
            return;
         }
      }
   }

   public static void updateStateForMinecraftClient8(MinecraftClient minecraftClient, boolean booleanValue) {
      if (minecraftClient != null) {
         setLongState2();
         if (!booleanValue) {
            if (!checkCondition5()) {
               ((MinecraftClientAccessor)minecraftClient).invokeDoAttack();
               return;
            }
         }

         SimulatedClicks.tap(minecraftClient, 0);
      }
   }

   public static boolean checkCondition5() {
      ClickSimulationModule clickSimulationModule = (ClickSimulationModule)ModuleLookup.computeModuleForClass(ClickSimulationModule.class);
      if (clickSimulationModule != null) {
         if (clickSimulationModule.isEnabled()) {
            if (clickSimulationModule.getValue()) {
               return true;
            }
         }
      }

      return false;
   }

   public static void setLongState(long longState2) {
      longState = longState2;
   }

   private InventorySynchronization() {
   }
}
