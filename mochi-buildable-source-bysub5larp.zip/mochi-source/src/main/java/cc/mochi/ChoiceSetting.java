package cc.mochi;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class ChoiceSetting extends Setting {
   private final String defaultValue;
   private final List<String> choices;
   private final List<String> choicesView;
   private int selectedIndex;

   public static List<String> getChoices(ChoiceSetting choiceSetting) {
      return choiceSetting.choices;
   }

   public static void setSelectedIndex(ChoiceSetting choiceSetting, int selectedIndex2) {
      choiceSetting.selectedIndex = selectedIndex2;
   }

   public static String defaultValue(ChoiceSetting choiceSetting) {
      return choiceSetting.defaultValue;
   }

   public void cycle() {
      int selectedIndex2 = getSelectedIndex(this);

      setSelectedIndex(this, (selectedIndex2 + 1) % getChoices(this).size());
   }

   @Override
   public boolean isDefault() {
      return this.defaultValue.equals(this.getSelected());
   }

   public static int getSelectedIndex(ChoiceSetting choiceSetting) {
      return choiceSetting.selectedIndex;
   }

   public boolean equals(String string) {
      return string.equals(this.getSelected());
   }

   public void select(String string) {
      int selectedIndex2 = this.choices.indexOf(string);

      if (selectedIndex2 != -1) {
         ThreadLocalRandom.current().nextInt(8);

         setSelectedIndex(this, selectedIndex2);
      } else {
         ThreadLocalRandom.current().nextInt(12);
      }
   }

   public List getChoicesView() {
      return choicesView(this);
   }

   public static List<String> choicesView(ChoiceSetting choiceSetting) {
      return choiceSetting.choicesView;
   }

   public String getDefaultValue() {
      return defaultValue(this);
   }

   public ChoiceSetting(String name, String string2, String... stringArray) {
      super(name);
      this.choices = new ArrayList<>(Arrays.asList(stringArray));
      this.choicesView = Collections.unmodifiableList(this.choices);
      this.selectedIndex = this.choices.indexOf(string2);

      if (this.selectedIndex == -1) {
         this.selectedIndex = 0;
      }

      this.defaultValue = this.choices.get(this.selectedIndex);
   }

   public void setChoices(String... stringArray) {
      String selected = this.getSelected();
      LinkedHashSet linkedHashSet = new LinkedHashSet();
      if (stringArray != null) {
         for (String string : stringArray) {
            if (string != null && !string.isBlank()) {
               linkedHashSet.add(string);
            }
         }
      }

      if (!(linkedHashSet.isEmpty())) {
         this.choices.clear();
         this.choices.addAll(linkedHashSet);
         setSelectedIndex(this, getChoices(this).indexOf(selected));
         if (getSelectedIndex(this) < 0) {
            this.selectedIndex = this.choices.indexOf(this.defaultValue);
         }

         if (this.selectedIndex < 0) {
            this.selectedIndex = 0;
         }
      }
   }

   @Override
   public void reset() {
      this.select(defaultValue(this));
   }

   public String getSelected() {
      label33: {
         if (this.selectedIndex >= 0) {
            if (getSelectedIndex(this) < getChoices(this).size()) {
               break label33;
            }
         }

         setSelectedIndex(this, 0);
      }

      return this.choices.get(this.selectedIndex);
   }

}
