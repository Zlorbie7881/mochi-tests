package cc.mochi;

public class LayoutChild {
   private int intState;
   private final int intState2;
   private int intState3;
   private int intState4;

   public int intState5 = 0;

   private final int intState6;
   private int intState7;
   private int intState8;
   private final Runnable runnable;

   public LayoutChild(int intState22, int intState62, Runnable runnable2) {
      this.intState = 1;
      this.intState2 = intState22;
      this.intState6 = intState62;
      this.runnable = runnable2;
   }

   public void updateState(int intState82, int intState72, int intState32, int intState42) {
      this.intState8 = intState82;
      this.intState7 = intState72;
      this.intState3 = intState32;
      this.intState4 = intState42;
   }

   public int getIntState4() {
      return this.intState4;
   }

   public int getIntState2() {
      return this.intState2;
   }

   public int getIntState7() {
      return this.intState7;
   }

   public int getIntState6() {
      return this.intState6;
   }

   public LayoutChild computeLayoutChild(int intState52) {
      this.intState5 = intState52;
      return this;
   }

   public int getIntState3() {
      return this.intState3;
   }

   public LayoutChild computeLayoutChild2(int intState9) {
      this.intState = intState9;
      return this;
   }

   public int getIntState8() {
      return this.intState8;
   }

   public void updateState2() {
      if (this.runnable != null) {
         this.runnable.run();
      }
   }
}
