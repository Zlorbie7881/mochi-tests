package cc.mochi;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.fluid.Fluid;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.registry.tag.TagKey;

public class MinecraftClientAccess34 {
   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static ObstacleKind getFLUID() {
      return ObstacleKind.FLUID;
   }

   public static ClientWorld getWorld(MinecraftClient minecraftClient) {
      return minecraftClient.world;
   }

   public static Block getCOBWEB() {
      return Blocks.COBWEB;
   }

   public static ObstacleKind getCOBWEB2() {
      return ObstacleKind.COBWEB;
   }

   public static TagKey<Fluid> getLAVA() {
      return FluidTags.LAVA;
   }

}
