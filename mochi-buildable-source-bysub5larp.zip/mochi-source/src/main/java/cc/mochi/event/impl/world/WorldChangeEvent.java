package cc.mochi.event.impl.world;

import cc.mochi.event.types.Event;
import net.minecraft.client.world.ClientWorld;

public class WorldChangeEvent implements Event {
   ClientWorld world;

   public ClientWorld getWorld() {
      return this.world;
   }

   public WorldChangeEvent(ClientWorld world2) {
      this.world = world2;
   }
}
