package cc.mochi.event.impl.chat;

import cc.mochi.event.types.CancellableEvent;

public class SendMessageEvent extends CancellableEvent {
   private final String message;

   public SendMessageEvent(String message2) {
      this.message = message2;
   }

   public String getMessage() {
      return this.message;
   }
}
