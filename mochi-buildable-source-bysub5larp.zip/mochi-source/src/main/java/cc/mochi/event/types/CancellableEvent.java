package cc.mochi.event.types;

public class CancellableEvent implements Event {
   private boolean cancelled;

   public void setCancelled(boolean cancelled2) {
      this.cancelled = cancelled2;
   }

   public boolean isCancelled() {
      return this.cancelled;
   }

   public void cancel() {
      this.setCancelled(true);
   }
}
