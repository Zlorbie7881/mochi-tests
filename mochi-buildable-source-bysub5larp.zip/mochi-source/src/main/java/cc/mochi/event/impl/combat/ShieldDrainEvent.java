package cc.mochi.event.impl.combat;

import cc.mochi.event.types.Event;

public class ShieldDrainEvent implements Event {
   private boolean active = false;

   public void setActive(boolean active2) {
      this.active = active2;
   }

   public boolean isActive() {
      return this.active;
   }
}
