package cc.mochi.event.impl.combat;

import cc.mochi.event.types.Event;

public class TriggerBotReadyEvent implements Event {
   private boolean cancelled = false;

   public void setCancelled(boolean cancelled2) {
      this.cancelled = cancelled2;
   }

   public boolean isCancelled() {
      return this.cancelled;
   }
}
