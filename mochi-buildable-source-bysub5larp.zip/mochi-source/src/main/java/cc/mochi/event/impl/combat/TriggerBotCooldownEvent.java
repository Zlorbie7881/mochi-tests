package cc.mochi.event.impl.combat;

import cc.mochi.event.types.Event;

public class TriggerBotCooldownEvent implements Event {
   private double threshold;

   public TriggerBotCooldownEvent(double threshold2) {
      this.threshold = threshold2;
   }

   public void setThreshold(double threshold2) {
      this.threshold = threshold2;
   }

   public double getThreshold() {
      return this.threshold;
   }
}
