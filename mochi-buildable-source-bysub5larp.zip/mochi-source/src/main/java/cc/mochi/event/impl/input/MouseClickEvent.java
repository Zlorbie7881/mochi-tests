package cc.mochi.event.impl.input;

import cc.mochi.event.types.Event;

public record MouseClickEvent(int button, int action, int mods) implements Event {
}
