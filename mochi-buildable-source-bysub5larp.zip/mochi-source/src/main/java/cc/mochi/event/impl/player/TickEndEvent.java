package cc.mochi.event.impl.player;

import cc.mochi.event.types.Event;

public class TickEndEvent implements Event {
}
