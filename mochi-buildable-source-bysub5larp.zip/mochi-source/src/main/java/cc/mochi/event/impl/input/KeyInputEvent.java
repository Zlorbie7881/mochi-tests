package cc.mochi.event.impl.input;

import cc.mochi.event.types.Event;

public record KeyInputEvent(int key, int action) implements Event {
}
