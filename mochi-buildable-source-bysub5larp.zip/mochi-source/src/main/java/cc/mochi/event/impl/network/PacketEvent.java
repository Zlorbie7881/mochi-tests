package cc.mochi.event.impl.network;

import cc.mochi.event.types.CancellableEvent;
import cc.mochi.event.types.TransferOrder;
import net.minecraft.network.packet.Packet;

public class PacketEvent extends CancellableEvent {
   private Packet packet;
   private final TransferOrder order;

   public Packet getPacket() {
      return this.packet;
   }

   public PacketEvent(Packet packet2, TransferOrder order2) {
      this.packet = packet2;
      this.order = order2;
   }

   public TransferOrder getOrder() {
      return this.order;
   }

   public void setPacket(Packet packet2) {
      this.packet = packet2;
   }
}
