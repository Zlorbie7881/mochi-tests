package cc.mochi.event.impl.player;

import cc.mochi.event.types.CancellableEvent;

public class ItemUseEvent extends CancellableEvent {
}
