package cc.mochi.event.impl.player;

import cc.mochi.event.types.Event;

public class TickEvent implements Event {
}
