package cc.mochi.event.impl.player;

import cc.mochi.event.types.Event;
import net.minecraft.entity.player.PlayerEntity;

public record BowReleaseEvent(PlayerEntity player) implements Event {
}
