package cc.mochi.event.impl.player;

import cc.mochi.event.types.CancellableEvent;
import net.minecraft.entity.Entity;

public class AttackEvent extends CancellableEvent {
   Entity target;

   public Entity getTarget() {
      return this.target;
   }

   public AttackEvent(Entity target2) {
      this.target = target2;
   }
}
