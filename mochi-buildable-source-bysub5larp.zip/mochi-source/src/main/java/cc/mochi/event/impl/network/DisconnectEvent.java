package cc.mochi.event.impl.network;

import cc.mochi.event.types.Event;

public class DisconnectEvent implements Event {
}
