package cc.mochi.event.impl.render;

import cc.mochi.event.types.Event;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;

public class Render3DEvent implements Event {
   private final Vec3d cameraPos;
   private final float tickDelta;
   private final MatrixStack matrixStack;

   public Render3DEvent(MatrixStack matrixStack2, Vec3d cameraPos2, float tickDelta2) {
      this.matrixStack = matrixStack2;
      this.cameraPos = cameraPos2;
      this.tickDelta = tickDelta2;
   }

   public MatrixStack getMatrixStack() {
      return this.matrixStack;
   }

   public float getTickDelta() {
      return this.tickDelta;
   }

   public Vec3d getCameraPos() {
      return this.cameraPos;
   }
}
