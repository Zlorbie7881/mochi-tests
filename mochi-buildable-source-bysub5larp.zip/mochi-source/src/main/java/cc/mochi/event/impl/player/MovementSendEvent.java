package cc.mochi.event.impl.player;

import cc.mochi.event.types.Event;
import net.minecraft.util.math.Vec3d;

public final class MovementSendEvent {
   private MovementSendEvent() {
   }

   public static record After(float yaw, float pitch, Vec3d sentEye) implements Event {
      public After(float floatValue, float floatValue2) {
         this(floatValue, floatValue2, null);
      }
   }

   public static record Before(float yaw, float pitch, Vec3d lastEye) implements Event {
      public Before(float floatValue, float floatValue2) {
         this(floatValue, floatValue2, null);
      }
   }
}
