package cc.mochi.event.impl.render;

import cc.mochi.event.types.Event;
import net.minecraft.client.gui.DrawContext;

public class Render2DEvent implements Event {
   private int width;
   private int height;
   private DrawContext context;

   public DrawContext getContext() {
      return this.context;
   }

   public void setHeight(int height2) {
      this.height = height2;
   }

   public void setContext(DrawContext context2) {
      this.context = context2;
   }

   public int getWidth() {
      return this.width;
   }

   public int getHeight() {
      return this.height;
   }

   public Render2DEvent(DrawContext context2, int width2, int height2) {
      this.context = context2;
      this.width = width2;
      this.height = height2;
   }

   public void setWidth(int width2) {
      this.width = width2;
   }
}
