package cc.mochi.event.impl.combat;

import cc.mochi.event.types.Event;

public class PearlThrowEvent implements Event {
}
