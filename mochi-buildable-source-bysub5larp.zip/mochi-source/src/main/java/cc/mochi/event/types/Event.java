package cc.mochi.event.types;

public interface Event {
}
