package cc.mochi.event.impl.chat;

import cc.mochi.event.types.CancellableEvent;

public class ChatEvent extends CancellableEvent {
   private String message;

   public ChatEvent(String message2) {
      this.message = message2;
   }

   public String getMessage() {
      return this.message;
   }

   public void setMessage(String message2) {
      this.message = message2;
   }
}
