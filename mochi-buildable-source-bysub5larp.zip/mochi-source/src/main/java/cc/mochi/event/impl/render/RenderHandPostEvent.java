package cc.mochi.event.impl.render;

import cc.mochi.event.types.Event;

public class RenderHandPostEvent implements Event {
}
