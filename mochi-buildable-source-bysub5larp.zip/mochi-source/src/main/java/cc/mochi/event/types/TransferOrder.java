package cc.mochi.event.types;

public enum TransferOrder {
   SEND,
   RECEIVE;

   private static TransferOrder[] $values() {
      return new TransferOrder[]{SEND, RECEIVE};
   }
}
