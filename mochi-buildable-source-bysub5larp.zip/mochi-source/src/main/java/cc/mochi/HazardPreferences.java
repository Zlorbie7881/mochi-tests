package cc.mochi;

public record HazardPreferences(boolean voids, boolean falls, boolean webs, boolean lava, boolean fire, boolean contact, boolean snow, String priority) {
   public boolean getFire() {
      return this.fire;
   }

   public boolean getSnow2() {
      return getSnow(this);
   }

   public static boolean getSnow(HazardPreferences hazardPreferences) {
      return hazardPreferences.snow;
   }

   public boolean getWebs2() {
      return getWebs(this);
   }

   public boolean getContact2() {
      return getContact(this);
   }

   public boolean getVoids2() {
      return getVoids(this);
   }

   public static boolean getContact(HazardPreferences hazardPreferences) {
      return hazardPreferences.contact;
   }

   public static boolean getWebs(HazardPreferences hazardPreferences) {
      return hazardPreferences.webs;
   }

   public boolean getFalls() {
      return this.falls;
   }

   public static boolean getVoids(HazardPreferences hazardPreferences) {
      return hazardPreferences.voids;
   }

   public boolean getLava() {
      return this.lava;
   }

   public String getPriority() {
      return this.priority;
   }
}
