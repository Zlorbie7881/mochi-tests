package cc.mochi;

public enum InstaCartState {
   IDLE,
   RAIL,
   CART,
   COVER,
   HOLD,
   TAKEBACK;

   private static InstaCartState[] computeInstaCartStateArray() {
      InstaCartState[] instaCartStateArray = new InstaCartState[6];

      instaCartStateArray[0] = IDLE;
      instaCartStateArray[1] = RAIL;
      instaCartStateArray[2] = CART;
      instaCartStateArray[3] = COVER;

      instaCartStateArray[4] = HOLD;

      instaCartStateArray[5] = TAKEBACK;
      return instaCartStateArray;
   }
}
