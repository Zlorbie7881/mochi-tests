package cc.mochi;

import java.awt.Color;

public class ColorAccess2 {
   public static Color getWHITE() {
      return Color.WHITE;
   }

   public static Color getBLACK() {
      return Color.BLACK;
   }

}
