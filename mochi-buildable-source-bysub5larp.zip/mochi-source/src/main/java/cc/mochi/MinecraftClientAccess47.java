package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.component.ComponentType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttackRangeComponent;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.hit.HitResult.Type;

public class MinecraftClientAccess47 {
   public static ClientPlayerInteractionManager getInteractionManager(MinecraftClient minecraftClient) {
      return minecraftClient.interactionManager;
   }

   public static Type getMISS() {
      return Type.MISS;
   }

   public static Item getMACE() {
      return Items.MACE;
   }

   public static ComponentType<AttackRangeComponent> getATTACK_RANGE() {
      return DataComponentTypes.ATTACK_RANGE;
   }

   public static ClientWorld getWorld(MinecraftClient minecraftClient) {
      return minecraftClient.world;
   }

   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static KeyBinding getUseKey(GameOptions gameOptions) {
      return gameOptions.useKey;
   }

}
