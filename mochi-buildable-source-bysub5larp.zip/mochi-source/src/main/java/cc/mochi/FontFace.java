package cc.mochi;

public enum FontFace {
   REGULAR,
   MEDIUM,
   SEMIBOLD,
   BOLD,
   POPPINS;

   private static FontFace[] createValues() {
      return new FontFace[]{REGULAR, MEDIUM, SEMIBOLD, BOLD, POPPINS};
   }
}
