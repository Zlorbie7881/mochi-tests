package cc.mochi;

public final class ConfigManagerModule extends Module {
   public ConfigManagerModule() {
      super("Config Manager", "Opens the config manager", -1, ModuleCategory.CLIENT);
   }

   @Override
   public void onEnable() {
      ClickGuiScreen.updateStateForClickGuiTab(ClickGuiTab.CONFIGS);
      this.setEnabled(false);
   }
}
