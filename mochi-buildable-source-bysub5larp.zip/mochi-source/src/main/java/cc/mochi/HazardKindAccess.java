package cc.mochi;

public class HazardKindAccess {
   public static HazardKind getSOUL_CAMPFIRE() {
      return HazardKind.SOUL_CAMPFIRE;
   }

   public static HazardKind getVOID() {
      return HazardKind.VOID;
   }

   public static HazardKind getPOWDER_SNOW() {
      return HazardKind.POWDER_SNOW;
   }

   public static HazardKind getFIRE() {
      return HazardKind.FIRE;
   }

   public static HazardKind getFALL() {
      return HazardKind.FALL;
   }

   public static HazardKind getSOUL_FIRE() {
      return HazardKind.SOUL_FIRE;
   }

   public static HazardKind getMAGMA() {
      return HazardKind.MAGMA;
   }
}
