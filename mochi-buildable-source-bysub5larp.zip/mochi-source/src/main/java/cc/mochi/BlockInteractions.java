package cc.mochi;

import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;

public final class BlockInteractions implements MinecraftAccess {
   public static boolean isIn(ItemStack itemStack) {
      return itemStack.isIn(SwordCombatAccess.getSWORDS());
   }

   public static void updateStateForBlockHitResult(BlockHitResult blockHitResult, boolean booleanValue) {
      ActionResult actionResult = SwordCombatAccess.getInteractionManager(mc).interactBlock(mc.player, Hand.MAIN_HAND, blockHitResult);
      if (actionResult.isAccepted()) {
         if (booleanValue) {
            mc.player.swingHand(SwordCombatAccess.getMAIN_HAND());
         }
      }
   }
}
