package cc.mochi;

import org.joml.Matrix4f;

final class ItemMeshContext {
   final Matrix4f transform;
   final MeshBuffer mesh = new MeshBuffer();

   boolean glint;

   public ItemMeshContext() {
      this.transform = new Matrix4f();
   }

   void reset() {
      this.glint = false;
      this.mesh.updateState2();
   }
}
