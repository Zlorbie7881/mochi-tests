package cc.mochi;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public final class KnockbackSimulator {
   private static boolean testVec3d(Vec3d vec3d) {
      if (vec3d != null) {
         if (Double.isFinite(vec3d.x)) {
            if (Double.isFinite(WorldVectorAccess.getY(vec3d))) {
               if (Double.isFinite(vec3d.z)) {
                  return true;
               }
            } else {
               ThreadLocalRandom.current().nextInt(16);
            }
         }
      }

      return false;
   }

   public static Box box(HazardVolume hazardVolume) {
      return hazardVolume.box();
   }

   public static KnockbackCandidate computeKnockbackCandidateForKnockbackSimulationInput(KnockbackSimulationInput knockbackSimulationInput, HazardView hazardView, float floatValue) {
      if (testKnockbackSimulationInput2(knockbackSimulationInput)) {
         if (hazardView != null && hazardView.testBox3(box3(knockbackSimulationInput)) && hazardView.testBox(knockbackSimulationInput.box())) {
            ArrayList arrayList = new ArrayList();
            byte byteValue = 0;

            do {
               updateStateForList(arrayList, computeKnockbackCandidateForKnockbackSimulationInput2(knockbackSimulationInput, hazardView, (float)byteValue));
               byteValue += 5;
            } while (byteValue < 360);

            Iterator iterator = List.copyOf(hazardView.computeList()).iterator();

            while (iterator.hasNext()) {
               HazardVolume hazardVolume = (HazardVolume)iterator.next();
               Float objectValue = computeFloatForKnockbackSimulationInput(knockbackSimulationInput, hazardVolume.box().getCenter());
               if (objectValue != null) {
                  updateStateForList(arrayList, computeKnockbackCandidateForKnockbackSimulationInput2(knockbackSimulationInput, hazardView, objectValue));
               }
            }

            if (arrayList.isEmpty()) {
               return null;
            }

            Comparator comparator = Comparator.comparingDouble(objectValue2 -> computeDoubleForKnockbackCandidate(floatValue, (KnockbackCandidate)objectValue2));
            arrayList.sort(comparator.reversed());

            for (KnockbackCandidate knockbackCandidate : (java.lang.Iterable<KnockbackCandidate>)(java.lang.Iterable<?>)(List.copyOf(arrayList.subList(0, Math.min(6, arrayList.size()))))) {
               int intValue = -12;

               do {
                  float floatValue2 = yaw(knockbackCandidate);
                  float intValue2 = (float)intValue;

                  updateStateForList(arrayList, computeKnockbackCandidateForKnockbackSimulationInput2(knockbackSimulationInput, hazardView, floatValue2 + intValue2 * (0.25F)));
               } while (++intValue <= 12);
            }

            arrayList.sort(comparator.reversed());

            Iterator iterator2 = arrayList.subList(0, Math.min(24, arrayList.size())).iterator();

            while (iterator2.hasNext()) {
               KnockbackCandidate knockbackCandidate2 = (KnockbackCandidate)iterator2.next();
               if (testKnockbackSimulationInput3(knockbackSimulationInput, hazardView, yaw2(knockbackCandidate2), knockbackCandidate2.hazard())) {
                  return knockbackCandidate2;
               }
            }

            return null;
         }
      }

      return null;
   }

   public static boolean testKnockbackSimulationInput(KnockbackSimulationInput knockbackSimulationInput, HazardView hazardView, float floatValue, HazardVolume hazardVolume) {
      if (testKnockbackSimulationInput2(knockbackSimulationInput)) {
         if (hazardVolume != null) {
            if (testKnockbackSimulationInput3(knockbackSimulationInput, hazardView, floatValue, hazardVolume)) {
               return true;
            }
         }
      } else {
         ThreadLocalRandom.current().nextInt(9);
      }

      return false;
   }

   public static Box box2(KnockbackSimulationInput knockbackSimulationInput) {
      return knockbackSimulationInput.box();
   }

   public static double value(HazardVolume hazardVolume) {
      return hazardVolume.value();
   }

   static boolean testBox(Box box, Vec3d vec3d, Box box2) {
      double doubleValue = box.getLengthX() * 0.5 + 0.001;
      double doubleValue2 = box.getLengthY() * 0.5 + 0.001;
      double doubleValue3 = box.getLengthZ() * 0.5;

      Box box3 = box2.expand(doubleValue, doubleValue2, doubleValue3 + (0.001));
      if (!box3.contains(box.getCenter())) {
         if (!box3.raycast(box.getCenter(), box.getCenter().add(vec3d)).isPresent()) {
            return false;
         }
      }

      return true;
   }

   public static Vec3d computeVec3dForBox(Box box, Vec3d vec3d, List list) {
      double doubleValue = WorldVectorAccess.getY(vec3d);

      double doubleValue2 = computeDoubleForBox(box, doubleValue, 1, list);

      box = box.offset((0.0), doubleValue2, 0.0);
      double doubleValue3;
      double doubleValue4;
      if (Math.abs(vec3d.x) < Math.abs(WorldVectorAccess.getZ(vec3d))) {
         doubleValue4 = computeDoubleForBox(box, WorldVectorAccess.getZ(vec3d), 2, list);
         doubleValue3 = computeDoubleForBox(box.offset(0.0, 0.0, doubleValue4), vec3d.x, 0, list);
      } else {
         doubleValue = WorldVectorAccess.getX(vec3d);

         doubleValue3 = computeDoubleForBox(box, doubleValue, 0, list);

         doubleValue4 = computeDoubleForBox(box.offset(doubleValue3, (0.0), 0.0), WorldVectorAccess.getZ(vec3d), 2, list);
      }

      return new Vec3d(doubleValue3, doubleValue2, doubleValue4);
   }

   public static boolean fallsHurt(KnockbackSimulationInput knockbackSimulationInput) {
      return knockbackSimulationInput.fallsHurt();
   }

   public static HazardKind danger(HazardVolume hazardVolume) {
      return hazardVolume.danger();
   }

   public static double computeDouble(int intValue, double doubleValue, boolean booleanValue, boolean booleanValue2) {
      double doubleValue2 = Math.max(0.0, doubleValue + (double)Math.max(0, intValue));

      return doubleValue2 * (0.5) + (booleanValue2 ? 0.4 : (booleanValue ? 0.5 : 0.0));
   }

   private static boolean testKnockbackCandidate(KnockbackCandidate knockbackCandidate, HazardVolume hazardVolume) {
      if (knockbackCandidate != null) {
         ThreadLocalRandom.current().nextInt(9);

         if (danger(knockbackCandidate.hazard()) == danger3(hazardVolume)) {
            if (danger4(hazardVolume) != HazardKind.VOID) {
               if (danger2(hazardVolume) != HazardKind.FALL) {
                  if (!hazard(knockbackCandidate).box().equals(box(hazardVolume))) {
                     return false;
                  }
               }
            }

            return true;
         }
      }

      return false;
   }

   public static Box box3(KnockbackSimulationInput knockbackSimulationInput) {
      return knockbackSimulationInput.box();
   }

   private static void updateStateForList(List list, KnockbackCandidate knockbackCandidate) {
      if (knockbackCandidate != null) {
         list.add(knockbackCandidate);
      }
   }

   private static boolean testKnockbackSimulationInput2(KnockbackSimulationInput knockbackSimulationInput) {
      if (knockbackSimulationInput != null && knockbackSimulationInput.box() != null) {
         if (testVec3d(velocity4(knockbackSimulationInput)) && testVec3d(attacker(knockbackSimulationInput)) && testVec3d(computeVec3dForBox2(box6(knockbackSimulationInput)))) {
            double doubleValue = velocity5(knockbackSimulationInput).lengthSquared();

            if (doubleValue <= (4.0)) {
               if (Double.isFinite(knockbackSimulationInput.resistance())) {
                  if (knockbackSimulationInput.resistance() >= 0.0) {
                     if (resistance(knockbackSimulationInput) < 1.0) {
                        if (Double.isFinite(bonus3(knockbackSimulationInput)) && bonus2(knockbackSimulationInput) > 0.0 && knockbackSimulationInput.bonus() <= 3.0 && Double.isFinite(gravity(knockbackSimulationInput))) {
                           doubleValue = knockbackSimulationInput.gravity();

                           if (doubleValue >= (0.0)) {
                              doubleValue = knockbackSimulationInput.gravity();

                              if (doubleValue <= (1.0)) {
                                 if (Double.isFinite(knockbackSimulationInput.safeFall()) && Double.isFinite(knockbackSimulationInput.fallDistance())) {
                                    return true;
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      return false;
   }

   public static double computeDoubleForHazardKind(HazardKind hazardKind, String string) {
      int intValue;

      double doubleValue;
      switch (hazardKind) {
         case VOID:
            long longValue = (5350098981162320990L);
            long longValue2 = 6658330247568244454L;
            longValue2 = 6658330247568244454L;
            long longValue3 = 1700529246L;
            doubleValue = (1000.0);
            break;
         case FALL:
            doubleValue = 620.0;
            break;
         case COBWEB:
            long longValue4 = (7138985797189537192L);
            long longValue5 = 2634800495244155261L;
            longValue5 = 2634800495244155261L;
            long longValue6 = 839552424L;
            doubleValue = (700.0);
            break;
         case LAVA:
            long longValue7 = (2551260488065842231L);
            long longValue8 = -846540308781152831L;
            longValue8 = -846540308781152831L;
            long longValue9 = 2426895415L;
            doubleValue = (900.0);
            break;
         case FIRE:
            long longValue10 = (6181921850001371327L);
            long longValue11 = 5768841214555955985L;
            longValue11 = 5768841214555955985L;
            long longValue12 = 1519300799L;
            doubleValue = (360.0);
            break;
         case SOUL_FIRE:
            doubleValue = 480.0;
            break;
         case CAMPFIRE:
            doubleValue = 320.0;
            break;
         case SOUL_CAMPFIRE:

            doubleValue = 440.0;
            break;
         case MAGMA:
            byte byteValue = 16;
            ThreadLocalRandom.current().nextInt(8);
            doubleValue = 280.0;
            break;
         case CACTUS:
            doubleValue = 260.0;
            break;
         case BERRY_BUSH:

            doubleValue = 380.0;
            break;
         case WITHER_ROSE:
            doubleValue = 460.0;
            break;
         case POWDER_SNOW:

            long longValue13 = (3064856400402913609L);
            long longValue14 = 5218009301657542705L;
            longValue14 = 5218009301657542705L;
            long longValue15 = 1771641161L;
            doubleValue = (540.0);
            break;
         case DRIPSTONE:
            doubleValue = 650.0;
            break;
         default:
            throw new MatchException(null, null);
      }

      double doubleValue2;
      label91: {
         doubleValue2 = doubleValue;
         if (hazardKind != HazardKind.COBWEB) {
            if (hazardKind != HazardKind.POWDER_SNOW) {
               if (hazardKind != HazardKind.BERRY_BUSH) {
                  intValue = 0;
                  break label91;
               }

               ThreadLocalRandom.current().nextInt(3);
            }
         } else {
            ThreadLocalRandom.current().nextInt(6);
         }

         intValue = 1;
      }

      int intValue2 = intValue;
      short shortValue;
      if ("Traps".equals(string) && intValue2 != 0) {
         shortValue = 400;
      } else {
         if ("Damage".equals(string)) {
            if (intValue2 == 0) {
               return doubleValue2 + (150.0);
            }

            ThreadLocalRandom.current().nextInt(13);
         }

         shortValue = 0;
      }

      return doubleValue2 + (double)shortValue;
   }

   public static double bonus(KnockbackSimulationInput knockbackSimulationInput) {
      return knockbackSimulationInput.bonus();
   }

   public static Vec3d velocity(KnockbackSimulationInput knockbackSimulationInput) {
      return knockbackSimulationInput.velocity();
   }

   public static Vec3d velocity2(KnockbackSimulationInput knockbackSimulationInput) {
      return knockbackSimulationInput.velocity();
   }

   public static Vec3d velocity3(KnockbackSimulationInput knockbackSimulationInput) {
      return knockbackSimulationInput.velocity();
   }

   public static HazardKind danger2(HazardVolume hazardVolume) {
      return hazardVolume.danger();
   }

   public static HazardKind danger3(HazardVolume hazardVolume) {
      return hazardVolume.danger();
   }

   public static Box box4(KnockbackSimulationInput knockbackSimulationInput) {
      return knockbackSimulationInput.box();
   }

   public static Vec3d computeVec3dForKnockbackSimulationInput(KnockbackSimulationInput knockbackSimulationInput, float floatValue) {
      Vec3d vec3d = computeVec3dForBox2(box5(knockbackSimulationInput));
      Vec3d vec3d2 = new Vec3d(vec3d.x - knockbackSimulationInput.attacker().x, 0.0, vec3d.z - WorldVectorAccess.getZ(knockbackSimulationInput.attacker()));
      double doubleValue = vec3d2.horizontalLengthSquared();

      if (doubleValue < (1.0E-5)) {
         return Vec3d.ZERO;
      } else {
         Vec3d vec3d3 = velocity2(knockbackSimulationInput);
         Vec3d vec3d4 = vec3d2.normalize();

         Vec3d vec3d5 = computeVec3dForVec3d(vec3d3, vec3d4, (0.4), knockbackSimulationInput);
         double doubleValue2 = Math.toRadians((double)floatValue);
         double doubleValue3 = -Math.sin(doubleValue2);

         return computeVec3dForVec3d(vec3d5, new Vec3d(doubleValue3, (0.0), Math.cos(doubleValue2)), bonus(knockbackSimulationInput), knockbackSimulationInput);
      }
   }

   public static double bonus2(KnockbackSimulationInput knockbackSimulationInput) {
      return knockbackSimulationInput.bonus();
   }

   public static float yaw(KnockbackCandidate knockbackCandidate) {
      return knockbackCandidate.yaw();
   }

   public static double bonus3(KnockbackSimulationInput knockbackSimulationInput) {
      return knockbackSimulationInput.bonus();
   }

   public static HazardKind danger4(HazardVolume hazardVolume) {
      return hazardVolume.danger();
   }

   public static HazardVolume hazard(KnockbackCandidate knockbackCandidate) {
      return knockbackCandidate.hazard();
   }

   private static Vec3d computeVec3dForVec3d(Vec3d vec3d, Vec3d vec3d2, double doubleValue, KnockbackSimulationInput knockbackSimulationInput) {
      double doubleValue2 = knockbackSimulationInput.resistance();

      double doubleValue3 = doubleValue * (1.0 - Math.clamp(doubleValue2, (0.0), 1.0));
      if (doubleValue3 <= 0.0) {
         return vec3d;
      } else {
         Vec3d vec3d3;
         doubleValue2 = WorldVectorAccess.getX(vec3d) * 0.5 + WorldVectorAccess.getX(vec3d2) * doubleValue3;
         double y;
         if (knockbackSimulationInput.grounded()) {
            double y3 = WorldVectorAccess.getY(vec3d);

            y = Math.min((0.4), y3 * (0.5) + doubleValue3);
         } else {
            y = vec3d.y;
         }

         double z3 = WorldVectorAccess.getZ(vec3d);

         vec3d3 = new Vec3d(
            doubleValue2, y, z3 * (0.5) + WorldVectorAccess.getZ(vec3d2) * doubleValue3
         );
         return vec3d3;
      }
   }

   private static double computeDoubleForKnockbackCandidate(float floatValue, KnockbackCandidate knockbackCandidate) {
      return knockbackCandidate.score() - (double)Math.abs(computeFloat(knockbackCandidate.yaw() - floatValue)) * 0.015;
   }

   public static Vec3d velocity4(KnockbackSimulationInput knockbackSimulationInput) {
      return knockbackSimulationInput.velocity();
   }

   public static KnockbackCandidate computeKnockbackCandidateForKnockbackSimulationInput2(KnockbackSimulationInput knockbackSimulationInput, HazardView hazardView, float floatValue) {
      int intValue;
      int intValue2;

      if (testKnockbackSimulationInput2(knockbackSimulationInput) && Float.isFinite(floatValue)) {
         Box box22 = box4(knockbackSimulationInput);

         int intValue3 = 0;

         while (true) {
            if (intValue3 >= Math.clamp((long)knockbackSimulationInput.leadTicks(), 0, 4)) {
               label244: {
                  label243: {
                     if (knockbackSimulationInput.grounded()) {
                        if (knockbackSimulationInput.leadTicks() <= 0) {
                           break label243;
                        }

                        if (hazardView.computeVec3dForBox(box22, new Vec3d(0.0, ((-0.05)), (0.0))).y > ((-0.049999))) {
                           break label243;
                        }
                     }

                     intValue = 0;
                     break label244;
                  }

                  intValue = 1;
               }

               int intValue4 = intValue;
               KnockbackSimulationInput knockbackSimulationInput2 = new KnockbackSimulationInput(
                  box22,
                  knockbackSimulationInput.velocity(),
                  knockbackSimulationInput.attacker(),
                  (intValue4 != 0),
                  knockbackSimulationInput.resistance(),
                  knockbackSimulationInput.bonus(),
                  knockbackSimulationInput.gravity(),
                  knockbackSimulationInput.safeFall(),
                  knockbackSimulationInput.fallDistance(),
                  fallsHurt(knockbackSimulationInput),
                  0
               );
               Vec3d vec3d52 = computeVec3dForKnockbackSimulationInput(knockbackSimulationInput2, floatValue);
               double doubleValue = knockbackSimulationInput.fallDistance();
               int intValue5 = intValue4;
               double minY = WorldVectorAccess.getMinY(box22);
               int intValue6 = 1;

               while (true) {
                  Vec3d vec3d2 = hazardView.computeVec3dForBox(box22, vec3d52);
                  Box box2 = box22.offset(vec3d2);
                  if (!hazardView.testBox3(box2)) {
                     return null;
                  }

                  Box box3 = box22.union(box2);

                  Box box4 = box3.expand((0.001));
                  KnockbackCandidate knockbackCandidate22 = null;

                  for (HazardVolume hazardVolume : (java.lang.Iterable<HazardVolume>)(java.lang.Iterable<?>)(hazardView.computeList())) {
                     if (box4.intersects(box8(hazardVolume)) && !knockbackSimulationInput.box().expand(0.001).intersects(hazardVolume.box())) {
                        if (hazardVolume.danger() == HazardKind.DRIPSTONE) {
                           if (!fallsHurt2(knockbackSimulationInput)) {
                              continue;
                           }

                           if (doubleValue < (0.6)) {
                              continue;
                           }

                           double y7 = WorldVectorAccess.getY(vec3d52);

                           if (y7 >= (0.0) || WorldVectorAccess.getY(vec3d2) <= vec3d52.y + 1.0E-7) {
                              continue;
                           }

                           double doubleValue2 = Math.abs(box2.minY - WorldVectorAccess.getMaxY(hazardVolume.box()));

                           if (doubleValue2 > (0.01)) {
                              continue;
                           }
                        }

                        if (testBox(box22, vec3d2, hazardVolume.box())) {
                           double doubleValue3 = Math.min(
                              Math.min(WorldVectorAccess.getMaxX(box2) - WorldVectorAccess.getMinX(hazardVolume.box()), hazardVolume.box().maxX - WorldVectorAccess.getMinX(box2)),
                              Math.min(WorldVectorAccess.getMaxZ(box2) - WorldVectorAccess.getMinZ(hazardVolume.box()), WorldVectorAccess.getMaxZ(box7(hazardVolume)) - box2.minZ)
                           );
                           double doubleValue4 = hazardVolume.value();

                           double doubleValue5 = Math.clamp(doubleValue3, (0.0), (0.6));

                           double doubleValue6 = doubleValue4 + doubleValue5 * (15.0);
                           double intValue62 = (double)intValue6;

                           double doubleValue8 = doubleValue6 - intValue62 * (0.35);
                           KnockbackCandidate knockbackCandidate2 = new KnockbackCandidate(floatValue, hazardVolume, computeVec3dForBox2(box2), intValue6, doubleValue8);
                           if (knockbackCandidate22 != null && !(knockbackCandidate2.score() > knockbackCandidate22.score())) {
                              ThreadLocalRandom.current().nextInt(16);
                           } else {
                              knockbackCandidate22 = knockbackCandidate2;
                           }
                        }
                     }
                  }

                  if (knockbackCandidate22 != null) {
                     return knockbackCandidate22;
                  }

                  if (!hazardView.testBox(box2)) {
                     return null;
                  }

                  label229: {
                     double y4 = WorldVectorAccess.getY(vec3d52);

                     if (y4 < (0.0)) {
                        double doubleValue9 = Math.abs(WorldVectorAccess.getY(vec3d2) - WorldVectorAccess.getY(vec3d52));

                        if (doubleValue9 > (1.0E-7)) {
                           intValue2 = 1;
                           break label229;
                        }
                     }

                     intValue2 = 0;
                  }

                  int intValue22 = intValue2;
                  if (WorldVectorAccess.getY(vec3d2) < 0.0) {
                     doubleValue -= WorldVectorAccess.getY(vec3d2);
                  }

                  if (intValue22 != 0) {
                     if (knockbackSimulationInput.fallsHurt()) {
                        if (doubleValue > knockbackSimulationInput.safeFall() + 1.0) {
                           if (hazardView.testBox2(box2)) {
                              HazardVolume hazardVolume2 = new HazardVolume(HazardKind.FALL, box2, hazardView.computeDoubleForHazardKind(HazardKind.FALL) + Math.min(200.0, (doubleValue - knockbackSimulationInput.safeFall()) * 8.0));
                              Vec3d vec3d3 = computeVec3dForBox2(box2);
                              double doubleValue10 = value(hazardVolume2);
                              double intValue63 = (double)intValue6;

                              return new KnockbackCandidate(floatValue, hazardVolume2, vec3d3, intValue6, doubleValue10 - intValue63 * (0.35));
                           }
                        } else {
                           ThreadLocalRandom.current().nextInt(14);
                        }
                     }
                  }

                  if (intValue22 != 0) {
                     doubleValue = (0.0);
                  }

                  double minY2 = WorldVectorAccess.getMinY(box2);

                  if (minY2 < minY - (3.0) && intValue22 == 0 && knockbackSimulationInput.fallsHurt()) {
                     double x = vec3d52.x;

                     Vec3d vec3d4 = new Vec3d(x / (0.09), 0.0, vec3d52.z / 0.09);
                     if (hazardView.testBox4(box2, vec3d4)) {
                        HazardVolume hazardVolume3 = new HazardVolume(HazardKind.VOID, box2, hazardView.computeDoubleForHazardKind(HazardKind.VOID));
                        return new KnockbackCandidate(floatValue, hazardVolume3, computeVec3dForBox2(box2), intValue6, hazardVolume3.value() - (double)intValue6 * 0.35);
                     }
                  }

                  double doubleValue12;
                  if (intValue5 != 0) {
                     doubleValue12 = hazardView.computeDoubleForBox2(box22) * 0.91F;
                  } else {
                     doubleValue12 = (0.9100000262260437);
                  }

                  double doubleValue122 = doubleValue12;
                  doubleValue122 *= hazardView.computeDoubleForBox(box2);
                  intValue5 = intValue22;
                  Vec3d vec3d5;
                  double doubleValue14 = Math.abs(vec3d2.x - vec3d52.x);

                  double doubleValue15;
                  if (doubleValue14 > (1.0E-7)) {
                     doubleValue15 = (0.0);
                  } else {
                     doubleValue15 = WorldVectorAccess.getX(vec3d52) * doubleValue122;
                  }

                  double doubleValue16 = (Math.abs(WorldVectorAccess.getY(vec3d2) - WorldVectorAccess.getY(vec3d52)) > 1.0E-7 ? 0.0 : vec3d52.y) - knockbackSimulationInput.gravity();

                  double doubleValue17 = doubleValue16 * (0.9800000190734863);
                  double doubleValue18 = Math.abs(vec3d2.z - vec3d52.z);

                  vec3d5 = new Vec3d(
                     doubleValue15, doubleValue17, doubleValue18 > (1.0E-7) ? 0.0 : vec3d52.z * doubleValue122
                  );
                  vec3d52 = vec3d5;
                  box22 = box2;
                  if (intValue22 == 0 || !(vec3d52.horizontalLengthSquared() < 1.0E-6)) {
                     if (++intValue6 <= 40) {
                        continue;
                     }
                  }

                  return null;
               }
            }

            box22 = box22.offset(hazardView.computeVec3dForBox(box22, knockbackSimulationInput.velocity()));
            if (!hazardView.testBox3(box22)) {
               break;
            }

            if (!hazardView.testBox(box22)) {
               break;
            }

            intValue3++;
         }

         return null;
      } else {
         return null;
      }
   }

   public static Box box5(KnockbackSimulationInput knockbackSimulationInput) {
      return knockbackSimulationInput.box();
   }

   public static Vec3d velocity5(KnockbackSimulationInput knockbackSimulationInput) {
      return knockbackSimulationInput.velocity();
   }

   private static Vec3d computeVec3dForBox2(Box box) {
      double doubleValue = (box.minX + box.maxX) * 0.5;
      double minY = box.minY;
      double doubleValue2 = box.minZ + box.maxZ;

      return new Vec3d(doubleValue, minY, doubleValue2 * (0.5));
   }

   public static Box box6(KnockbackSimulationInput knockbackSimulationInput) {
      return knockbackSimulationInput.box();
   }

   private static boolean testKnockbackSimulationInput3(KnockbackSimulationInput knockbackSimulationInput, HazardView hazardView, float floatValue, HazardVolume hazardVolume) {
      if (testKnockbackCandidate(computeKnockbackCandidateForKnockbackSimulationInput2(knockbackSimulationInput, hazardView, floatValue), hazardVolume)) {
         if (testKnockbackCandidate(computeKnockbackCandidateForKnockbackSimulationInput2(knockbackSimulationInput, hazardView, floatValue - 1.0F), hazardVolume)) {
            ThreadLocalRandom.current().nextInt(8);

            if (testKnockbackCandidate(computeKnockbackCandidateForKnockbackSimulationInput2(knockbackSimulationInput, hazardView, floatValue + 1.0F), hazardVolume)) {
               double doubleValue = Math.toRadians((double)floatValue);
               double doubleValue2 = Math.cos(doubleValue);

               doubleValue2 *= (0.03);

               double doubleValue3 = Math.sin(doubleValue);

               Vec3d vec3d = new Vec3d(doubleValue2, (0.0), doubleValue3 * (0.03));
               if (testKnockbackCandidate(computeKnockbackCandidateForKnockbackSimulationInput2(knockbackSimulationInput.createKnockbackSimulationInput(velocity3(knockbackSimulationInput).add(vec3d)), hazardView, floatValue), hazardVolume)) {
                  if (testKnockbackCandidate(computeKnockbackCandidateForKnockbackSimulationInput2(knockbackSimulationInput.createKnockbackSimulationInput(velocity(knockbackSimulationInput).subtract(vec3d)), hazardView, floatValue), hazardVolume)) {
                     return true;
                  }
               }

               return false;
            }
         } else {
            ThreadLocalRandom.current().nextInt(13);
         }
      }

      return false;
   }

   private static double computeDoubleForBox(Box box, double doubleValue, int intValue, List list) {
      for (Box box2 : (java.lang.Iterable<Box>)(java.lang.Iterable<?>)(list)) {
         byte byteValue;
         switch (intValue) {
            case 0:
               double maxY = box.maxY;
               double doubleValue2 = WorldVectorAccess.getMinY(box2);
               long longValue = (2689516819050344448L);
               long longValue2 = -4673015453531225918L;
               longValue2 = -4673015453531225918L;
               long longValue3 = 2186518344L;
               if (maxY > doubleValue2 + (1.0E-7) && WorldVectorAccess.getMinY(box) < box2.maxY - 1.0E-7) {
                  double maxZ = WorldVectorAccess.getMaxZ(box);
                  doubleValue2 = WorldVectorAccess.getMinZ(box2);
                  longValue = (-3740060458763744308L);
                  longValue2 = -7505085476103961305L;
                  longValue2 = -7505085476103961305L;
                  longValue3 = 2388370564L;
                  if (maxZ > doubleValue2 + (1.0E-7) && box.minZ < WorldVectorAccess.getMaxZ(box2) - 1.0E-7) {
                     byteValue = 1;
                     break;
                  }
               }

               byteValue = 0;
               break;
            case 1:
               double maxX = WorldVectorAccess.getMaxX(box);
               double doubleValue3 = box2.minX;
               long longValue4 = (-6717825421354089790L);
               long longValue5 = 4002265094398419393L;
               longValue5 = 4002265094398419393L;
               long longValue6 = 2879745418L;
               if (maxX > doubleValue3 + (1.0E-7) && WorldVectorAccess.getMinX(box) < WorldVectorAccess.getMaxX(box2) - 1.0E-7) {
                  double maxZ2 = box.maxZ;
                  doubleValue3 = WorldVectorAccess.getMinZ(box2);
                  longValue4 = (-8069974709832679269L);
                  longValue5 = -5030562777733689043L;
                  longValue5 = -5030562777733689043L;
                  longValue6 = 2427793363L;
                  if (maxZ2 > doubleValue3 + (1.0E-7)) {
                     double minZ = WorldVectorAccess.getMinZ(box);
                     doubleValue3 = box2.maxZ;
                     longValue4 = (7199081499257941383L);
                     longValue5 = 6423912635419541959L;
                     longValue5 = 6423912635419541959L;
                     longValue6 = 2867299023L;
                     if (minZ < doubleValue3 - (1.0E-7)) {
                        byteValue = 1;
                        break;
                     }
                  }
               }

               byteValue = 0;
               break;
            default:
               label156: {
                  if (WorldVectorAccess.getMaxX(box) > WorldVectorAccess.getMinX(box2) + 1.0E-7) {
                     double minX = box.minX;
                     double doubleValue4 = WorldVectorAccess.getMaxX(box2);

                     if (minX < doubleValue4 - (1.0E-7)) {
                        double maxY2 = box.maxY;
                        doubleValue4 = box2.minY;

                        if (maxY2 > doubleValue4 + (1.0E-7)) {
                           if (WorldVectorAccess.getMinY(box) < WorldVectorAccess.getMaxY(box2) - 1.0E-7) {
                              byteValue = 1;
                              break label156;
                           }
                        }
                     }
                  }

                  byteValue = 0;
               }
         }

         byte byteValue2 = byteValue;
         if (byteValue2 != 0) {
            double doubleValue5;
            if (intValue == 0) {
               doubleValue5 = box.minX;
            } else if (intValue == 1) {
               doubleValue5 = box.minY;
            } else {
               doubleValue5 = box.minZ;
            }

            double doubleValue52 = doubleValue5;
            double maxX6;
            if (intValue == 0) {
               maxX6 = WorldVectorAccess.getMaxX(box);
            } else {
               maxX6 = intValue == 1 ? box.maxY : WorldVectorAccess.getMaxZ(box);
            }

            double maxX62 = maxX6;
            double doubleValue7;
            if (intValue == 0) {
               doubleValue7 = box2.minX;
            } else {
               if (intValue == 1) {
                  doubleValue7 = box2.minY;
               } else {
                  byteValue = 25;
                  ThreadLocalRandom.current().nextInt(17);

                  doubleValue7 = box2.minZ;
               }
            }

            double doubleValue72 = doubleValue7;
            double maxX2;
            if (intValue == 0) {
               maxX2 = box2.maxX;
            } else {
               maxX2 = intValue == 1 ? WorldVectorAccess.getMaxY(box2) : box2.maxZ;
            }

            double maxX22 = maxX2;
            if (doubleValue > 0.0 && maxX62 <= doubleValue72 + 1.0E-7) {
               doubleValue = Math.min(doubleValue, Math.max(0.0, doubleValue72 - maxX62));
            }

            if (doubleValue < 0.0) {
               if (doubleValue52 >= maxX22 - (1.0E-7)) {
                  byteValue = 6;
                  ThreadLocalRandom.current().nextInt(3);

                  doubleValue = Math.max(doubleValue, Math.min((0.0), maxX22 - doubleValue52));
               }
            }
         }
      }

      return doubleValue;
   }

   private static float computeFloat(float floatValue) {
      float floatValue2 = floatValue % 360.0F;

      return (floatValue2 + (540.0F)) % 360.0F - 180.0F;
   }

   public static double resistance(KnockbackSimulationInput knockbackSimulationInput) {
      return knockbackSimulationInput.resistance();
   }

   public static double gravity(KnockbackSimulationInput knockbackSimulationInput) {
      return knockbackSimulationInput.gravity();
   }

   public static Box box7(HazardVolume hazardVolume) {
      return hazardVolume.box();
   }

   public static Box box8(HazardVolume hazardVolume) {
      return hazardVolume.box();
   }

   public static float yaw2(KnockbackCandidate knockbackCandidate) {
      return knockbackCandidate.yaw();
   }

   public static Vec3d attacker(KnockbackSimulationInput knockbackSimulationInput) {
      return knockbackSimulationInput.attacker();
   }

   private static Float computeFloatForKnockbackSimulationInput(KnockbackSimulationInput knockbackSimulationInput, Vec3d vec3d) {
      double doubleValue = knockbackSimulationInput.bonus();

      double doubleValue2 = knockbackSimulationInput.resistance();

      double doubleValue3 = doubleValue * ((1.0) - Math.clamp(doubleValue2, 0.0, (1.0)));
      if (doubleValue3 <= 1.0E-7) {
         return null;
      } else {
         Vec3d vec3d2 = computeVec3dForKnockbackSimulationInput(knockbackSimulationInput, (0.0F));

         Vec3d vec3d3 = vec3d2.subtract((0.0), 0.0, doubleValue3);
         Vec3d vec3d4 = vec3d.subtract(computeVec3dForBox2(box2(knockbackSimulationInput)));

         Vec3d vec3d5 = vec3d4.multiply((1.0), 0.0, 1.0).normalize();
         double doubleValue4 = vec3d3.x * WorldVectorAccess.getX(vec3d5) + vec3d3.z * WorldVectorAccess.getZ(vec3d5);
         double doubleValue5 = vec3d3.horizontalLengthSquared() - doubleValue4 * doubleValue4;
         doubleValue = doubleValue3 * doubleValue3;

         double doubleValue6 = doubleValue - Math.max((0.0), doubleValue5);

         if (doubleValue6 < (0.0)) {
            ThreadLocalRandom.current().nextInt(14);

            return null;
         } else {
            double doubleValue7 = doubleValue4 + Math.sqrt(doubleValue6);

            if (doubleValue7 <= (1.0E-7)) {
               return null;
            } else {
               Vec3d vec3d6 = vec3d5.multiply(doubleValue7).subtract(vec3d3);

               Vec3d vec3d7 = vec3d6.multiply(1.0, 0.0, (1.0));
               return (float)Math.toDegrees(Math.atan2(-vec3d7.x, vec3d7.z));
            }
         }
      }
   }

   private KnockbackSimulator() {
   }

   public static boolean fallsHurt2(KnockbackSimulationInput knockbackSimulationInput) {
      return knockbackSimulationInput.fallsHurt();
   }
}
