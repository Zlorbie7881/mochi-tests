package cc.mochi;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public class MinecraftClientAccess4 {
   public static Type getBLOCK() {
      return Type.BLOCK;
   }

   public static ClientWorld getWorld(MinecraftClient minecraftClient) {
      return minecraftClient.world;
   }

   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static ShapeType getOUTLINE() {
      return ShapeType.OUTLINE;
   }

   public static FluidHandling getSOURCE_ONLY() {
      return FluidHandling.SOURCE_ONLY;
   }

   public static Block getFIRE() {
      return Blocks.FIRE;
   }

   public static FluidHandling getNONE() {
      return FluidHandling.NONE;
   }

   public static double getX(Vec3d vec3d) {
      return vec3d.x;
   }

   public static double getY(Vec3d vec3d) {
      return vec3d.y;
   }

}
