package cc.mochi;

import com.mojang.blaze3d.opengl.GlStateManager;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import javax.imageio.ImageIO;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.ApiStatus.Internal;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.BufferUtils;

public class ClientRenderHelpers {
   @Internal
   public static final Matrix4f matrix4f2 = new Matrix4f();
   @Internal
   public static final Matrix4f matrix4f3 = new Matrix4f();

   @Internal
   public static final Matrix4f matrix4f4 = new Matrix4f();

   private static final Vector4f vector4f = new Vector4f();
   private static final Vector3f vector3f = new Vector3f();
   private static final Matrix4f matrix4f = new Matrix4f();
   private static final int[] intArray = new int[4];

   private static final CachedMatrixStack cachedMatrixStack = new CachedMatrixStack();
   private static final MinecraftClient minecraftClient = MinecraftClient.getInstance();
   private static final Random random = new Random();

   @Contract(
      value = "_ -> new",
      pure = true
   )
   public static Vec3d computeVec3dForVec3d( Vec3d vec3d) {
      if (vec3d == null) {
         throw new NullPointerException("pos is marked non-null but is null");
      } else {
         Camera camera = minecraftClient.getEntityRenderDispatcher().camera;
         int framebufferHeight = minecraftClient.getWindow().getFramebufferHeight();
         intArray[2] = minecraftClient.getWindow().getFramebufferWidth();
         intArray[3] = framebufferHeight;
         double doubleValue = vec3d.x - camera.getCameraPos().x;
         double doubleValue2 = vec3d.y - camera.getCameraPos().y;
         double doubleValue3 = vec3d.z - camera.getCameraPos().z;
         vector4f.set((float)doubleValue, (float)doubleValue2, (float)doubleValue3, 1.0F).mul(matrix4f4);
         matrix4f2.mul(matrix4f3, matrix4f).project(vector4f.x(), vector4f.y(), vector4f.z(), intArray, vector3f);
         return new Vec3d((double)(vector3f.x / UiViewport.getScale()), (double)(((float)framebufferHeight - vector3f.y) / UiViewport.getScale()), (double)vector3f.z);
      }
   }

   @Contract(
      value = "_, _ -> new",
      pure = true
   )
   public static Vec3d computeVec3dForMatrixStack( MatrixStack matrixStack,  Vec3d vec3d) {
      if (matrixStack == null) {
         throw new NullPointerException("stack is marked non-null but is null");
      } else if (vec3d == null) {
         throw new NullPointerException("in is marked non-null but is null");
      } else {
         Matrix4f positionMatrix = matrixStack.peek().getPositionMatrix();
         Vector4f vector4f2 = new Vector4f((float)vec3d.x, (float)vec3d.y, (float)vec3d.z, 1.0F);
         vector4f2.mul(positionMatrix);
         return new Vec3d((double)vector4f2.x(), (double)vector4f2.y(), (double)vector4f2.z());
      }
   }

   private static String valueOf(int intValue) {
      return String.valueOf((char)random.nextInt(97, 123));
   }

   @Contract(
      value = "_, _, _ -> new",
      pure = true
   )
   public static Color computeColorForColor( Color color,  Color color2, double doubleValue) {
      if (color == null) {
         throw new NullPointerException("a is marked non-null but is null");
      } else if (color2 == null) {
         throw new NullPointerException("b is marked non-null but is null");
      } else {
         return new Color(
            floor(color.getRed(), color2.getRed(), doubleValue),
            floor(color.getGreen(), color2.getGreen(), doubleValue),
            floor(color.getBlue(), color2.getBlue(), doubleValue),
            floor(color.getAlpha(), color2.getAlpha(), doubleValue)
         );
      }
   }

   @Contract(
      value = "-> new",
      pure = true
   )
   public static Identifier computeIdentifier() {
      return Identifier.of("renderer", "temp/" + collect());
   }

   public static int floor(int intValue, int intValue2, double doubleValue) {
      return (int)Math.floor((double)intValue + (double)(intValue2 - intValue) * MathHelper.clamp(doubleValue, 0.0, 1.0));
   }

   @Contract(
      value = "_,_,_ -> new",
      pure = true
   )
   public static Vec3d computeVec3d(double doubleValue, double doubleValue2, double doubleValue3) {
      Camera camera = minecraftClient.getEntityRenderDispatcher().camera;
      int height = UiViewport.getHeight();
      int width = UiViewport.getWidth();
      intArray[2] = minecraftClient.getWindow().getFramebufferWidth();
      intArray[3] = minecraftClient.getWindow().getFramebufferHeight();
      matrix4f2.mul(matrix4f3, matrix4f)
         .mul(matrix4f4, matrix4f)
         .unproject((float)doubleValue / (float)width * (float)intArray[2], (float)((double)height - doubleValue2) / (float)height * (float)intArray[3], (float)doubleValue3, intArray, vector3f);
      return new Vec3d((double)vector3f.x, (double)vector3f.y, (double)vector3f.z).add(camera.getCameraPos());
   }

   public static void updateState() {
      GlStateManager._disableCull();
      GlStateManager._enableBlend();
      GlStateManager._blendFuncSeparate(770, 771, 1, 0);
   }

   private static String collect() {
      return IntStream.range(0, 32).mapToObj(intValue -> valueOf(intValue)).collect(Collectors.joining());
   }

   public static int max() {
      return UiViewport.max();
   }

   public static MatrixStack computeMatrixStack() {
      if (!cachedMatrixStack.isEmpty()) {
         throw new IllegalStateException("Supposed \"empty\" stack is not actually empty; someone does not clean up after themselves.");
      } else {
         cachedMatrixStack.loadIdentity();
         return cachedMatrixStack;
      }
   }

   public static boolean testVec3d(Vec3d vec3d) {
      return vec3d != null && vec3d.z > ((-1.0)) && vec3d.z < 1.0;
   }

   @Contract(
      value = "_, _, _, _, _ -> new",
      pure = true
   )
   public static Color computeColorForColor2( Color color, int intValue, int intValue2, int intValue3, int intValue4) {
      if (color == null) {
         throw new NullPointerException("original is marked non-null but is null");
      } else {
         return new Color(
            intValue == -1 ? color.getRed() : intValue, intValue2 == -1 ? color.getGreen() : intValue2, intValue3 == -1 ? color.getBlue() : intValue3, intValue4 == -1 ? color.getAlpha() : intValue4
         );
      }
   }

   public static double computeDouble(double doubleValue, double doubleValue2, double doubleValue3) {
      return doubleValue + (doubleValue2 - doubleValue) * MathHelper.clamp(doubleValue3, 0.0, 1.0);
   }

   private static void registerTexture(Identifier identifier, NativeImageBackedTexture nativeImageBackedTexture) {
      MinecraftClient.getInstance().getTextureManager().registerTexture(identifier, nativeImageBackedTexture);
   }

   public static void updateStateForIdentifier( Identifier identifier,  BufferedImage bufferedImage) {
      if (identifier == null) {
         throw new NullPointerException("i is marked non-null but is null");
      } else if (bufferedImage == null) {
         throw new NullPointerException("bi is marked non-null but is null");
      } else {
         try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            ImageIO.write(bufferedImage, "png", byteArrayOutputStream);
            byte[] byteArray = byteArrayOutputStream.toByteArray();
            ByteBuffer byteBuffer = BufferUtils.createByteBuffer(byteArray.length).put(byteArray);
            byteBuffer.flip();
            NativeImageBackedTexture nativeImageBackedTexture = new NativeImageBackedTexture(() -> getStringConstant(), NativeImage.read(byteBuffer));
            MinecraftClient.getInstance().execute(() -> registerTexture(identifier, nativeImageBackedTexture));
         } catch (Exception failure) {
         }
      }
   }

   private static String getStringConstant() {
      return "mochi-dynamic";
   }

   public static void updateState2() {
      GlStateManager._disableBlend();
      GlStateManager._enableCull();
      GlStateManager._depthFunc(515);
   }

   @Contract("-> new")
   public static Vec3d computeVec3d2() {
      Camera camera = minecraftClient.gameRenderer.getCamera();
      float floatValue = (float)Math.toRadians((double)(-camera.getYaw()));
      float floatValue2 = (float)Math.toRadians((double)(-camera.getPitch()));
      float floatValue3 = MathHelper.cos((double)(floatValue - (float) Math.PI));
      float floatValue4 = MathHelper.sin((double)(floatValue - (float) Math.PI));
      float floatValue5 = -MathHelper.cos((double)floatValue2);
      float floatValue6 = MathHelper.sin((double)floatValue2);
      return new Vec3d((double)(floatValue4 * floatValue5), (double)floatValue6, (double)(floatValue3 * floatValue5)).add(camera.getCameraPos());
   }
}
