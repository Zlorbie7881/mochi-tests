package cc.mochi;

public class CommandPaletteAccess {
   public static Icon getPLUS() {
      return Icon.PLUS;
   }

   public static Icon getFOLDER() {
      return Icon.FOLDER;
   }

   public static MochiClient getINSTANCE() {
      return MochiClient.INSTANCE;
   }

   public static UiLayer getMODAL() {
      return UiLayer.MODAL;
   }

   public static TextStyle getSTRONG() {
      return TextStyle.STRONG;
   }

   public static Icon getRESET() {
      return Icon.RESET;
   }

   public static ControlTone getDANGER() {
      return ControlTone.DANGER;
   }

}
