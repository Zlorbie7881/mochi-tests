package cc.mochi;

import java.util.HashMap;
import java.util.Map;
import org.lwjgl.opengl.GL20;

final class CircleUniformCache {
   private final Map<String, Integer> integerByString = new HashMap<>();
   public final int intState;

   int computeIfAbsent(String string) {
      return this.integerByString.computeIfAbsent(string, string2 -> this.glGetUniformLocation(string2));
   }

   private Integer glGetUniformLocation(String string) {
      return GL20.glGetUniformLocation(this.intState, string);
   }

   void glUseProgram() {
      GL20.glUseProgram(this.intState);
   }

   CircleUniformCache(int intState2) {
      this.intState = intState2;
   }
}
