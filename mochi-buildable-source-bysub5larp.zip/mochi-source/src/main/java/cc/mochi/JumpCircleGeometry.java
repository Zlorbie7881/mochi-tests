package cc.mochi;

import java.util.Random;

public final class JumpCircleGeometry {
   public static int computeIntForJumpCircleStyle(JumpCircleStyle jumpCircleStyle, float floatValue, float[] floatArray, float floatValue2, float floatValue3, float floatValue4, float[] floatArray2, int intValue) {
      int intValue2 = floatArray.length / 6;
      float floatValue5 = Math.max(0.2F, jumpCircleStyle.floatState);
      float floatValue6 = max(floatValue / floatValue5);
      float floatValue7 = jumpCircleStyle.floatState4 * (0.2F + 0.8F * (1.0F - (1.0F - floatValue6) * (1.0F - floatValue6) * (1.0F - floatValue6)));

      for (int intValue3 = 0; intValue3 < intValue2; intValue3++) {
         int intValue4 = intValue3 * 6;
         float floatValue8 = floatValue - floatArray[intValue4 + 2] * floatValue5;
         float floatValue9 = floatArray[intValue4 + 3] * floatValue5;
         float floatValue10 = floatValue8 / floatValue9;
         if (!(floatValue10 <= 0.0F) && !(floatValue10 >= 1.0F)) {
            float floatValue11 = floatArray[intValue4];
            float floatValue12 = floatValue7 * floatArray[intValue4 + 1];
            float floatValue13 = 0.03F + floatArray[intValue4 + 4] * floatValue8;
            float floatValue14 = jumpCircleStyle.floatState2 * (float)Math.sin(Math.PI * (double)floatValue10) * (0.65F + 0.35F * (float)Math.sin((double)(floatValue8 * 30.0F + floatArray[intValue4 + 5])));
            if (!(floatValue14 <= 0.01F)) {
               int intValue5 = intValue * 9;
               if (intValue5 + 9 > floatArray2.length) {
                  return intValue;
               }

               floatArray2[intValue5] = floatValue2 + (float)Math.cos((double)floatValue11) * floatValue12;
               floatArray2[intValue5 + 1] = floatValue3 + floatValue13;
               floatArray2[intValue5 + 2] = floatValue4 + (float)Math.sin((double)floatValue11) * floatValue12;
               floatArray2[intValue5 + 3] = 0.0F;
               floatArray2[intValue5 + 4] = floatArray[intValue4 + 4];
               floatArray2[intValue5 + 5] = 0.0F;
               floatArray2[intValue5 + 6] = 0.03F * (jumpCircleStyle.floatState4 / 1.15F);
               floatArray2[intValue5 + 7] = floatValue14;
               floatArray2[intValue5 + 8] = 1.0F;
               intValue++;
            }
         }
      }

      return intValue;
   }

   public static int computeIntForJumpCircleStyle2(JumpCircleStyle jumpCircleStyle, float floatValue, float[] floatArray, float floatValue2, float floatValue3, float floatValue4, float[] floatArray2, int intValue) {
      int intValue2 = floatArray.length / 6;
      float floatState2 = jumpCircleStyle.floatState2;

      for (int intValue3 = 0; intValue3 < intValue2; intValue3++) {
         int intValue4 = intValue3 * 6;
         float floatValue5 = floatArray[intValue4 + 3];
         float floatValue6 = floatValue / floatValue5;
         if (!(floatValue6 <= 0.0F) && !(floatValue6 >= 1.0F)) {
            float floatValue7 = floatArray[intValue4];
            float floatValue8 = (float)Math.cos((double)floatValue7);
            float floatValue9 = (float)Math.sin((double)floatValue7);
            float floatValue10 = floatArray[intValue4 + 1] * (jumpCircleStyle.floatState4 / 1.15F);
            float floatValue11 = floatArray[intValue4 + 2];
            float floatValue12 = (float)Math.exp((double)(((-2.2F)) * floatValue));
            float floatValue13 = (1.0F - floatValue12) / 2.2F;
            float floatValue14 = floatValue10 * floatValue13;
            float floatValue15 = floatValue11 * floatValue13 - 9.0F * (floatValue / 2.2F - floatValue13 / 2.2F);
            float floatValue16 = jumpCircleStyle.floatState4 * 0.22F;
            float floatValue17 = 0.04F + floatValue15;
            if (!(floatValue17 < 0.02F)) {
               float floatValue18 = floatValue10 * floatValue12;
               float floatValue19 = floatValue11 * floatValue12 - 9.0F * (1.0F - floatValue12) / 2.2F;
               float floatValue20 = 0.7F + 0.3F * (float)Math.sin((double)(floatValue * 38.0F + floatArray[intValue4 + 5]));
               float floatValue21 = floatState2 * computeFloat2(0.0F, 0.05F, floatValue6) * (float)Math.pow((double)(1.0F - floatValue6), 1.3F) * floatValue20;
               if (!(floatValue21 <= 0.01F)) {
                  int intValue5 = intValue * 9;
                  if (intValue5 + 9 > floatArray2.length) {
                     return intValue;
                  }

                  float floatValue22 = floatValue16 + floatValue14;
                  floatArray2[intValue5] = floatValue2 + floatValue8 * floatValue22;
                  floatArray2[intValue5 + 1] = floatValue3 + floatValue17;
                  floatArray2[intValue5 + 2] = floatValue4 + floatValue9 * floatValue22;
                  floatArray2[intValue5 + 3] = floatValue8 * floatValue18;
                  floatArray2[intValue5 + 4] = floatValue19;
                  floatArray2[intValue5 + 5] = floatValue9 * floatValue18;
                  floatArray2[intValue5 + 6] = floatArray[intValue4 + 4] * (jumpCircleStyle.floatState4 / 1.15F);
                  floatArray2[intValue5 + 7] = floatValue21;
                  floatArray2[intValue5 + 8] = 1.0F - floatValue6;
                  intValue++;
               }
            }
         }
      }

      return intValue;
   }

   private static float computeFloat(float floatValue) {
      float floatValue2 = floatValue - 1.0F;
      return 1.0F + 2.70158F * floatValue2 * floatValue2 * floatValue2 + 1.70158F * floatValue2 * floatValue2;
   }

   static float computeFloat2(float floatValue, float floatValue2, float floatValue3) {
      float floatValue4 = max((floatValue3 - floatValue) / (floatValue2 - floatValue));
      return floatValue4 * floatValue4 * (3.0F - 2.0F * floatValue4);
   }

   public static int computeIntForJumpCircleStyle3(JumpCircleStyle jumpCircleStyle, float floatValue, float[] floatArray, float floatValue2, float floatValue3, float floatValue4, float[] floatArray2, int intValue) {
      int intValue2 = floatArray.length / 6;
      float floatState2 = jumpCircleStyle.floatState2;

      for (int intValue3 = 0; intValue3 < intValue2; intValue3++) {
         int intValue4 = intValue3 * 6;
         float floatValue5 = floatArray[intValue4 + 4];
         float floatValue6 = floatArray[intValue4 + 5] / 6.2832F * 0.25F;
         float floatValue7 = floatValue - floatValue6;
         float floatValue8 = floatValue7 / floatValue5;
         if (!(floatValue8 <= 0.0F) && !(floatValue8 >= 1.0F)) {
            float floatValue9 = floatArray[intValue4 + 3];
            float floatValue10 = floatArray[intValue4] + floatValue9 * floatValue7;
            float floatValue11 = jumpCircleStyle.floatState4 * 0.42F * floatArray[intValue4 + 1] * (1.0F + 0.4F * floatValue8);
            float floatValue12 = floatArray[intValue4 + 2];
            float floatValue13 = 0.05F + floatValue12 * floatValue7;
            float floatValue14 = 0.04F * (float)Math.sin((double)(floatValue7 * 6.0F + floatArray[intValue4 + 5]));
            float floatValue15 = (float)Math.cos((double)floatValue10);
            float floatValue16 = (float)Math.sin((double)floatValue10);
            float floatValue17 = 0.6F + 0.4F * (float)Math.sin((double)(floatValue7 * 17.0F + floatArray[intValue4 + 5] * 3.0F));
            float floatValue18 = floatState2 * 0.8F * computeFloat2(0.0F, 0.1F, floatValue8) * (float)Math.pow((double)(1.0F - floatValue8), 1.2F) * floatValue17;
            if (!(floatValue18 <= 0.01F)) {
               int intValue5 = intValue * 9;
               if (intValue5 + 9 > floatArray2.length) {
                  return intValue;
               }

               floatArray2[intValue5] = floatValue2 + floatValue15 * (floatValue11 + floatValue14);
               floatArray2[intValue5 + 1] = floatValue3 + floatValue13;
               floatArray2[intValue5 + 2] = floatValue4 + floatValue16 * (floatValue11 + floatValue14);
               floatArray2[intValue5 + 3] = -floatValue16 * floatValue9 * floatValue11;
               floatArray2[intValue5 + 4] = floatValue12;
               floatArray2[intValue5 + 5] = floatValue15 * floatValue9 * floatValue11;
               floatArray2[intValue5 + 6] = 0.011F * (jumpCircleStyle.floatState4 / 1.15F);
               floatArray2[intValue5 + 7] = floatValue18;
               floatArray2[intValue5 + 8] = 0.6F;
               intValue++;
            }
         }
      }

      return intValue;
   }

   public static float[] computeFloatArrayForRandom(Random random, int intValue) {
      float[] floatArray = new float[intValue * 6];

      for (int intValue2 = 0; intValue2 < intValue; intValue2++) {
         int intValue3 = intValue2 * 6;
         floatArray[intValue3] = random.nextFloat() * 6.2832F;
         floatArray[intValue3 + 1] = 1.2F + random.nextFloat() * 3.2F;
         floatArray[intValue3 + 2] = 2.6F + random.nextFloat() * 4.6F;
         floatArray[intValue3 + 3] = 0.45F + random.nextFloat() * 0.75F;
         floatArray[intValue3 + 4] = 0.016F + random.nextFloat() * 0.018F;
         floatArray[intValue3 + 5] = random.nextFloat() * 6.2832F;
      }

      return floatArray;
   }

   private static float max(float floatValue) {
      return Math.max(0.0F, Math.min(1.0F, floatValue));
   }

   public static float[] computeFloatArrayForRandom2(Random random, int intValue) {
      float[] floatArray = new float[intValue * 6];

      for (int intValue2 = 0; intValue2 < intValue; intValue2++) {
         int intValue3 = intValue2 * 6;
         floatArray[intValue3] = random.nextFloat() * 6.2832F;
         floatArray[intValue3 + 1] = 0.55F + random.nextFloat() * 0.75F;
         floatArray[intValue3 + 2] = random.nextFloat() * 0.55F;
         floatArray[intValue3 + 3] = 0.25F + random.nextFloat() * 0.45F;
         floatArray[intValue3 + 4] = 0.15F + random.nextFloat() * 0.5F;
         floatArray[intValue3 + 5] = random.nextFloat() * 6.2832F;
      }

      return floatArray;
   }

   public static float max2(JumpCircleStyle jumpCircleStyle) {
      return Math.max(jumpCircleStyle.floatState * 1.05F, 1.8F);
   }

   private JumpCircleGeometry() {
   }

   public static float[] computeFloatArrayForRandom3(Random random, int intValue) {
      float[] floatArray = new float[intValue * 6];

      for (int intValue2 = 0; intValue2 < intValue; intValue2++) {
         int intValue3 = intValue2 * 6;
         floatArray[intValue3] = random.nextFloat() * 6.2832F;
         floatArray[intValue3 + 1] = 0.25F + random.nextFloat() * 0.6F;
         floatArray[intValue3 + 2] = 0.7F + random.nextFloat() * 1.1F;
         floatArray[intValue3 + 3] = (random.nextBoolean() ? 1.0F : ((-1.0F))) * (1.8F + random.nextFloat() * 2.4F);
         floatArray[intValue3 + 4] = 0.9F + random.nextFloat() * 0.9F;
         floatArray[intValue3 + 5] = random.nextFloat() * 6.2832F;
      }

      return floatArray;
   }

   public static boolean testJumpCircleStyle(JumpCircleStyle jumpCircleStyle, float floatValue, float floatState17, float floatState2, float floatState16, float floatState11, JumpCircleInstance jumpCircleInstance) {
      float floatValue2 = Math.max(0.2F, jumpCircleStyle.floatState);
      float floatValue3 = floatValue / floatValue2;
      float floatState4 = jumpCircleStyle.floatState4;
      float floatState22 = jumpCircleStyle.floatState2;
      jumpCircleInstance.floatState2 = floatState2;
      jumpCircleInstance.floatState16 = floatState16;
      jumpCircleInstance.floatState11 = floatState11;
      jumpCircleInstance.floatState17 = floatState17;
      jumpCircleInstance.floatState4 = floatValue * 0.55F + floatState17 * 6.2832F;
      if (jumpCircleStyle.booleanState3) {
         float floatValue4 = max(floatValue3);
         float floatValue5 = 1.0F - (1.0F - floatValue4) * (1.0F - floatValue4) * (1.0F - floatValue4);
         float floatValue6 = computeFloat2(0.5F, 1.0F, floatValue4);
         jumpCircleInstance.floatState10 = floatState4 * (0.2F + 0.8F * floatValue5);
         jumpCircleInstance.floatState5 = floatState4 * 0.155F * (1.0F - 0.78F * floatValue6);
         jumpCircleInstance.floatState14 = floatValue3 < 1.0F ? floatState22 * computeFloat2(0.0F, 0.05F, floatValue3) * (1.0F - computeFloat2(0.86F, 1.0F, floatValue4)) : 0.0F;
         jumpCircleInstance.floatState18 = 0.0F;
         jumpCircleInstance.floatState3 = 0.0F;
         jumpCircleInstance.floatState = 0.0F;
         jumpCircleInstance.floatState9 = 0.0F;
         jumpCircleInstance.intState = 0;
         return jumpCircleInstance.floatState14 > 0.002F;
      } else {
         jumpCircleInstance.floatState14 = 0.0F;
         if (jumpCircleStyle.booleanState2 && floatValue3 < 1.0F) {
            float floatValue7 = computeFloat(max(floatValue3 * 3.2F));
            jumpCircleInstance.floatState6 = floatState4 * 0.9F * (0.55F + 0.45F * floatValue7);
            jumpCircleInstance.floatState18 = floatState22 * computeFloat2(0.0F, 0.06F, floatValue3) * (1.0F - computeFloat2(0.45F, 0.98F, floatValue3));
         } else {
            jumpCircleInstance.floatState18 = 0.0F;
         }

         jumpCircleInstance.floatState13 = floatState4 * 1.05F;
         jumpCircleInstance.floatState3 = floatValue3 < 1.0F ? floatState22 * 0.85F * computeFloat2(0.0F, 0.05F, floatValue3) * (float)Math.pow((double)(1.0F - floatValue3), 1.4F) : 0.0F;
         float floatValue8 = max(floatValue3 / 0.85F);
         jumpCircleInstance.floatState15 = floatState4 * (0.25F + 2.1F * (1.0F - (1.0F - floatValue8) * (1.0F - floatValue8)));
         jumpCircleInstance.floatState = floatValue8 < 1.0F ? floatState22 * 0.8F * computeFloat2(0.0F, 0.04F, floatValue8) * (1.0F - floatValue8) * (1.0F - floatValue8) : 0.0F;
         if (jumpCircleStyle.booleanState && floatValue3 < 1.0F) {
            float floatValue9 = 1.0F - (float)Math.pow((double)(1.0F - max(floatValue3 * 4.0F)), 3.0);
            jumpCircleInstance.floatState12 = jumpCircleStyle.floatState3 * (0.08F + 0.92F * floatValue9);
            jumpCircleInstance.floatState8 = floatState4 * 0.42F * (1.0F + 0.3F * floatValue3);
            jumpCircleInstance.floatState7 = computeFloat2(0.22F, 1.0F, floatValue3) * 1.05F;
            jumpCircleInstance.floatState9 = floatState22 * computeFloat2(0.0F, 0.035F, floatValue3) * (1.0F - computeFloat2(0.62F, 1.0F, floatValue3));
         } else {
            jumpCircleInstance.floatState9 = 0.0F;
         }

         jumpCircleInstance.intState = Math.max(0, Math.min(3, jumpCircleStyle.intState));
         boolean booleanValue = jumpCircleInstance.floatState18 > 0.002F || jumpCircleInstance.floatState3 > 0.002F || jumpCircleInstance.floatState > 0.002F || jumpCircleInstance.floatState9 > 0.002F;

         for (int intValue = 0; intValue < jumpCircleInstance.intState; intValue++) {
            float floatValue10 = (floatValue - (float)intValue * 0.1F) / (floatValue2 * 0.72F);
            if (!(floatValue10 <= 0.0F) && !(floatValue10 >= 1.0F)) {
               float floatValue11 = 1.0F - (float)intValue * 0.14F;
               float floatValue12 = 1.0F - (float)Math.pow((double)(1.0F - floatValue10), 4.0);
               jumpCircleInstance.floatArray2[intValue] = floatState4 * floatValue11 * (0.12F + 1.18F * floatValue12);
               jumpCircleInstance.floatArray3[intValue] = floatState4 / 1.15F * (1.0F - (float)intValue * 0.25F) * (0.012F + 0.085F * (float)Math.pow((double)(1.0F - floatValue10), 1.5));
               jumpCircleInstance.floatArray[intValue] = floatState22 * computeFloat2(0.0F, 0.035F, floatValue10) * (float)Math.pow((double)(1.0F - floatValue10), 1.5) * (intValue == 0 ? 1.0F : 0.7F);
               booleanValue = true;
            } else {
               jumpCircleInstance.floatArray[intValue] = 0.0F;
            }
         }

         return booleanValue;
      }
   }
}
