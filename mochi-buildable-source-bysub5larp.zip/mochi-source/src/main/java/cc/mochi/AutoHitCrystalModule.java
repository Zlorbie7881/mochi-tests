package cc.mochi;

import cc.mochi.event.impl.input.KeyInputEvent;
import cc.mochi.event.impl.input.MouseClickEvent;
import cc.mochi.event.impl.network.DisconnectEvent;
import cc.mochi.event.impl.player.ItemUseEvent;
import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.event.impl.world.WorldChangeEvent;
import cc.mochi.mixin.ClientPlayerInteractionManagerMixin;
import cc.mochi.mixin.KeyBindingAccessor;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Predicate;
import java.util.function.Supplier;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil.Key;
import net.minecraft.client.util.InputUtil.Type;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.Entity.RemovalReason;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.ActionResult.Success;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public final class AutoHitCrystalModule extends Module implements AttackInputBlocker {
   private long longState;

   private final DoubleRangeSetting placeDelayMsSetting;
   private final KeybindSetting activationKeySetting = new KeybindSetting("Activation Key", -1, false);

   private final BooleanSetting aimAtCrystalSetting;

   private int intState;

   private BlockPos blockPos;

   private ClientWorld clientWorld;

   private long longState2;

   private final DoubleRangeSetting breakDelayMsSetting;

   private int intState2;

   private boolean booleanState;

   private final ChoiceSetting modeSetting;

   private final BooleanSetting silentSwapSetting;

   private boolean booleanState2;

   private final ItemListSetting itemWhitelistSetting;

   private final DoubleRangeSetting obsidianDelayMsSetting;

   private final HumanizedRandom humanizedRandom;

   private static AutoHitCrystalModule autoHitCrystalModule;

   private final BooleanSetting fastBreakSetting;

   private final DoubleRangeSetting swapDelayMsSetting;

   private int intState3;

   private CrystalPlacementState crystalPlacementState;
   private final DoubleSetting cyclesSetting;

   private int intState4;

   private boolean booleanState3;

   private boolean booleanState4;

   private boolean booleanState5;

   private boolean on;

   private final BooleanSetting switchBackSetting;

   private ClientPlayerEntity clientPlayerEntity;

   private Hand computeHand() {
      if (mc.player.getOffHandStack().isOf(Items.END_CRYSTAL)) {
         return MinecraftClientAccess8.getOFF_HAND();
      } else {
         Hand mainHand;
         if (computeIntForItem(Items.END_CRYSTAL) >= 0) {
            mainHand = Hand.MAIN_HAND;
         } else {
            ThreadLocalRandom.current().nextInt(9);
            mainHand = null;
         }

         return mainHand;
      }
   }

   public static CrystalPlacementState getCrystalPlacementState(AutoHitCrystalModule autoHitCrystalModule2) {
      return autoHitCrystalModule2.crystalPlacementState;
   }

   public static void setBooleanState2(AutoHitCrystalModule autoHitCrystalModule2, boolean booleanState22) {
      autoHitCrystalModule2.booleanState2 = booleanState22;
   }

   public static ChoiceSetting getModeSetting(AutoHitCrystalModule autoHitCrystalModule2) {
      return autoHitCrystalModule2.modeSetting;
   }

   private void setLongState25() {
      setLongState2(this, (-9223372036854775808L));
   }

   static int computeInt(int intValue) {
      if (intValue <= -100) {
         int intValue2 = -100 - intValue;

         if (intValue2 <= 7) {
         return intValue2;
      } else {
         return -1;
      }
      } else if (intValue < -1) {
         int intValue42 = 10;
         ThreadLocalRandom.current().nextInt(3);

         int intValue4 = -(intValue + 1);

         if (intValue4 <= 7) {
            intValue42 = intValue4;
         } else {
            intValue42 = -1;
         }

         return intValue42;
      } else {
         if (intValue > 0) {
            if (intValue <= 7) {
               return intValue;
            }
         }

         return -1;
      }
   }

   private boolean checkCondition() {
      long longValue = System.currentTimeMillis() - this.longState;

      return (longValue > (1000L));
   }

   private EndCrystalEntity computeEndCrystalEntity() {
      if (BlockInteractUtils.computeHitResult2() instanceof EntityHitResult var3) {
         Entity entity = var3.getEntity();
         if (entity instanceof EndCrystalEntity) {
            EndCrystalEntity entity2 = (EndCrystalEntity)entity;
            if (entity2.isAlive()) {
               if (entity2.getBlockPos().down().equals(this.blockPos)) {
                  return entity2;
               }
            }
         } else {
            ThreadLocalRandom.current().nextInt(10);
         }
      }

      return null;
   }

   @EventHandler
   private void onKeyInput(KeyInputEvent keyInputEvent) {
      int keyCode = this.activationKeySetting.getKeyCode();
      if (keyInputEvent.action() == 1) {
         if (computeInt(keyCode) < 0) {
            if (keyInputEvent.key() == keyCode) {
               ThreadLocalRandom.current().nextInt(10);

               setBooleanState4(this, true);
            }
         } else {
            ThreadLocalRandom.current().nextInt(8);
         }
      }
   }

   public static int getIntState(AutoHitCrystalModule autoHitCrystalModule2) {
      return autoHitCrystalModule2.intState;
   }

   private boolean checkCondition2() {
      BlockPos blockPos2 = this.blockPos.up();
      if (mc.world.isAir(blockPos2)) {
         if (mc.world
            .getOtherEntities(
               null,
               new Box(
                  (double)blockPos2.getX(),
                  (double)blockPos2.getY(),
                  (double)blockPos2.getZ(),
                  (double)blockPos2.getX() + 1.0,
                  (double)blockPos2.getY() + 2.0,
                  (double)blockPos2.getZ() + 1.0
               )
            )
            .isEmpty()) {
            return true;
         }
      }

      return false;
   }

   @EventHandler
   private void onItemUse(ItemUseEvent itemUseEvent) {
      if (getBooleanState2(this)) {
         if (this.testKeyBinding(MinecraftClientAccess8.getOptions(mc).useKey)) {
            itemUseEvent.cancel();
         } else {
            ThreadLocalRandom.current().nextInt(3);
         }
      }
   }

   public static void setIntState3(AutoHitCrystalModule autoHitCrystalModule2, int intState32) {
      autoHitCrystalModule2.intState3 = intState32;
   }

   private void updateStateForCrystalPlacementState(CrystalPlacementState crystalPlacementState2, DoubleRangeSetting doubleRangeSetting) {
      this.crystalPlacementState = crystalPlacementState2;
      double lowerValue2 = doubleRangeSetting.getLowerValue2();
      double upperValue3 = doubleRangeSetting.getUpperValue3();
      setLongState(this, System.currentTimeMillis() + Math.round(upperValue3 > lowerValue2 ? getHumanizedRandom(this).computeDouble5(lowerValue2, upperValue3) : lowerValue2));
   }

   public static void setBooleanState(AutoHitCrystalModule autoHitCrystalModule2, boolean booleanState6) {
      autoHitCrystalModule2.booleanState = booleanState6;
   }

   public static BlockPos getBlockPos(AutoHitCrystalModule autoHitCrystalModule2) {
      return autoHitCrystalModule2.blockPos;
   }

   public static KeybindSetting getActivationKeySetting(AutoHitCrystalModule autoHitCrystalModule2) {
      return autoHitCrystalModule2.activationKeySetting;
   }

   public static boolean getBooleanState5(AutoHitCrystalModule autoHitCrystalModule2) {
      return autoHitCrystalModule2.booleanState5;
   }

   public static void setLongState2(AutoHitCrystalModule autoHitCrystalModule2, long longState22) {
      autoHitCrystalModule2.longState2 = longState22;
   }

   public static ItemListSetting getItemWhitelistSetting(AutoHitCrystalModule autoHitCrystalModule2) {
      return autoHitCrystalModule2.itemWhitelistSetting;
   }

   public static void setBooleanState5(AutoHitCrystalModule autoHitCrystalModule2, boolean booleanState52) {
      autoHitCrystalModule2.booleanState5 = booleanState52;
   }

   private EndCrystalEntity orElse(BlockPos blockPos2) {
      return (EndCrystalEntity)MinecraftClientAccess8.getWorld(mc)
         .getEntitiesByClass(EndCrystalEntity.class, new Box(blockPos2.up()), endCrystalEntity -> ((Entity)((EndCrystalEntity)endCrystalEntity)).isAlive())
         .stream()
         .findFirst()
         .orElse(null);
   }

   public static boolean getOn(AutoHitCrystalModule autoHitCrystalModule2) {
      return autoHitCrystalModule2.on;
   }

   private void updateState() {
      ActionSchedulers.updateState4(this);

      this.longState2 = Long.MIN_VALUE;
      setCrystalPlacementState(this, CrystalPlacementState.IDLE);
      setBlockPos(this, null);
      setBooleanState5(this, this.booleanState3);
      this.updateState7();
      if (getOn(this)) {
         ThreadLocalRandom.current().nextInt(13);

         HotbarSwapCoordinator.updateState4(this);
      }

      setOn(this, false);
      this.clientPlayerEntity = null;
      this.clientWorld = null;
   }

   private boolean checkCondition3() {
      if (getAimAtCrystalSetting(this).isOn()) {
         if (!getModeSetting(this).equals("Spam Till Release")) {
            ThreadLocalRandom.current().nextInt(13);

            return true;
         }
      } else {
         ThreadLocalRandom.current().nextInt(16);
      }

      return false;
   }

   public AutoHitCrystalModule() {
      super("Auto Hit Crystal", "Places obsidian, then places and breaks crystals on it from your own aim", ModuleCategory.COMBAT);
      String[] stringArray = new String[3];

      stringArray[0] = "Hit Crystal";

      stringArray[1] = "Dtap";
      stringArray[2] = "Spam Till Release";
      this.modeSetting = new ChoiceSetting("Mode", "Hit Crystal", stringArray);

      this.cyclesSetting = new DoubleSetting("Cycles", 1.0, (10.0), 1.0, (1.0));

      this.obsidianDelayMsSetting = new DoubleRangeSetting("Obsidian Delay (ms)", (0.0), (300.0), (0.0), 0.0, (5.0));

      this.swapDelayMsSetting = new DoubleRangeSetting("Swap Delay (ms)", 0.0, (300.0), 30.0, (50.0), 5.0);

      this.placeDelayMsSetting = new DoubleRangeSetting("Place Delay (ms)", (0.0), (300.0), 0.0, (20.0), 5.0);

      this.breakDelayMsSetting = new DoubleRangeSetting("Break Delay (ms)", 0.0, (300.0), (0.0), (20.0), 5.0);
      this.fastBreakSetting = new BooleanSetting("Fast Break", true);

      this.aimAtCrystalSetting = new BooleanSetting("Aim At Crystal", true);
      this.switchBackSetting = new BooleanSetting("Switch Back", true);

      this.silentSwapSetting = new BooleanSetting("Silent Swap", true);
      Predicate predicate = objectValue -> testItem((Item)objectValue);

      Item[] itemArray = new Item[]{Items.WOODEN_SWORD, null, null, null, null, null, null, null};

      itemArray[1] = Items.STONE_SWORD;
      itemArray[2] = Items.COPPER_SWORD;
      itemArray[3] = Items.IRON_SWORD;

      itemArray[4] = Items.GOLDEN_SWORD;

      itemArray[5] = Items.DIAMOND_SWORD;
      itemArray[6] = Items.NETHERITE_SWORD;

      itemArray[7] = Items.TOTEM_OF_UNDYING;
      this.itemWhitelistSetting = new ItemListSetting("Item Whitelist", predicate, itemArray);
      this.crystalPlacementState = CrystalPlacementState.IDLE;

      this.longState2 = Long.MIN_VALUE;

      this.intState4 = -1;

      this.intState2 = -1;
      this.humanizedRandom = new HumanizedRandom();

      Setting[] settingArray = new Setting[12];

      settingArray[0] = this.activationKeySetting;

      settingArray[1] = this.modeSetting;
      settingArray[2] = this.cyclesSetting;
      settingArray[3] = this.obsidianDelayMsSetting;
      settingArray[4] = this.swapDelayMsSetting;

      settingArray[5] = this.placeDelayMsSetting;

      settingArray[6] = this.breakDelayMsSetting;
      settingArray[7] = this.fastBreakSetting;

      settingArray[8] = this.aimAtCrystalSetting;
      settingArray[9] = this.switchBackSetting;
      settingArray[10] = this.silentSwapSetting;

      settingArray[11] = this.itemWhitelistSetting;
      this.addSettings(settingArray);
      this.cyclesSetting.setVisibility(() -> this.equals());
      this.aimAtCrystalSetting.setVisibility(() -> this.valueOf());
      autoHitCrystalModule = this;
   }

   private void updateState2() {
      HotbarSwapCoordinator.updateState(this);
      if (this.booleanState3) {
         ThreadLocalRandom.current().nextInt(9);
         RotationManager.updateState(this);
      }

      this.booleanState3 = false;

      setBooleanState5(this, false);
      setCrystalPlacementState(this, CrystalPlacementState.IDLE);
      this.blockPos = null;

      this.booleanState2 = false;

      this.booleanState4 = false;

      setLongState2(this, Long.MIN_VALUE);

      setIntState4(this, this.intState2 = -1);
      setOn(this, false);
      setClientPlayerEntity(this, null);
      setClientWorld(this, null);
   }

   private Boolean equals() {
      return getModeSetting(this).equals("Hit Crystal");
   }

   private static boolean testItem(Item item) {
      return (!(item instanceof BlockItem));
   }

   public static void setLongState(AutoHitCrystalModule autoHitCrystalModule2, long longState3) {
      autoHitCrystalModule2.longState = longState3;
   }

   public static CrystalPlacementState getOBSIDIAN() {
      return CrystalPlacementState.OBSIDIAN;
   }

   public static DoubleRangeSetting getBreakDelayMsSetting(AutoHitCrystalModule autoHitCrystalModule2) {
      return autoHitCrystalModule2.breakDelayMsSetting;
   }

   public static CrystalPlacementState getBREAK() {
      return CrystalPlacementState.BREAK;
   }

   private void updateState3() {
      this.updateState6();
      EndCrystalEntity endCrystalEntity = this.computeEndCrystalEntity();
      if (endCrystalEntity != null) {
         if (CombatTickBudget.checkCondition3()) {
            if (AttackActions.testMinecraftClient4(mc, endCrystalEntity, "combat.attack.autoHitCrystal")) {
               if (getFastBreakSetting(this).isOn()) {
                  if (this.checkCondition5()) {
                     endCrystalEntity.setRemoved(RemovalReason.KILLED);
                     endCrystalEntity.onRemoved();
                  }
               }

               int intState32 = getIntState3(this);

               int intValue = intState32 + 1;
               setIntState3(this, intState32 + 1);
               if (intValue >= getIntState(this)) {
                  this.updateState();
               } else {
                  this.updateStateForCrystalPlacementState(CrystalPlacementState.PLACE, this.placeDelayMsSetting);
               }
            }
         }
      } else {
         if (this.checkCondition()) {
            if (this.modeSetting.equals("Spam Till Release")) {
               if (testBlockPos(getBlockPos(this))) {
                  this.updateStateForCrystalPlacementState(CrystalPlacementState.PLACE, getPlaceDelayMsSetting(this));
                  return;
               }
            }

            this.updateState();
         }
      }
   }

   public static CrystalPlacementState getPLACE() {
      return CrystalPlacementState.PLACE;
   }

   @EventHandler
   private void onWorldChange(WorldChangeEvent worldChangeEvent) {
      ActionSchedulers.updateState4(this);
      this.updateState2();
   }

   private static boolean isOf(Item item, ItemStack itemStack) {
      return itemStack.isOf(item);
   }

   public static int getIntState3(AutoHitCrystalModule autoHitCrystalModule2) {
      return autoHitCrystalModule2.intState3;
   }

   private static boolean testBlockPos(BlockPos blockPos2) {
      BlockState blockState = MinecraftClientAccess8.getWorld(mc).getBlockState(blockPos2);
      if (!blockState.isOf(Blocks.OBSIDIAN)) {
         if (!blockState.isOf(Blocks.BEDROCK)) {
            return false;
         }
      }

      ThreadLocalRandom.current().nextInt(15);
      return true;
   }

   public static void setClientPlayerEntity(AutoHitCrystalModule autoHitCrystalModule2, ClientPlayerEntity clientPlayerEntity2) {
      autoHitCrystalModule2.clientPlayerEntity = clientPlayerEntity2;
   }

   public static void setOn(AutoHitCrystalModule autoHitCrystalModule2, boolean on2) {
      autoHitCrystalModule2.on = on2;
   }

   public static void setIntState4(AutoHitCrystalModule autoHitCrystalModule2, int intState42) {
      autoHitCrystalModule2.intState4 = intState42;
   }

   private void updateState4() {
      if (!testBlockPos(getBlockPos(this))) {
         this.updateState();
      } else if (this.orElse(getBlockPos(this)) != null) {
         this.updateStateForCrystalPlacementState(CrystalPlacementState.BREAK, getBreakDelayMsSetting(this));
      } else {
         if (this.checkCondition()) {
            this.updateState();
         } else {
            Hand hand = this.computeHand();
            if (hand == null) {
               this.updateState();
            } else {
               int intValue = 16;
               ThreadLocalRandom.current().nextInt(12);
               this.updateState6();
               if (this.computeBlockHitResult() != null) {
                  intValue = (((byte)7));
                  ThreadLocalRandom.current().nextInt(4);
                  if (this.checkCondition2()) {
                     if (this.checkCondition4()) {
                        if (hand == MinecraftClientAccess8.getMAIN_HAND()) {
                           intValue = computeIntForItem(Items.END_CRYSTAL);
                        } else {
                           ThreadLocalRandom.current().nextInt(10);
                           intValue = -1;
                        }

                        int intValue2 = intValue;
                        this.updateStateForHand(intValue2, hand, () -> this.updateStateForHand2(hand));
                        return;
                     }
                  } else {
                     ThreadLocalRandom.current().nextInt(3);
                  }
               }
            }
         }
      }
   }

   public static BooleanSetting getSwitchBackSetting(AutoHitCrystalModule autoHitCrystalModule2) {
      return autoHitCrystalModule2.switchBackSetting;
   }

   public static void setBooleanState4(AutoHitCrystalModule autoHitCrystalModule2, boolean booleanState42) {
      autoHitCrystalModule2.booleanState4 = booleanState42;
   }

   public static void setCrystalPlacementState(AutoHitCrystalModule autoHitCrystalModule2, CrystalPlacementState crystalPlacementState2) {
      autoHitCrystalModule2.crystalPlacementState = crystalPlacementState2;
   }

   public static boolean getBooleanState2(AutoHitCrystalModule autoHitCrystalModule2) {
      return autoHitCrystalModule2.booleanState2;
   }

   private boolean checkCondition4() {
      if (!this.modeSetting.equals("Spam Till Release")) {
         if (!this.testBlockPos2(getBlockPos(this))) {
            return false;
         }
      } else {
         ThreadLocalRandom.current().nextInt(10);
      }

      return true;
   }

   public static void setBlockPos(AutoHitCrystalModule autoHitCrystalModule2, BlockPos blockPos2) {
      autoHitCrystalModule2.blockPos = blockPos2;
   }

   public static AutoHitCrystalModule getAutoHitCrystalModule() {
      return autoHitCrystalModule;
   }

   public static BooleanSetting getSilentSwapSetting(AutoHitCrystalModule autoHitCrystalModule2) {
      return autoHitCrystalModule2.silentSwapSetting;
   }

   public static int getIntState2(AutoHitCrystalModule autoHitCrystalModule2) {
      return autoHitCrystalModule2.intState2;
   }

   private boolean checkCondition5() {
      StatusEffectInstance statusEffect = MinecraftClientAccess8.getPlayer(mc).getStatusEffect(StatusEffects.WEAKNESS);
      if (statusEffect == null) {
         return true;
      } else {
         StatusEffectInstance statusEffect2 = mc.player.getStatusEffect(MinecraftClientAccess8.getSTRENGTH());
         ItemStack mainHandStack = mc.player.getMainHandStack();
         if (statusEffect2 != null) {
            if (statusEffect2.getAmplifier() > statusEffect.getAmplifier()) {
               return true;
            }
         }

         if (!mainHandStack.isIn(ItemTags.PICKAXES)) {
            if (!mainHandStack.isIn(ItemTags.AXES)) {
               if (!mainHandStack.isIn(MinecraftClientAccess8.getSHOVELS())) {
                  if (!mainHandStack.isIn(MinecraftClientAccess8.getHOES())) {
                     ThreadLocalRandom.current().nextInt(7);
                     if (!mainHandStack.isIn(ItemTags.SWORDS)) {
                        return false;
                     }
                  }
               }
            } else {
               ThreadLocalRandom.current().nextInt(7);
            }
         }

         return true;
      }
   }

   @Override
   public boolean shouldBlockAttackInput() {
      if (getBooleanState2(this)) {
         if (this.testKeyBinding(MinecraftClientAccess8.getOptions(mc).attackKey)) {
            return true;
         }
      }

      ThreadLocalRandom.current().nextInt(9);
      return false;
   }

   private void updateStateForHand(int intState22, Hand hand, Runnable runnable) {
      if (hand != Hand.OFF_HAND) {
         if (InventoryUtils.computeInt() != intState22) {
            if (intState22 >= 0) {
               if (CombatTickBudget.checkCondition2()) {
                  this.updateState8(intState22);
                  long currentTick22 = ActionSchedulers.getCurrentTick22();
                  ClientPlayerEntity player = mc.player;
                  setLongState2(this, currentTick22);
                  ActionSchedulers.schedule2(this, () -> this.updateStateForClientPlayerEntity(player, currentTick22, intState22, runnable), () -> this.setLongState25());
                  return;
               }

               ThreadLocalRandom.current().nextInt(5);
            }

            return;
         }
      }

      runnable.run();
   }

   @EventHandler
   private void onMouseClick(MouseClickEvent mouseClickEvent) {
      if (mouseClickEvent.action() == 1) {
         if (mouseClickEvent.button() == computeInt(this.activationKeySetting.getKeyCode())) {
            ThreadLocalRandom.current().nextInt(8);
            setBooleanState4(this, true);
         }
      }
   }

   public static boolean checkCondition6() {
      AutoHitCrystalModule autoHitCrystalModule2 = getAutoHitCrystalModule();
      if (autoHitCrystalModule2 != null) {
         if (autoHitCrystalModule2.isEnabled()) {
            if (getBooleanState2(autoHitCrystalModule2)) {
               if (autoHitCrystalModule2.testKeyBinding(MinecraftClientAccess8.getAttackKey(mc.options))) {
                  return true;
               }
            }
         }
      } else {
         ThreadLocalRandom.current().nextInt(11);
      }

      return false;
   }

   private void updateStateForActionResult(ActionResult actionResult, Hand hand) {
      if (actionResult instanceof Success) {
         Success actionResult2 = (Success)actionResult;
         if (actionResult2.swingSource() == MinecraftClientAccess8.getCLIENT()) {
            mc.player.swingHand(hand);
         }
      }
   }

   public static ClientPlayerEntity getClientPlayerEntity(AutoHitCrystalModule autoHitCrystalModule2) {
      return autoHitCrystalModule2.clientPlayerEntity;
   }

   public static DoubleRangeSetting getPlaceDelayMsSetting(AutoHitCrystalModule autoHitCrystalModule2) {
      return autoHitCrystalModule2.placeDelayMsSetting;
   }

   private BlockHitTarget computeBlockHitTargetForItemStack(ItemStack itemStack) {
      ClientPlayerEntity player = MinecraftClientAccess8.getPlayer(mc);
      return InteractionActions.computeBlockHitTargetForWorld(MinecraftClientAccess8.getWorld(mc), player, player.getEyePos(), player.getYaw(), player.getPitch(), itemStack);
   }

   private void updateState5() {
      if (getBooleanState3(this)) {
         RotationManager.updateState9(this);
      }

      setBooleanState3(this, false);
      setBooleanState5(this, false);
   }

   private static int computeIntForItem(Item item) {
      return InventoryUtils.computeIntForPredicate2(objectValue -> isOf(item, (ItemStack)objectValue));
   }

   public static boolean getBooleanState4(AutoHitCrystalModule autoHitCrystalModule2) {
      return autoHitCrystalModule2.booleanState4;
   }

   private BlockHitResult computeBlockHitResult() {
      HitResult hitResult = BlockInteractUtils.computeHitResult2();
      if (hitResult instanceof BlockHitResult) {
         BlockHitResult hitResult2 = (BlockHitResult)hitResult;
         if (hitResult.getType() == MinecraftClientAccess8.getBLOCK()) {
            if (hitResult2.getBlockPos().equals(getBlockPos(this))) {
               return hitResult2;
            }
         }
      }

      return null;
   }

   public static CrystalPlacementState getIDLE() {
      return CrystalPlacementState.IDLE;
   }

   private void updateState6() {
      if (this.checkCondition3()) {
         if (this.blockPos != null) {
            if (!getBooleanState3(this)) {
               double doubleValue = (double)this.blockPos.getX() + 0.5;
               double y = (double)this.blockPos.getY();

               Vec3d vec3d = new Vec3d(doubleValue, y + (1.0), (double)getBlockPos(this).getZ() + 0.5);
               ActionPriority high = ActionPriority.HIGH;
               Supplier supplier = () -> computeVec3dForVec3d(vec3d);
               RotationProfile rotationProfile = RotationProfile.createRotationProfile().withMaxRotationSpeed(720.0).computeRotationProfile10(0.6);

               RotationManager.updateStateForActionPriority(this, high, supplier, rotationProfile.withSilentAim(true));
               this.booleanState3 = true;
               setBooleanState5(this, false);
               return;
            }

            ThreadLocalRandom.current().nextInt(4);
         }
      } else {
         ThreadLocalRandom.current().nextInt(6);
      }
   }

   public static boolean getBooleanState3(AutoHitCrystalModule autoHitCrystalModule2) {
      return autoHitCrystalModule2.booleanState3;
   }

   private static Vec3d computeVec3dForVec3d(Vec3d vec3d) {
      return vec3d;
   }

   private void updateState7() {
      int intState42 = this.intState4;
      int intState22 = getIntState2(this);

      setIntState2(this, -1);
      this.intState4 = -1;
      if (getSwitchBackSetting(this).isOn()) {
         ThreadLocalRandom.current().nextInt(4);
         if (intState42 >= 0) {
            if (intState22 >= 0) {
               ThreadLocalRandom.current().nextInt(3);

               if (intState42 != intState22) {
                  if (!this.isWorldUnavailable()) {
                     ThreadLocalRandom.current().nextInt(15);

                     ThreadLocalRandom.current().nextInt(11);

                     if (mc.interactionManager != null && InventoryUtils.computeInt() == intState22) {
                        if (!CombatTickBudget.checkCondition2()) {
                           CombatTickBudget.updateState6(intState42);
                           return;
                        }

                        InventoryUtils.updateState3(intState42);
                        ((ClientPlayerInteractionManagerMixin.ClientPlayerInteractionManagerAccessor)MinecraftClientAccess8.getInteractionManager(mc)).mochi$syncSelectedSlot();
                        CombatTickBudget.setBooleanState222();
                        return;
                     }
                  }
               } else {
                  ThreadLocalRandom.current().nextInt(4);
               }
            } else {
               ThreadLocalRandom.current().nextInt(4);
            }
         }
      }
   }

   public static void setClientWorld(AutoHitCrystalModule autoHitCrystalModule2, ClientWorld clientWorld2) {
      autoHitCrystalModule2.clientWorld = clientWorld2;
   }

   private void updateStateForClientPlayerEntity(ClientPlayerEntity clientPlayerEntity2, long longValue, int intValue, Runnable runnable) {
      setLongState2(this, Long.MIN_VALUE);
      if (this.isEnabled()) {
         if (MinecraftClientAccess8.getPlayer(mc) == clientPlayerEntity2) {
            ThreadLocalRandom.current().nextInt(11);
            if (mc.interactionManager != null && mc.currentScreen == null && ActionSchedulers.getCurrentTick22() == longValue) {
               if (InventoryUtils.computeInt() == intValue) {
                  if (!clientPlayerEntity2.isUsingItem()) {
                     runnable.run();
                  }
               }
            }
         }
      }
   }

   @Override
   public void onDisable() {
      this.updateState();
      this.updateState5();
      setBooleanState2(this, false);
      this.booleanState4 = false;
   }

   public static void setBooleanState3(AutoHitCrystalModule autoHitCrystalModule2, boolean booleanState32) {
      autoHitCrystalModule2.booleanState3 = booleanState32;
   }

   public static BooleanSetting getAimAtCrystalSetting(AutoHitCrystalModule autoHitCrystalModule2) {
      return autoHitCrystalModule2.aimAtCrystalSetting;
   }

   private void updateState8(int intState22) {
      label34: {
         int intState42 = InventoryUtils.computeInt();
         if (getIntState2(this) >= 0) {
            if (intState42 == getIntState2(this)) {
               ThreadLocalRandom.current().nextInt(13);
               break label34;
            }
         } else {
            ThreadLocalRandom.current().nextInt(7);
         }

         this.intState4 = intState42;
      }

      InventoryUtils.updateState3(intState22);
      ((ClientPlayerInteractionManagerMixin.ClientPlayerInteractionManagerAccessor)MinecraftClientAccess8.getInteractionManager(mc)).mochi$syncSelectedSlot();
      CombatTickBudget.setBooleanState222();
      CombatTickBudget.updateIntState();
      this.intState2 = intState22;
      if (this.on) {
         HotbarSwapCoordinator.updateState3(this, intState22);
      }
   }

   private boolean testKeyBinding(KeyBinding keyBinding) {
      int keyCode = this.activationKeySetting.getKeyCode();

      if (keyCode != -1) {
         if (keyCode != 0 && keyBinding instanceof KeyBindingAccessor var3) {
            Key boundKey = var3.getBoundKey();
            if (boundKey == null) {
               return false;
            }

            int intValue = computeInt(keyCode);
            if (boundKey.getCategory() == Type.MOUSE) {
               if (intValue >= 0) {
                  if (intValue == boundKey.getCode()) {
                     return true;
                  }
               } else {
                  ThreadLocalRandom.current().nextInt(14);
               }

               return false;
            }

            if (intValue < 0) {
               ThreadLocalRandom.current().nextInt(7);
               if (boundKey.getCode() == keyCode) {
                  return true;
               }
            }

            return false;
         }
      }

      return false;
   }

   public static DoubleRangeSetting getSwapDelayMsSetting(AutoHitCrystalModule autoHitCrystalModule2) {
      return autoHitCrystalModule2.swapDelayMsSetting;
   }

   @EventHandler
   private void onTick(TickEvent tickEvent) {
      if (!this.isWorldUnavailable()) {
         if (MinecraftClientAccess8.getInteractionManager(mc) != null) {
            if (getBooleanState5(this) && getCrystalPlacementState(this) == CrystalPlacementState.IDLE) {
               this.updateState5();
            }

            boolean booleanState6 = KeybindUtils.checkCondition(getActivationKeySetting(this).getKeyCode());
            int intValue = getBooleanState4(this) || booleanState6 && !this.booleanState ? 1 : 0;
            setBooleanState4(this, false);
            setBooleanState(this, booleanState6);
            int intValue2 = !booleanState6 && intValue == 0 ? 0 : 1;
            if (getCrystalPlacementState(this) != CrystalPlacementState.IDLE && getModeSetting(this).equals("Spam Till Release") && intValue2 == 0) {
               this.updateState();
            }

            if (getCrystalPlacementState(this) == CrystalPlacementState.IDLE) {
               if (intValue2 == 0) {
                  this.booleanState2 = false;
               }

               int intValue3 = this.modeSetting.equals("Spam Till Release") ? intValue2 : intValue;
               if (intValue3 == 0) {
                  ThreadLocalRandom.current().nextInt(13);
                  return;
               }

               if (!this.checkCondition8(getBooleanState2(this))) {
                  return;
               }

               setBooleanState2(this, true);
               if (this.testKeyBinding(MinecraftClientAccess8.getAttackKey(MinecraftClientAccess8.getOptions(mc)))) {
                  mc.interactionManager.cancelBlockBreaking();
               }

               this.on = getSilentSwapSetting(this).isOn();
               this.clientPlayerEntity = mc.player;
               this.clientWorld = MinecraftClientAccess8.getWorld(mc);
               if (getOn(this)) {
                  HotbarSwapCoordinator.updateStateForClientPlayerEntity(this, getClientPlayerEntity(this), this.clientWorld, InventoryUtils.computeInt());
               }
            }

            if (this.longState2 != ActionSchedulers.getCurrentTick22()) {
               if (System.currentTimeMillis() >= this.longState) {
                  switch (getCrystalPlacementState(this)) {
                     case OBSIDIAN:
                        this.updateState10();
                        break;
                     case PLACE:
                        this.updateState4();
                        break;
                     case BREAK:
                        this.updateState3();
                  }

                  return;
               }
            }

            return;
         }
      }

      this.updateState2();
   }

   private boolean checkCondition7() {
      if (!this.checkCondition3()) {
         ThreadLocalRandom.current().nextInt(10);

         if (!getModeSetting(this).equals("Spam Till Release")) {
            ThreadLocalRandom.current().nextInt(9);

            return true;
         }
      }

      return false;
   }

   private void updateState9() {
      BlockHitTarget blockHitTarget = this.computeBlockHitTargetForItemStack(mc.player.getMainHandStack());
      if (blockHitTarget != null && blockHitTarget.getCell().equals(getBlockPos(this))) {
         if (CombatTickBudget.checkCondition4()) {
            this.updateStateForActionResult(MinecraftClientAccess8.getInteractionManager(mc).interactBlock(mc.player, MinecraftClientAccess8.getMAIN_HAND(), blockHitTarget.getHit2()), Hand.MAIN_HAND);
            this.updateStateForCrystalPlacementState(CrystalPlacementState.PLACE, this.swapDelayMsSetting);
            return;
         }
      }
   }

   private void updateStateForHand2(Hand hand) {
      BlockHitResult blockHitResult = this.computeBlockHitResult();
      if (blockHitResult != null) {
         if (this.checkCondition2()) {
            if (this.checkCondition4()) {
               if (CombatTickBudget.checkCondition4()) {
                  if (MinecraftClientAccess8.getPlayer(mc).getStackInHand(hand).isOf(MinecraftClientAccess8.getEND_CRYSTAL())) {
                     this.updateStateForActionResult(mc.interactionManager.interactBlock(MinecraftClientAccess8.getPlayer(mc), hand, blockHitResult), hand);
                     this.updateStateForCrystalPlacementState(CrystalPlacementState.BREAK, getBreakDelayMsSetting(this));
                     return;
                  }
               } else {
                  ThreadLocalRandom.current().nextInt(14);
               }
            } else {
               ThreadLocalRandom.current().nextInt(14);
            }
         }
      }
   }

   private boolean checkCondition8(boolean booleanValue) {
      ClientPlayerEntity player4 = MinecraftClientAccess8.getPlayer(mc);
      if (!booleanValue && !getItemWhitelistSetting(this).contains(player4.getMainHandStack().getItem())) {
         return false;
      } else {
         if (MinecraftClientAccess8.getCurrentScreen(mc) == null) {
            if (player4.isAlive()) {
               if (!player4.isSpectator() && !player4.isUsingItem() && player4.getAbilities().allowModifyWorld && this.computeHand() != null) {
                  setIntState(this, this.modeSetting.equals("Spam Till Release") ? Integer.MAX_VALUE : (getModeSetting(this).equals("Dtap") ? 2 : getCyclesSetting(this).intValue()));

                  setIntState3(this, 0);
                  HitResult hitResult = BlockInteractUtils.computeHitResult2();
                  if (hitResult instanceof EntityHitResult) {
                     ThreadLocalRandom.current().nextInt(3);
                     EntityHitResult hitResult2 = (EntityHitResult)hitResult;
                     if (hitResult2.getEntity() instanceof EndCrystalEntity var5 && var5.isAlive()) {
                        if (testBlockPos(var5.getBlockPos().down())) {
                           setBlockPos(this, var5.getBlockPos().down());
                           this.updateStateForCrystalPlacementState(CrystalPlacementState.BREAK, this.breakDelayMsSetting);
                           return true;
                        }
                     }
                  }

                  if (hitResult instanceof BlockHitResult var11 && hitResult.getType() == MinecraftClientAccess8.getBLOCK()) {
                     if (testBlockPos(var11.getBlockPos())) {
                        if (this.checkCondition7() && !this.testBlockPos2(var11.getBlockPos())) {
                           return false;
                        }

                        this.blockPos = var11.getBlockPos();
                        this.updateStateForCrystalPlacementState(CrystalPlacementState.PLACE, this.placeDelayMsSetting);
                        return true;
                     }

                     int intValue = computeIntForItem(Items.OBSIDIAN);
                     if (intValue < 0) {
                        return false;
                     }

                     BlockHitTarget blockHitTarget = this.computeBlockHitTargetForItemStack(player4.getInventory().getStack(intValue));
                     if (blockHitTarget == null) {
                        return false;
                     }

                     if (!mc.world.isAir(blockHitTarget.getCell().up())) {
                        return false;
                     }

                     if (this.checkCondition7() && !this.testBlockPos2(blockHitTarget.getCell())) {
                        return false;
                     }

                     setBlockPos(this, blockHitTarget.getCell().toImmutable());
                     this.updateStateForCrystalPlacementState(CrystalPlacementState.OBSIDIAN, this.obsidianDelayMsSetting);

                     return true;
                  }

                  return false;
               }
            }
         }

         return false;
      }
   }

   public static void setIntState2(AutoHitCrystalModule autoHitCrystalModule2, int intState22) {
      autoHitCrystalModule2.intState2 = intState22;
   }

   @EventHandler
   private void onDisconnect(DisconnectEvent disconnectEvent) {
      ActionSchedulers.updateState4(this);
      this.updateState2();
   }

   private void updateState10() {
      if (testBlockPos(this.blockPos)) {
         this.updateStateForCrystalPlacementState(CrystalPlacementState.PLACE, getSwapDelayMsSetting(this));
      } else {
         if (this.checkCondition()) {
            this.updateState();
         } else {
            int intState22 = computeIntForItem(Items.OBSIDIAN);
            if (intState22 < 0) {
               this.updateState();
            } else {
               BlockHitTarget blockHitTarget = this.computeBlockHitTargetForItemStack(mc.player.getInventory().getStack(intState22));
               if (blockHitTarget != null) {
                  ThreadLocalRandom.current().nextInt(10);

                  ThreadLocalRandom.current().nextInt(11);
                  if (blockHitTarget.getCell().equals(this.blockPos)) {
                     this.updateStateForHand(intState22, Hand.MAIN_HAND, () -> this.updateState9());
                     return;
                  }

                  ThreadLocalRandom.current().nextInt(4);
               }
            }
         }
      }
   }

   private boolean testBlockPos2(BlockPos blockPos2) {
      ClientPlayerEntity player6 = MinecraftClientAccess8.getPlayer(mc);
      Vec3d eyePos = player6.getEyePos();
      Vec3d vec3d = eyePos.add(player6.getRotationVec((1.0F)).multiply(player6.getEntityInteractionRange()));
      double x = (double)blockPos2.getX();

      x -= (0.5);
      double doubleValue = (double)blockPos2.getY() + 1.0;
      double z = (double)blockPos2.getZ();

      double doubleValue2 = z - (0.5);
      double doubleValue3 = (double)blockPos2.getX() + 1.5;
      double doubleValue4 = (double)blockPos2.getY() + 3.0;
      double z2 = (double)blockPos2.getZ();

      Box box = new Box(x, doubleValue, doubleValue2, doubleValue3, doubleValue4, z2 + (1.5));
      if (!box.contains(eyePos)) {
         if (!box.raycast(eyePos, vec3d).isPresent()) {
            return false;
         }
      }

      return true;
   }

   public static void setIntState(AutoHitCrystalModule autoHitCrystalModule2, int intState5) {
      autoHitCrystalModule2.intState = intState5;
   }

   public static HumanizedRandom getHumanizedRandom(AutoHitCrystalModule autoHitCrystalModule2) {
      return autoHitCrystalModule2.humanizedRandom;
   }

   public static DoubleSetting getCyclesSetting(AutoHitCrystalModule autoHitCrystalModule2) {
      return autoHitCrystalModule2.cyclesSetting;
   }

   private Boolean valueOf() {
      return Boolean.valueOf((!this.modeSetting.equals("Spam Till Release")));
   }

   @Override
   public void onEnable() {
      this.updateState2();
      this.booleanState = ((!this.isWorldUnavailable() && KeybindUtils.checkCondition(getActivationKeySetting(this).getKeyCode()) ? 1 : 0) != 0);
   }

   public static BooleanSetting getFastBreakSetting(AutoHitCrystalModule autoHitCrystalModule2) {
      return autoHitCrystalModule2.fastBreakSetting;
   }
}
