package cc.mochi;

public final class HumanizedDelay {
   private final double doubleState;

   private final double doubleState2;
   private final double doubleState3;
   private long longState;
   private final long timestampMillis;
   private final double doubleState4;
   private double doubleState5;
   private final HumanizedRandom humanizedRandom = new HumanizedRandom();

   private final FractalNoise fractalNoise = new FractalNoise();

   public double computeDouble(long longValue) {
      if (this.doubleState2 <= 0.0) {
         return 0.0;
      } else {
         double doubleValue = (double)(longValue - this.timestampMillis) / 1000.0;
         double doubleValue2 = this.fractalNoise.sampleOctaves(doubleValue * this.doubleState3, 3);
         double doubleValue3 = Math.sin((double)longValue * this.doubleState * (Math.PI * 2) / 1000.0 + this.doubleState4) * 0.18;
         if (longValue >= this.longState) {
            this.doubleState5 = this.humanizedRandom.computeDouble8(0.55);
            this.longState = longValue + this.humanizedRandom.computeLong(180L, 60L, 500L);
         }

         this.doubleState5 *= 0.88;
         double doubleValue4 = (doubleValue2 * 0.7 + doubleValue3 + this.doubleState5) * this.doubleState2;
         return MathUtils.computeDouble4(doubleValue4, 0.01);
      }
   }

   public HumanizedDelay(int intValue, double doubleValue) {
      this.doubleState2 = Math.max(0.0, doubleValue) * MathUtils.computeDouble6(intValue);
      this.doubleState3 = 0.15 + this.humanizedRandom.computeDouble5(0.0, 0.25);
      this.doubleState = 1.5 + this.humanizedRandom.computeDouble5(0.0, 3.0);
      this.doubleState4 = this.humanizedRandom.computeDouble5(0.0, Math.PI * 2);
      this.timestampMillis = System.currentTimeMillis();
      this.longState = this.timestampMillis + this.humanizedRandom.computeLong(180L, 60L, 500L);
   }

   public HumanizedDelay(int intValue) {
      this(intValue, 1.0);
   }
}
