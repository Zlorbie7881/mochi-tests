package cc.mochi;

public record MenuAction(String label, String detail, Icon icon, ControlTone tone, boolean checked, Runnable action) {
   public static final MenuAction INSTANCE = new MenuAction(null, null, null, ControlTone.NEUTRAL, false, null);

   public static String getLabel(MenuAction menuAction) {
      return menuAction.label;
   }

   public ControlTone getTone2() {
      return getTone(this);
   }

   public static boolean getChecked(MenuAction menuAction) {
      return menuAction.checked;
   }

   public boolean checkCondition() {
      return getLabel(this) == null;
   }

   public Runnable getAction2() {
      return getAction(this);
   }

   public static Runnable getAction(MenuAction menuAction) {
      return menuAction.action;
   }

   public static MenuAction createMenuAction(String string, String string2, Icon icon2, Runnable runnable) {
      return new MenuAction(string, string2, icon2, ControlTone.NEUTRAL, false, runnable);
   }

   public static MenuAction createMenuAction2(String string, Icon icon2, Runnable runnable) {
      return new MenuAction(string, null, icon2, ControlTone.DANGER, false, runnable);
   }

   public String getLabel2() {
      return getLabel(this);
   }

   public static ControlTone getTone(MenuAction menuAction) {
      return menuAction.tone;
   }

   public static MenuAction createMenuAction3(String string, boolean booleanValue, Runnable runnable) {
      return new MenuAction(string, null, null, ControlTone.NEUTRAL, booleanValue, runnable);
   }

   public static MenuAction createMenuAction4(String string, Icon icon2, Runnable runnable) {
      return new MenuAction(string, null, icon2, ControlTone.NEUTRAL, false, runnable);
   }

   public String getDetail() {
      return this.detail;
   }

   public Icon getIcon() {
      return this.icon;
   }

   public boolean getChecked2() {
      return getChecked(this);
   }
}
