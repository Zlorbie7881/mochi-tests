package cc.mochi;

public final class ClickSimulationModule extends Module {
   private final BooleanSetting simulateAttacksSetting;
   private final BooleanSetting simulateBlockUseSetting = new BooleanSetting("Simulate Block Use", true);

   public boolean getValue() {
      return getSimulateAttacksSetting(this).getValue();
   }

   public static BooleanSetting getSimulateAttacksSetting(ClickSimulationModule clickSimulationModule) {
      return clickSimulationModule.simulateAttacksSetting;
   }

   public static BooleanSetting getSimulateBlockUseSetting(ClickSimulationModule clickSimulationModule) {
      return clickSimulationModule.simulateBlockUseSetting;
   }

   public boolean getValue2() {
      return getSimulateBlockUseSetting(this).getValue();
   }

   public ClickSimulationModule() {
      super("Click Simulation", "Dispatches module input as verified, self-releasing simulated clicks", -1, ModuleCategory.CLIENT);

      this.simulateAttacksSetting = new BooleanSetting("Simulate Attacks", false);

      Setting[] settingArray = new Setting[2];

      settingArray[0] = this.simulateBlockUseSetting;

      settingArray[1] = this.simulateAttacksSetting;
      this.addSettings(settingArray);
   }
}
