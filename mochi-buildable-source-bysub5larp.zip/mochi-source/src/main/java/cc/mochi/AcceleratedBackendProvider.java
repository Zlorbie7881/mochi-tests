package cc.mochi;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

public final class AcceleratedBackendProvider implements RenderBackendProvider {
   static float fontWeight(FontFace fontFace) {
      float floatValue;
      switch (fontFace) {
         case SEMIBOLD:
            floatValue = 0.025F;
            break;
         case BOLD:
            floatValue = 0.05F;
            break;
         default:
            floatValue = 0.0F;
      }

      return floatValue;
   }

   @Override
   public void reloadResources() {
      Render2D.resetResources();
      Render2D.initialize();
   }

   @Override
   public void resetResources() {
      Render2D.resetResources();
   }

   @Override
   public boolean isFallback() {
      return false;
   }

   @Override
   public UiRenderBackend openUnscaled(DrawContext drawContext, int intValue, int intValue2) {
      return openFrame(intValue, intValue2);
   }

   @Override
   public void drawTexture(
      DrawContext drawContext,
      int intValue,
      int intValue2,
      Identifier identifier,
      float floatValue,
      float floatValue2,
      float floatValue3,
      float floatValue4,
      float floatValue5,
      float floatValue6,
      int intValue3,
      int intValue4,
      int intValue5,
      int intValue6
   ) {
      boolean booleanValue = !Render2D.isFrameOpen();
      if (!booleanValue || Render2D.beginFrame((float)intValue, (float)intValue2)) {
         try {
            Render2D.updateStateForIdentifier(identifier, floatValue, floatValue2, floatValue3, floatValue4, floatValue5, floatValue6, (float)intValue3, (float)intValue4, intValue5, intValue6, 0.0F, -1);
         } finally {
            if (booleanValue) {
               Render2D.endFrame();
            }
         }
      }
   }

   static FontResourceFamily fontFamily(FontFace fontFace) {
      return fontFace == FontFace.REGULAR ? FontResourceFamily.INTER : FontResourceFamily.POPPINS;
   }

   @Override
   public UiRenderBackend openScaled(DrawContext drawContext, int intValue, int intValue2) {
      return openFrame(intValue, intValue2);
   }

   private static UiRenderBackend openFrame(int intValue, int intValue2) {
      return (UiRenderBackend)(Render2D.beginFrame((float)intValue, (float)intValue2) ? new OpenGlRenderBackend() : NoOpRenderBackend.INSTANCE);
   }

   @Override
   public void initialize() {
      Render2D.initialize();
   }
}
