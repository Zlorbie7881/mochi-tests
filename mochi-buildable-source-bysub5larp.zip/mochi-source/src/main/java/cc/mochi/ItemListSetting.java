package cc.mochi;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Predicate;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

public final class ItemListSetting extends Setting {
   private final Predicate<Item> filter;

   private final List<String> defaults;
   private final Set<String> selectedIds = new LinkedHashSet<>();

   public void toggleItem(Item item) {
      if ((item != null)) {
         String itemId = getItemId(item);
         if (!getSelectedIds(this).remove(itemId)) {
            if (this.isAllowed(item)) {
               this.selectedIds.add(itemId);
            }
         }
      }
   }

   public boolean isAllowed(Item item) {
      if (item != null) {
         if (item != Items.AIR) {
            if (this.filter.test(item)) {
               return true;
            }
         }
      }

      return false;
   }

   public static Set<String> getSelectedIds(ItemListSetting itemListSetting) {
      return itemListSetting.selectedIds;
   }

   public void deserialize(String string) {
      getSelectedIds(this).clear();
      if (string != null) {
         if (!string.isBlank()) {
            String[] stringArray = string.split(",");
            int length = stringArray.length;

            int intValue = 0;

            for (; intValue < length; intValue++) {
               String string2 = stringArray[intValue];
               String string3 = string2.trim();
               if (!string3.isEmpty()) {
                  if (Identifier.tryParse(string3) != null) {
                     this.selectedIds.add(string3);
                  }
               }
            }

            return;
         }
      }
   }

   public ItemListSetting(String name, Predicate predicate, Item... itemArray) {
      super(name);
      this.filter = predicate == null ? item -> acceptAllItems(item) : predicate;
      ArrayList arrayList = new ArrayList();

      for (Item item2 : itemArray) {
         arrayList.add(getItemId(item2));
      }

      this.defaults = List.copyOf(arrayList);
      this.selectedIds.addAll(this.defaults);
   }

   private static String getItemId(Item item) {
      return RegistriesAccess.getITEM().getId(item).toString();
   }

   public boolean contains(Item item) {
      if (item != null) {
         if (this.selectedIds.contains(getItemId(item))) {
            return true;
         }

         ThreadLocalRandom.current().nextInt(11);
      }

      return false;
   }

   @Override
   public void reset() {
      getSelectedIds(this).clear();
      getSelectedIds(this).addAll(this.defaults);
   }

   @Override
   public boolean isDefault() {
      return getSelectedIds(this).equals(new LinkedHashSet<>(this.defaults));
   }

   private static boolean acceptAllItems(Item item) {
      return true;
   }

   public void removeItem(Item item) {
      if (item != null) {
         getSelectedIds(this).remove(getItemId(item));
      }
   }

   public List getItems() {
      ArrayList arrayList = new ArrayList();
      Iterator iterator = getSelectedIds(this).iterator();

      while (iterator.hasNext()) {
         String string = (String)iterator.next();
         Identifier identifier = Identifier.tryParse(string);
         if (identifier != null) {
            if ((RegistriesAccess.getITEM().containsId(identifier))) {
               Item item = (Item)Registries.ITEM.get(identifier);
               if (this.isAllowed(item)) {
                  ThreadLocalRandom.current().nextInt(10);
                  arrayList.add(item);
               }
            }
         }
      }

      return arrayList;
   }

   public String join() {
      return String.join(",", this.selectedIds);
   }
}
