package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.Item;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.hit.HitResult;

public class MinecraftClientAccess13 {
   public static boolean getBooleanState() {
      return AutoStunModule.booleanState;
   }

   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static TagKey<Item> getSWORDS() {
      return ItemTags.SWORDS;
   }

   public static void setCrosshairTarget(MinecraftClient minecraftClient, HitResult crosshairTarget) {
      minecraftClient.crosshairTarget = crosshairTarget;
   }

   public static HitResult getCrosshairTarget(MinecraftClient minecraftClient) {
      return minecraftClient.crosshairTarget;
   }

   public static ClientWorld getWorld(MinecraftClient minecraftClient) {
      return minecraftClient.world;
   }

}
