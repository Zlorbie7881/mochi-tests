package cc.mochi;

import cc.mochi.event.impl.network.PacketEvent;
import cc.mochi.event.impl.player.ItemUseEvent;
import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.event.types.TransferOrder;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;

public class HitSelectModule extends Module implements AttackInputBlocker {
   private final ChoiceSetting modeSetting;

   private int intState;

   private final DoubleSetting chanceSetting;
   private boolean booleanState;

   private final ChoiceSetting preferenceSetting;
   private boolean booleanState2;

   private int intState2;

   private LivingEntity computeLivingEntity() {
      if (MinecraftClientAccess49.getPlayer(mc) == null) {
         return null;
      } else {
         EntityHitResult entityHitResult = EntityRaycastUtils.computeEntityHitResultForMinecraftClient(mc, MinecraftClientAccess49.getPlayer(mc).getEntityInteractionRange());
         if (entityHitResult != null) {
            Entity entity = entityHitResult.getEntity();
            if (entity instanceof LivingEntity) {
               LivingEntity entity2 = (LivingEntity)entity;
               if (entity2 != mc.player) {
                  return entity2;
               }
            }
         }

         return null;
      }
   }

   public HitSelectModule() {
      super("HitSelect", "Holds the click back until the hit counts, and the right-click with it", ModuleCategory.COMBAT);

      String[] stringArray = new String[2];

      stringArray[0] = "Right-click use cancel";
      stringArray[1] = "Normal";
      this.modeSetting = new ChoiceSetting("Mode", "Right-click use cancel", stringArray);

      this.chanceSetting = new DoubleSetting("Chance %", 0.0, (100.0), 90.0, 1.0);
      this.preferenceSetting = new ChoiceSetting("Preference", "KB reduction", "KB reduction", "Critical hits");
      Setting[] settingArray = new Setting[3];

      settingArray[0] = this.modeSetting;
      settingArray[1] = this.chanceSetting;

      settingArray[2] = this.preferenceSetting;
      this.addSettings(settingArray);
      this.preferenceSetting.setVisibility(() -> this.equals());
   }

   private boolean equals() {
      return getModeSetting(this).equals("Normal");
   }

   public static int getIntState2(HitSelectModule hitSelectModule) {
      return hitSelectModule.intState2;
   }

   private boolean equals2() {
      return this.modeSetting.equals("Right-click use cancel");
   }

   public static boolean getBooleanState2(HitSelectModule hitSelectModule) {
      return hitSelectModule.booleanState2;
   }

   public static void setIntState(HitSelectModule hitSelectModule, int intState3) {
      hitSelectModule.intState = intState3;
   }

   public static void setBooleanState(HitSelectModule hitSelectModule, boolean booleanState3) {
      hitSelectModule.booleanState = booleanState3;
   }

   private boolean checkCondition() {
      double value = this.chanceSetting.getValue();
      if (value >= 100.0) {
         return true;
      } else {
         if (value <= (0.0)) {
            return false;
         } else {
            ThreadLocalRandom threadLocalRandom = ThreadLocalRandom.current();

            return (threadLocalRandom.nextDouble((100.0)) < value);
         }
      }
   }

   public static ChoiceSetting getModeSetting(HitSelectModule hitSelectModule) {
      return hitSelectModule.modeSetting;
   }

   @EventHandler
   private void onItemUseEvent(ItemUseEvent itemUseEvent) {
      label23: {
         if (!this.booleanState2) {
            if (!this.booleanState) {
               ThreadLocalRandom.current().nextInt(12);

               break label23;
            }
         }

         itemUseEvent.cancel();
      }
   }

   @Override
   public boolean shouldBlockAttackInput() {
      if (this.isEnabled()) {
         if (mc.player != null) {
            if (MinecraftClientAccess49.getWorld(mc) != null) {
               if (InventorySynchronization.checkCondition3()) {
                  return false;
               }

               if (this.equals2()) {
         return getBooleanState2(this);
      } else {
         return this.checkCondition2();
      }
            }
         }
      } else {
         ThreadLocalRandom.current().nextInt(8);
      }

      return false;
   }

   private boolean checkCondition2() {
      if (!this.checkCondition()) {
         return false;
      } else {
         byte byteValue = 0;
         if (this.intState > 0) {
            this.intState--;
            if (mc.player.isOnGround()) {
               this.intState = 0;
            }

            if (this.equals3()) {
               return false;
            }

            double y = MinecraftClientAccess49.getPlayer(mc).getVelocity().y;

            if (y > (0.0)) {
               byteValue = 1;
            } else {
               if (!MinecraftClientAccess49.getPlayer(mc).isOnGround()) {
                  return false;
               }
            }
         }

         LivingEntity livingEntity = this.computeLivingEntity();
         if (livingEntity != null) {
            if (this.testLivingEntity(livingEntity)) {
               ThreadLocalRandom.current().nextInt(16);
               if (byteValue == 0) {
                  if (MinecraftClientAccess49.getHurtTime(livingEntity) <= 0) {
                     return false;
                  }

                  if (MinecraftClientAccess49.getHurtTime(livingEntity) <= 1) {
                     ThreadLocalRandom.current().nextInt(14);
                     return false;
                  }
               }

               setBooleanState(this, true);

               return true;
            }

            ThreadLocalRandom.current().nextInt(7);
         }

         return false;
      }
   }

   private boolean equals3() {
      return getPreferenceSetting(this).equals("KB reduction");
   }

   public static void setIntState2(HitSelectModule hitSelectModule, int intState22) {
      hitSelectModule.intState2 = intState22;
   }

   public static void setBooleanState22(HitSelectModule hitSelectModule, boolean booleanState22) {
      hitSelectModule.booleanState2 = booleanState22;
   }

   private boolean testLivingEntity(LivingEntity livingEntity) {
      if (mc.player == null) {
         return false;
      } else {
         double doubleValue = livingEntity.getX() - mc.player.getX();
         double doubleValue2 = livingEntity.getZ() - mc.player.getZ();
         Vec3d velocity = mc.player.getVelocity();
         if ((doubleValue < 0.0 ? 1 : 0) == (velocity.x < 0.0 ? 1 : 0)) {
            byte byteValue;
            if (doubleValue2 < (0.0)) {
               byteValue = 1;
            } else {
               byteValue = 24;
               ThreadLocalRandom.current().nextInt(16);
               byteValue = 0;
            }

            double z = MinecraftClientAccess49.getZ(velocity);

            byte byteValue2;
            if (z < (0.0)) {
               byteValue2 = 1;
            } else {
               ThreadLocalRandom.current().nextInt(4);
               byteValue2 = 0;
            }

            if (byteValue == byteValue2) {
               return true;
            }
         }

         return false;
      }
   }

   @EventHandler
   private void onPacketEvent(PacketEvent packetEvent) {
      if (packetEvent.getOrder() == TransferOrder.RECEIVE) {
         if (!this.equals2()) {
            if (MinecraftClientAccess49.getPlayer(mc) == null) {
               return;
            }

            Packet packet = packetEvent.getPacket();
            int intValue;
            if (packet instanceof EntityVelocityUpdateS2CPacket) {
               EntityVelocityUpdateS2CPacket packet2 = (EntityVelocityUpdateS2CPacket)packet;
               intValue = packet2.getEntityId() == MinecraftClientAccess49.getPlayer(mc).getId() ? 1 : 0;
            } else {
               packet = packetEvent.getPacket();
               if (!(packet instanceof ExplosionS2CPacket)) {
                  return;
               }

               ExplosionS2CPacket packet3 = (ExplosionS2CPacket)packet;
               intValue = packet3.playerKnockback().isPresent() ? 1 : 0;
            }

            if (intValue != 0) {
               ThreadLocalRandom.current().nextInt(12);

               this.intState = 7;
            }

            return;
         }
      }
   }

   public static ChoiceSetting getPreferenceSetting(HitSelectModule hitSelectModule) {
      return hitSelectModule.preferenceSetting;
   }

   @EventHandler
   private void onTickEvent(TickEvent tickEvent) {
      if (!getModeSetting(this).getSelected().equals(this.getDisplaySuffix())) {
         this.setDisplaySuffix(this.modeSetting.getSelected());
      }

      this.booleanState = false;
      if (!this.equals2()) {
         this.booleanState2 = false;
         this.intState2 = 0;
      } else {
         if (MinecraftClientAccess49.getPlayer(mc) == null || mc.world == null) {
            setBooleanState22(this, false);
         } else if (getIntState2(this) > 0) {
            this.intState2--;
            this.booleanState2 = false;
         } else {
            LivingEntity livingEntity = this.computeLivingEntity();
            if (livingEntity != null) {
               if (mc.player.isOnGround()) {
                  if (livingEntity.timeUntilRegen > 12) {
                     if (!this.checkCondition()) {
                        setIntState2(this, 8);
                     }

                     this.booleanState2 = true;
                     return;
                  }

                  ThreadLocalRandom.current().nextInt(14);
               }
            }

            this.booleanState2 = false;
         }
      }
   }

   @Override
   public void onDisable() {
      this.booleanState2 = false;

      setIntState2(this, 0);
      setIntState(this, 0);
      setBooleanState(this, false);
   }
}
