package cc.mochi;

import cc.mochi.utils.platform.OverlayWindowManager;
import net.minecraft.client.gui.screen.Screen;

public final class GlCapabilities {
   public static boolean checkCondition() {
      return testRenderPass(RenderPass.NOTIFICATIONS);
   }

   public static boolean checkCondition2() {
      return testRenderPass(RenderPass.ISLAND_HUD);
   }

   public static boolean checkCondition3() {
      return testRenderPass(RenderPass.HUD_TEXT);
   }

   public static boolean returnFalse22() {
      return returnFalse2(RenderPass.SCREENS);
   }

   static boolean returnFalse() {
      return false;
   }

   public static void updateStateForScreen(Screen screen, Runnable runnable, Runnable runnable2) {
      if (StreamRenderLayers.checkCondition5() && StreamRenderLayers.checkCondition3()) {
         if (screen instanceof ClientGuiScreen && returnFalse22()) {
            StreamRenderLayers.updateStateForRunnable3(runnable, runnable2);
         } else {
            StreamRenderLayers.updateStateForRunnable(runnable, runnable2);
         }
      } else {
         runnable.run();
      }
   }

   static boolean returnFalse2(RenderPass renderPass) {
      return false;
   }

   private GlCapabilities() {
   }

   private static boolean testRenderPass(RenderPass renderPass) {
      boolean booleanValue = returnFalse2(renderPass);
      if (!StreamRenderLayers.checkCondition5()) {
         return booleanValue;
      } else {
         StreamRenderLayers.updateState13(booleanValue);
         return false;
      }
   }

   public static boolean checkCondition4() {
      return returnFalse22() && StreamRenderLayers.checkCondition5();
   }

   public static boolean checkCondition5() {
      return testRenderPass(RenderPass.WORLD_ESP);
   }

   public static void updateState() {
      StreamRenderLayers.updateState7();
      OverlayWindowManager.endFrame();
   }
}
