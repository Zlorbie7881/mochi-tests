package cc.mochi;

public enum KeybindCaptureState {
   BOUND,
   EMPTY,
   CAPTURING;

   private static KeybindCaptureState[] createValues() {
      return new KeybindCaptureState[]{BOUND, EMPTY, CAPTURING};
   }
}
