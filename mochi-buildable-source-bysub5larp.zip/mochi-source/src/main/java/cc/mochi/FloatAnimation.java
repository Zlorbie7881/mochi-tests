package cc.mochi;

public class FloatAnimation {
   private final long longState;
   private float floatState;
   private float floatState2;
   private long timestampMillis;

   private final EasingFunction easingFunction;
   private Runnable runnable;
   public float floatState3;
   private boolean booleanState;

   public boolean getBooleanState() {
      return this.booleanState;
   }

   public float computeFloat() {
      if (this.booleanState) {
         return this.floatState2;
      } else {
         long longValue = System.currentTimeMillis() - this.timestampMillis;
         float floatValue = Math.min(1.0F, (float)longValue / (float)this.longState);
         if (floatValue >= 1.0F) {
            this.floatState2 = this.floatState3;
            this.booleanState = true;
            if (this.runnable != null) {
               this.runnable.run();
            }
         } else {
            float floatValue2 = this.easingFunction.apply(floatValue);
            this.floatState2 = this.floatState + (this.floatState3 - this.floatState) * floatValue2;
         }

         return this.floatState2;
      }
   }

   public void updateState(float floatState32) {
      this.floatState = this.floatState2;
      this.floatState3 = floatState32;
      this.timestampMillis = System.currentTimeMillis();
      this.booleanState = false;
   }

   public FloatAnimation(float floatValue, float floatState32, long longState2, EasingFunction easingFunction2) {
      this.floatState = floatValue;
      this.floatState3 = floatState32;
      this.floatState2 = floatValue;
      this.timestampMillis = System.currentTimeMillis();
      this.longState = longState2;
      this.easingFunction = easingFunction2;
      this.booleanState = false;
   }
}
