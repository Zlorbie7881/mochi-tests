package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerInteractionManager;

public class MinecraftClientAccess45 {
   public static ClientPlayerInteractionManager getInteractionManager(MinecraftClient minecraftClient) {
      return minecraftClient.interactionManager;
   }
}
