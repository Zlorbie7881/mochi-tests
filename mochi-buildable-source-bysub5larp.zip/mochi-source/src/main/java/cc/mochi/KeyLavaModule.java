package cc.mochi;

import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.mixin.MinecraftClientAccessor;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.BlockState;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;

public final class KeyLavaModule extends Module {
   private final KeybindSetting activationKeySetting;

   private long deadlineMillis;
   private int intState;

   private int intState2;
   private boolean booleanState;
   private boolean booleanState2;
   private boolean booleanState3;
   private final DoubleSetting restoreDelayMsSetting;

   public static void setIntState(KeyLavaModule keyLavaModule, int intState3) {
      keyLavaModule.intState = intState3;
   }

   private void updateState() {
      if (mc.crosshairTarget instanceof BlockHitResult var1) {
         BlockPos blockPos = var1.getBlockPos();
         BlockState blockState = MinecraftClientAccess25.getWorld(mc).getBlockState(blockPos);
         if (!blockState.isAir()) {
            if (getIntState2(this) == 0) {
               if (this.testItem(MinecraftClientAccess25.getLAVA_BUCKET())) {
                  ((MinecraftClientAccessor)mc).invokeDoItemUse();
                  setIntState2(this, this.intState2 + 1);
               }
            } else {
               if (this.intState2 == 1) {
                  ((MinecraftClientAccessor)mc).invokeDoItemUse();
                  this.updateState5();
                  this.booleanState3 = true;
               }
            }
         }
      } else {
         ThreadLocalRandom.current().nextInt(15);
      }
   }

   public static int getIntState(KeyLavaModule keyLavaModule) {
      return keyLavaModule.intState;
   }

   public static void setDeadlineMillis(KeyLavaModule keyLavaModule, long deadlineMillis2) {
      keyLavaModule.deadlineMillis = deadlineMillis2;
   }

   public static void setIntState2(KeyLavaModule keyLavaModule, int intState22) {
      keyLavaModule.intState2 = intState22;
   }

   private void updateState2() {
      if (getIntState(this) != -1) {
         if (!getBooleanState2(this)) {
            ThreadLocalRandom.current().nextInt(6);
            mc.player.getInventory().setSelectedSlot(this.intState);
         }
      }

      setIntState(this, -1);

      setIntState2(this, 0);

      this.booleanState3 = false;

      this.booleanState2 = false;

      setDeadlineMillis(this, (0L));
   }

   private void updateState3() {
      setIntState(this, mc.player.getInventory().getSelectedSlot());

      this.intState2 = 0;
      setBooleanState3(this, false);
   }

   public KeyLavaModule() {
      super("Key Lava", "Places lava bucket and picks it back up in a 2-tick cycle", -1, ModuleCategory.COMBAT);

      this.activationKeySetting = new KeybindSetting("Activation Key", 76, false);
      this.restoreDelayMsSetting = new DoubleSetting("Restore Delay (ms)", 0.0, 1000.0, 100.0, 1.0);
      this.booleanState = false;

      this.intState = -1;

      this.intState2 = 0;
      this.booleanState3 = false;

      this.booleanState2 = false;

      this.deadlineMillis = (0L);

      Setting[] settingArray = new Setting[2];

      settingArray[0] = this.activationKeySetting;

      settingArray[1] = this.restoreDelayMsSetting;
      this.addSettings(settingArray);
      this.getSettings().removeIf(objectValue -> this.testSetting((Setting)objectValue));
   }

   public static int getIntState2(KeyLavaModule keyLavaModule) {
      return keyLavaModule.intState2;
   }

   @EventHandler
   private void onTickEvent(TickEvent tickEvent) {
      if (!this.isWorldUnavailable()) {
         if (this.isEnabled()) {
            if (MinecraftClientAccess25.getCurrentScreen(mc) != null) {
               return;
            }

            boolean booleanState4 = KeybindUtils.checkCondition2(this.activationKeySetting.getKeyCode());
            if (booleanState4 && !getBooleanState(this)) {
               this.updateState3();
            } else if (!booleanState4) {
               if (this.booleanState) {
                  this.updateState2();
               }
            } else {
               ThreadLocalRandom.current().nextInt(17);
            }

            this.booleanState = booleanState4;
            if (this.booleanState && !this.booleanState3) {
               this.updateState();
            }

            if (getBooleanState2(this)) {
               if (System.currentTimeMillis() >= this.deadlineMillis) {
                  this.updateState4();

                  this.booleanState2 = false;
               }
            } else {
               ThreadLocalRandom.current().nextInt(12);
            }

            return;
         }
      } else {
         ThreadLocalRandom.current().nextInt(7);
      }
   }

   private void updateState4() {
      if (getIntState(this) != -1) {
         mc.player.getInventory().setSelectedSlot(getIntState(this));
      }
   }

   private boolean testItem(Item item) {
      int intValue = 0;

      while (true) {
         if (intValue >= 9) {
            return false;
         }

         ItemStack stack = mc.player.getInventory().getStack(intValue);
         if (!stack.isEmpty()) {
            if (stack.getItem() == item) {
               ThreadLocalRandom.current().nextInt(11);
               mc.player.getInventory().setSelectedSlot(intValue);
               return true;
            }
         }

         intValue++;
      }
   }

   @Override
   public void onDisable() {
      this.updateState2();
      super.onDisable();
   }

   public static void setBooleanState3(KeyLavaModule keyLavaModule, boolean booleanState32) {
      keyLavaModule.booleanState3 = booleanState32;
   }

   public static boolean getBooleanState2(KeyLavaModule keyLavaModule) {
      return keyLavaModule.booleanState2;
   }

   public static boolean getBooleanState(KeyLavaModule keyLavaModule) {
      return keyLavaModule.booleanState;
   }

   private void updateState5() {
      int intState3 = getIntState(this);

      if (intState3 != -1) {
         this.booleanState2 = true;
         this.deadlineMillis = System.currentTimeMillis() + (long)this.restoreDelayMsSetting.intValue();
      }
   }

   private boolean testSetting(Setting setting) {
      if (setting instanceof KeybindSetting) {
         if (!setting.equals(getActivationKeySetting(this))) {
            return true;
         }
      }

      ThreadLocalRandom.current().nextInt(16);
      return false;
   }

   @Override
   public void onEnable() {
      this.booleanState = false;

      setIntState(this, -1);
      setIntState2(this, 0);

      setBooleanState3(this, false);
      this.booleanState2 = false;
      this.deadlineMillis = 0L;
      super.onEnable();
   }

   @Override
   public int getKeyCode() {
      return -1;
   }

   public static KeybindSetting getActivationKeySetting(KeyLavaModule keyLavaModule) {
      return keyLavaModule.activationKeySetting;
   }

}
