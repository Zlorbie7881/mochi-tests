package cc.mochi;

import net.minecraft.block.BlockState;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;

public record BlockHitTarget(BlockHitResult hit, BlockPos cell, BlockState state) {
   public static BlockHitResult getHit(BlockHitTarget blockHitTarget) {
      return blockHitTarget.hit;
   }

   public BlockHitResult getHit2() {
      return getHit(this);
   }

   public BlockState getState2() {
      return getState(this);
   }

   public static BlockState getState(BlockHitTarget blockHitTarget) {
      return blockHitTarget.state;
   }

   public BlockPos getCell() {
      return this.cell;
   }
}
