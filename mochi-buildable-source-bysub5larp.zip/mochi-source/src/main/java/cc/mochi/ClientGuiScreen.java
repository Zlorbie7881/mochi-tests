package cc.mochi;

public interface ClientGuiScreen {
}
