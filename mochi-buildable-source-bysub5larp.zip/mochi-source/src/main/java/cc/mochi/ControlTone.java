package cc.mochi;

import java.awt.Color;

public enum ControlTone {
   NEUTRAL,
   ACCENT,
   SUCCESS,
   WARNING,
   DANGER;

   private static final ControlTone[] ENUM_VALUES = {NEUTRAL, ACCENT, SUCCESS, WARNING, DANGER};

   public Color computeColorForThemeSnapshot(ThemeSnapshot themeSnapshot) {
      Color color;
      switch (this) {
         case NEUTRAL:
            color = themeSnapshot.getPrimaryText();
            break;
         case ACCENT:
            color = themeSnapshot.getAccentText2();
            break;
         default:
            color = this.computeColorForThemeSnapshot2(themeSnapshot);
      }

      return color;
   }

   public Color computeColorForThemeSnapshot2(ThemeSnapshot themeSnapshot) {
      Color color;
      switch (this) {
         case NEUTRAL:
            color = themeSnapshot.getSecondaryText2();
            break;
         case ACCENT:
            color = themeSnapshot.getAccent2();
            break;
         case SUCCESS:
            color = themeSnapshot.getSuccess();
            break;
         case WARNING:
            color = themeSnapshot.getWarning2();
            break;
         case DANGER:
            color = themeSnapshot.getDanger();
            break;
         default:
            throw new MatchException(null, null);
      }

      return color;
   }

   public static ControlTone[] getENUM_VALUES() {
      return ENUM_VALUES;
   }

   private static ControlTone[] createValues() {
      return new ControlTone[]{NEUTRAL, ACCENT, SUCCESS, WARNING, DANGER};
   }
}
