package cc.mochi.mixin;

import cc.mochi.OutlineESPModule;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.MovementType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({Entity.class})
public abstract class EntityMixin {
   @Shadow
   protected abstract void method_5623(double doubleValue, boolean booleanValue, BlockState blockState, BlockPos blockPos);

   @Inject(
      method = {"getTeamColorValue"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onGetTeamColorValue(CallbackInfoReturnable<Integer> cir) {
      OutlineESPModule outlineESPModule = OutlineESPModule.getOutlineESPModule();
      Entity entity = (Entity)(Object)this;
      if (outlineESPModule != null && outlineESPModule.isEnabled() && outlineESPModule.testEntity2(entity)) {
         cir.setReturnValue(outlineESPModule.computeIntForEntity(entity));
      }
   }

   @Shadow
   public abstract World method_73183();

   @Shadow
   public abstract BlockPos method_43260();

   @Inject(
      method = {"isGlowing"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onIsGlowing(CallbackInfoReturnable<Boolean> cir) {
      OutlineESPModule outlineESPModule = OutlineESPModule.getOutlineESPModule();
      if (outlineESPModule != null && outlineESPModule.isEnabled()) {
         Entity entity = (Entity)(Object)this;
         if (outlineESPModule.testEntity2(entity)) {
            cir.setReturnValue(true);
         }
      }
   }

   @Inject(
      method = {"move"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/entity/Entity;isRemoved()Z"
      )}
   )
   private void onMove(MovementType type, Vec3d movement, CallbackInfo ci) {
      if (this.method_73183().isClient()) {
         BlockPos blockPos = this.method_43260();
         BlockState blockState = this.method_73183().getBlockState(blockPos);
         this.method_5623(movement.y, this.method_24828(), blockState, blockPos);
      }
   }

   @Shadow
   public abstract boolean method_24828();
}
