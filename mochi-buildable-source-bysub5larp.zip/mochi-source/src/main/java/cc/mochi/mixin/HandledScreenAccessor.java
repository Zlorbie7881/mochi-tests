package cc.mochi.mixin;

import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.screen.slot.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({HandledScreen.class})
public interface HandledScreenAccessor {
   @Invoker("getSlotAt")
   Slot invokeGetSlotAt(double doubleValue, double doubleValue2);

   @Accessor("focusedSlot")
   Slot getFocusedSlot();

   @Accessor("focusedSlot")
   void setFocusedSlot(Slot slot);

   @Accessor("y")
   int getY();

   @Accessor("x")
   int getX();
}
