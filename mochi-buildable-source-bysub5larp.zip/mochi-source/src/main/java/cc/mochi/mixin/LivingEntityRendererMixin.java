package cc.mochi.mixin;

import cc.mochi.RotationManager;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({LivingEntityRenderer.class})
public class LivingEntityRendererMixin {
   @Inject(
      method = {"updateRenderState(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V"},
      at = {@At("RETURN")}
   )
   private void mochi$easeLocalLook(LivingEntity entity, LivingEntityRenderState state, float tickDelta, CallbackInfo ci) {
      if (!state.flipUpsideDown) {
         float[] floatArray = RotationManager.computeFloatArrayForEntity(entity, tickDelta);
         if (floatArray != null) {
            state.relativeHeadYaw = MathHelper.wrapDegrees(floatArray[0] - state.bodyYaw);
            state.pitch = floatArray[1];
         }
      }
   }
}
