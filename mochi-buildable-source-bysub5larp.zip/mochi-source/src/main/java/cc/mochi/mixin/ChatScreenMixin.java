package cc.mochi.mixin;

import cc.mochi.MochiClient;
import cc.mochi.event.impl.chat.ChatEvent;
import net.minecraft.client.gui.screen.ChatScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ChatScreen.class})
public class ChatScreenMixin {
   @Inject(
      method = {"sendMessage"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onSendMessage(String chatText, boolean addToHistory, CallbackInfo ci) {
      ChatEvent chatEvent = new ChatEvent(chatText);
      MochiClient.INSTANCE.getMochiEventBus().post(chatEvent);
      if (chatEvent.isCancelled()) {
         ci.cancel();
      }
   }
}
