package cc.mochi.mixin;

import cc.mochi.ItemMeshRenderer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.EntityRenderManager;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({EntityRenderManager.class})
public class EntityRenderManagerMixin {
   @Inject(
      method = {"render"},
      at = {@At("HEAD")}
   )
   private void mochi$beginOutline(
      EntityRenderState state,
      CameraRenderState cameraState,
      double x,
      double y,
      double z,
      MatrixStack matrices,
      OrderedRenderCommandQueue queue,
      CallbackInfo ci
   ) {
      ItemMeshRenderer.updateStateForEntityRenderState(state);
   }

   @Inject(
      method = {"getAndUpdateRenderState"},
      at = {@At("RETURN")}
   )
   private void mochi$tagOutline(Entity entity, float tickProgress, CallbackInfoReturnable<EntityRenderState> cir) {
      ItemMeshRenderer.updateStateForEntity(entity, (EntityRenderState)cir.getReturnValue());
   }

   @Inject(
      method = {"render"},
      at = {@At("RETURN")}
   )
   private void mochi$endOutline(
      EntityRenderState state,
      CameraRenderState cameraState,
      double x,
      double y,
      double z,
      MatrixStack matrices,
      OrderedRenderCommandQueue queue,
      CallbackInfo ci
   ) {
      ItemMeshRenderer.updateState6();
   }
}
