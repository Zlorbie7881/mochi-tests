package cc.mochi.mixin;

import cc.mochi.ActionSchedulers;
import cc.mochi.RotationManager;
import cc.mochi.MochiClient;
import cc.mochi.event.impl.player.MovementSendEvent;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ClientPlayerEntity.class})
public class ClientPlayerMovementMixin {
   @Unique
   private double mochi$lastEyeHeight = Double.NaN;
   @Shadow
   private double field_3940;
   @Shadow
   private float field_3941;
   @Shadow
   private double field_3926;
   @Shadow
   private double field_3924;
   @Shadow
   private float field_3925;

   @Inject(
      method = {"tick"},
      at = {@At("HEAD")}
   )
   private void restoreRotationStepOrigin(CallbackInfo ci) {
      ActionSchedulers.finishTick2();
      RotationManager.updateStateForClientPlayerEntity2((ClientPlayerEntity)(Object)this);
   }

   @Inject(
      method = {"sendMovementPackets"},
      at = {@At("HEAD")}
   )
   private void beforeMovementSend(CallbackInfo ci) {
      if (MochiClient.INSTANCE != null) {
         Vec3d vec3d = Double.isFinite(this.mochi$lastEyeHeight)
            ? new Vec3d(this.field_3926, this.field_3940 + this.mochi$lastEyeHeight, this.field_3924)
            : null;
         MochiClient.INSTANCE.getMochiEventBus().post(new MovementSendEvent.Before(this.field_3941, this.field_3925, vec3d));
         ActionSchedulers.finishTick();
      }
   }

   @Inject(
      method = {"sendMovementPackets"},
      at = {@At("RETURN")}
   )
   private void afterMovementSend(CallbackInfo ci) {
      ClientPlayerEntity clientPlayerEntity = (ClientPlayerEntity)(Object)this;
      this.mochi$lastEyeHeight = clientPlayerEntity.getEyeY() - clientPlayerEntity.getY();
      if (MochiClient.INSTANCE != null) {
         MochiClient.INSTANCE
            .getMochiEventBus()
            .post(
               new MovementSendEvent.After(
                  this.field_3941, this.field_3925, new Vec3d(this.field_3926, this.field_3940 + this.mochi$lastEyeHeight, this.field_3924)
               )
            );
      }
   }
}
