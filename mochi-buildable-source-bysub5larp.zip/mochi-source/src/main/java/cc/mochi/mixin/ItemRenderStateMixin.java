package cc.mochi.mixin;

import cc.mochi.ItemMeshRenderer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ItemRenderState.class})
public class ItemRenderStateMixin {
   @Inject(
      method = {"render"},
      at = {@At("RETURN")}
   )
   private void mochi$exitItem(MatrixStack matrices, OrderedRenderCommandQueue queue, int light, int overlay, int outlineColors, CallbackInfo ci) {
      ItemMeshRenderer.updateState4();
   }

   @Inject(
      method = {"render"},
      at = {@At("HEAD")}
   )
   private void mochi$enterItem(MatrixStack matrices, OrderedRenderCommandQueue queue, int light, int overlay, int outlineColors, CallbackInfo ci) {
      ItemMeshRenderer.updateState5();
   }
}
