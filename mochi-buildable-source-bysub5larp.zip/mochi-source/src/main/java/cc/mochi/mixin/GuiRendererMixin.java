package cc.mochi.mixin;

import cc.mochi.StreamRenderLayers;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import net.minecraft.client.gui.render.GuiRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin({GuiRenderer.class})
public class GuiRendererMixin {
   private static void callback$mochi$replayIntoStreamFrame$0(Operation original, GuiRenderer renderer, GpuBufferSlice fogBuffer) {
      original.call(new Object[]{renderer, fogBuffer});
   }

   @WrapOperation(
      method = {"render(Lcom/mojang/blaze3d/buffers/GpuBufferSlice;)V"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/render/GuiRenderer;renderPreparedDraws(Lcom/mojang/blaze3d/buffers/GpuBufferSlice;)V"
      )}
   )
   private void mochi$replayIntoStreamFrame(GuiRenderer renderer, GpuBufferSlice fogBuffer, Operation<Void> original) {
      StreamRenderLayers.updateStateForRunnable2(() -> callback$mochi$replayIntoStreamFrame$0(original, renderer, fogBuffer));
   }
}
