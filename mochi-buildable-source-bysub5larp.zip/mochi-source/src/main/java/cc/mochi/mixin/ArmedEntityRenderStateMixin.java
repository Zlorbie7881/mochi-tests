package cc.mochi.mixin;

import cc.mochi.HotbarSwapCoordinator;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.client.render.entity.state.ArmedEntityRenderState;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin({ArmedEntityRenderState.class})
public class ArmedEntityRenderStateMixin {
   @WrapOperation(
      method = {"updateRenderState"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/entity/LivingEntity;getMainHandStack()Lnet/minecraft/item/ItemStack;"
      )}
   )
   private static ItemStack mochi$visualMainHand(LivingEntity entity, Operation<ItemStack> original) {
      return HotbarSwapCoordinator.computeItemStackForLivingEntity(entity, (ItemStack)original.call(new Object[]{entity}));
   }
}
