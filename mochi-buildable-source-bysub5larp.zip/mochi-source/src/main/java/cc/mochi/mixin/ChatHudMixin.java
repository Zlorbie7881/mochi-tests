package cc.mochi.mixin;

import cc.mochi.NickModule;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin({ChatHud.class})
public class ChatHudMixin {
   @ModifyVariable(
      method = {"addMessage(Lnet/minecraft/text/Text;)V"},
      at = @At("HEAD"),
      argsOnly = true
   )
   private Text mochi$nickChat(Text message) {
      return NickModule.computeTextForText2(message);
   }
}
