package cc.mochi.mixin;

import cc.mochi.FreeCamModule;
import cc.mochi.MovementInputOverride;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.input.Input;
import net.minecraft.client.input.KeyboardInput;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.Vec2f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({KeyboardInput.class})
public class KeyboardInputMixin {
   @Inject(
      method = {"tick"},
      at = {@At("TAIL")}
   )
   private void onTick(CallbackInfo ci) {
      if (!FreeCamModule.checkCondition4()) {
         ClientPlayerEntity player = MinecraftClient.getInstance().player;
         if (player != null && player.input == (Object)this) {
            MovementInputOverride.updateStateForInput((Input)(Object)this, player.getYaw());
         }
      } else {
         Input input = (Input)(Object)this;
         input.playerInput = new PlayerInput(false, false, false, false, false, false, false);
         ((InputAccessor)input).setMovementVector(Vec2f.ZERO);
      }
   }
}
