package cc.mochi.mixin;

import cc.mochi.Module;
import cc.mochi.ClickGuiModule;
import cc.mochi.MochiClient;
import cc.mochi.event.impl.input.KeyInputEvent;
import net.minecraft.client.Keyboard;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.input.KeyInput;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Keyboard.class})
public class KeyboardMixin {
   @Unique
   private static final boolean FORCE_GUI = Boolean.getBoolean("mochi.dev.forceGui");
   @Shadow
   @Final
   private MinecraftClient field_1678;

   private static Boolean callback$onPress$0(int key, ClickGuiModule module) {
      return module.getKeyCode() == key;
   }

   @Inject(
      method = {"onKey"},
      at = {@At("HEAD")}
   )
   private void onPress(long window, int action, KeyInput keyInput, CallbackInfo ci) {
      if (window == this.field_1678.getWindow().getHandle() && this.field_1678.currentScreen == null) {
         int intValue = keyInput.key();
         if (intValue == -1 || intValue == 0) {
            return;
         }

         MochiClient.INSTANCE.getMochiEventBus().post(new KeyInputEvent(intValue, action));

         for (Module module : (java.lang.Iterable<Module>)(java.lang.Iterable<?>)(MochiClient.INSTANCE.moduleManager.getModules())) {
            if (intValue == module.getKeyCode()) {
               if (module.getKeybind().isHoldMode()) {
                  if (action == 1 && !module.isEnabled()) {
                     module.setEnabled(true);
                  } else if (action == 0 && module.isEnabled()) {
                     module.setEnabled(false);
                  }
               } else if (action == 1) {
                  module.toggle();
               }
            }
         }
      }
   }
}
