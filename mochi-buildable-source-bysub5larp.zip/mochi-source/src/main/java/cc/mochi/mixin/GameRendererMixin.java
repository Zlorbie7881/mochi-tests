package cc.mochi.mixin;

import cc.mochi.NoHurtCamModule;
import cc.mochi.ProjectionMatrices;
import cc.mochi.GlCapabilities;
import cc.mochi.RotationManager;
import cc.mochi.ItemMeshRenderer;
import cc.mochi.StreamRenderLayers;
import cc.mochi.MochiClient;
import cc.mochi.event.impl.render.RenderHandPostEvent;
import cc.mochi.event.impl.render.RenderWorldPostEvent;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.render.GuiRenderer;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.fog.FogRenderer;
import net.minecraft.client.render.fog.FogRenderer.FogType;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({GameRenderer.class})
public class GameRendererMixin {
   @Shadow
   @Final
   private GuiRenderer field_59965;
   @Shadow
   @Final
   private FogRenderer field_60793;

   @Inject(
      method = {"render(Lnet/minecraft/client/render/RenderTickCounter;Z)V"},
      at = {@At("TAIL")}
   )
   private void mochi$endStreamFrame(RenderTickCounter tickCounter, boolean tick, CallbackInfo ci) {
      GlCapabilities.updateState();
   }

   @Inject(
      method = {"renderWorld"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/WorldRenderer;render(Lnet/minecraft/client/util/ObjectAllocator;Lnet/minecraft/client/render/RenderTickCounter;ZLnet/minecraft/client/render/Camera;Lorg/joml/Matrix4f;Lorg/joml/Matrix4f;Lorg/joml/Matrix4f;Lcom/mojang/blaze3d/buffers/GpuBufferSlice;Lorg/joml/Vector4f;Z)V",
         shift = Shift.AFTER
      )}
   )
   private void onWorldRendered(RenderTickCounter tickCounter, CallbackInfo ci) {
      MochiClient.INSTANCE.getMochiEventBus().post(new RenderWorldPostEvent());
   }

   @Inject(
      method = {"renderWorld"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/GameRenderer;renderHand(FZLorg/joml/Matrix4f;)V"
      )}
   )
   private void renderHand(RenderTickCounter tickCounter, CallbackInfo ci) {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      Camera camera = minecraftClient.gameRenderer.getCamera();
      float tickProgress = tickCounter.getTickProgress(false);
      float floatValue = this.method_3196(camera, tickProgress, true);
      ProjectionMatrices.matrix4f2.set(minecraftClient.gameRenderer.getBasicProjectionMatrix(floatValue));
      Vec3d cameraPos = camera.getCameraPos();
      Quaternionf quaternionf = camera.getRotation().conjugate(new Quaternionf());
      Matrix4f matrix4f = new Matrix4f().rotation(quaternionf);
      matrix4f.translate((float)(-cameraPos.x), (float)(-cameraPos.y), (float)(-cameraPos.z));
      ProjectionMatrices.matrix4f.set(matrix4f);
   }

   private void callback$mochi$renderScreenForStream$1() {
      this.field_59965.render(this.field_60793.getFogBuffer(FogType.NONE));
   }

   @Inject(
      method = {"tiltViewWhenHurt(Lnet/minecraft/client/util/math/MatrixStack;F)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onTiltViewWhenHurt(MatrixStack matrices, float tickDelta, CallbackInfo ci) {
      if (NoHurtCamModule.checkCondition()) {
         ci.cancel();
      }
   }

   @WrapOperation(
      method = {"render(Lnet/minecraft/client/render/RenderTickCounter;Z)V"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/screen/Screen;renderWithTooltip(Lnet/minecraft/client/gui/DrawContext;IIF)V"
      )}
   )
   private void mochi$renderScreenForStream(Screen screen, DrawContext context, int mouseX, int mouseY, float delta, Operation<Void> original) {
      GlCapabilities.updateStateForScreen(
         screen,
         () -> callback$mochi$renderScreenForStream$0(original, screen, context, mouseX, mouseY, delta),
         () -> this.callback$mochi$renderScreenForStream$1()
      );
   }

   @Inject(
      method = {"renderHand"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/item/HeldItemRenderer;renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V"
      )}
   )
   private void mochi$beginHandOutline(float tickProgress, boolean sleeping, Matrix4f positionMatrix, CallbackInfo ci) {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      int framebufferWidth = minecraftClient.getWindow().getFramebufferWidth();
      int framebufferHeight = minecraftClient.getWindow().getFramebufferHeight();
      if (framebufferWidth > 0 && framebufferHeight > 0) {
         float floatValue = this.method_3196(minecraftClient.gameRenderer.getCamera(), tickProgress, false);
         Matrix4f matrix4f = new Matrix4f().perspective(floatValue * (float) (Math.PI / 180.0), (float)framebufferWidth / (float)framebufferHeight, 0.05F, 100.0F);
         ItemMeshRenderer.updateStateForMatrix4fc(positionMatrix, matrix4f);
      }
   }

   private static void callback$mochi$renderScreenForStream$0(Operation original, Screen screen, DrawContext context, int mouseX, int mouseY, float delta) {
      original.call(new Object[]{screen, context, mouseX, mouseY, delta});
   }

   @Inject(
      method = {"renderHand"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/item/HeldItemRenderer;renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V",
         shift = Shift.AFTER
      )}
   )
   private void mochi$endHandOutline(float tickProgress, boolean sleeping, Matrix4f positionMatrix, CallbackInfo ci) {
      ItemMeshRenderer.updateState();
      MochiClient.INSTANCE.getMochiEventBus().post(new RenderHandPostEvent());
   }

   @Shadow
   private float method_3196(Camera camera, float tickDelta, boolean changingFov) {
      throw new AssertionError("shadowed");
   }

   @Inject(
      method = {"renderWorld"},
      at = {@At("TAIL")}
   )
   private void onRenderWorldTail(RenderTickCounter tickCounter, CallbackInfo ci) {
      RotationManager.updateState2(tickCounter.getTickProgress(true));
      StreamRenderLayers.updateState2();
   }
}
