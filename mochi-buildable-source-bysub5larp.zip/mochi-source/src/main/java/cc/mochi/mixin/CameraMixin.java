package cc.mochi.mixin;

import cc.mochi.FreeCamModule;
import cc.mochi.RotationManager;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Camera.class})
public abstract class CameraMixin {
   @Redirect(
      method = {"update"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/entity/Entity;getYaw(F)F"
      )
   )
   private float redirectCameraYaw(Entity entity, float tickDelta) {
      if (RotationManager.testEntity(entity)) {
         return RotationManager.computeFloat6();
      } else {
         float floatValue = RotationManager.computeFloatForEntity(entity, tickDelta);
         return Float.isNaN(floatValue) ? entity.getYaw(tickDelta) : floatValue;
      }
   }

   @Shadow
   protected abstract void method_19327(double doubleValue, double doubleValue2, double doubleValue3);

   @Inject(
      method = {"update"},
      at = {@At("TAIL")}
   )
   private void onCameraUpdate(World world, Entity focusedEntity, boolean thirdPerson, boolean inverseView, float tickDelta, CallbackInfo ci) {
      FreeCamModule freeCamModule3 = FreeCamModule.getFreeCamModule3();
      if (freeCamModule3 != null && freeCamModule3.testEntity(focusedEntity)) {
         this.method_19327(freeCamModule3.computeDouble(tickDelta), freeCamModule3.computeDouble4(tickDelta), freeCamModule3.computeDouble2(tickDelta));
         this.method_19325(freeCamModule3.getYaw22(), freeCamModule3.getPitch3());
      }
   }

   @Shadow
   protected abstract void method_19325(float floatValue, float floatValue2);

   @Redirect(
      method = {"update"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/entity/Entity;getPitch(F)F"
      )
   )
   private float redirectCameraPitch(Entity entity, float tickDelta) {
      if (RotationManager.testEntity(entity)) {
         return RotationManager.computeFloat();
      } else {
         float floatValue = RotationManager.computeFloatForEntity2(entity, tickDelta);
         return Float.isNaN(floatValue) ? entity.getPitch(tickDelta) : floatValue;
      }
   }
}
