package cc.mochi.mixin;

import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import net.minecraft.client.gl.Framebuffer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({Framebuffer.class})
public interface FramebufferAccessor {
   @Accessor("colorAttachment")
   void mochi$setColorAttachment(GpuTexture gpuTexture);

   @Accessor("colorAttachmentView")
   void mochi$setColorAttachmentView(GpuTextureView gpuTextureView);
}
