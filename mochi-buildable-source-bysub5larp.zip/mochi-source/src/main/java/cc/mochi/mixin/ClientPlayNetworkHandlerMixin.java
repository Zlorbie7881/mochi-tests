package cc.mochi.mixin;

import cc.mochi.RenderBackendManager;
import cc.mochi.PlayerStatusListener;
import cc.mochi.ModuleLookup;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRespawnS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ClientPlayNetworkHandler.class})
public class ClientPlayNetworkHandlerMixin {
   @Inject(
      method = {"onEntityStatus(Lnet/minecraft/network/packet/s2c/play/EntityStatusS2CPacket;)V"},
      at = {@At("HEAD")}
   )
   private void mochi$onEntityStatus(EntityStatusS2CPacket packet, CallbackInfo ci) {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (minecraftClient.world != null) {
         if (packet.getStatus() == 30) {
            if (packet.getEntity(minecraftClient.world) instanceof PlayerEntity var5) {
               for (PlayerStatusListener playerStatusListener : (java.lang.Iterable<PlayerStatusListener>)(java.lang.Iterable<?>)(ModuleLookup.computeListForClass(PlayerStatusListener.class))) {
                  playerStatusListener.onPlayerStatus(var5);
               }
            }
         }
      }
   }

   @Inject(
      method = {"onPlayerRespawn(Lnet/minecraft/network/packet/s2c/play/PlayerRespawnS2CPacket;)V"},
      at = {@At("TAIL")}
   )
   private void mochi$onPlayerRespawn(PlayerRespawnS2CPacket packet, CallbackInfo ci) {
      RenderBackendManager.getINSTANCE().enableBooleanState();
   }
}
