package cc.mochi.mixin;

import cc.mochi.HotbarSwapCoordinator;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin({HeldItemRenderer.class})
public class HeldItemRendererMixin {
   @WrapOperation(
      method = {"updateHeldItems"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/network/ClientPlayerEntity;getMainHandStack()Lnet/minecraft/item/ItemStack;"
      )}
   )
   private ItemStack mochi$visualMainHand(ClientPlayerEntity player, Operation<ItemStack> original) {
      return HotbarSwapCoordinator.computeItemStackForLivingEntity(player, (ItemStack)original.call(new Object[]{player}));
   }

   @WrapOperation(
      method = {"updateHeldItems"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/network/ClientPlayerEntity;getHandEquippingProgress(F)F"
      )}
   )
   private float mochi$visualEquipProgress(ClientPlayerEntity player, float baseTime, Operation<Float> original) {
      return HotbarSwapCoordinator.computeFloatForClientPlayerEntity(player, baseTime, (Float)original.call(new Object[]{player, baseTime}));
   }

   @WrapOperation(
      method = {"getHandRenderType"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/network/ClientPlayerEntity;getMainHandStack()Lnet/minecraft/item/ItemStack;"
      )}
   )
   private static ItemStack mochi$visualHandChoice(ClientPlayerEntity player, Operation<ItemStack> original) {
      return HotbarSwapCoordinator.computeItemStackForLivingEntity(player, (ItemStack)original.call(new Object[]{player}));
   }
}
