package cc.mochi.mixin;

import cc.mochi.ItemMeshRenderer;
import java.util.List;
import net.minecraft.client.model.Model;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.command.BatchingRenderCommandQueue;
import net.minecraft.client.render.command.ModelCommandRenderer.CrumblingOverlayCommand;
import net.minecraft.client.render.item.ItemRenderState.Glint;
import net.minecraft.client.render.model.BakedQuad;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemDisplayContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({BatchingRenderCommandQueue.class})
public class BatchingRenderCommandQueueMixin {
   @Inject(
      method = {"submitItem"},
      at = {@At("HEAD")}
   )
   private void mochi$captureItem(
      MatrixStack matrices,
      ItemDisplayContext displayContext,
      int light,
      int overlay,
      int outlineColors,
      int[] tintLayers,
      List<BakedQuad> quads,
      RenderLayer renderLayer,
      Glint glintType,
      CallbackInfo ci
   ) {
      ItemMeshRenderer.updateStateForMatrixStack(matrices, quads, renderLayer, light, overlay);
   }

   @Inject(
      method = {"submitModelPart"},
      at = {@At("HEAD")}
   )
   private void mochi$capturePart(
      ModelPart part,
      MatrixStack matrices,
      RenderLayer renderLayer,
      int light,
      int overlay,
      Sprite sprite,
      boolean sheeted,
      boolean hasGlint,
      int tintedColor,
      CrumblingOverlayCommand crumblingOverlay,
      int outlineColor,
      CallbackInfo ci
   ) {
      ItemMeshRenderer.updateStateForModelPart(part, matrices, renderLayer, light, overlay, sprite);
   }

   @Inject(
      method = {"submitModel"},
      at = {@At("HEAD")}
   )
   private void mochi$captureModel(
      Model<?> model,
      Object state,
      MatrixStack matrices,
      RenderLayer renderLayer,
      int light,
      int overlay,
      int tintedColor,
      Sprite sprite,
      int outlineColor,
      CrumblingOverlayCommand crumblingOverlay,
      CallbackInfo ci
   ) {
      ItemMeshRenderer.updateStateForModel(model, state, matrices, renderLayer, light, overlay, sprite);
   }
}
