package cc.mochi.mixin;

import cc.mochi.SwingSpeedModule;
import cc.mochi.MochiClient;
import cc.mochi.event.impl.player.JumpEvent;
import java.util.Optional;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({LivingEntity.class})
public class LivingEntityMixin {
   @Inject(
      method = {"jump"},
      at = {@At("TAIL")}
   )
   public void jumpInject(CallbackInfo ci) {
      if (MochiClient.INSTANCE != null && MochiClient.mc != null && MochiClient.mc.player != null) {
         if ((Object)this == MochiClient.mc.player) {
            MochiClient.INSTANCE.getMochiEventBus().post(new JumpEvent());
         }
      }
   }

   @Inject(
      method = {"getHandSwingDuration"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void getHandSwingDurationInject(CallbackInfoReturnable<Integer> cir) {
      if (MochiClient.INSTANCE != null && MochiClient.mc != null) {
         Optional optional = MochiClient.INSTANCE.getModuleManager().findFirst(SwingSpeedModule.class);
         if (optional.isPresent()) {
            SwingSpeedModule swingSpeedModule = (SwingSpeedModule)optional.get();
            if (swingSpeedModule.isEnabled()) {
               cir.setReturnValue(swingSpeedModule.intValue());
            }
         }
      }
   }
}
