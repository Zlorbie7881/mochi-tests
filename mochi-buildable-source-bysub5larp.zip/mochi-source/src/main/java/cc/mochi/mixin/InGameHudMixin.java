package cc.mochi.mixin;

import cc.mochi.HotbarSwapCoordinator;
import cc.mochi.UiViewport;
import cc.mochi.RenderUtils;
import cc.mochi.ClientGuiScreen;
import cc.mochi.GlCapabilities;
import cc.mochi.HudBloomRenderer;
import cc.mochi.StreamRenderLayers;
import cc.mochi.MochiClient;
import cc.mochi.event.impl.render.Render2DEvent;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.blaze3d.opengl.GlStateManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.fog.FogRenderer.FogType;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import org.slf4j.Logger;
import org.slf4j.helpers.NOPLogger;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({InGameHud.class})
public class InGameHudMixin {
   private static final Logger LOGGER = NOPLogger.NOP_LOGGER;
   private static boolean flushFailureLogged;

   @Inject(
      method = {"render"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hideVanillaHudOnGui(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
      if (isClickGuiOpen() && !GlCapabilities.checkCondition4()) {
         ci.cancel();
      }
   }

   @WrapOperation(
      method = {"tick()V"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/entity/player/PlayerInventory;getSelectedStack()Lnet/minecraft/item/ItemStack;"
      )}
   )
   private ItemStack mochi$visualSelectedStack(PlayerInventory inventory, Operation<ItemStack> original) {
      return HotbarSwapCoordinator.computeItemStackForPlayerInventory(inventory, (ItemStack)original.call(new Object[]{inventory}));
   }

   @WrapOperation(
      method = {"renderHotbar"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/entity/player/PlayerInventory;getSelectedSlot()I"
      )}
   )
   private int mochi$visualSelectedSlot(PlayerInventory inventory, Operation<Integer> original) {
      return HotbarSwapCoordinator.computeIntForPlayerInventory(inventory, (Integer)original.call(new Object[]{inventory}));
   }

   private static boolean isClickGuiOpen() {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      Screen currentScreen = minecraftClient.currentScreen;
      return currentScreen instanceof ClientGuiScreen;
   }

   private static void flushVanillaHud() {
      if (!HudBloomRenderer.checkCondition2() || StreamRenderLayers.getBooleanState2()) {
         MinecraftClient minecraftClient = MinecraftClient.getInstance();
         if (minecraftClient != null && minecraftClient.gameRenderer != null) {
            try {
               GameRenderer gameRenderer = minecraftClient.gameRenderer;
               GameRendererAccessor gameRenderer2 = (GameRendererAccessor)gameRenderer;
               gameRenderer2.getGuiRenderer().render(gameRenderer2.getFogRenderer().getFogBuffer(FogType.NONE));
            } catch (Throwable failure) {
               if (!flushFailureLogged) {
                  flushFailureLogged = true;
                  LOGGER.error(
                     "Could not submit the vanilla HUD ahead of the Mochi HUD; HUD elements may render beneath the vanilla scoreboard and boss bar", failure
                  );
               }
            }
         }
      }
   }

   @Inject(
      method = {"render"},
      at = {@At("TAIL")}
   )
   private void onRender(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
      RenderUtils.resetBooleanState();
      RenderUtils.enableBooleanState();
      GlStateManager._disableDepthTest();
      GlStateManager._enableBlend();
      GlStateManager._blendFuncSeparate(770, 771, 1, 0);
      GlStateManager._disableCull();
      StreamRenderLayers.checkCondition3();
      flushVanillaHud();
      if (!isClickGuiOpen()) {
         HudBloomRenderer.updateState2();
         StreamRenderLayers.updateState4();

         try {
            MochiClient.INSTANCE.getMochiEventBus().post(new Render2DEvent(context, UiViewport.getWidth(), UiViewport.getHeight()));
         } finally {
            StreamRenderLayers.updateState9();
            HudBloomRenderer.updateState();
         }
      }

      GlStateManager._enableDepthTest();
      GlStateManager._enableCull();
   }
}
