package cc.mochi.mixin;

import cc.mochi.AutoComboModule;
import cc.mochi.AnchorModuleAccess;
import cc.mochi.HeldItemOverride;
import cc.mochi.CombatTargetTracker;
import cc.mochi.EntityMotionTracker;
import cc.mochi.ModuleLookup;
import cc.mochi.CombatTickBudget;
import cc.mochi.MochiClient;
import cc.mochi.event.impl.player.AttackEvent;
import cc.mochi.event.impl.player.BowReleaseEvent;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.component.type.PiercingWeaponComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({ClientPlayerInteractionManager.class})
public class ClientPlayerInteractionManagerMixin {
   @Inject(
      method = {"attackWithPiercingWeapon"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/network/ClientPlayerInteractionManager;syncSelectedSlot()V",
         shift = Shift.AFTER
      )}
   )
   private void observePiercingAttack(PiercingWeaponComponent weapon, CallbackInfo ci) {
      CombatTickBudget.updateState2();
   }

   @Inject(
      method = {"interactBlock"},
      at = {@At("HEAD")}
   )
   private void onInteractBlock(ClientPlayerEntity player, Hand hand, BlockHitResult hitResult, CallbackInfoReturnable<ActionResult> cir) {
      CombatTickBudget.setBooleanState322();
      AnchorModuleAccess.updateStateForHitResult(hitResult);
   }

   @Inject(
      method = {"attackEntity"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/network/ClientPlayerInteractionManager;syncSelectedSlot()V",
         shift = Shift.AFTER
      )}
   )
   private void attackEntityInject(PlayerEntity player, Entity target, CallbackInfo callbackInfo) {
      CombatTickBudget.updateState2();
      HeldItemOverride.updateStateForPlayerEntity(player, target);
      MochiClient.INSTANCE.getMochiEventBus().post(new AttackEvent(target));
      CombatTargetTracker.updateStateForEntity(target);
      EntityMotionTracker.updateStateForEntity2(target);
      AutoComboModule autoComboModule = (AutoComboModule)ModuleLookup.computeModuleForClass(AutoComboModule.class);
      if (autoComboModule != null && autoComboModule.isEnabled()) {
         autoComboModule.updateStateForEntity(target);
      }
   }

   @Inject(
      method = {"stopUsingItem"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/entity/player/PlayerEntity;stopUsingItem()V"
      )}
   )
   private void observeBowRelease(PlayerEntity player, CallbackInfo ci) {
      if (MochiClient.INSTANCE != null) {
         MochiClient.INSTANCE.getMochiEventBus().post(new BowReleaseEvent(player));
      }
   }

   @Mixin({ClientPlayerInteractionManager.class})
   public interface ClientPlayerInteractionManagerAccessor {
      @Mutable
      @Accessor("blockBreakingCooldown")
      void setBlockBreakingCooldown(int intValue);

      @Invoker("syncSelectedSlot")
      void mochi$syncSelectedSlot();
   }
}
