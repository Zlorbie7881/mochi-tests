package cc.mochi.mixin;

import cc.mochi.ModuleLookup;
import cc.mochi.MouseTweaksModule;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({HandledScreen.class})
public abstract class HandledScreenMixin {
   @Inject(
      method = {"mouseScrolled"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void mochi$mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount, CallbackInfoReturnable<Boolean> cir) {
      MouseTweaksModule enabledModule = this.getEnabledModule();
      if (enabledModule != null && enabledModule.testHandledScreen2((HandledScreen)(Object)this, mouseX, mouseY, verticalAmount)) {
         cir.setReturnValue(true);
      }
   }

   private MouseTweaksModule getEnabledModule() {
      MouseTweaksModule mouseTweaksModule = (MouseTweaksModule)ModuleLookup.computeModuleForClass(MouseTweaksModule.class);
      return mouseTweaksModule != null && mouseTweaksModule.isEnabled() ? mouseTweaksModule : null;
   }

   @Inject(
      method = {"mouseDragged"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void mochi$mouseDragged(Click click, double deltaX, double deltaY, CallbackInfoReturnable<Boolean> cir) {
      MouseTweaksModule enabledModule = this.getEnabledModule();
      if (enabledModule != null && enabledModule.testHandledScreen4((HandledScreen)(Object)this, click.x(), click.y(), click.button(), click.modifiers())) {
         cir.setReturnValue(true);
      }
   }

   @Inject(
      method = {"mouseReleased"},
      at = {@At("HEAD")}
   )
   private void mochi$mouseReleased(Click click, CallbackInfoReturnable<Boolean> cir) {
      MouseTweaksModule enabledModule = this.getEnabledModule();
      if (enabledModule != null && enabledModule.testHandledScreen3((HandledScreen)(Object)this, click.button())) {
         cir.setReturnValue(true);
      }
   }

   @Inject(
      method = {"mouseClicked"},
      at = {@At("HEAD")}
   )
   private void mochi$mouseClicked(Click click, boolean doubled, CallbackInfoReturnable<Boolean> cir) {
      MouseTweaksModule enabledModule = this.getEnabledModule();
      if (enabledModule != null) {
         enabledModule.updateStateForHandledScreen5((HandledScreen)(Object)this, click.x(), click.y(), click.button());
      }
   }
}
