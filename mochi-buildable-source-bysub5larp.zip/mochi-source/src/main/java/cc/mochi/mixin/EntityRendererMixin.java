package cc.mochi.mixin;

import cc.mochi.NickModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({EntityRenderer.class})
public class EntityRendererMixin {
   @Inject(
      method = {"getDisplayName"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void mochi$nickNametag(Entity entity, CallbackInfoReturnable<Text> cir) {
      if (entity == MinecraftClient.getInstance().player) {
         cir.setReturnValue(NickModule.computeTextForText2((Text)cir.getReturnValue()));
      }
   }
}
