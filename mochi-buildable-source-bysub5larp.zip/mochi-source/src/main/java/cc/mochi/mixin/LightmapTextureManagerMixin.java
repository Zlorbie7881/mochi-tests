package cc.mochi.mixin;

import cc.mochi.FullBrightModule;
import cc.mochi.MochiClient;
import java.util.Optional;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.world.dimension.DimensionType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({LightmapTextureManager.class})
public class LightmapTextureManagerMixin {
   @Inject(
      method = {"getBrightness(Lnet/minecraft/world/dimension/DimensionType;I)F"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private static void setBrightness(DimensionType dimensionType, int light, CallbackInfoReturnable<Float> ci) {
      if (isFullBrightEnabled()) {
         ci.setReturnValue(1.0F);
      }
   }

   @Inject(
      method = {"getBrightness(FI)F"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private static void setBrightnessFloat(float f, int i, CallbackInfoReturnable<Float> ci) {
      if (isFullBrightEnabled()) {
         ci.setReturnValue(1.0F);
      }
   }

   private static boolean isFullBrightEnabled() {
      if (MochiClient.INSTANCE != null && MochiClient.INSTANCE.moduleManager != null) {
         Optional optional = MochiClient.INSTANCE.moduleManager.findFirst(FullBrightModule.class);
         return optional.isPresent() && ((FullBrightModule)optional.get()).checkCondition();
      } else {
         return false;
      }
   }
}
