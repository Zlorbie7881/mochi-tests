package cc.mochi;

import java.util.UUID;

public record FriendEntry(UUID uuid, String name) {
   public UUID getUuid2() {
      return getUuid(this);
   }

   public String getName() {
      return this.name;
   }

   public static UUID getUuid(FriendEntry friendEntry) {
      return friendEntry.uuid;
   }
}
