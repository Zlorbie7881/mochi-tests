package cc.mochi;

import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.Locale;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.world.World;

public final class EnchantmentUtils {
   private static Boolean contains(String string, RegistryKey registryKey) {
      return registryKey.getValue().getPath().toLowerCase(DataComponentTypesAccess2.getROOT()).contains(string);
   }

   public static int computeIntForItemStack(ItemStack itemStack, RegistryKey registryKey) {
      if (itemStack != null) {
         if (!itemStack.isEmpty()) {
            if (registryKey != null) {
               ItemEnchantmentsComponent itemEnchantmentsComponent = (ItemEnchantmentsComponent)itemStack.get(DataComponentTypesAccess2.getENCHANTMENTS());
               if (itemEnchantmentsComponent == null) {
                  return 0;
               }

               Iterator iterator = itemEnchantmentsComponent.getEnchantments().iterator();

               while (iterator.hasNext()) {
                  RegistryEntry registryEntry = (RegistryEntry)iterator.next();
                  if (registryKey.equals(registryEntry.getKey().orElse(null))) {
                     ThreadLocalRandom.current().nextInt(13);

                     return itemEnchantmentsComponent.getLevel(registryEntry);
                  }
               }

               return 0;
            }
         }
      }

      return 0;
   }

   public static boolean testItemStack(ItemStack itemStack, World world, Enchantment enchantment) {
      if (itemStack != null) {
         if (world != null) {
            if (enchantment != null) {
               ItemEnchantmentsComponent itemEnchantmentsComponent = (ItemEnchantmentsComponent)itemStack.get(DataComponentTypesAccess2.getENCHANTMENTS());
               if (itemEnchantmentsComponent == null) {
                  ThreadLocalRandom.current().nextInt(9);
                  return false;
               }

               label150: {
                  label164: {
                     RegistryEntry entry;
                     try {
                        Registry orThrow = world.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
                        entry = orThrow.getEntry(enchantment);
                        if (entry == null) {
                           break label164;
                        }
                     } catch (Throwable failure) {
                        break label150;
                     }

                     byte byteValue;
                     label141: {
                        label159: {
                           try {
                              if (itemEnchantmentsComponent.getLevel(entry) > 0) {
                                 break label159;
                              }
                           } catch (Throwable failure2) {
                              break label150;
                           }

                           try {
                              byteValue = 0;
                              break label141;
                           } catch (Throwable failure3) {
                              break label150;
                           }
                        }

                        try {
                           byteValue = 1;
                        } catch (Throwable failure4) {
                           break label150;
                        }
                     }

                     try {
                        return (byteValue != 0);
                     } catch (Throwable failure5) {
                        break label150;
                     }
                  }
               }

               label126: {
                  byte byteValue2;
                  label162: {
                     label160: {
                        Integer integer;
                        try {
                           Method method = world.getRegistryManager().getClass().getMethod("get", RegistryKey.class);
                           DynamicRegistryManager registryManager = world.getRegistryManager();

                           Registry registry = (Registry)method.invoke(registryManager, RegistryKeys.ENCHANTMENT);
                           Class objectValue = registry.getClass();
                           Class[] classArray = new Class[1];

                           classArray[0] = Object.class;
                           Method method2 = objectValue.getMethod("getEntry", classArray);

                           Object[] objectValue2 = new Object[1];

                           objectValue2[0] = enchantment;
                           Object objectValue3 = method2.invoke(registry, objectValue2);
                           Method method3 = itemEnchantmentsComponent.getClass().getMethod("getLevel", objectValue3.getClass());

                           integer = (Integer)method3.invoke(itemEnchantmentsComponent, objectValue3);
                           if (integer == null) {
                              break label160;
                           }
                        } catch (Throwable failure6) {
                           break label126;
                        }

                        try {
                           if (integer > 0) {
                              byteValue2 = 1;
                              break label162;
                           }
                        } catch (Throwable failure7) {
                           break label126;
                        }
                     }

                     try {
                        byteValue2 = 0;
                     } catch (Throwable failure8) {
                        break label126;
                     }
                  }

                  try {
                     return (byteValue2 != 0);
                  } catch (Throwable failure9) {
                  }
               }

               byte byteValue3;
               label163: {
                  label161: {
                     Integer integer2;
                     try {
                        integer2 = (Integer)itemEnchantmentsComponent.getClass().getMethod("getLevel", Enchantment.class).invoke(itemEnchantmentsComponent, enchantment);
                        if (integer2 == null) {
                           break label161;
                        }
                     } catch (Throwable failure10) {
                        return false;
                     }

                     try {
                        if (integer2 > 0) {
                           byteValue3 = 1;
                           break label163;
                        }
                     } catch (Throwable failure11) {
                        return false;
                     }
                  }

                  try {
                     byteValue3 = 0;
                  } catch (Throwable failure12) {
                     return false;
                  }
               }

               try {
                  return (byteValue3 != 0);
               } catch (Throwable failure13) {
                  return false;
               }
            }
         } else {
            ThreadLocalRandom.current().nextInt(7);
         }
      }

      return false;
   }

   public static int computeIntForItemStack2(ItemStack itemStack) {
      return computeIntForItemStack(itemStack, Enchantments.DENSITY);
   }

   public static boolean testItemStack2(ItemStack itemStack, World world, RegistryEntry registryEntry) {
      if (itemStack != null) {
         if (world != null) {
            if (registryEntry != null) {
               byte byteValue = 16;
               ThreadLocalRandom.current().nextInt(15);

               ItemEnchantmentsComponent itemEnchantmentsComponent = (ItemEnchantmentsComponent)itemStack.get(DataComponentTypesAccess2.getENCHANTMENTS());
               if (itemEnchantmentsComponent == null) {
                  byteValue = 14;
                  ThreadLocalRandom.current().nextInt(10);
                  return false;
               }

               if (itemEnchantmentsComponent.getLevel(registryEntry) > 0) {
                  byteValue = 1;
               } else {
                  byteValue = 0;
               }

               return (byteValue != 0);
            }

            ThreadLocalRandom.current().nextInt(9);
         }
      }

      return false;
   }

   public static boolean testItemStack3(ItemStack itemStack, World world, String string) {
      if (itemStack != null) {
         ThreadLocalRandom.current().nextInt(14);
         if (!itemStack.isEmpty() && string != null) {
            if (!string.isBlank()) {
               ItemEnchantmentsComponent itemEnchantmentsComponent = (ItemEnchantmentsComponent)itemStack.get(DataComponentTypes.ENCHANTMENTS);
               if (itemEnchantmentsComponent == null) {
                  return false;
               }

               String string2 = string.toLowerCase(DataComponentTypesAccess2.getROOT());

               for (RegistryEntry registryEntry : itemEnchantmentsComponent.getEnchantments()) {
                  if ((Boolean)registryEntry.getKey().map(objectValue -> contains(string2, (RegistryKey)objectValue)).orElse(false)) {
                     return true;
                  }

                  if (((Enchantment)registryEntry.value()).description().getString().toLowerCase(Locale.ROOT).contains(string2)) {
                     return true;
                  }
               }

               return false;
            }
         }
      }

      return false;
   }

   public static boolean testItemStack4(ItemStack itemStack, World world, RegistryKey registryKey) {
      if (itemStack != null) {
         if (world != null) {
            if (registryKey != null) {
               ItemEnchantmentsComponent itemEnchantmentsComponent = (ItemEnchantmentsComponent)itemStack.get(DataComponentTypes.ENCHANTMENTS);
               if (itemEnchantmentsComponent == null) {
                  return false;
               }

               label101: {
                  label113: {
                     Registry orThrow;
                     Enchantment enchantment;
                     try {
                        orThrow = world.getRegistryManager().getOrThrow(DataComponentTypesAccess2.getENCHANTMENT());
                        enchantment = (Enchantment)orThrow.get(registryKey);
                        if (enchantment == null) {
                           break label101;
                        }
                     } catch (Throwable failure) {
                        break label101;
                     }

                     byte byteValue;
                     label111: {
                        try {
                           RegistryEntry entry = orThrow.getEntry(enchantment);
                           if (entry == null) {
                              break label113;
                           }

                           if (itemEnchantmentsComponent.getLevel(entry) > 0) {
                              byteValue = 1;
                              break label111;
                           }
                        } catch (Throwable failure2) {
                           break label101;
                        }

                        try {
                           byteValue = 0;
                        } catch (Throwable failure3) {
                           break label101;
                        }
                     }

                     try {
                        return (byteValue != 0);
                     } catch (Throwable failure4) {
                        break label101;
                     }
                  }

                  ThreadLocalRandom.current().nextInt(10);
               }

               label114: {
                  Object objectValue;
                  Optional optional;
                  try {
                     Class objectValue2 = world.getRegistryManager().getClass();
                     Class[] classArray = new Class[1];

                     classArray[0] = RegistryKey.class;
                     Method method = objectValue2.getMethod("get", classArray);
                     DynamicRegistryManager registryManager = world.getRegistryManager();

                     objectValue = method.invoke(registryManager, RegistryKeys.ENCHANTMENT);
                     objectValue2 = objectValue.getClass();

                     classArray = new Class[1];

                     classArray[0] = RegistryKey.class;
                     Method method2 = objectValue2.getMethod("getOrEmpty", classArray);

                     Object objectValue3 = method2.invoke(objectValue, registryKey);
                     optional = (Optional)objectValue3;
                     if (!optional.isPresent()) {
                        break label114;
                     }
                  } catch (Throwable failure5) {
                     return false;
                  }

                  try {
                     Object objectValue4 = optional.get();
                     Class objectValue5 = objectValue.getClass();

                     Class[] classArray2 = new Class[1];

                     classArray2[0] = Object.class;
                     Object objectValue6 = objectValue5.getMethod("getEntry", classArray2).invoke(objectValue, objectValue4);
                     return testItemStack2(itemStack, world, (RegistryEntry)objectValue6);
                  } catch (Throwable failure6) {
                     return false;
                  }
               }

               return false;
            }
         }
      }

      return false;
   }

   public static int computeIntForItemStack3(ItemStack itemStack) {
      return computeIntForItemStack(itemStack, Enchantments.BREACH);
   }
}
