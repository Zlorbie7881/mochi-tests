package cc.mochi;

public class HudMoveDragHandler implements DragHandler {
   final HudElement hudElement;

   final float floatState;

   final float floatState2;

   final HudEditorScreen hudEditorScreen;

   @Override
   public void drag(double doubleValue, double doubleValue2) {
      getHudEditorScreen(this).updateStateForHudElement7(getHudElement(this), getHudEditorScreen(this).computeFloat2(doubleValue) - this.floatState, getHudEditorScreen(this).computeFloat4(doubleValue2) - getFloatState2(this));
   }

   public static HudEditorScreen getHudEditorScreen(HudMoveDragHandler hudMoveDragHandler) {
      return hudMoveDragHandler.hudEditorScreen;
   }

   public static HudElement getHudElement(HudMoveDragHandler hudMoveDragHandler) {
      return hudMoveDragHandler.hudElement;
   }

   @Override
   public void release(double doubleValue, double doubleValue2) {
      getHudEditorScreen(this).updateState9();
   }

   public static float getFloatState2(HudMoveDragHandler hudMoveDragHandler) {
      return hudMoveDragHandler.floatState2;
   }

   HudMoveDragHandler(HudEditorScreen hudEditorScreen2, HudElement hudElement2, float floatState3, float floatState22) {
      this.hudEditorScreen = hudEditorScreen2;
      this.hudElement = hudElement2;
      this.floatState = floatState3;
      this.floatState2 = floatState22;
   }
}
