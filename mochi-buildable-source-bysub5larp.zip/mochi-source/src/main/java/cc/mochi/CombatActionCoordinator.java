package cc.mochi;

import java.util.concurrent.ThreadLocalRandom;

public final class CombatActionCoordinator {
   private static CombatActionOwner combatActionOwner = CombatActionOwner.NONE;

   public static boolean testCombatActionOwner(CombatActionOwner combatActionOwner2) {
      if (combatActionOwner2 != CombatActionOwner.NONE) {
         ThreadLocalRandom.current().nextInt(16);
         if (combatActionOwner2.ordinal() > combatActionOwner.ordinal()) {
            combatActionOwner = combatActionOwner2;

            return true;
         }
      }

      return false;
   }

   public static void updateState() {
      updateStateForCombatActionOwner(CombatActionOwner.AUTOMACE);
   }

   public static void updateStateForCombatActionOwner(CombatActionOwner combatActionOwner2) {
      if (combatActionOwner == combatActionOwner2) {
         setCombatActionOwner(CombatActionOwner.NONE);
      }
   }

   public static CombatActionOwner getCombatActionOwner22() {
      return getCombatActionOwner();
   }

   public static boolean checkCondition() {
      return (getCombatActionOwner() == CombatActionOwner.AUTOMACE);
   }

   public static CombatActionOwner getCombatActionOwner() {
      return combatActionOwner;
   }

   public static void setCombatActionOwner(CombatActionOwner combatActionOwner2) {
      combatActionOwner = combatActionOwner2;
   }

   private CombatActionCoordinator() {
   }

   public static boolean checkCondition2() {
      return testCombatActionOwner(CombatActionOwner.AUTOMACE);
   }
}
