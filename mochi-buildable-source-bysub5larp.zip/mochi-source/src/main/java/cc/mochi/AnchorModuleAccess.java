package cc.mochi;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

public class AnchorModuleAccess {
   public static void updateStateForHitResult(HitResult hitResult) {
      label42:
      if (hitResult instanceof BlockHitResult var1) {
         try {
            for (AnchorModule anchorModule : (java.lang.Iterable<AnchorModule>)(java.lang.Iterable<?>)(ModuleLookup.computeListForClass(AnchorModule.class))) {
               anchorModule.updateStateForBlockHitResult(var1);
            }
         } catch (Exception failure) {
            ThreadLocalRandom.current().nextInt(9);
            break label42;
         }
      } else {
      }
   }
}
