package cc.mochi;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.helpers.NOPLogger;

final class FontResourceCache {
   private static final Logger logger = NOPLogger.NOP_LOGGER;
   private static final Map<String, StbFontRenderer> stbFontRendererByString = new HashMap<>();

   private static final Set<String> stringSet = new HashSet<>();
   private static final Map<FontResourceFamily, StbFontRenderer[]> stbFontRendererArrayByFontResourceFamily = new EnumMap<>(FontResourceFamily.class);

   private FontResourceCache() {
   }

   static float computeFloatForFontResourceFamily(FontResourceFamily fontResourceFamily, String string, float floatValue, GlyphLoadCallback glyphLoadCallback) {
      StbFontRenderer[] stbFontRendererArray = computeStbFontRendererArrayForFontResourceFamily(fontResourceFamily);
      if (stbFontRendererArray.length != 0 && string != null && !string.isEmpty() && !(floatValue <= 0.0F)) {
         float floatValue2 = 0.0F;
         StbFontRenderer stbFontRenderer = null;
         int intValue = -1;
         int intValue2 = 0;

         while (intValue2 < string.length()) {
            int intValue3 = string.codePointAt(intValue2);
            intValue2 += Character.charCount(intValue3);
            StbFontRenderer stbFontRenderer32 = stbFontRendererArray[0];
            int intValue52 = 0;

            for (StbFontRenderer stbFontRenderer3 : stbFontRendererArray) {
               int intValue5 = stbFontRenderer3.computeIfAbsent2(intValue3);
               if (intValue5 != 0) {
                  stbFontRenderer32 = stbFontRenderer3;
                  intValue52 = intValue5;
                  break;
               }
            }

            float floatValue3 = floatValue / stbFontRenderer32.computeFloat();
            if (stbFontRenderer == stbFontRenderer32 && intValue >= 0) {
               floatValue2 += (float)Math.round((float)stbFontRenderer32.computeInt(intValue, intValue52) * floatValue3);
            }

            if (glyphLoadCallback != null) {
               glyphLoadCallback.loadGlyph(stbFontRenderer32, intValue52, floatValue2);
            }

            floatValue2 += (float)((int)((float)stbFontRenderer32.computeIfAbsent(intValue52) * floatValue3 + 0.5F));
            stbFontRenderer = stbFontRenderer32;
            intValue = intValue52;
         }

         return floatValue2;
      } else {
         return 0.0F;
      }
   }

   static synchronized void updateState() {
      for (StbFontRenderer stbFontRenderer : stbFontRendererByString.values()) {
         stbFontRenderer.updateState();
      }
   }

   static synchronized StbFontRenderer[] computeStbFontRendererArrayForFontResourceFamily(FontResourceFamily fontResourceFamily) {
      StbFontRenderer[] stbFontRendererArray = stbFontRendererArrayByFontResourceFamily.get(fontResourceFamily);
      if (stbFontRendererArray != null) {
         return stbFontRendererArray;
      } else {
         ArrayList arrayList = new ArrayList();

         for (String string : fontResourceFamily.resources) {
            StbFontRenderer stbFontRenderer = computeStbFontRenderer(string);
            if (stbFontRenderer != null && !arrayList.contains(stbFontRenderer)) {
               arrayList.add(stbFontRenderer);
            }
         }

         if (arrayList.isEmpty() && fontResourceFamily != FontResourceFamily.INTER) {
            arrayList.addAll(List.of(computeStbFontRendererArrayForFontResourceFamily(FontResourceFamily.INTER)));
         }

         stbFontRendererArray = (StbFontRenderer[])arrayList.toArray(new StbFontRenderer[0]);
         stbFontRendererArrayByFontResourceFamily.put(fontResourceFamily, stbFontRendererArray);
         return stbFontRendererArray;
      }
   }

   static float computeFloatForFontResourceFamily2(FontResourceFamily fontResourceFamily) {
      StbFontRenderer[] stbFontRendererArray = computeStbFontRendererArrayForFontResourceFamily(fontResourceFamily);
      if (stbFontRendererArray.length == 0) {
         return 1.0F;
      } else {
         StbFontRenderer stbFontRenderer = stbFontRendererArray[0];
         return (float)(stbFontRenderer.intState2 - stbFontRenderer.intState + stbFontRenderer.intState3) / stbFontRenderer.computeFloat();
      }
   }

   static float computeFloatForFontResourceFamily3(FontResourceFamily fontResourceFamily) {
      StbFontRenderer[] stbFontRendererArray = computeStbFontRendererArrayForFontResourceFamily(fontResourceFamily);
      if (stbFontRendererArray.length == 0) {
         return 0.8F;
      } else {
         StbFontRenderer stbFontRenderer = stbFontRendererArray[0];
         return (float)stbFontRenderer.intState2 / stbFontRenderer.computeFloat();
      }
   }

   private static StbFontRenderer computeStbFontRenderer(String string) {
      StbFontRenderer stbFontRenderer = stbFontRendererByString.get(string);
      if (stbFontRenderer != null) {
         return stbFontRenderer;
      } else if (stringSet.contains(string)) {
         return null;
      } else {
         try {
            StbFontRenderer stbFontRenderer2 = StbFontRenderer.computeStbFontRenderer(string, "assets/mochi/" + string);
            stbFontRendererByString.put(string, stbFontRenderer2);
            return stbFontRenderer2;
         } catch (LinkageError | Exception failure) {
            stringSet.add(string);
            logger.error("Could not load font {}", string, failure);
            return null;
         }
      }
   }
}
