package cc.mochi;

import cc.mochi.mixin.KeyBindingAccessor;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil.Key;
import org.apache.commons.lang3.StringUtils;
import org.lwjgl.glfw.GLFW;

public final class KeybindUtils implements MinecraftAccess {
   private static int age;
   private static KeyBinding keyBinding;

   public static int computeInt(int intValue) {
      return -100 - Math.max(0, intValue);
   }

   public static String computeString(int intValue) {
      if (intValue == -1 || intValue == 0) {
         return "Unbound";
      } else if (intValue <= -100) {
         return computeString2(-100 - intValue);
      } else if (intValue < -1) {
         return computeString2(-(intValue + 1));
      } else {
         String string;
         switch (intValue) {
            case 1:
               string = "Right Mouse";
               break;
            case 2:
               string = "Middle Mouse";
               break;
            case 3:
               string = "Mouse 4";
               break;
            case 4:
               string = "Mouse 5";
               break;
            case 5:
               string = "Mouse 6";
               break;
            case 6:
               string = "Mouse 7";
               break;
            case 7:
               string = "Mouse 8";
               break;
            case 8:
            case 9:
            case 10:
            case 11:
            case 12:
            case 13:
            case 14:
            case 15:
            case 16:
            case 17:
            case 18:
            case 19:
            case 20:
            case 21:
            case 22:
            case 23:
            case 24:
            case 25:
            case 26:
            case 27:
            case 28:
            case 29:
            case 30:
            case 31:
            case 33:
            case 34:
            case 35:
            case 36:
            case 37:
            case 38:
            case 40:
            case 41:
            case 42:
            case 43:
            case 45:
            case 46:
            case 47:
            case 48:
            case 49:
            case 50:
            case 51:
            case 52:
            case 53:
            case 54:
            case 55:
            case 56:
            case 57:
            case 58:
            case 60:
            case 62:
            case 63:
            case 64:
            case 65:
            case 66:
            case 67:
            case 68:
            case 69:
            case 70:
            case 71:
            case 72:
            case 73:
            case 74:
            case 75:
            case 76:
            case 77:
            case 78:
            case 79:
            case 80:
            case 81:
            case 82:
            case 83:
            case 84:
            case 85:
            case 86:
            case 87:
            case 88:
            case 89:
            case 90:
            case 94:
            case 95:
            case 97:
            case 98:
            case 99:
            case 100:
            case 101:
            case 102:
            case 103:
            case 104:
            case 105:
            case 106:
            case 107:
            case 108:
            case 109:
            case 110:
            case 111:
            case 112:
            case 113:
            case 114:
            case 115:
            case 116:
            case 117:
            case 118:
            case 119:
            case 120:
            case 121:
            case 122:
            case 123:
            case 124:
            case 125:
            case 126:
            case 127:
            case 128:
            case 129:
            case 130:
            case 131:
            case 132:
            case 133:
            case 134:
            case 135:
            case 136:
            case 137:
            case 138:
            case 139:
            case 140:
            case 141:
            case 142:
            case 143:
            case 144:
            case 145:
            case 146:
            case 147:
            case 148:
            case 149:
            case 150:
            case 151:
            case 152:
            case 153:
            case 154:
            case 155:
            case 156:
            case 157:
            case 158:
            case 159:
            case 160:
            case 163:
            case 164:
            case 165:
            case 166:
            case 167:
            case 168:
            case 169:
            case 170:
            case 171:
            case 172:
            case 173:
            case 174:
            case 175:
            case 176:
            case 177:
            case 178:
            case 179:
            case 180:
            case 181:
            case 182:
            case 183:
            case 184:
            case 185:
            case 186:
            case 187:
            case 188:
            case 189:
            case 190:
            case 191:
            case 192:
            case 193:
            case 194:
            case 195:
            case 196:
            case 197:
            case 198:
            case 199:
            case 200:
            case 201:
            case 202:
            case 203:
            case 204:
            case 205:
            case 206:
            case 207:
            case 208:
            case 209:
            case 210:
            case 211:
            case 212:
            case 213:
            case 214:
            case 215:
            case 216:
            case 217:
            case 218:
            case 219:
            case 220:
            case 221:
            case 222:
            case 223:
            case 224:
            case 225:
            case 226:
            case 227:
            case 228:
            case 229:
            case 230:
            case 231:
            case 232:
            case 233:
            case 234:
            case 235:
            case 236:
            case 237:
            case 238:
            case 239:
            case 240:
            case 241:
            case 242:
            case 243:
            case 244:
            case 245:
            case 246:
            case 247:
            case 248:
            case 249:
            case 250:
            case 251:
            case 252:
            case 253:
            case 254:
            case 255:
            case 270:
            case 271:
            case 272:
            case 273:
            case 274:
            case 275:
            case 276:
            case 277:
            case 278:
            case 279:
            case 285:
            case 286:
            case 287:
            case 288:
            case 289:
            case 315:
            case 316:
            case 317:
            case 318:
            case 319:
            case 320:
            case 321:
            case 322:
            case 323:
            case 324:
            case 325:
            case 326:
            case 327:
            case 328:
            case 329:
            case 330:
            case 331:
            case 332:
            case 333:
            case 334:
            case 336:
            case 337:
            case 338:
            case 339:
            default:
               String string2 = GLFW.glfwGetKeyName(intValue, 0);
               string = string2 != null && !string2.isBlank() ? StringUtils.capitalize(string2) : "None";
               break;
            case 32:
               string = "Space";
               break;
            case 39:
               string = "Apostrophe";
               break;
            case 44:
               string = "Comma";
               break;
            case 59:
               string = "Semicolon";
               break;
            case 61:
               string = "Equals";
               break;
            case 91:
               string = "Left Bracket";
               break;
            case 92:
               string = "Backslash";
               break;
            case 93:
               string = "Right Bracket";
               break;
            case 96:
               string = "Grave Accent";
               break;
            case 161:
               string = "World 1";
               break;
            case 162:
               string = "World 2";
               break;
            case 256:
               string = "Escape";
               break;
            case 257:
               string = "Enter";
               break;
            case 258:
               string = "Tab";
               break;
            case 259:
               string = "Backspace";
               break;
            case 260:
               string = "Insert";
               break;
            case 261:
               string = "Delete";
               break;
            case 262:
               string = "Arrow Right";
               break;
            case 263:
               string = "Arrow Left";
               break;
            case 264:
               string = "Arrow Down";
               break;
            case 265:
               string = "Arrow Up";
               break;
            case 266:
               string = "Page Up";
               break;
            case 267:
               string = "Page Down";
               break;
            case 268:
               string = "Home";
               break;
            case 269:
               string = "End";
               break;
            case 280:
               string = "Caps Lock";
               break;
            case 281:
               string = "Scroll Lock";
               break;
            case 282:
               string = "Num Lock";
               break;
            case 283:
               string = "Print Screen";
               break;
            case 284:
               string = "Pause";
               break;
            case 290:
               string = "F1";
               break;
            case 291:
               string = "F2";
               break;
            case 292:
               string = "F3";
               break;
            case 293:
               string = "F4";
               break;
            case 294:
               string = "F5";
               break;
            case 295:
               string = "F6";
               break;
            case 296:
               string = "F7";
               break;
            case 297:
               string = "F8";
               break;
            case 298:
               string = "F9";
               break;
            case 299:
               string = "F10";
               break;
            case 300:
               string = "F11";
               break;
            case 301:
               string = "F12";
               break;
            case 302:
               string = "F13";
               break;
            case 303:
               string = "F14";
               break;
            case 304:
               string = "F15";
               break;
            case 305:
               string = "F16";
               break;
            case 306:
               string = "F17";
               break;
            case 307:
               string = "F18";
               break;
            case 308:
               string = "F19";
               break;
            case 309:
               string = "F20";
               break;
            case 310:
               string = "F21";
               break;
            case 311:
               string = "F22";
               break;
            case 312:
               string = "F23";
               break;
            case 313:
               string = "F24";
               break;
            case 314:
               string = "F25";
               break;
            case 335:
               string = "Numpad Enter";
               break;
            case 340:
               string = "Left Shift";
               break;
            case 341:
               string = "Left Control";
               break;
            case 342:
               string = "Left Alt";
               break;
            case 343:
               string = "Left Super";
               break;
            case 344:
               string = "Right Shift";
               break;
            case 345:
               string = "Right Control";
               break;
            case 346:
               string = "Right Alt";
               break;
            case 347:
               string = "Right Super";
               break;
            case 348:
               string = "Menu";
         }

         return string;
      }
   }

   public static boolean checkCondition(int intValue) {
      return mc != null && mc.currentScreen == null ? checkCondition2(intValue) : false;
   }

   public static boolean checkCondition2(int intValue) {
      try {
         if (intValue == -1 || intValue == 0) {
            return false;
         } else if (intValue <= -100) {
            int intValue2 = -100 - intValue;
            return intValue2 >= 0 && intValue2 <= 8 ? GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), intValue2) == 1 : false;
         } else if (intValue < -1) {
            int intValue3 = -(intValue + 1);
            return intValue3 >= 0 && intValue3 <= 8 ? GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), intValue3) == 1 : false;
         } else {
            return intValue > 0 && intValue <= 7
               ? GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), intValue) == 1
               : GLFW.glfwGetKey(mc.getWindow().getHandle(), intValue) == 1;
         }
      } catch (Exception failure) {
         return false;
      }
   }

   private static boolean testKeyBinding(KeyBinding keyBinding2) {
      if (!(keyBinding2 instanceof KeyBindingAccessor var1)) {
         return false;
      } else {
         Key boundKey = var1.getBoundKey();
         return boundKey != null && checkCondition2(boundKey.getCode());
      }
   }

   private KeybindUtils() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }

   public static void updateState() {
      KeyBinding keyBinding2 = keyBinding;
      keyBinding = null;
      if (keyBinding2 != null && !testKeyBinding(keyBinding2)) {
         keyBinding2.setPressed(false);
      }
   }

   public static void updateStateForKeyBinding(KeyBinding keyBinding2) {
      if (keyBinding2 != null && mc != null && mc.player != null) {
         keyBinding2.setPressed(true);
         keyBinding = keyBinding2;
         age = mc.player.age;
      }
   }

   private static String computeString2(int intValue) {
      String string;
      switch (intValue) {
         case 0:
            string = "Left Mouse";
            break;
         case 1:
            string = "Right Mouse";
            break;
         case 2:
            string = "Middle Mouse";
            break;
         default:
            string = "Mouse " + (intValue + 1);
      }

      return string;
   }

   public static void updateState2() {
      KeyBinding keyBinding2 = keyBinding;
      if (keyBinding2 != null) {
         if (mc == null || mc.player == null || mc.player.age != age) {
            keyBinding = null;
            if (!testKeyBinding(keyBinding2)) {
               keyBinding2.setPressed(false);
            }
         }
      }
   }
}
