package cc.mochi;

public class InstaCartStateSwitchMap {
   static final int[] intArray2 = new int[InstaCartState.values().length];

   static {
      try {
         intArray2[InstaCartState.RAIL.ordinal()] = 1;
      } catch (NoSuchFieldError failure) {
      }

      label42: {
         try {
            int[] intArray = intArray2;
            int intValue = InstaCartState.CART.ordinal();

            intArray[intValue] = 2;
         } catch (NoSuchFieldError failure2) {
            break label42;
         }
      }

      label38: {
         try {
            intArray2[InstaCartState.COVER.ordinal()] = 3;
         } catch (NoSuchFieldError failure3) {
            break label38;
         }
      }
   }
}
