package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;

public class MinecraftClientAccess10 {
   public static KeyBinding getUseKey(GameOptions gameOptions) {
      return gameOptions.useKey;
   }

   public static GameOptions getOptions(MinecraftClient minecraftClient) {
      return minecraftClient.options;
   }

}
