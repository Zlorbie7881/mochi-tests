package cc.mochi;

public class EasingFunctionAccess {
   public static final EasingFunction LINEAR = progress -> linear(progress);

   public static final EasingFunction IN_QUAD = progress2 -> inQuad(progress2);

   public static final EasingFunction OUT_QUAD = progress3 -> outQuad(progress3);
   public static final EasingFunction IN_OUT_QUAD = progress4 -> inOutQuad(progress4);

   public static final EasingFunction IN_CUBIC = progress5 -> inCubic(progress5);

   public static final EasingFunction OUT_CUBIC = progress6 -> outCubic(progress6);
   public static final EasingFunction IN_OUT_CUBIC = progress7 -> inOutCubic(progress7);

   public static final EasingFunction IN_QUART = progress8 -> inQuart(progress8);

   public static final EasingFunction OUT_QUART = progress9 -> outQuart(progress9);

   public static final EasingFunction IN_OUT_QUART = progress10 -> inOutQuart(progress10);

   public static final EasingFunction IN_SINE = progress11 -> inSine(progress11);
   public static final EasingFunction OUT_SINE = progress12 -> outSine(progress12);
   public static final EasingFunction IN_OUT_SINE = progress13 -> inOutSine(progress13);

   public static final EasingFunction IN_EXPO = progress14 -> inExpo(progress14);
   public static final EasingFunction OUT_EXPO = progress15 -> outExpo(progress15);

   public static final EasingFunction IN_OUT_EXPO = progress16 -> inOutExpo(progress16);

   public static final EasingFunction IN_CIRC = progress17 -> inCirc(progress17);

   public static final EasingFunction OUT_CIRC = progress18 -> outCirc(progress18);

   public static final EasingFunction IN_OUT_CIRC = progress19 -> inOutCirc(progress19);

   public static final EasingFunction IN_BACK = progress20 -> inBack(progress20);

   public static final EasingFunction OUT_BACK = progress21 -> outBack(progress21);

   public static final EasingFunction IN_OUT_BACK = progress22 -> inOutBack(progress22);
   public static final EasingFunction IN_ELASTIC = progress23 -> inElastic(progress23);

   public static final EasingFunction OUT_ELASTIC = progress24 -> outElastic(progress24);

   public static final EasingFunction IN_OUT_ELASTIC = progress25 -> inOutElastic(progress25);

   public static final EasingFunction OUT_BOUNCE = progress26 -> outBounce(progress26);
   public static final EasingFunction IN_BOUNCE = progress27 -> inBounce(progress27);

   public static final EasingFunction IN_OUT_BOUNCE = progress28 -> inOutBounce(progress28);

   private static float linear(float progress) {
      return progress;
   }

   private static float inOutCubic(float progress) {
      return progress < 0.5F ? 4.0F * progress * progress * progress : 1.0F - (float)Math.pow((double)(((-2.0F)) * progress + 2.0F), 3.0) / 2.0F;
   }

   private static float inOutSine(float progress) {
      return -((float)Math.cos(Math.PI * (double)progress) - 1.0F) / 2.0F;
   }

   private static float inOutBounce(float progress) {
      return progress < 0.5F ? (1.0F - OUT_BOUNCE.apply(1.0F - 2.0F * progress)) / 2.0F : (1.0F + OUT_BOUNCE.apply(2.0F * progress - 1.0F)) / 2.0F;
   }

   private static float inBounce(float progress) {
      return 1.0F - OUT_BOUNCE.apply(1.0F - progress);
   }

   private static float inOutExpo(float progress) {
      if (progress == 0.0F) {
         return 0.0F;
      } else if (progress == 1.0F) {
         return 1.0F;
      } else {
         return progress < 0.5F
            ? (float)Math.pow(2.0, (double)(20.0F * progress - 10.0F)) / 2.0F
            : (2.0F - (float)Math.pow(2.0, (double)(((-20.0F)) * progress + 10.0F))) / 2.0F;
      }
   }

   private static float inCirc(float progress) {
      return 1.0F - (float)Math.sqrt((double)(1.0F - progress * progress));
   }

   private static float inOutQuad(float progress) {
      return progress < 0.5F ? 2.0F * progress * progress : 1.0F - 2.0F * (1.0F - progress) * (1.0F - progress);
   }

   private static float outCirc(float progress) {
      return (float)Math.sqrt((double)(1.0F - (progress - 1.0F) * (progress - 1.0F)));
   }

   private static float outElastic(float progress) {
      return progress == 0.0F
         ? 0.0F
         : (
            progress == 1.0F
               ? 1.0F
               : (float)Math.pow(2.0, (double)(((-10.0F)) * progress)) * (float)Math.sin((double)((progress * 10.0F - 0.75F) * (float) (Math.PI * 2.0 / 3.0))) + 1.0F
         );
   }

   private static float outSine(float progress) {
      return (float)Math.sin((double)progress * Math.PI / 2.0);
   }

   private static float outQuart(float progress) {
      return 1.0F - (float)Math.pow((double)(1.0F - progress), 4.0);
   }

   private static float inOutElastic(float progress) {
      return progress == 0.0F
         ? 0.0F
         : (
            progress == 1.0F
               ? 1.0F
               : (
                  progress < 0.5F
                     ? -(
                           (float)Math.pow(2.0, (double)(20.0F * progress - 10.0F))
                              * (float)Math.sin((double)((20.0F * progress - 11.125F) * ((float) Math.PI * 4.0F / 9.0F)))
                        )
                        / 2.0F
                     : (float)Math.pow(2.0, (double)(((-20.0F)) * progress + 10.0F))
                           * (float)Math.sin((double)((20.0F * progress - 11.125F) * ((float) Math.PI * 4.0F / 9.0F)))
                           / 2.0F
                        + 1.0F
               )
         );
   }

   private static float inOutQuart(float progress) {
      return progress < 0.5F ? 8.0F * progress * progress * progress * progress : 1.0F - (float)Math.pow((double)(((-2.0F)) * progress + 2.0F), 4.0) / 2.0F;
   }

   private static float outBounce(float progress) {
      if (progress < 0.36363637F) {
         return 7.5625F * progress * progress;
      } else if (progress < 0.72727275F) {
         float floatValue;
         return 7.5625F * (floatValue = progress - 0.54545456F) * floatValue + 0.75F;
      } else {
         float floatValue2;
         float floatValue3;
         return (double)progress < 0.9090909090909091
            ? 7.5625F * (floatValue2 = progress - 0.8181818F) * floatValue2 + 0.9375F
            : 7.5625F * (floatValue3 = progress - 0.95454544F) * floatValue3 + 0.984375F;
      }
   }

   private static float inElastic(float progress) {
      return progress == 0.0F
         ? 0.0F
         : (
            progress == 1.0F
               ? 1.0F
               : -((float)Math.pow(2.0, (double)(10.0F * progress - 10.0F))) * (float)Math.sin((double)((progress * 10.0F - 10.75F) * (float) (Math.PI * 2.0 / 3.0)))
         );
   }

   private static float outBack(float progress) {
      return 1.0F + 2.70158F * (float)Math.pow((double)(progress - 1.0F), 3.0) + 1.70158F * (float)Math.pow((double)(progress - 1.0F), 2.0);
   }

   private static float inQuad(float progress) {
      return progress * progress;
   }

   private static float outExpo(float progress) {
      return progress == 1.0F ? 1.0F : 1.0F - (float)Math.pow(2.0, (double)(((-10.0F)) * progress));
   }

   private static float inBack(float progress) {
      return 2.70158F * progress * progress * progress - 1.70158F * progress * progress;
   }

   private static float outQuad(float progress) {
      return 1.0F - (1.0F - progress) * (1.0F - progress);
   }

   private static float inQuart(float progress) {
      return progress * progress * progress * progress;
   }

   private static float inSine(float progress) {
      return 1.0F - (float)Math.cos((double)progress * Math.PI / 2.0);
   }

   private static float inOutBack(float progress) {
      return progress < 0.5F
         ? (float)Math.pow((double)(2.0F * progress), 2.0) * (7.189819F * progress - 2.5949094F) / 2.0F
         : ((float)Math.pow((double)(2.0F * progress - 2.0F), 2.0) * (3.5949094F * (progress * 2.0F - 2.0F) + 2.5949094F) + 2.0F) / 2.0F;
   }

   private static float inOutCirc(float progress) {
      return progress < 0.5F
         ? (1.0F - (float)Math.sqrt((double)(1.0F - 4.0F * progress * progress))) / 2.0F
         : ((float)Math.sqrt((double)(1.0F - (((-2.0F)) * progress + 2.0F) * (((-2.0F)) * progress + 2.0F))) + 1.0F) / 2.0F;
   }

   private static float inCubic(float progress) {
      return progress * progress * progress;
   }

   private static float inExpo(float progress) {
      return progress == 0.0F ? 0.0F : (float)Math.pow(2.0, (double)(10.0F * (progress - 1.0F)));
   }

   private static float outCubic(float progress) {
      return 1.0F - (float)Math.pow((double)(1.0F - progress), 3.0);
   }
}
