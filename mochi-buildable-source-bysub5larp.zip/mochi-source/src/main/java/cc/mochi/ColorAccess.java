package cc.mochi;

import java.awt.Color;

public class ColorAccess {
   public static Color getWHITE() {
      return Color.WHITE;
   }

   public static Color getBLACK() {
      return Color.BLACK;
   }

}
