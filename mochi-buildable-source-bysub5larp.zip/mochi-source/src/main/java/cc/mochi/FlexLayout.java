package cc.mochi;

import java.util.ArrayList;
import java.util.List;

public class FlexLayout {
   private LayoutInsets layoutInsets;
   private CrossAxisAlignment crossAxisAlignment;
   private FlexDirection flexDirection;
   public final List<LayoutChild> layoutChildList = new ArrayList<>();
   private int intState;

   private MainAxisAlignment mainAxisAlignment;

   public FlexLayout computeFlexLayoutForCrossAxisAlignment(CrossAxisAlignment crossAxisAlignment2) {
      this.crossAxisAlignment = crossAxisAlignment2;
      return this;
   }

   public FlexLayout computeFlexLayoutForFlexDirection(FlexDirection flexDirection2) {
      this.flexDirection = flexDirection2;
      return this;
   }

   public FlexLayout computeFlexLayoutForMainAxisAlignment(MainAxisAlignment mainAxisAlignment2) {
      this.mainAxisAlignment = mainAxisAlignment2;
      return this;
   }

   public FlexLayout computeFlexLayoutForLayoutChild(LayoutChild layoutChild) {
      this.layoutChildList.add(layoutChild);
      return this;
   }

   public FlexLayout computeFlexLayout(int intValue, int intValue2, int intValue3, int intValue4) {
      this.layoutInsets = new LayoutInsets(intValue, intValue2, intValue3, intValue4);
      return this;
   }

   public FlexLayout computeFlexLayout2(int intState2) {
      this.intState = intState2;
      return this;
   }

   private int computeIntForLayoutChild(LayoutChild layoutChild, int intValue) {
      boolean booleanValue = this.flexDirection == FlexDirection.ROW || this.flexDirection == FlexDirection.ROW_REVERSE;
      int intValue2 = booleanValue ? layoutChild.getIntState6() : layoutChild.getIntState2();
      switch (this.crossAxisAlignment) {
         case START:
            return 0;
         case END:
            return intValue - intValue2;
         case CENTER:
            return (intValue - intValue2) / 2;
         case STRETCH:
            return 0;
         default:
            return 0;
      }
   }

   public FlexLayout computeFlexLayout3(int intValue) {
      this.layoutInsets = new LayoutInsets(intValue);
      return this;
   }

   public void updateState(int intValue, int intValue2, int intValue3, int intValue4) {
      if (!this.layoutChildList.isEmpty()) {
         int intValue5 = intValue + this.layoutInsets.left();
         int intValue6 = intValue2 + this.layoutInsets.top();
         int intValue7 = intValue3 - this.layoutInsets.left() - this.layoutInsets.right();
         int intValue8 = intValue4 - this.layoutInsets.top() - this.layoutInsets.bottom();
         boolean booleanValue = this.flexDirection == FlexDirection.ROW || this.flexDirection == FlexDirection.ROW_REVERSE;
         int intValue9 = booleanValue ? intValue7 : intValue8;
         int intValue10 = booleanValue ? intValue8 : intValue7;
         int intValue11 = 0;
         int intValue12 = 0;

         for (LayoutChild layoutChild : this.layoutChildList) {
            if (booleanValue) {
               intValue11 += layoutChild.getIntState2();
            } else {
               intValue11 += layoutChild.getIntState6();
            }

            intValue12 += layoutChild.intState5;
         }

         intValue11 += this.intState * (this.layoutChildList.size() - 1);
         int intValue13 = Math.max(0, intValue9 - intValue11);
         int[] intArray = this.computeIntArray(intValue9, intValue11, intValue13);

         for (int intValue14 = 0; intValue14 < this.layoutChildList.size(); intValue14++) {
            LayoutChild layoutChild2 = this.layoutChildList.get(intValue14);
            int intValue15 = intArray[intValue14];
            int intValue16 = this.computeIntForLayoutChild(layoutChild2, intValue10);
            int intState8;
            int intState7;
            int intState2;
            int intState6;
            if (booleanValue) {
               intState8 = intValue5 + intValue15;
               intState7 = intValue6 + intValue16;
               intState2 = layoutChild2.getIntState2();
               if (layoutChild2.intState5 > 0 && intValue13 > 0) {
                  intState2 += intValue13 * layoutChild2.intState5 / intValue12;
               }

               intState6 = this.crossAxisAlignment == CrossAxisAlignment.STRETCH ? intValue10 : layoutChild2.getIntState6();
            } else {
               intState8 = intValue5 + intValue16;
               intState7 = intValue6 + intValue15;
               intState2 = this.crossAxisAlignment == CrossAxisAlignment.STRETCH ? intValue10 : layoutChild2.getIntState2();
               intState6 = layoutChild2.getIntState6();
               if (layoutChild2.intState5 > 0 && intValue13 > 0) {
                  intState6 += intValue13 * layoutChild2.intState5 / intValue12;
               }
            }

            layoutChild2.updateState(intState8, intState7, intState2, intState6);
         }
      }
   }

   private int[] computeIntArray(int intValue, int intValue2, int intValue3) {
      int[] intArray = new int[this.layoutChildList.size()];
      switch (this.mainAxisAlignment) {
         case START:
            int intValue4 = 0;

            for (int intValue5 = 0; intValue5 < this.layoutChildList.size(); intValue5++) {
               intArray[intValue5] = intValue4;
               intValue4 += (this.flexDirection == FlexDirection.ROW ? this.layoutChildList.get(intValue5).getIntState2() : this.layoutChildList.get(intValue5).getIntState6()) + this.intState;
            }
            break;
         case END:
            int intValue6 = intValue - intValue2;

            for (int intValue7 = 0; intValue7 < this.layoutChildList.size(); intValue7++) {
               intArray[intValue7] = intValue6;
               intValue6 += (this.flexDirection == FlexDirection.ROW ? this.layoutChildList.get(intValue7).getIntState2() : this.layoutChildList.get(intValue7).getIntState6()) + this.intState;
            }
            break;
         case CENTER:
            int intValue8 = (intValue - intValue2) / 2;

            for (int intValue9 = 0; intValue9 < this.layoutChildList.size(); intValue9++) {
               intArray[intValue9] = intValue8;
               intValue8 += (this.flexDirection == FlexDirection.ROW ? this.layoutChildList.get(intValue9).getIntState2() : this.layoutChildList.get(intValue9).getIntState6()) + this.intState;
            }
            break;
         case SPACE_BETWEEN:
            if (this.layoutChildList.size() == 1) {
               intArray[0] = 0;
            } else {
               int intValue10 = intValue3 / (this.layoutChildList.size() - 1);
               int intValue11 = 0;

               for (int intValue12 = 0; intValue12 < this.layoutChildList.size(); intValue12++) {
                  intArray[intValue12] = intValue11;
                  intValue11 += (this.flexDirection == FlexDirection.ROW ? this.layoutChildList.get(intValue12).getIntState2() : this.layoutChildList.get(intValue12).getIntState6()) + this.intState + intValue10;
               }
            }
            break;
         case SPACE_AROUND:
            int intValue13 = intValue3 / this.layoutChildList.size();
            int intValue14 = intValue13 / 2;

            for (int intValue15 = 0; intValue15 < this.layoutChildList.size(); intValue15++) {
               intArray[intValue15] = intValue14;
               intValue14 += (this.flexDirection == FlexDirection.ROW ? this.layoutChildList.get(intValue15).getIntState2() : this.layoutChildList.get(intValue15).getIntState6()) + this.intState + intValue13;
            }
            break;
         case SPACE_EVENLY:
            int intValue16 = intValue3 / (this.layoutChildList.size() + 1);
            int intValue162 = intValue16;

            for (int intValue18 = 0; intValue18 < this.layoutChildList.size(); intValue18++) {
               intArray[intValue18] = intValue162;
               intValue162 += (this.flexDirection == FlexDirection.ROW ? this.layoutChildList.get(intValue18).getIntState2() : this.layoutChildList.get(intValue18).getIntState6()) + this.intState + intValue16;
            }
      }

      return intArray;
   }

   public FlexLayout() {
      this.flexDirection = FlexDirection.ROW;
      this.mainAxisAlignment = MainAxisAlignment.START;
      this.crossAxisAlignment = CrossAxisAlignment.START;
      this.intState = 0;
      this.layoutInsets = new LayoutInsets(0);
   }
}
