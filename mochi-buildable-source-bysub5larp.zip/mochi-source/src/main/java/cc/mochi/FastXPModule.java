package cc.mochi;

import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.mixin.MinecraftClientAccessor;
import cc.mochi.utils.keybinding.simulation.ClickSimulator;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.ExperienceBottleItem;
import net.minecraft.item.ItemStack;

public class FastXPModule extends Module {
   private final DoubleSetting skipChanceSetting;

   private int intState;
   private final DoubleRangeSetting cPSSetting;
   private final DoubleSetting varianceSetting;
   private final ThreadLocalRandom threadLocalRandom;
   private final BooleanSetting clickSimSetting;
   private long longState;
   private final BooleanSetting offHandSetting;

   public static void setLongState(FastXPModule fastXPModule, long longState2) {
      fastXPModule.longState = longState2;
   }

   @Override
   public void onDisable() {
      this.longState = (0L);
      this.intState = 0;
      ((MinecraftClientAccessor)mc).setItemUseCooldown(4);
   }

   public static ThreadLocalRandom getThreadLocalRandom(FastXPModule fastXPModule) {
      return fastXPModule.threadLocalRandom;
   }

   @Override
   public void onEnable() {
      this.longState = 0L;
      this.intState = 0;
   }

   public static BooleanSetting getClickSimSetting(FastXPModule fastXPModule) {
      return fastXPModule.clickSimSetting;
   }

   private void updateState(double doubleValue, double doubleValue2) {
      double doubleValue3 = 1000.0 / Math.max(1.0, doubleValue2);
      double doubleValue4 = 1000.0 / Math.max(1.0, doubleValue);
      double doubleValue32 = doubleValue3;
      double doubleValue6 = this.varianceSetting.getValue() / 100.0;

      int intValue = 0;

      do {
         double doubleValue7 = doubleValue3 + (doubleValue4 - doubleValue3) * getThreadLocalRandom(this).nextDouble();
         double doubleValue8 = doubleValue7 * doubleValue6;
         double doubleValue9 = this.threadLocalRandom.nextDouble() * 2.0;

         double doubleValue10 = doubleValue8 * (doubleValue9 - (1.0));
         doubleValue32 = Math.max(doubleValue32, Math.max(doubleValue3, Math.min(doubleValue4, doubleValue7 + doubleValue10)));
         intValue++;
      } while (intValue < 3);

      this.updateState2(doubleValue32);
      this.updateState3();
      if (getClickSimSetting(this).isOn()) {
         ThreadLocalRandom.current().nextInt(10);
         ClickSimulator.tapRight();
      } else {
         ((MinecraftClientAccessor)mc).invokeDoItemUse();
      }
   }

   private void updateState2(double doubleValue) {
      long longValue;

      double doubleValue2 = doubleValue * (0.12);
      double doubleValue3 = getThreadLocalRandom(this).nextDouble() * 2.0;

      long longValue2 = (long)(doubleValue2 * (doubleValue3 - (1.0)));
      longValue = System.currentTimeMillis();

      this.longState = longValue + (long)Math.max((24.0), doubleValue + (double)longValue2);
   }

   private void updateState3() {
      double lowerValue2 = this.cPSSetting.getLowerValue2();
      double upperValue3 = getCPSSetting(this).getUpperValue3();
      int intValue = 4;

      if (upperValue3 > (0.0)) {
         double doubleValue = lowerValue2 + (upperValue3 - lowerValue2) * getThreadLocalRandom(this).nextDouble();
         int intValue2 = (int)Math.floor(1000.0 / Math.max(1.0, doubleValue) / 50.0);

         intValue = Math.max(0, Math.min(4, intValue2 - 1));
      }

      ((MinecraftClientAccessor)mc).setItemUseCooldown(intValue);
   }

   public static long getLongState(FastXPModule fastXPModule) {
      return fastXPModule.longState;
   }

   public FastXPModule() {
      super("Fast XP", "Throws XP bottles at randomized CPS while holding use", ModuleCategory.PLAYER);

      this.cPSSetting = new DoubleRangeSetting("CPS", (0.0), (20.0), (10.0), (15.0), 1.0);

      this.varianceSetting = new DoubleSetting("Variance", 0.0, 80.0, (15.0), (1.0));
      this.skipChanceSetting = new DoubleSetting("Skip Chance", 0.0, 30.0, 3.0, 1.0);
      this.clickSimSetting = new BooleanSetting("Click Sim", false);

      this.offHandSetting = new BooleanSetting("Off Hand", true);
      this.threadLocalRandom = ThreadLocalRandom.current();
      this.addSetting(this.cPSSetting);
      this.addSetting(this.varianceSetting);
      this.addSetting(this.skipChanceSetting);
      this.addSetting(this.clickSimSetting);
      this.addSetting(this.offHandSetting);
   }

   public static DoubleRangeSetting getCPSSetting(FastXPModule fastXPModule) {
      return fastXPModule.cPSSetting;
   }

   @EventHandler
   private void onTickEvent(TickEvent tickEvent) {
      if (cc.mochi.MinecraftClientAccess33.getPlayer(mc) != null) {
         if (cc.mochi.MinecraftClientAccess33.getOptions(mc) != null) {
            if (mc.options.useKey.isPressed()) {
               if (cc.mochi.MinecraftClientAccess33.getCurrentScreen(mc) == null) {
                  if (!this.checkCondition()) {
                     ItemStack mainHandStack = cc.mochi.MinecraftClientAccess33.getPlayer(mc).getMainHandStack();
                     ItemStack offHandStack = mc.player.getOffHandStack();
                     boolean booleanValue = mainHandStack.getItem() instanceof ExperienceBottleItem;
                     boolean booleanValue2 = offHandStack.getItem() instanceof ExperienceBottleItem;
                     if (!booleanValue) {
                        if (!this.offHandSetting.isOn() || !booleanValue2) {
                           this.longState = (0L);
                           setIntState(this, 0);
                           return;
                        }
                     }

                     long longValue = System.currentTimeMillis();
                     if (longValue < getLongState(this)) {
                        return;
                     }

                     if (this.intState > 0) {
                        this.intState--;

                        this.updateState2((0.0));
                        return;
                     }

                     double lowerValue2 = this.cPSSetting.getLowerValue2();
                     double upperValue3 = this.cPSSetting.getUpperValue3();
                     if (upperValue3 <= 0.0) {
                        setLongState(this, Long.MAX_VALUE);
                        return;
                     }

                     this.updateState(lowerValue2, upperValue3);
                     int intValue = (int)Math.round(this.skipChanceSetting.getValue());
                     if (intValue > 0) {
                        ThreadLocalRandom threadLocalRandom2 = getThreadLocalRandom(this);

                        if (threadLocalRandom2.nextInt(100) < intValue) {
                           this.intState = 1 + this.threadLocalRandom.nextInt(2);
                        }
                     }

                     return;
                  }
               }
            }
         }
      }

      setLongState(this, (0L));
   }

   private boolean checkCondition() {
      if (!cc.mochi.MinecraftClientAccess33.getOptions(mc).attackKey.isPressed()) {
         if (!cc.mochi.MinecraftClientAccess33.getPlayer(mc).isBlocking()) {
            if (!mc.player.isUsingItem()) {
               ThreadLocalRandom.current().nextInt(3);
               if (!cc.mochi.MinecraftClientAccess33.getPlayer(mc).isSprinting()) {
                  if (!cc.mochi.MinecraftClientAccess33.getPlayer(mc).isSneaking()) {
                     return false;
                  }
               }
            }
         }
      }

      return true;
   }

   public static void setIntState(FastXPModule fastXPModule, int intState2) {
      fastXPModule.intState = intState2;
   }
}
