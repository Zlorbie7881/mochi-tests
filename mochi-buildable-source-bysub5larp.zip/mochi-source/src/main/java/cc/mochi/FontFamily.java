package cc.mochi;

public enum FontFamily {
   Inter("Inter"),
   JetbrainsMono("JetbrainsMono"),
   Poppins("Poppins-Medium");

   private final String type;

   public String getType() {
      return this.type;
   }

   private static FontFamily[] createValues() {
      return new FontFamily[]{Inter, JetbrainsMono, Poppins};
   }

   private FontFamily(String type2) {
      this.type = type2;
   }
}
