package cc.mochi;

import java.awt.Color;
import net.minecraft.item.ItemStack;

public final class HotbarPatternEditor {
   private static final Color color = new Color(255, 168, 72);

   private static Rect computeRect(float floatValue, float floatValue2, float floatValue3, String string) {
      float floatValue4 = max(string);
      return new Rect(floatValue + floatValue3 - floatValue4, computeFloat(floatValue2, string), floatValue4, 11.0F);
   }

   public static int computeInt(float floatValue, float floatValue2, float floatValue3, boolean booleanValue, double pointX, double pointY, String string) {
      if (computeRect(floatValue, floatValue2, floatValue3, string).contains(pointX, pointY)) {
         return 1;
      } else {
         return booleanValue && computeRect2(floatValue, floatValue2, floatValue3, string).contains(pointX, pointY) ? 2 : 0;
      }
   }

   private static void updateStateForHotbarPatternSetting(HotbarPatternSetting hotbarPatternSetting) {
      if (HotbarPatternCapture.testHotbarPatternSetting(hotbarPatternSetting)) {
         ClientSounds.updateState4();
      }
   }

   public static void updateStateForUiContext(UiContext uiContext, String string, HotbarPatternSetting hotbarPatternSetting, float floatValue, float floatValue2, float floatValue3, UiLayer uiLayer, Rect rect, float floatValue4, boolean booleanValue) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      String string2 = hotbarPatternSetting.getString();
      boolean patterns = hotbarPatternSetting.hasPatterns();
      updateStateForUiContext2(uiContext, string + ".import", computeRect(floatValue, floatValue2, floatValue3, string2), string2 == null ? "Import" : string2, true, uiLayer, rect, floatValue4, () -> updateStateForHotbarPatternSetting(hotbarPatternSetting));
      if (patterns) {
         updateStateForUiContext2(uiContext, string + ".clear", computeRect2(floatValue, floatValue2, floatValue3, string2), "Clear", false, uiLayer, rect, floatValue4, () -> updateStateForHotbarPatternSetting2(hotbarPatternSetting));
      }

      float floatValue5 = computeFloat4(floatValue3);
      float floatValue6 = floatValue5 * 9.0F + 20.0F;
      float floatValue7 = floatValue + (floatValue3 - floatValue6) / 2.0F;
      float y = floatValue2 + 2.5F + 15.0F * (float)(checkCondition(string2) ? 2 : 1);
      float radius = Math.min(5.0F, floatValue5 * 0.24F);
      float floatValue10 = Math.max(1.5F, floatValue5 * 0.1F);
      ItemStack[] itemStackArray = HotbarPatternCapture.computeItemStackArrayForHotbarPatternSetting(hotbarPatternSetting);
      AnchorAvailability[] anchorAvailabilityArray = HotbarPatternCapture.computeAnchorAvailabilityArrayForHotbarPatternSetting(hotbarPatternSetting);
      Color color2 = ThemeSnapshot.computeColorForColor(themeSnapshot2.getAccent2());

      for (int intValue = 0; intValue < 9; intValue++) {
         float x = floatValue7 + (float)intValue * (floatValue5 + 2.5F);
         AnchorAvailability anchorAvailability = anchorAvailabilityArray != null && intValue < anchorAvailabilityArray.length ? anchorAvailabilityArray[intValue] : AnchorAvailability.EMPTY;
         Color color3;
         Color hairline2;
         switch (getIntArray()[anchorAvailability.ordinal()]) {
            case 1:
               color3 = UiRenderContext.multiplyAlpha(color2, 0.16F);
               hairline2 = UiRenderContext.multiplyAlpha(color2, 0.85F);
               break;
            case 2:
               color3 = UiRenderContext.withAlpha(getColor(), 38.0F);
               hairline2 = UiRenderContext.withAlpha(getColor(), 215.0F);
               break;
            case 3:
               color3 = themeSnapshot2.getSurfaceRaised();
               hairline2 = themeSnapshot2.getHairline2();
               break;
            default:
               color3 = themeSnapshot2.getSurfaceSunken();
               hairline2 = UiRenderContext.multiplyAlpha(themeSnapshot2.getHairline2(), 0.6F);
         }

         uiContext.getUiRenderContext().fillRoundedRect(x, y, floatValue5, floatValue5, radius, UiContext.multiplyAlpha(color3, floatValue4));
         uiContext.getUiRenderContext().strokeRoundedRect(x, y, floatValue5, floatValue5, radius, 1.0F, UiContext.multiplyAlpha(hairline2, floatValue4));
         ItemStack itemStack = itemStackArray != null && intValue < itemStackArray.length ? itemStackArray[intValue] : ItemStack.EMPTY;
         if (booleanValue && floatValue4 > 0.95F && itemStack != null && !itemStack.isEmpty()) {
            uiContext.getUiRenderContext().drawItemStack(itemStack, x + floatValue10, y + floatValue10, floatValue5 - floatValue10 * 2.0F);
         } else {
            uiContext.drawCenteredText(String.valueOf(intValue + 1), x + floatValue5 / 2.0F, y + floatValue5 / 2.0F, TextStyle.CAPTION, UiContext.multiplyAlpha(themeSnapshot2.getDisabledText2(), floatValue4));
         }
      }
   }

   private static void updateStateForHotbarPatternSetting2(HotbarPatternSetting hotbarPatternSetting) {
      hotbarPatternSetting.clear();
      ClientSounds.updateState5();
   }

   private static Rect computeRect2(float floatValue, float floatValue2, float floatValue3, String string) {
      Rect rect = computeRect(floatValue, floatValue2, floatValue3, string);
      return new Rect(rect.getX() - 4.0F - 31.0F, rect.getY(), 31.0F, 11.0F);
   }

   public static Color getColor() {
      return color;
   }

   private static float max(String string) {
      return Math.max(38.0F, (float)(string == null ? 6 : string.length()) * 4.2F + 12.0F);
   }

   private HotbarPatternEditor() {
   }

   private static float computeFloat(float floatValue, String string) {
      return floatValue + 2.5F + (checkCondition(string) ? 15.0F : 0.0F) + 2.0F;
   }

   private static void updateStateForUiContext2(UiContext uiContext, String string, Rect rect, String text, boolean booleanValue, UiLayer uiLayer, Rect rect2, float floatValue, Runnable runnable) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      Rect rect3 = rect.intersection(rect2);
      float progress = uiContext.animateHover(string, uiContext.isHovered(rect3, uiLayer));
      Color color2 = ThemeSnapshot.computeColorForColor(themeSnapshot2.getAccent2());
      Color color3 = booleanValue ? UiRenderContext.multiplyAlpha(color2, 0.28F + 0.14F * progress) : UiContext.blendColors(themeSnapshot2.getSurfaceSunken(), themeSnapshot2.getSurfaceRaised(), progress);
      Color color4 = booleanValue ? UiRenderContext.multiplyAlpha(color2, 0.75F + 0.25F * progress) : UiContext.blendColors(themeSnapshot2.getHairline2(), themeSnapshot2.getAccent2(), 0.4F * progress);
      float radius = rect.getHeight() / 2.0F;
      uiContext.getUiRenderContext().fillRoundedRect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), radius, UiContext.multiplyAlpha(color3, floatValue));
      uiContext.getUiRenderContext().strokeRoundedRect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), radius, 0.75F, UiContext.multiplyAlpha(color4, floatValue));
      uiContext.drawCenteredText(text, rect.centerX(), rect.centerY(), TextStyle.CAPTION, UiContext.multiplyAlpha(booleanValue ? themeSnapshot2.getPrimaryText() : UiContext.blendColors(themeSnapshot2.getSecondaryText2(), themeSnapshot2.getPrimaryText(), progress), floatValue));
      uiContext.getInputRouter().addClickRegion(rect3, uiLayer, runnable);
   }

   private static boolean checkCondition(String string) {
      return string != null && !"Import".equals(string);
   }

   public static float computeFloat2(float floatValue, String string) {
      return 2.5F + 15.0F * (float)(checkCondition(string) ? 2 : 1) + computeFloat4(floatValue) + 6.0F;
   }

   public static float computeFloat3(String string, boolean booleanValue) {
      return checkCondition(string) ? 0.0F : max(string) + (booleanValue ? 35.0F : 0.0F);
   }

   public static float computeFloat4(float floatValue) {
      float floatValue2 = (floatValue - 20.0F) / 9.0F;
      return Math.max(12.0F, Math.min(24.0F, floatValue2));
   }

   public static int[] getIntArray() {
      return AnchorAvailabilitySwitchMap.intArray;
   }
}
