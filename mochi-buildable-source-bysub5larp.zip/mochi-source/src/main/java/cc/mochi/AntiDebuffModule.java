package cc.mochi;

import cc.mochi.event.impl.player.TickEvent;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.network.ClientPlayerEntity;

public class AntiDebuffModule extends Module {
   private static AntiDebuffModule antiDebuffModule;

   public static boolean checkCondition() {
      AntiDebuffModule antiDebuffModule2 = antiDebuffModule;
      return antiDebuffModule2 != null && antiDebuffModule2.isEnabled();
   }

   @EventHandler
   private void onTickEvent(TickEvent tickEvent) {
      if (!this.isWorldUnavailable()) {
         ClientPlayerEntity player = mc.player;
         if (player instanceof ClientPlayerEntity) {
            player.nauseaIntensity = 0.0F;
            player.lastNauseaIntensity = 0.0F;
            return;
         }
      }
   }

   public AntiDebuffModule() {
      super("Anti Debuff", "Removes blindness darkness and nausea visuals.", ModuleCategory.RENDER);
      antiDebuffModule = this;
   }
}
