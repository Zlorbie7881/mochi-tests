package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;

public class MinecraftClientAccess12 {
   public static GameOptions getOptions(MinecraftClient minecraftClient) {
      return minecraftClient.options;
   }

   public static KeyBinding getForwardKey(GameOptions gameOptions) {
      return gameOptions.forwardKey;
   }

   public static KeyBinding getLeftKey(GameOptions gameOptions) {
      return gameOptions.leftKey;
   }

   public static KeyBinding getSprintKey(GameOptions gameOptions) {
      return gameOptions.sprintKey;
   }

   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static KeyBinding getRightKey(GameOptions gameOptions) {
      return gameOptions.rightKey;
   }

}
