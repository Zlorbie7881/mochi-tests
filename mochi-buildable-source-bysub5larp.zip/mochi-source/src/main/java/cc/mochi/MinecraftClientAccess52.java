package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult.SwingSource;
import net.minecraft.util.math.Vec3d;

public class MinecraftClientAccess52 {
   public static ClientWorld getWorld(MinecraftClient minecraftClient) {
      return minecraftClient.world;
   }

   public static Item getWIND_CHARGE() {
      return Items.WIND_CHARGE;
   }

   public static double getY(Vec3d vec3d) {
      return vec3d.y;
   }

   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static double getZ(Vec3d vec3d) {
      return vec3d.z;
   }

   public static ClientPlayerInteractionManager getInteractionManager(MinecraftClient minecraftClient) {
      return minecraftClient.interactionManager;
   }

   public static double getX(Vec3d vec3d) {
      return vec3d.x;
   }

   public static SwingSource getCLIENT() {
      return SwingSource.CLIENT;
   }

}
