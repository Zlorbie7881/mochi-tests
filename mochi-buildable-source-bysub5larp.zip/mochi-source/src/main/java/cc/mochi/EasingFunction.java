package cc.mochi;

@FunctionalInterface
public interface EasingFunction {
   float apply(float floatValue);
}
