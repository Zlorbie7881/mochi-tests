package cc.mochi;

import cc.mochi.event.impl.player.TickEvent;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Supplier;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.MaceItem;
import net.minecraft.item.TridentItem;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class AimAssistModule extends Module {
   private final ChoiceSetting stopModeSetting;

   private double doubleState;

   private double doubleState2;
   private final BooleanSetting targetModeSetting;

   private final DoubleSetting predictionTimeMsSetting;

   private final DoubleSetting randomnessSetting;
   private final BooleanSetting onlyWeaponSetting;
   private final BooleanSetting visibleOnlySetting;

   private long longState;

   private final DoubleSetting hitboxPaddingSetting;
   private final CombatTargetTracker combatTargetTracker;
   private final BooleanSetting playersOnlySetting;
   private final DoubleSetting switchDelayMsSetting;

   private double doubleState3;

   private long timestampMillis;

   private long deadlineMillis;

   private final HumanizedDelay humanizedDelay;

   private Entity entity;

   private final DoubleSetting fOVSetting;

   private double doubleState4;

   private Entity entity2;

   private final DoubleSetting distanceSetting;

   private final DoubleSetting strengthSetting;

   private final BooleanSetting booleanSetting;

   private double doubleState5;

   private final DoubleSetting smoothingSetting;

   private final HumanizedRandom humanizedRandom;

   private long timestampMillis2;

   private double doubleState6;

   private final BooleanSetting predictionSetting;
   private final BooleanSetting silentAimSetting;

   private final ChoiceSetting aimPointSetting;

   private final BooleanSetting verticalRotationSetting;

   private void updateState() {
      if (getBooleanSetting(this).isOn()) {
         ThreadLocalRandom.current().nextInt(9);
         CombatTargetTracker combatTargetTracker2 = getCombatTargetTracker(this);

         LivingEntity entity23 = combatTargetTracker2.computeLivingEntityForLivingEntity3(null, true);
         if (entity23 != null && this.testEntity2(entity23, true)) {
            this.updateStateForEntity2(entity23);
            return;
         }
      } else {
         if (this.combatTargetTracker.checkCondition2()) {
            getCombatTargetTracker(this).updateState();
         }
      }

      Object entity22 = null;
      double value = getFOVSetting(this).getValue();
      if (this.entity2 != null) {
         if (this.testEntity2(this.entity2, false)) {
            entity22 = this.entity2;
            value = this.computeDoubleForEntity(getEntity2(this));
         }
      }

      if ((double)(System.currentTimeMillis() - getLongState(this)) > getSwitchDelayMsSetting(this).getValue()) {
         for (Entity entity3 : MinecraftClientAccess20.getWorld(mc).getEntities()) {
            if (entity3 != getEntity2(this)) {
               if (this.testEntity2(entity3, false)) {
                  double doubleValue;
                  if ((doubleValue = this.computeDoubleForEntity(entity3)) < value) {
                     entity22 = entity3;
                     value = doubleValue;
                  }
               }
            }
         }
      }

      if (getBooleanSetting(this).isOn() && entity22 instanceof LivingEntity var13) {
         LivingEntity livingEntity2 = this.combatTargetTracker.computeLivingEntityForLivingEntity3(var13, true);
         if (livingEntity2 != null) {
            entity22 = livingEntity2;
         }
      }

      this.updateStateForEntity2((Entity)entity22);
   }

   public static HumanizedRandom getHumanizedRandom(AimAssistModule aimAssistModule) {
      return aimAssistModule.humanizedRandom;
   }

   private Vec3d computeVec3d() {
      return this.computeVec3dForEntity(getEntity2(this));
   }

   private boolean checkCondition() {
      if (mc.player == null) {
         return false;
      } else {
         ItemStack mainHandStack = mc.player.getMainHandStack();
         if (!mainHandStack.isIn(MinecraftClientAccess20.getSWORDS()) && !mainHandStack.isIn(ItemTags.AXES)) {
            if (!(mainHandStack.getItem() instanceof MaceItem)) {
               if (!(mainHandStack.getItem() instanceof TridentItem)) {
                  ThreadLocalRandom.current().nextInt(7);
                  return false;
               }
            }
         }

         return true;
      }
   }

   public static CombatTargetTracker getCombatTargetTracker(AimAssistModule aimAssistModule) {
      return aimAssistModule.combatTargetTracker;
   }

   public static long getTimestampMillis2(AimAssistModule aimAssistModule) {
      return aimAssistModule.timestampMillis2;
   }

   private void updateStateForEntity(Entity entity3) {
      long timestampMillis22 = System.currentTimeMillis();
      if (this.entity != entity3) {
         this.entity = entity3;
         this.updateStateForEntity3(entity3);
         this.doubleState6 = this.doubleState3;
         this.doubleState = this.doubleState5;
         this.doubleState2 = this.doubleState4;
         this.timestampMillis2 = timestampMillis22;
         HumanizedRandom humanizedRandom2 = this.humanizedRandom;

         setDeadlineMillis(this, timestampMillis22 + humanizedRandom2.computeLong(3000L, (2000L), 4000L));
      } else {
         if (timestampMillis22 >= getDeadlineMillis(this)) {
            this.updateStateForEntity3(entity3);
            HumanizedRandom humanizedRandom3 = getHumanizedRandom(this);

            this.deadlineMillis = timestampMillis22 + humanizedRandom3.computeLong((3000L), 2000L, 4000L);
         }

         ThreadLocalRandom.current().nextInt(8);

         double doubleValue = (double)Math.max((0L), timestampMillis22 - getTimestampMillis2(this));

         double doubleValue2 = -doubleValue;

         double doubleValue3 = (1.0) - Math.exp(doubleValue2 / (3000.0));
         setDoubleState6(this, this.doubleState6 + (getDoubleState3(this) - getDoubleState6(this)) * doubleValue3);
         this.doubleState = getDoubleState(this) + (this.doubleState5 - this.doubleState) * doubleValue3;
         setDoubleState2(this, getDoubleState2(this) + (this.doubleState4 - getDoubleState2(this)) * doubleValue3);
         setTimestampMillis2(this, timestampMillis22);
      }
   }

   public static DoubleSetting getFOVSetting(AimAssistModule aimAssistModule) {
      return aimAssistModule.fOVSetting;
   }

   public static Entity getEntity2(AimAssistModule aimAssistModule) {
      return aimAssistModule.entity2;
   }

   public static void setDoubleState2(AimAssistModule aimAssistModule, double doubleState22) {
      aimAssistModule.doubleState2 = doubleState22;
   }

   public static BooleanSetting getBooleanSetting(AimAssistModule aimAssistModule) {
      return aimAssistModule.booleanSetting;
   }

   public static void setDeadlineMillis(AimAssistModule aimAssistModule, long deadlineMillis2) {
      aimAssistModule.deadlineMillis = deadlineMillis2;
   }

   private boolean testEntity(Entity entity3) {
      if (MinecraftClientAccess20.getPlayer(mc) == null) {
         return false;
      } else {
         Vec3d eyePos = mc.player.getEyePos();
         Vec3d rotationVec = MinecraftClientAccess20.getPlayer(mc).getRotationVec(1.0F);
         double value = this.distanceSetting.getValue();
         Vec3d vec3d = eyePos.add(rotationVec.multiply(value));
         Box box = entity3.getBoundingBox().expand(this.hitboxPaddingSetting.getValue());
         return box.raycast(eyePos, vec3d).isPresent();
      }
   }

   private boolean testEntity2(Entity entity3, boolean booleanValue) {
      if (entity3 instanceof LivingEntity) {
         if (entity3 != mc.player && entity3.isAlive()) {
            if (entity3 instanceof PlayerEntity var3) {
               if (FriendManager.testPlayerEntity(var3)) {
                  return false;
               }
            }

            if ((double)MinecraftClientAccess20.getPlayer(mc).distanceTo(entity3) > this.distanceSetting.getValue()) {
               return false;
            }

            if (this.playersOnlySetting.isOn()) {
               if (!(entity3 instanceof PlayerEntity)) {
                  ThreadLocalRandom.current().nextInt(10);

                  return false;
               }
            } else {
               ThreadLocalRandom.current().nextInt(13);
            }

            if (this.visibleOnlySetting.isOn()) {
               ThreadLocalRandom.current().nextInt(10);

               if (!MinecraftClientAccess20.getPlayer(mc).canSee(entity3)) {
                  return false;
               }
            }

            if (getTargetModeSetting(this).isOn()) {
               if (!this.testEntity4(entity3)) {
                  return false;
               }
            }

            if (booleanValue) {
               return true;
            }

            return ((this.computeDoubleForEntity(entity3) <= this.fOVSetting.getValue() ? 1 : 0) != 0);
         }
      } else {
         ThreadLocalRandom.current().nextInt(4);
      }

      return false;
   }

   public static HumanizedDelay getHumanizedDelay(AimAssistModule aimAssistModule) {
      return aimAssistModule.humanizedDelay;
   }

   public static void setLongState(AimAssistModule aimAssistModule, long longState2) {
      aimAssistModule.longState = longState2;
   }

   public static void setDoubleState6(AimAssistModule aimAssistModule, double doubleState62) {
      aimAssistModule.doubleState6 = doubleState62;
   }

   public static BooleanSetting getTargetModeSetting(AimAssistModule aimAssistModule) {
      return aimAssistModule.targetModeSetting;
   }

   @Override
   public void onDisable() {
      RotationManager.updateState(this);
      setEntity2(this, null);
      setEntity(this, null);

      this.timestampMillis = (0L);
      getCombatTargetTracker(this).updateState();
   }

   public static void setEntity(AimAssistModule aimAssistModule, Entity entity3) {
      aimAssistModule.entity = entity3;
   }

   public static double getDoubleState6(AimAssistModule aimAssistModule) {
      return aimAssistModule.doubleState6;
   }

   public static void setTimestampMillis2(AimAssistModule aimAssistModule, long timestampMillis22) {
      aimAssistModule.timestampMillis2 = timestampMillis22;
   }

   private boolean testEntity3(Entity entity3) {
      byte byteValue = 19;
      ThreadLocalRandom.current().nextInt(11);
      HitResult crosshairTarget2 = MinecraftClientAccess20.getCrosshairTarget(mc);
      if (crosshairTarget2 instanceof EntityHitResult) {
         EntityHitResult crosshairTarget22 = (EntityHitResult)crosshairTarget2;
         if (crosshairTarget22.getEntity() == entity3) {
            byteValue = 20;
            ThreadLocalRandom.current().nextInt(15);
            byteValue = 1;
         } else {
            byteValue = 0;
         }

         return (byteValue != 0);
      } else {
         return false;
      }
   }

   private void updateStateForEntity2(Entity entity22) {
      if (entity22 == getEntity2(this)) {
         ThreadLocalRandom.current().nextInt(10);

         ThreadLocalRandom.current().nextInt(15);
      } else {
         ThreadLocalRandom.current().nextInt(4);
         setLongState(this, System.currentTimeMillis());
         this.entity2 = entity22;
         RotationManager.updateState10(this);
         this.entity = null;
      }
   }

   public static double getDoubleState3(AimAssistModule aimAssistModule) {
      return aimAssistModule.doubleState3;
   }

   private double computeDoubleForEntity(Entity entity3) {
      Vec3d eyePos = MinecraftClientAccess20.getPlayer(mc).getEyePos();
      Vec3d center = entity3.getBoundingBox().getCenter();
      double doubleValue = MinecraftClientAccess20.getX(center) - eyePos.x;
      double doubleValue2 = center.z - MinecraftClientAccess20.getZ(eyePos);
      float floatValue = (float)Math.toDegrees(Math.atan2(doubleValue2, doubleValue)) - 90.0F;
      return (double)Math.abs(MathHelper.wrapDegrees(mc.player.getYaw() - floatValue));
   }

   public static DoubleSetting getPredictionTimeMsSetting(AimAssistModule aimAssistModule) {
      return aimAssistModule.predictionTimeMsSetting;
   }

   private Boolean computeBoolean() {
      byte byteValue;
      label28: {
         if (!this.stopModeSetting.equals("Exact Center")) {
            if (!this.stopModeSetting.equals("Off")) {
               byteValue = 0;

               ThreadLocalRandom.current().nextInt(15);
               break label28;
            }

            byteValue = 18;
            ThreadLocalRandom.current().nextInt(14);
         }

         byteValue = 1;
      }

      ThreadLocalRandom.current().nextInt(12);
      return Boolean.valueOf((byteValue != 0));
   }

   public static long getLongState(AimAssistModule aimAssistModule) {
      return aimAssistModule.longState;
   }

   public AimAssistModule() {
      super("Aim Assist", "Glides your crosshair toward your target.", ModuleCategory.COMBAT);

      this.strengthSetting = new DoubleSetting("Strength", 0.0, (40.0), 5.0, (1.0));

      this.smoothingSetting = new DoubleSetting("Smoothing", (0.0), 100.0, 60.0, (1.0));

      this.randomnessSetting = new DoubleSetting("Randomness", (1.0), (100.0), 35.0, (1.0));
      this.predictionSetting = new BooleanSetting("Prediction", true);

      this.predictionTimeMsSetting = new DoubleSetting("Prediction Time (ms)", (0.0), 300.0, (120.0), (5.0));

      String[] stringArray = new String[3];

      stringArray[0] = "Hitbox Edge";

      stringArray[1] = "Off";
      stringArray[2] = "Exact Center";
      this.stopModeSetting = new ChoiceSetting("Stop Mode", "Hitbox Edge", stringArray);
      this.aimPointSetting = new ChoiceSetting("Aim Point", "Center", "Head", "Center", "Legs");

      this.hitboxPaddingSetting = new DoubleSetting("Hitbox Padding", ((-0.5)), 0.0, 0.0, (0.01));

      this.distanceSetting = new DoubleSetting("Distance", 3.0, (8.0), (4.5), 0.1);

      this.fOVSetting = new DoubleSetting("FOV", (10.0), (180.0), 90.0, (1.0));
      this.verticalRotationSetting = new BooleanSetting("Vertical rotation", false);
      this.silentAimSetting = new BooleanSetting("Silent aim", false);

      this.visibleOnlySetting = new BooleanSetting("Visible Only", true);

      this.switchDelayMsSetting = new DoubleSetting("Switch Delay (ms)", (0.0), (1000.0), 200.0, (1.0));
      this.playersOnlySetting = new BooleanSetting("Players Only", true);
      this.onlyWeaponSetting = new BooleanSetting("Only Weapon", true);
      this.targetModeSetting = new BooleanSetting("Target Mode", false);
      this.booleanSetting = CombatTargetTracker.createBooleanSetting();
      this.combatTargetTracker = new CombatTargetTracker();
      this.entity2 = null;
      this.longState = 0L;

      this.timestampMillis = (0L);
      this.humanizedRandom = new HumanizedRandom();

      this.humanizedDelay = new HumanizedDelay(100);
      this.addSetting(this.strengthSetting);
      this.addSetting(this.smoothingSetting);
      this.addSetting(this.randomnessSetting);
      this.addSetting(this.predictionSetting);
      this.predictionTimeMsSetting.setVisibility(() -> this.predictionSetting.isOn());
      this.addSetting(this.predictionTimeMsSetting);
      this.addSetting(this.stopModeSetting);
      this.aimPointSetting.setVisibility(() -> this.computeBoolean());
      this.addSetting(this.aimPointSetting);
      this.addSetting(this.hitboxPaddingSetting);
      this.addSetting(this.distanceSetting);
      this.addSetting(this.fOVSetting);
      this.addSetting(this.verticalRotationSetting);
      this.addSetting(this.silentAimSetting);
      this.addSetting(this.visibleOnlySetting);
      this.addSetting(this.switchDelayMsSetting);
      this.addSetting(this.playersOnlySetting);
      this.addSetting(this.onlyWeaponSetting);
      this.addSetting(this.targetModeSetting);
      this.addSetting(this.booleanSetting);
   }

   public static void setEntity2(AimAssistModule aimAssistModule, Entity entity22) {
      aimAssistModule.entity2 = entity22;
   }

   public static BooleanSetting getVerticalRotationSetting(AimAssistModule aimAssistModule) {
      return aimAssistModule.verticalRotationSetting;
   }

   public static long getDeadlineMillis(AimAssistModule aimAssistModule) {
      return aimAssistModule.deadlineMillis;
   }

   @EventHandler
   private void onTickEvent(TickEvent tickEvent) {
      if (this.isEnabled()) {
         label105:
         if (MinecraftClientAccess20.getWorld(mc) != null && mc.player != null && MinecraftClientAccess20.getCurrentScreen(mc) == null) {
            if (this.onlyWeaponSetting.isOn()) {
               if (!this.checkCondition()) {
                  break label105;
               }
            }

            this.updateState();
            if (getEntity2(this) != null) {
               String selected;
               byte byteValue;
               label92: {
                  label112: {
                     selected = this.stopModeSetting.getSelected();
                     if (selected.equals("Exact Center")) {
                        if (this.testEntity3(this.entity2)) {
                           break label112;
                        }
                     }

                     if (selected.equals("Hitbox Edge")) {
                        if (this.testEntity(getEntity2(this))) {
                           break label112;
                        }
                     }

                     byteValue = 0;
                     break label92;
                  }

                  byteValue = 1;
               }

               byte byteValue2 = byteValue;
               if (byteValue2 != 0) {
                  this.timestampMillis = System.currentTimeMillis();
                  RotationManager.updateState9(this);
                  return;
               }

               if (!selected.equals("Off")) {
                  long longValue = System.currentTimeMillis() - this.timestampMillis;

                  if (longValue < 150L) {
                     RotationManager.updateState9(this);
                     return;
                  }
               }

               Supplier supplier = () -> this.computeVec3d();
               RotationManager.updateStateForActionPriority(this, ActionPriority.LOW, supplier, this.computeRotationProfile(!getVerticalRotationSetting(this).isOn()));
            } else {
               RotationManager.updateState9(this);
            }

            return;
         }

         RotationManager.updateState9(this);
      }
   }

   public static DoubleSetting getStrengthSetting(AimAssistModule aimAssistModule) {
      return aimAssistModule.strengthSetting;
   }

   private RotationProfile computeRotationProfile(boolean booleanState3) {
      RotationProfile rotationProfile = RotationProfile.createRotationProfile();
      double value = getStrengthSetting(this).getValue();

      rotationProfile = rotationProfile.withMaxRotationSpeed(value * (40.0));
      double value2 = this.smoothingSetting.getValue();

      rotationProfile = rotationProfile.computeRotationProfile10(0.1 + (1.0 - value2 / (100.0)) * 0.9).computeRotationProfile4(MathUtils.computeDouble6((int)Math.round(this.randomnessSetting.getValue())));

      rotationProfile = rotationProfile.computeRotationProfile3((0.0));

      value = (45.0);

      return rotationProfile.computeRotationProfile9(MathUtils.computeLong3((45.0), (140.0))).withSilentAim(this.silentAimSetting.isOn()).computeRotationProfile2(booleanState3);
   }

   public static double getDoubleState2(AimAssistModule aimAssistModule) {
      return aimAssistModule.doubleState2;
   }

   public static DoubleSetting getRandomnessSetting(AimAssistModule aimAssistModule) {
      return aimAssistModule.randomnessSetting;
   }

   private void updateStateForEntity3(Entity entity3) {
      Box boundingBox = entity3.getBoundingBox();
      double doubleValue = Math.max(boundingBox.getLengthX(), boundingBox.getLengthZ());
      double lengthY = boundingBox.getLengthY();
      double doubleValue2 = MathUtils.computeDouble6((int)Math.round(getRandomnessSetting(this).getValue()));
      long longValue = System.currentTimeMillis();
      this.doubleState3 = getHumanizedDelay(this).computeDouble(longValue) * doubleValue * 0.1 * doubleValue2;
      HumanizedDelay humanizedDelay2 = getHumanizedDelay(this);

      double doubleValue3 = humanizedDelay2.computeDouble(longValue + 1301L) * lengthY;

      this.doubleState5 = doubleValue3 * (0.15) * doubleValue2;

      this.doubleState4 = this.humanizedDelay.computeDouble(longValue + 2711L) * doubleValue * 0.1 * doubleValue2;
   }

   private double computeDoubleForVec3d(Vec3d vec3d) {
      float[] floatArray = RotationManager.computeFloatArrayForVec3d(vec3d, RotationManager.computeFloat2());
      double doubleValue = (double)Math.abs(RotationMath.wrapDegrees(RotationManager.computeFloat2(), floatArray[0]));
      return doubleValue / Math.max(1.0, this.strengthSetting.getValue() * 40.0);
   }

   public static double getDoubleState(AimAssistModule aimAssistModule) {
      return aimAssistModule.doubleState;
   }

   public static DoubleSetting getSwitchDelayMsSetting(AimAssistModule aimAssistModule) {
      return aimAssistModule.switchDelayMsSetting;
   }

   private Vec3d computeVec3dForEntity(Entity entity3) {
      this.updateStateForEntity(entity3);
      double doubleValue;
      if (this.stopModeSetting.equals("Hitbox Edge")) {
         doubleValue = (double)entity3.getHeight() * 0.5;
      } else {
         label41: {
            String selected = this.aimPointSetting.getSelected();
            switch (selected.hashCode()) {
               case 2245120:
                  if (selected.equals("Head")) {
                     doubleValue = (double)entity3.getHeight() * 0.9;
                     break label41;
                  }
                  break;
               case 2364485:

                  if (selected.equals("Legs")) {
                     double height = (double)entity3.getHeight();

                     doubleValue = height * (0.1);
                     break label41;
                  }

                  break;
               default:
            }

            doubleValue = (double)entity3.getHeight() * 0.5;
         }
      }

      doubleValue += this.doubleState;
      RenderTickCounter renderTickCounter = mc.getRenderTickCounter();

      double doubleValue2 = MathHelper.lerp((double)renderTickCounter.getTickProgress(false), MinecraftClientAccess20.getLastRenderX(entity3), entity3.getX());
      double doubleValue3 = MathHelper.lerp((double)mc.getRenderTickCounter().getTickProgress(false), entity3.lastRenderY, entity3.getY());
      double doubleValue4 = MathHelper.lerp((double)mc.getRenderTickCounter().getTickProgress(false), entity3.lastRenderZ, entity3.getZ());
      Vec3d vec3d = new Vec3d(doubleValue2 + getDoubleState6(this), doubleValue3 + doubleValue, doubleValue4 + this.doubleState2);
      return this.computeVec3dForEntity2(entity3, vec3d);
   }

   private boolean testEntity4(Entity entity3) {
      if (MinecraftClientAccess20.getCrosshairTarget(mc) instanceof EntityHitResult var3) {
         byte byteValue;
         if (var3.getEntity() == entity3) {
            byteValue = 17;
            ThreadLocalRandom.current().nextInt(15);

            byteValue = 1;
         } else {
            byteValue = 0;
         }

         return (byteValue != 0);
      } else {
         return false;
      }
   }

   private Vec3d computeVec3dForEntity2(Entity entity3, Vec3d vec3d) {
      if (this.predictionSetting.isOn()) {
         if (entity3 instanceof LivingEntity) {
            LivingEntity entity32 = (LivingEntity)entity3;
            double value = getPredictionTimeMsSetting(this).getValue();

            double doubleValue = value / (1000.0);

            if (doubleValue <= (0.0)) {
               return vec3d;
            }

            Vec3d vec3d2 = EntityMotionTracker.computeVec3dForLivingEntity2(entity32, Math.min(doubleValue, this.computeDoubleForVec3d(vec3d)));
            double x2 = MinecraftClientAccess20.getX(vec3d2);
            double y = vec3d2.y;

            return vec3d.add(x2, y * (0.5), vec3d2.z);
         }

         ThreadLocalRandom.current().nextInt(17);
      }

      return vec3d;
   }
}
