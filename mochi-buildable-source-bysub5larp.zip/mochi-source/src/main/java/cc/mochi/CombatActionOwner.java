package cc.mochi;

public enum CombatActionOwner {
   NONE,
   ATTRIBUTESWAP,
   AUTOSHIELDBREAK,
   KNOCKBACK,
   TRIGGERBOT,
   AUTOMACE;

   private static final CombatActionOwner[] ENUM_VALUES = {NONE, ATTRIBUTESWAP, AUTOSHIELDBREAK, KNOCKBACK, TRIGGERBOT, AUTOMACE};

   private static CombatActionOwner[] computeCombatActionOwnerArray() {
      CombatActionOwner[] combatActionOwnerArray = new CombatActionOwner[]{NONE, null, null, null, null, null};

      combatActionOwnerArray[1] = ATTRIBUTESWAP;
      combatActionOwnerArray[2] = AUTOSHIELDBREAK;
      combatActionOwnerArray[3] = KNOCKBACK;
      combatActionOwnerArray[4] = TRIGGERBOT;
      combatActionOwnerArray[5] = AUTOMACE;
      return combatActionOwnerArray;
   }

   public static CombatActionOwner[] getENUM_VALUES() {
      return ENUM_VALUES;
   }
}
