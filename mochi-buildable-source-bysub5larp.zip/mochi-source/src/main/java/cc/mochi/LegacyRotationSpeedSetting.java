package cc.mochi;

public class LegacyRotationSpeedSetting extends DoubleSetting {
   LegacyRotationSpeedSetting(InstaCartModule instaCartModule, String name, double minimum, double maximum, double doubleValue, double step) {
      super(name, minimum, maximum, doubleValue, step);
   }

   @Override
   public void setValue(double doubleValue) {
      double doubleValue2;
      if (doubleValue > 100.0) {
         doubleValue2 = doubleValue / (21.6);
      } else {
         doubleValue2 = doubleValue;
      }

      super.setValue(RotationSpeedScale.normalizeLegacySpeed(doubleValue2));
   }
}
