package cc.mochi;

import cc.mochi.event.impl.network.DisconnectEvent;
import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.event.impl.world.WorldChangeEvent;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.BlockState;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.entry.RegistryEntry.Reference;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

public class AutoToolModule extends Module {
   private final BooleanSetting swapBackSetting;
   private boolean booleanState;

   private int intState;
   private final DoubleSetting durabilityFloorSetting;
   private int selectedSlot3;
   private final BooleanSetting onlyEffectiveToolsSetting;

   @EventHandler
   public void onTick(TickEvent tickEvent) {
      if (!this.isWorldUnavailable()) {
         if (PlayerStateUtils.canInteract()) {
            if (MinecraftClientAccess9.getInteractionManager(mc) != null) {
               if (mc.interactionManager.isBreakingBlock()) {
                  HitResult crosshairTarget = mc.crosshairTarget;
                  if (crosshairTarget instanceof BlockHitResult) {
                     BlockHitResult crosshairTarget2 = (BlockHitResult)crosshairTarget;
                     BlockState blockState = MinecraftClientAccess9.getWorld(mc).getBlockState(crosshairTarget2.getBlockPos());
                     int intState2 = this.computeIntForBlockState(blockState);
                     int selectedSlot = mc.player.getInventory().getSelectedSlot();

                     if (intState2 != -1 && selectedSlot != intState2) {
                        if (!this.booleanState) {
                           this.selectedSlot3 = selectedSlot;
                        }

                        setIntState(this, intState2);
                        setBooleanState(this, true);
                        MinecraftClientAccess9.getPlayer(mc).getInventory().setSelectedSlot(intState2);
                     }
                  }
               } else if (getBooleanState(this)) {
                  if (this.swapBackSetting.isOn() && this.selectedSlot3 >= 0) {
                     if (getSelectedSlot3(this) < 9) {
                        int selectedSlot2 = MinecraftClientAccess9.getPlayer(mc).getInventory().getSelectedSlot();
                        if (selectedSlot2 == this.intState) {
                           mc.player.getInventory().setSelectedSlot(getSelectedSlot3(this));
                        }
                     }
                  }

                  this.updateState(false);
               } else {
               }

               return;
            }

            ThreadLocalRandom.current().nextInt(3);
         }
      }

      if (this.booleanState) {
         this.updateState(true);
      }
   }

   @Override
   public void onEnable() {
      this.updateState(false);
   }

   @EventHandler
   public void onDisconnect(DisconnectEvent disconnectEvent) {
      this.updateState(false);
   }

   public static void setBooleanState(AutoToolModule autoToolModule, boolean booleanState2) {
      autoToolModule.booleanState = booleanState2;
   }

   private int computeIntForBlockState(BlockState blockState) {
      if (MinecraftClientAccess9.getWorld(mc) != null) {
         ThreadLocalRandom.current().nextInt(10);
         if (MinecraftClientAccess9.getPlayer(mc) != null) {
            PlayerInventory inventory = MinecraftClientAccess9.getPlayer(mc).getInventory();
            int intValue22 = -1;
            float miningSpeedMultiplier2 = (1.0F);
            Reference orThrow = mc.world.getRegistryManager().getOrThrow(MinecraftClientAccess9.getENCHANTMENT()).getOrThrow(Enchantments.EFFICIENCY);

            int intValue2 = 0;

            do {
               ItemStack stack = inventory.getStack(intValue2);
               label61:
               if (!stack.isEmpty()) {
                  float miningSpeedMultiplier = stack.getMiningSpeedMultiplier(blockState);
                  if (this.onlyEffectiveToolsSetting.isOn()) {
                     ThreadLocalRandom.current().nextInt(10);

                     if (miningSpeedMultiplier <= (1.0F)) {
                        break label61;
                     }
                  }

                  if (this.testItemStack(stack)) {
                     int level = EnchantmentHelper.getLevel(orThrow, stack);
                     if (level > 0) {
                        int intValue3 = level * level;

                        miningSpeedMultiplier += (float)(intValue3 + 1);
                     }

                     if (miningSpeedMultiplier > miningSpeedMultiplier2) {
                        miningSpeedMultiplier2 = miningSpeedMultiplier;
                        intValue22 = intValue2;
                     }
                  }
               }

               intValue2++;
            } while (intValue2 < 9);

            ThreadLocalRandom.current().nextInt(9);
            return intValue22;
         }
      }

      return -1;
   }

   public static int getSelectedSlot3(AutoToolModule autoToolModule) {
      return autoToolModule.selectedSlot3;
   }

   private void updateState(boolean booleanValue) {
      if (booleanValue) {
         if (this.booleanState) {
            if (getSelectedSlot3(this) >= 0) {
               int selectedSlot32 = getSelectedSlot3(this);

               if (selectedSlot32 < 9) {
                  if (mc.player != null) {
                     int selectedSlot = MinecraftClientAccess9.getPlayer(mc).getInventory().getSelectedSlot();
                     if (selectedSlot == getIntState(this)) {
                        ThreadLocalRandom.current().nextInt(12);
                        mc.player.getInventory().setSelectedSlot(this.selectedSlot3);
                     }
                  }
               }
            }
         }
      }

      this.selectedSlot3 = -1;
      setIntState(this, -1);

      this.booleanState = false;
   }

   private boolean testItemStack(ItemStack itemStack) {
      int intValue = this.durabilityFloorSetting.intValue();
      if (intValue > 0) {
         if (itemStack.isDamageable()) {
            int intValue2 = itemStack.getMaxDamage() - itemStack.getDamage();
            return ((intValue2 > intValue ? 1 : 0) != 0);
         }
      }

      return true;
   }

   public AutoToolModule() {
      super("AutoTool", "Snaps to the fastest tool while breaking blocks", ModuleCategory.PLAYER);

      this.onlyEffectiveToolsSetting = new BooleanSetting("Only Effective Tools", false);

      this.durabilityFloorSetting = new DoubleSetting("Durability Floor", 0.0, (200.0), 0.0, (1.0));

      this.swapBackSetting = new BooleanSetting("Swap Back", true);

      this.selectedSlot3 = -1;
      this.intState = -1;

      this.booleanState = false;
      Setting[] settingArray = new Setting[3];

      settingArray[0] = this.onlyEffectiveToolsSetting;
      settingArray[1] = this.durabilityFloorSetting;
      settingArray[2] = this.swapBackSetting;
      this.addSettings(settingArray);
   }

   public static int getIntState(AutoToolModule autoToolModule) {
      return autoToolModule.intState;
   }

   @Override
   public void onDisable() {
      this.updateState(true);
   }

   public static boolean getBooleanState(AutoToolModule autoToolModule) {
      return autoToolModule.booleanState;
   }

   @EventHandler
   public void onWorldChange(WorldChangeEvent worldChangeEvent) {
      this.updateState(false);
   }

   public static void setIntState(AutoToolModule autoToolModule, int intState2) {
      autoToolModule.intState = intState2;
   }

}
