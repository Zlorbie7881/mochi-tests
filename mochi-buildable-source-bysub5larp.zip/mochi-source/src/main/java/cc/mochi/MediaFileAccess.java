package cc.mochi;

import java.io.File;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.Locale;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.gui.screen.Screen;

public class MediaFileAccess {
   public static StandardOpenOption getCREATE() {
      return StandardOpenOption.CREATE;
   }

   public static Locale getROOT() {
      return Locale.ROOT;
   }

   public static Charset getUTF_8() {
      return StandardCharsets.UTF_8;
   }

   public static Screen getCurrentScreen(MinecraftClient minecraftClient) {
      return minecraftClient.currentScreen;
   }

   public static InGameHud getInGameHud(MinecraftClient minecraftClient) {
      return minecraftClient.inGameHud;
   }

   public static File getRunDirectory(MinecraftClient minecraftClient) {
      return minecraftClient.runDirectory;
   }

   public static StandardOpenOption getTRUNCATE_EXISTING() {
      return StandardOpenOption.TRUNCATE_EXISTING;
   }

   public static String getSeparator() {
      return File.separator;
   }

   public static XorText getCLIENT_NAME() {
      return ClientText.CLIENT_NAME;
   }

   public static StandardCopyOption getREPLACE_EXISTING() {
      return StandardCopyOption.REPLACE_EXISTING;
   }

   public static StandardOpenOption getWRITE() {
      return StandardOpenOption.WRITE;
   }

}
