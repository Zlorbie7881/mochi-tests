package cc.mochi;

import java.awt.Color;

public record ColoredKeyValue(String key, String value, Color color) {
   public String getKey() {
      return this.key;
   }

   public String getValue() {
      return this.value;
   }

   public ColoredKeyValue(String string, String string2) {
      this(string, string2, null);
   }

   public Color getColor() {
      return this.color;
   }
}
