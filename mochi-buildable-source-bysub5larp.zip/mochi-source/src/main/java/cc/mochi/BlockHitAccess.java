package cc.mochi;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.hit.HitResult;

public class BlockHitAccess {
   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static HitResult getCrosshairTarget(MinecraftClient minecraftClient) {
      return minecraftClient.crosshairTarget;
   }

   public static Block getBEDROCK() {
      return Blocks.BEDROCK;
   }

   public static Block getOBSIDIAN() {
      return Blocks.OBSIDIAN;
   }

   public static KeyBinding getUseKey(GameOptions gameOptions) {
      return gameOptions.useKey;
   }

   public static Item getSHIELD() {
      return Items.SHIELD;
   }

   public static GameOptions getOptions(MinecraftClient minecraftClient) {
      return minecraftClient.options;
   }

   public static ClientWorld getWorld(MinecraftClient minecraftClient) {
      return minecraftClient.world;
   }

   public static TagKey<Item> getAXES() {
      return ItemTags.AXES;
   }

   public static Item getGLOWSTONE() {
      return Items.GLOWSTONE;
   }

   public static Item getEND_CRYSTAL() {
      return Items.END_CRYSTAL;
   }
}
