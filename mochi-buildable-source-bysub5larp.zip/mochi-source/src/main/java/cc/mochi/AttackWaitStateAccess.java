package cc.mochi;

public class AttackWaitStateAccess {
   public static AttackWaitState getSWING() {
      return AttackWaitState.SWING;
   }

   public static AttackWaitState getWAIT() {
      return AttackWaitState.WAIT;
   }

   public static AttackWaitState getRELEASE_AND_WAIT() {
      return AttackWaitState.RELEASE_AND_WAIT;
   }
}
