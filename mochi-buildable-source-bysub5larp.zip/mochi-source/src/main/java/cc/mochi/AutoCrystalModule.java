package cc.mochi;

import cc.mochi.event.impl.player.TickEvent;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Predicate;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.MaceItem;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

public class AutoCrystalModule extends Module implements AttackInputBlocker {
   private final DoubleSetting breakDelayTicksSetting;
   private int age3;
   private final DoubleSetting placeDelayTicksSetting;
   private int age4;

   public static DoubleSetting getBreakDelayTicksSetting(AutoCrystalModule autoCrystalModule) {
      return autoCrystalModule.breakDelayTicksSetting;
   }

   private static boolean testItemStack(ItemStack itemStack) {
      return (itemStack.getItem() == Items.END_CRYSTAL);
   }

   private boolean testBlockPos(BlockPos blockPos) {
      BlockPos blockPos2 = blockPos.up();
      if (!BlockHitAccess.getWorld(mc).getBlockState(blockPos2).isAir()) {
         return false;
      } else {
         double x = (double)blockPos2.getX();
         double y = (double)blockPos2.getY();
         double z = (double)blockPos2.getZ();
         double doubleValue = x + 1.0;

         Box box = new Box(x, y, z, doubleValue, y + (2.0), z + 1.0);
         return (!mc.world.getOtherEntities(null, box).isEmpty());
      }
   }

   public static void setAge4(AutoCrystalModule autoCrystalModule, int age42) {
      autoCrystalModule.age4 = age42;
   }

   private boolean checkCondition() {
      int age = mc.player.age;
      if (age < this.age3) {
         setAge3(this, age);
         return false;
      } else {
         if (getBreakDelayTicksSetting(this).intValue() > 0) {
            if (age - this.age3 < this.breakDelayTicksSetting.intValue()) {
               return false;
            }
         }

         return true;
      }
   }

   @Override
   public boolean shouldBlockAttackInput() {
      if (this.isWorldUnavailable()) {
         return false;
      } else if (!this.checkCondition2()) {
         return false;
      } else {
         HitResult crosshairTarget = mc.crosshairTarget;
         if (!(crosshairTarget instanceof BlockHitResult)) {
            return false;
         } else {
            BlockHitResult crosshairTarget2 = (BlockHitResult)crosshairTarget;
            BlockState blockState = BlockHitAccess.getWorld(mc).getBlockState(crosshairTarget2.getBlockPos());
            if (!blockState.isOf(BlockHitAccess.getOBSIDIAN())) {
               if (!blockState.isOf(BlockHitAccess.getBEDROCK())) {
                  return false;
               }
            }

            return true;
         }
      }
   }

   public AutoCrystalModule() {
      super("Auto Crystal", "Automatically places and detonates crystals", ModuleCategory.COMBAT);

      this.placeDelayTicksSetting = new DoubleSetting("Place Delay (Ticks)", 0.0, 20.0, 1.0, (1.0));

      this.breakDelayTicksSetting = new DoubleSetting("Break Delay (Ticks)", (0.0), (20.0), 1.0, (1.0));
      Setting[] settingArray = new Setting[]{this.placeDelayTicksSetting, null};

      settingArray[1] = this.breakDelayTicksSetting;
      this.addSettings(settingArray);
   }

   private void updateState() {
      if (BlockHitAccess.getCrosshairTarget(mc) instanceof EntityHitResult var1) {
         Entity entity = var1.getEntity();
         if (entity instanceof EndCrystalEntity) {
            ThreadLocalRandom.current().nextInt(12);

            EndCrystalEntity entity2 = (EndCrystalEntity)entity;
            if (!entity2.isRemoved() && entity2.isAlive()) {
               if (this.checkCondition()) {
                  if (AttackActions.testMinecraftClient(mc, "combat.attack.autocrystal")) {
                     this.age3 = mc.player.age;
                  }
               }
            }
         }
      }
   }

   @Override
   public void onEnable() {
      int age;
      if (mc.player != null) {
         age = mc.player.age;
      } else {
         ThreadLocalRandom.current().nextInt(7);
         age = 0;
      }

      int age2 = age;
      setAge4(this, age2);
      this.age3 = age2;
   }

   @EventHandler
   private void onTickEvent(TickEvent tickEvent) {
      if (!this.isWorldUnavailable()) {
         if (mc.currentScreen != null) {
            ThreadLocalRandom.current().nextInt(6);
         } else {
            if (!mc.player.isUsingItem()) {
               if (this.checkCondition2()) {
                  if (this.testItemStack2(BlockHitAccess.getPlayer(mc).getMainHandStack())) {
                     this.updateState2();
                     this.updateState();
                     return;
                  }

                  ThreadLocalRandom.current().nextInt(16);
               }
            }
         }
      }
   }

   private boolean checkCondition2() {
      if (!KeybindUtils.checkCondition2(1)) {
         ThreadLocalRandom.current().nextInt(10);

         if (!BlockHitAccess.getUseKey(BlockHitAccess.getOptions(mc)).isPressed()) {
            return false;
         }
      }

      return true;
   }

   private int computeIntForPredicate(Predicate predicate) {
      int intValue = 0;

      while (!predicate.test(mc.player.getInventory().getStack(intValue))) {
         intValue++;

         if (intValue > 8) {
            return -1;
         }
      }

      ThreadLocalRandom.current().nextInt(3);

      return intValue;
   }

   public static int getAge4(AutoCrystalModule autoCrystalModule) {
      return autoCrystalModule.age4;
   }

   public static void setAge3(AutoCrystalModule autoCrystalModule, int age32) {
      autoCrystalModule.age3 = age32;
   }

   private boolean checkCondition3() {
      int age = BlockHitAccess.getPlayer(mc).age;
      if (age < this.age4) {
         setAge4(this, age);
         return false;
      } else {
         if (this.placeDelayTicksSetting.intValue() > 0) {
            if (age - getAge4(this) < this.placeDelayTicksSetting.intValue()) {
               ThreadLocalRandom.current().nextInt(6);

               return false;
            }
         }

         return true;
      }
   }

   private void updateState2() {
      net.minecraft.util.math.BlockPos blockPos;

      HitResult crosshairTarget2 = BlockHitAccess.getCrosshairTarget(mc);
      if (crosshairTarget2 instanceof BlockHitResult) {
         byte byteValue;
         label66: {
            byteValue = 9;
            ThreadLocalRandom.current().nextInt(8);
            BlockHitResult crosshairTarget22 = (BlockHitResult)crosshairTarget2;
            blockPos = crosshairTarget22.getBlockPos();
            BlockState blockState = mc.world.getBlockState(blockPos);
            if (!blockState.isOf(BlockHitAccess.getOBSIDIAN())) {
               if (!blockState.isOf(BlockHitAccess.getBEDROCK())) {
                  byteValue = 0;
                  break label66;
               }
            }

            byteValue = 1;
         }

         byte byteValue2 = byteValue;
         if (byteValue2 != 0) {
            byteValue = 20;
            ThreadLocalRandom.current().nextInt(13);
            if (!this.testBlockPos(blockPos)) {
               if (mc.player.getMainHandStack().getItem() != Items.END_CRYSTAL) {
                  int intValue = this.computeIntForPredicate(objectValue -> testItemStack((ItemStack)objectValue));
                  if (intValue != -1) {
                     mc.player.getInventory().setSelectedSlot(intValue);
                  }
               } else {
                  if (this.checkCondition3()) {
                     InventorySynchronization.updateStateForMinecraftClient4(mc);
                     this.age4 = BlockHitAccess.getPlayer(mc).age;
                  }
               }
            }
         }
      }
   }

   private boolean testItemStack2(ItemStack itemStack) {
      Item item = itemStack.getItem();
      if (item == BlockHitAccess.getEND_CRYSTAL()) {
         return true;
      } else {
         if (item != BlockHitAccess.getSHIELD()) {
            if (item != BlockHitAccess.getGLOWSTONE()) {
               if (item != Items.RESPAWN_ANCHOR) {
                  if (itemStack.isIn(ItemTags.SPEARS)) {
                     return false;
                  }

                  return ((!itemStack.isIn(ItemTags.SWORDS) && !itemStack.isIn(BlockHitAccess.getAXES()) && !(item instanceof MaceItem) ? 0 : 1) != 0);
               }

               ThreadLocalRandom.current().nextInt(9);
            }
         }

         return false;
      }
   }
}
