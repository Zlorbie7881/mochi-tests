package cc.mochi;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.nio.ByteBuffer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

public final class CamouflageRenderer {
   private static final GlFramebufferTarget glFramebufferTarget = new GlFramebufferTarget();

   private static float floatState = 0.8F;
   private static int intState;

   private static int intState2;
   private static int intState3;
   private static boolean booleanState;

   private static long timestampNanos;
   private static int intState4;
   private static boolean booleanState2;

   private static float computeFloat() {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      return minecraftClient != null && minecraftClient.options != null
         ? (float)Math.toRadians((double)((Integer)minecraftClient.options.getFov().getValue()).intValue())
         : (float)Math.toRadians(70.0);
   }

   public static boolean checkCondition(float floatValue, int intValue, int intValue2, float floatValue2, Color[] colorArray) {
      if (colorArray != null && colorArray.length >= 4 && checkCondition5()) {
         int intState22 = computeInt3();
         int intState32 = computeInt2();
         OpenGlStateSnapshot openGlStateSnapshot = OpenGlStateSnapshot.capture();

         try {
            if (checkCondition3(intState22, intState32)) {
               updateState3();
               GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, intState);
               GL11.glViewport(0, 0, intState22, intState32);
               ShaderProgramCache.bind("camo");
               updateState(floatValue, intValue, intValue2, floatValue2, colorArray, 0.0F, 0.0F, (float)intState22, (float)intState32, 0.0F);
               glFramebufferTarget.draw();
               return true;
            }
         } finally {
            openGlStateSnapshot.restore();
         }

         return false;
      } else {
         return false;
      }
   }

   private static void updateState(float floatValue, int intValue, int intValue2, float floatValue2, Color[] colorArray, float floatValue3, float floatValue4, float floatValue5, float floatValue6, float floatValue7) {
      ShaderProgramCache.uniform1f("camo", "uAlpha", max(floatValue2));
      ShaderProgramCache.uniform2f("camo", "uLocation", floatValue3, floatValue4);
      ShaderProgramCache.uniform2f("camo", "uSize", floatValue5, floatValue6);
      ShaderProgramCache.uniform2f("camo", "uResolution", (float)computeInt3(), (float)computeInt2());
      ShaderProgramCache.uniform1f("camo", "uTime", floatValue);
      ShaderProgramCache.uniform1f("camo", "RadiusTopLeft", floatValue7);
      ShaderProgramCache.uniform1f("camo", "RadiusTopRight", floatValue7);
      ShaderProgramCache.uniform1f("camo", "RadiusBottomLeft", floatValue7);
      ShaderProgramCache.uniform1f("camo", "RadiusBottomRight", floatValue7);
      updateStateForColor(colorArray[0], "color1");
      updateStateForColor(colorArray[1], "color2");
      updateStateForColor(colorArray[2], "color3");
      updateStateForColor(colorArray[3], "color4");
      ShaderProgramCache.uniform1f("camo", "uSpeed", floatState);
      ShaderProgramCache.uniform1f("camo", "uScale", 0.5F);
      ShaderProgramCache.uniform1f("camo", "uWarp", 0.6F);
      ShaderProgramCache.uniform1f("camo", "uShimmer", 0.22F);
      ShaderProgramCache.uniform2f("camo", "uMouse", ((-10000.0F)), ((-10000.0F)));
      ShaderProgramCache.uniform1f("camo", "uMouseRadius", 1.0F);
      ShaderProgramCache.uniform1f("camo", "uMousePush", 0.0F);
      ShaderProgramCache.uniform1i("camo", "uOctaves", 5);
      ShaderProgramCache.uniform1i("camo", "uPatternMode", intValue);
      ShaderProgramCache.uniform1f("camo", "uGeoDensity", 6.0F);
      ShaderProgramCache.uniform1f("camo", "uGeoSoftness", 0.22F);
      ShaderProgramCache.uniform1f("camo", "uGeoJitter", 0.6F);
      ShaderProgramCache.uniform1i("camo", "uSkyMode", intValue2);
      ShaderProgramCache.uniform1f("camo", "uYaw", computeFloat3());
      ShaderProgramCache.uniform1f("camo", "uPitch", computeFloat2());
      ShaderProgramCache.uniform1f("camo", "uFov", computeFloat());
   }

   public static int computeInt() {
      return intState4 != 0 && GL11.glIsTexture(intState4) ? intState4 : 0;
   }

   private static void updateState2() {
      if (intState != 0 && GL30.glIsFramebuffer(intState)) {
         GL30.glDeleteFramebuffers(intState);
      }

      if (intState4 != 0 && GL11.glIsTexture(intState4)) {
         GL11.glDeleteTextures(intState4);
      }

      intState = 0;
      intState4 = 0;
      intState2 = 0;
      intState3 = 0;
   }

   private static float computeFloat2() {
      ClientPlayerEntity clientPlayerEntity = MinecraftClient.getInstance() == null ? null : MinecraftClient.getInstance().player;
      return clientPlayerEntity != null ? (float)Math.toRadians((double)clientPlayerEntity.getPitch()) : 0.0F;
   }

   private static void updateState3() {
      GL11.glEnable(GL11.GL_BLEND);
      GL14.glBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ONE_MINUS_SRC_ALPHA);
      GL11.glDisable(GL11.GL_DEPTH_TEST);
      GL11.glDisable(GL11.GL_CULL_FACE);
      GL11.glDisable(GL11.GL_SCISSOR_TEST);
      GL11.glDisable(GL11.GL_STENCIL_TEST);
      GL11.glColorMask(true, true, true, true);
   }

   private static float max(float floatValue) {
      return Math.max(0.0F, Math.min(1.0F, floatValue));
   }

   private static int computeInt2() {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      return minecraftClient != null && minecraftClient.getWindow() != null ? Math.max(1, minecraftClient.getWindow().getFramebufferHeight()) : 1;
   }

   private static float computeFloat3() {
      ClientPlayerEntity clientPlayerEntity = MinecraftClient.getInstance() == null ? null : MinecraftClient.getInstance().player;
      return clientPlayerEntity != null ? (float)Math.toRadians((double)clientPlayerEntity.getYaw()) : 0.0F;
   }

   private static void updateState4(String string) {
      booleanState = true;
      if (!booleanState2) {
         booleanState2 = true;
      }
   }

   public static void updateFloatState(float floatValue) {
      floatState = Math.max(0.01F, Math.min(8.0F, floatValue));
   }

   public static int getIntState2() {
      return intState2;
   }

   public static void updateState5() {
      RenderSystem.assertOnRenderThread();
      updateState2();
      MainFramebufferBridge.delete();
      glFramebufferTarget.destroy();
      ShaderProgramCache.deleteProgram("camo");
      booleanState = false;
      booleanState2 = false;
      timestampNanos = 0L;
   }

   public static boolean checkCondition2(float floatValue, int intValue, int intValue2, float floatValue2, Color[] colorArray) {
      if (colorArray != null && colorArray.length >= 4 && checkCondition5()) {
         int intValue3 = computeInt3();
         int intValue4 = computeInt2();
         OpenGlStateSnapshot openGlStateSnapshot = OpenGlStateSnapshot.capture();

         try {
            int orCreate = MainFramebufferBridge.getOrCreate();
            if (orCreate != 0) {
               updateState3();
               GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, orCreate);
               GL11.glViewport(0, 0, intValue3, intValue4);
               ShaderProgramCache.bind("camo");
               updateState(floatValue, intValue, intValue2, floatValue2, colorArray, 0.0F, 0.0F, (float)intValue3, (float)intValue4, 0.0F);
               glFramebufferTarget.draw();
               return true;
            }
         } finally {
            openGlStateSnapshot.restore();
         }

         return false;
      } else {
         return false;
      }
   }

   private static boolean checkCondition3(int intState22, int intState32) {
      if (intState != 0 && intState4 != 0 && intState2 == intState22 && intState3 == intState32 && GL30.glIsFramebuffer(intState) && GL11.glIsTexture(intState4)) {
         return true;
      } else {
         updateState2();
         int intState42 = GL11.glGenTextures();
         if (intState42 == 0) {
            return false;
         } else {
            GL11.glBindTexture(GL11.GL_TEXTURE_2D, intState42);
            GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA8, intState22, intState32, 0, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, (ByteBuffer)null);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, org.lwjgl.opengl.GL12.GL_CLAMP_TO_EDGE);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, org.lwjgl.opengl.GL12.GL_CLAMP_TO_EDGE);
            int intState5 = GL30.glGenFramebuffers();
            if (intState5 == 0) {
               GL11.glDeleteTextures(intState42);
               return false;
            } else {
               GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, intState5);
               GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, intState42, 0);
               if (GL30.glCheckFramebufferStatus(GL30.GL_FRAMEBUFFER) != 36053) {
                  GL30.glDeleteFramebuffers(intState5);
                  GL11.glDeleteTextures(intState42);
                  updateState4("CamoRenderer: offscreen framebuffer incomplete");
                  return false;
               } else {
                  intState = intState5;
                  intState4 = intState42;
                  intState2 = intState22;
                  intState3 = intState32;
                  return true;
               }
            }
         }
      }
   }

   public static boolean checkCondition4() {
      return checkCondition5();
   }

   private static boolean checkCondition5() {
      RenderSystem.assertOnRenderThread();
      if (booleanState) {
         return false;
      } else {
         Integer integer = ShaderProgramCache.get("camo");
         if (integer == null || integer == 0 || !GL20.glIsProgram(integer)) {
            integer = ShaderProgramCache.loadProgram("camo", "shaders/gui/camo.vsh", "shaders/gui/camo.fsh");
         }

         if (integer == 0) {
            updateState4("CamoRenderer: shader initialization failed; skipping the camo backdrop");
            return false;
         } else if (glFramebufferTarget.isValid()) {
            return true;
         } else {
            OpenGlStateSnapshot openGlStateSnapshot = OpenGlStateSnapshot.capture();

            try {
               if (!glFramebufferTarget.ensureInitialized()) {
                  updateState4("CamoRenderer: full-screen geometry initialization failed");
                  return false;
               }
            } finally {
               openGlStateSnapshot.restore();
            }

            return true;
         }
      }
   }

   private static void updateStateForColor(Color color, String string) {
      Color color2 = color == null ? Color.BLACK : color;
      ShaderProgramCache.uniform4f("camo", string, (float)color2.getRed() / 255.0F, (float)color2.getGreen() / 255.0F, (float)color2.getBlue() / 255.0F, (float)color2.getAlpha() / 255.0F);
   }

   public static boolean checkCondition6(float floatValue, Color[] colorArray) {
      long longValue = System.nanoTime();
      if (longValue - timestampNanos < 500000L && computeInt() != 0) {
         return true;
      } else {
         boolean booleanValue = checkCondition(floatValue, 0, 0, 1.0F, colorArray);
         if (booleanValue) {
            timestampNanos = System.nanoTime();
         }

         return booleanValue;
      }
   }

   private static int computeInt3() {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      return minecraftClient != null && minecraftClient.getWindow() != null ? Math.max(1, minecraftClient.getWindow().getFramebufferWidth()) : 1;
   }

   public static int getIntState3() {
      return intState3;
   }

   private CamouflageRenderer() {
   }
}
