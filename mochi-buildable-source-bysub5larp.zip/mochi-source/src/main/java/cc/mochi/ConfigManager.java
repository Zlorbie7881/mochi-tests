package cc.mochi;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ThreadLocalRandom;

public final class ConfigManager {
   private final Gson gson;

   private final Gson gson2;
   private final ModuleManager moduleManager = MochiClient.INSTANCE != null ? MochiClient.INSTANCE.getModuleManager() : null;
   private final File file;

   public static ModuleManager getModuleManager(ConfigManager configManager) {
      return configManager.moduleManager;
   }

   public static File getFile(ConfigManager configManager) {
      return configManager.file;
   }

   private void updateStateForFile(File file) {
      if (file == null || getModuleManager(this) == null || ClientCleanup.getBooleanState()) return;
      JsonObject config = new JsonObject();
      config.addProperty("schemaVersion", 1);
      for (Object entry : getModuleManager(this).getModules()) {
            Module module = (Module)entry;
         if (module == null) continue;
         JsonObject values = new JsonObject();
         values.addProperty("enabled", module.isEnabled());
         values.addProperty("bind", module.getKeyCode());
         if (module.getSettings() != null) {
            for (Object settingEntry : module.getSettings()) {
                  Setting setting = (Setting)settingEntry;
               if (setting != null) write(setting, values);
            }
         }
         if (module instanceof HudElement hud) HudLayoutJson.updateStateForJsonObject(values, hud);
         if (module.getName() != null) config.add(module.getName(), values);
      }
      try (FileWriter writer = new FileWriter(file, StandardCharsetsAccess3.getUTF_8())) {
         this.gson2.toJson(config, writer);
      } catch (IOException error) {
         ChatMessages.updateState7("§cFailed to write config: " + error.getMessage());
      }
   }

   private static void write(Setting setting, JsonObject json) {
      SettingJson.write(setting, json);
   }

   public String computeString(String name) {
      if (name == null || name.isBlank() || this.moduleManager == null) return null;
      File file = new File(this.file, name + ".json");
      if (!file.exists()) return null;
      try {
         JsonObject config = this.gson2.fromJson(Files.readString(file.toPath(), StandardCharsetsAccess3.getUTF_8()), JsonObject.class);
         if (config == null || !config.has("schemaVersion")) return null;
         JsonObject exported = new JsonObject();
         exported.addProperty("schemaVersion", computeIntForJsonObject(config));
         exported.addProperty("name", name);
         for (Object entry : getModuleManager(this).getModules()) {
            Module module = (Module)entry;
            if (!testModule(module)) continue;
            JsonObject values = ConfigMigration.computeJsonObjectForJsonObject(config, module.getName());
            if (values != null) exported.add(module.getName(), values);
         }
         return getGson(this).toJson(exported);
      } catch (IOException error) {
         ChatMessages.updateState7("§cFailed to read config: " + error.getMessage());
         return null;
      }
   }

   public void updateState(String string, String string2) {
      ThreadLocalRandom.current().nextInt(6);

      if (string != null) {
         if (string2 != null && !string.isBlank() && !string2.isBlank()) {
            File file2 = new File(this.file, string + ".json");
            File file3 = new File(getFile(this), string2 + ".json");
            if (!file2.exists()) {
               ChatMessages.updateState7("§cConfig not found: " + string);
               return;
            }

            if (file3.exists()) {
               ChatMessages.updateState7("§eConfig '" + string2 + "' already exists.");
               return;
            }

            if (file2.renameTo(file3)) {
               ChatMessages.updateState7("§aConfig renamed from '" + string + "' to '" + string2 + "'.");
            } else {
               ChatMessages.updateState7("§cFailed to rename config.");
            }

            return;
         }
      } else {
         ThreadLocalRandom.current().nextInt(13);
      }
   }

   public void updateState2(String string) {
      if (string != null) {
         ThreadLocalRandom.current().nextInt(14);
         if (!string.isBlank()) {
            if (this.moduleManager == null) {
               return;
            }

            File file2 = new File(this.file, string + ".json");
            if (file2.exists()) {
               ChatMessages.updateState7("§eOverwriting existing config '" + string + "'.");
            } else {
               ThreadLocalRandom.current().nextInt(3);
            }

            this.updateStateForFile(file2);
            ChatMessages.updateState7("§aConfig '" + string + "' saved.");
            return;
         }
      }
   }

   private void updateStateForFile2(File file) {
      if (file == null || !file.exists() || this.moduleManager == null) return;
      try (FileReader reader = new FileReader(file, StandardCharsetsAccess3.getUTF_8())) {
         JsonObject config = getGson2(this).fromJson(reader, JsonObject.class);
         if (config == null) return;
         this.updateState7();
         int version = computeIntForJsonObject(config);
         for (Object entry : this.moduleManager.getModules()) {
            Module module = (Module)entry;
            if (module == null) continue;
            JsonObject values = ConfigMigration.computeJsonObjectForJsonObject(config, module.getName());
            if (values != null) this.updateStateForModule(module, values, version);
         }
      } catch (Exception error) {
         ChatMessages.updateState7("§cFailed to load config: " + error.getMessage());
      }
   }

   public String computeString2(String requestedName, String contents) {
      if (ClientCleanup.getBooleanState()) return null;
      if (contents == null || contents.isBlank()) {
         ChatMessages.updateState7("§cNothing to import.");
         return null;
      }
      try {
         JsonObject config = this.gson2.fromJson(contents, JsonObject.class);
         if (config == null || !config.has("schemaVersion")) {
            ChatMessages.updateState7("§cClipboard isn't a valid Mochi config.");
            return null;
         }
         String embeddedName = config.has("name") && config.get("name").isJsonPrimitive()
            ? config.get("name").getAsString() : null;
         String name = requestedName == null || requestedName.isBlank() ? embeddedName : requestedName;
         if (name == null || name.isBlank()) name = "pasted";
         name = computeString3(name);
         if (name == null || name.isBlank()) {
            ChatMessages.updateState7("§cInvalid config name.");
            return null;
         }
         config.remove("name");
         File file = new File(this.file, name + ".json");
         if (file.exists()) ChatMessages.updateState7("§eOverwriting existing config '" + name + "'.");
         try (java.io.FileWriter writer = new java.io.FileWriter(file, java.nio.charset.StandardCharsets.UTF_8)) {
            getGson2(this).toJson(config, writer);
         }
         ChatMessages.updateState7("§aConfig '" + name + "' imported.");
         return name;
      } catch (com.google.gson.JsonParseException error) {
         ChatMessages.updateState7("§cClipboard isn't a valid Mochi config.");
      } catch (IOException error) {
         ChatMessages.updateState7("§cFailed to import config: " + error.getMessage());
      }
      return null;
   }

   public static Gson getGson(ConfigManager configManager) {
      return configManager.gson;
   }

   private static boolean endsWith(File file2, String string) {
      return string.endsWith(".json");
   }

   public static Gson getGson2(ConfigManager configManager) {
      return configManager.gson2;
   }

   public ConfigManager() {
      this.gson2 = new GsonBuilder().setPrettyPrinting().create();
      this.gson = new Gson();
      File file2;
      if (MochiClient.mc != null && MochiClient.mc.runDirectory != null) {
         String separator = File.separator;
         file2 = new File(MochiClient.mc.runDirectory, "config" + separator + "mochi");
      } else {
         String separator2 = File.separator;
         file2 = new File("config" + separator2 + "mochi");
      }

      this.file = file2;
      this.updateState4();
   }

   private void updateStateForModule(Module module, JsonObject jsonObject, int intValue) {
      if (module != null && jsonObject != null) {
         if (jsonObject.has("enabled")) {
            module.setEnabled(jsonObject.get("enabled").getAsBoolean());

            ThreadLocalRandom.current().nextInt(6);
         }

         if (jsonObject.has("bind")) {
            module.setKeyCode(jsonObject.get("bind").getAsInt());
         }

         if (module.getSettings() != null) {
            Iterator iterator = module.getSettings().iterator();

            while (true) {
               if (!iterator.hasNext()) {
                  break;
               }

               Setting setting = (Setting)iterator.next();
               if (setting != null) {
                  updateStateForSetting(setting, jsonObject);
               }
            }
         }

         if (module instanceof HudElement) {
            HudElement module2 = (HudElement)module;
            HudLayoutJson.updateStateForJsonObject2(jsonObject, module2);
         } else {
            ThreadLocalRandom.current().nextInt(12);
         }
      }
   }

   private static String computeString3(String string) {
      ThreadLocalRandom.current().nextInt(5);
      if (string == null) {
         return null;
      } else {
         StringBuilder stringBuilder = new StringBuilder(string.length());

         int intValue = 0;

         while (intValue < string.length()) {
            label56: {
               char charValue = string.charAt(intValue);
               if (!Character.isLetterOrDigit(charValue)) {
                  if (charValue != '_') {
                     if (charValue != '-') {
                        if (charValue != '.') {
                           break label56;
                        }
                     }
                  }
               }

               stringBuilder.append(charValue);
            }

            intValue++;
         }

         if (stringBuilder.length() > 0) {
         return stringBuilder.toString();
      } else {
         return null;
      }
      }
   }

   private static void updateStateForSetting(Setting setting, JsonObject json) {
      if (setting == null || json == null) return;
      String name = setting.getName();
      if (name == null || !json.has(name)) return;
      try {
         SettingJson.read(setting, json.get(name));
      } catch (Exception error) {
         ChatMessages.updateState7("§cFailed to load setting: " + name);
      }
   }

   private static int computeIntForJsonObject(JsonObject jsonObject) {
      if (jsonObject != null) {
         if (jsonObject.has("schemaVersion")) {
            try {
               return Math.max(0, jsonObject.get("schemaVersion").getAsInt());
            } catch (RuntimeException failure) {
               return 0;
            }
         }

         ThreadLocalRandom.current().nextInt(17);
      }

      return 0;
   }

   public void updateState3() {
      this.updateState7();
      ChatMessages.updateState7("§aAll modules reset to defaults.");
   }

   private void updateState4() {
      if (getFile(this) != null) {
         if (!this.file.exists()) {
            if (!getFile(this).mkdirs()) {
               String absolutePath = getFile(this).getAbsolutePath();
               ChatMessages.updateState7("§cFailed to create config directory: " + absolutePath);
            }
         } else {
            ThreadLocalRandom.current().nextInt(12);
         }
      }
   }

   public File getFile3() {
      return this.file;
   }

   public List computeList() {
      ArrayList arrayList = new ArrayList();
      if (this.file != null) {
         if (this.file.exists()) {
            File[] fileArray = this.file.listFiles((file2, string) -> endsWith(file2, string));
            if (fileArray == null) {
               return arrayList;
            }

            File[] fileArray2 = fileArray;
            int length = fileArray.length;
            int intValue = 0;

            while (intValue < length) {
               File file3 = fileArray2[intValue];
               String name = file3.getName();
               if (name.endsWith(".json")) {
                  arrayList.add(name.substring(0, name.length() - 5));
               }

               intValue++;
            }

            arrayList.sort(StandardCharsetsAccess3.getCASE_INSENSITIVE_ORDER());
            return arrayList;
         }
      }

      return arrayList;
   }

   public void updateState5(String string) {
      if ((string != null)) {
         File file2 = new File(this.file, string + ".json");
         if (!file2.exists()) {
            ChatMessages.updateState7("§cConfig not found: " + string);
         } else {
            if (file2.delete()) {
               ChatMessages.updateState7("§aConfig '" + string + "' deleted.");
            } else {
               ChatMessages.updateState7("§cFailed to delete config: " + string);
            }
         }
      }
   }

   public void updateState6(String string) {
      if (string != null) {
         if (this.moduleManager != null) {
            File file2 = new File(getFile(this), string + ".json");
            if (!file2.exists()) {
               ChatMessages.updateState7("§cConfig not found: " + string);
               return;
            }

            this.updateStateForFile2(file2);
            ChatMessages.updateState7("§aConfig '" + string + "' loaded.");
            return;
         }
      }

      ThreadLocalRandom.current().nextInt(9);
   }

   private static boolean testModule(Module module) {
      if (module == null) {
         return false;
      } else if (module.isEnabled()) {
         return true;
      } else {
         KeybindSetting keybind = module.getKeybind();
         if (keybind != null) {
            if (!keybind.isDefault()) {
               return true;
            }
         } else {
            ThreadLocalRandom.current().nextInt(14);
         }

         if (module.getSettings() != null) {
            for (Setting setting : (java.lang.Iterable<Setting>)(java.lang.Iterable<?>)(module.getSettings())) {
               if (setting != null && !setting.isDefault()) {
                  return true;
               }
            }
         }

         return false;
      }
   }

   private void updateState7() {
      if (this.moduleManager != null) {
         if (getModuleManager(this).getModules() != null) {
            Iterator iterator = getModuleManager(this).getModules().iterator();

            while (true) {
               if (!iterator.hasNext()) {
                  return;
               }

               Module module = (Module)iterator.next();
               if (module != null) {
                  module.setEnabled(false);
                  if (module.getKeybind() != null) {
                     module.getKeybind().reset();
                     module.setKeyCode(module.getKeybind().getDefaultKeyCode());
                  }

                  if (module.getSettings() != null) {
                     Iterator iterator2 = module.getSettings().iterator();

                     while (true) {
                        if (!iterator2.hasNext()) {
                           break;
                        }

                        Setting setting = (Setting)iterator2.next();
                        if (setting != null) {
                           setting.reset();
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private static int settingTypeIndex0(Object objectValue, int intValue) {
      Objects.checkIndex(intValue, 12);
      if (objectValue == null) {
         return -1;
      } else if (intValue <= 0 && objectValue instanceof BooleanSetting) {
         return 0;
      } else if (intValue <= 1 && objectValue instanceof DoubleSetting) {
         return 1;
      } else if (intValue <= 2 && objectValue instanceof DecimalSetting) {
         return 2;
      } else if (intValue <= 3 && objectValue instanceof DoubleRangeSetting) {
         return 3;
      } else if (intValue <= 4 && objectValue instanceof ChoiceSetting) {
         return 4;
      } else if (intValue <= 5 && objectValue instanceof KeybindSetting) {
         return 5;
      } else if (intValue <= 6 && objectValue instanceof StringSetting) {
         return 6;
      } else if (intValue <= 7 && objectValue instanceof HotbarPatternSetting) {
         return 7;
      } else if (intValue <= 8 && objectValue instanceof ItemListSetting) {
         return 8;
      } else if (intValue <= 9 && objectValue instanceof HotbarSlotSetting) {
         return 9;
      } else {
         return intValue <= 10 && objectValue instanceof ColorSetting ? 10 : 11;
      }
   }

   private static int settingTypeIndex1(Object objectValue, int intValue) {
      Objects.checkIndex(intValue, 12);
      if (objectValue == null) {
         return -1;
      } else if (intValue <= 0 && objectValue instanceof BooleanSetting) {
         return 0;
      } else if (intValue <= 1 && objectValue instanceof DoubleSetting) {
         return 1;
      } else if (intValue <= 2 && objectValue instanceof DecimalSetting) {
         return 2;
      } else if (intValue <= 3 && objectValue instanceof DoubleRangeSetting) {
         return 3;
      } else if (intValue <= 4 && objectValue instanceof ChoiceSetting) {
         return 4;
      } else if (intValue <= 5 && objectValue instanceof KeybindSetting) {
         return 5;
      } else if (intValue <= 6 && objectValue instanceof StringSetting) {
         return 6;
      } else if (intValue <= 7 && objectValue instanceof HotbarPatternSetting) {
         return 7;
      } else if (intValue <= 8 && objectValue instanceof ItemListSetting) {
         return 8;
      } else if (intValue <= 9 && objectValue instanceof HotbarSlotSetting) {
         return 9;
      } else {
         return intValue <= 10 && objectValue instanceof ColorSetting ? 10 : 11;
      }
   }
}
