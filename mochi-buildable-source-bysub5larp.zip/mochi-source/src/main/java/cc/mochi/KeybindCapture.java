package cc.mochi;

public final class KeybindCapture {
   private String string;
   private KeybindSetting keybindSetting;

   private boolean booleanState;

   public String getString() {
      return this.string;
   }

   public static KeybindSetting getKeybindSetting(KeybindCapture keybindCapture) {
      return keybindCapture.keybindSetting;
   }

   public boolean checkCondition() {
      if (this.keybindSetting != null) {
         return true;
      } else {
         boolean booleanState2 = getBooleanState(this);
         this.booleanState = false;
         return booleanState2;
      }
   }

   public boolean checkCondition2() {
      return getKeybindSetting(this) != null;
   }

   public boolean checkCondition3(int keyCode) {
      if (getKeybindSetting(this) == null) {
         return false;
      } else {
         if (keyCode == 256) {
            getKeybindSetting(this).setKeyCode(-1);
            ClientSounds.updateState5();
         } else {
            if (keyCode == -1 || keyCode == 0) {
               return true;
            }

            this.keybindSetting.setKeyCode(keyCode);
            this.booleanState = true;
            ClientSounds.updateState4();
         }

         this.updateState();
         return true;
      }
   }

   public static boolean getBooleanState(KeybindCapture keybindCapture) {
      return keybindCapture.booleanState;
   }

   public static void setString(KeybindCapture keybindCapture, String string2) {
      keybindCapture.string = string2;
   }

   public void updateStateForKeybindSetting(KeybindSetting keybindSetting2, String string2) {
      this.keybindSetting = keybindSetting2;
      setString(this, string2);
      ClientSounds.updateState4();
   }

   public static String computeString(int intValue) {
      if (intValue != -1 && intValue != 0) {
         String string2 = KeybindUtils.computeString(intValue);
         return string2 != null && !string2.isBlank() && !string2.equals("Unbound") ? string2 : null;
      } else {
         return null;
      }
   }

   public boolean checkCondition4(int intValue) {
      if (this.keybindSetting == null) {
         return false;
      } else {
         this.keybindSetting.setKeyCode(KeybindUtils.computeInt(intValue));
         ClientSounds.updateState4();
         this.updateState();
         return true;
      }
   }

   public boolean testKeybindSetting(KeybindSetting keybindSetting2) {
      return this.keybindSetting != null && getKeybindSetting(this) == keybindSetting2;
   }

   public void updateState() {
      setKeybindSetting(this, null);
      setString(this, null);
   }

   public static void setKeybindSetting(KeybindCapture keybindCapture, KeybindSetting keybindSetting2) {
      keybindCapture.keybindSetting = keybindSetting2;
   }

   public static boolean checkCondition5(int intValue) {
      return computeString(intValue) != null;
   }

}
