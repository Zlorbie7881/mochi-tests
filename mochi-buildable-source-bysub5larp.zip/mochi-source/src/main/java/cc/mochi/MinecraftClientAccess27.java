package cc.mochi;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.state.property.IntProperty;

public class MinecraftClientAccess27 {
   public static ClientWorld getWorld(MinecraftClient minecraftClient) {
      return minecraftClient.world;
   }

   public static IntProperty getCHARGES() {
      return RespawnAnchorBlock.CHARGES;
   }

   public static Block getRESPAWN_ANCHOR() {
      return Blocks.RESPAWN_ANCHOR;
   }
}
