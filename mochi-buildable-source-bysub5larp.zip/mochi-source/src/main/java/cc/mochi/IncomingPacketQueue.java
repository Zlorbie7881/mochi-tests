package cc.mochi;

import cc.mochi.mixin.EntityS2CPacketAccessor;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.network.listener.PacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.EntityS2CPacket;
import net.minecraft.util.math.Vec3d;
import org.slf4j.Logger;
import org.slf4j.helpers.NOPLogger;

public final class IncomingPacketQueue {
   private final Object lock;

   private static final double POSITION_SCALE = 4096.0;

   private final Map<Object, PacketDelayLease> owners = new ConcurrentHashMap<>();
   private static final IncomingPacketQueue INSTANCE = new IncomingPacketQueue();
   private volatile boolean flushing;
   private volatile int queuedCount;

   private static final int MAX_QUEUED_PACKETS = 8192;
   private final AtomicBoolean workerRunning;
   private boolean booleanState;
   private final ConcurrentLinkedDeque<QueuedIncomingPacket> queuedPackets = new ConcurrentLinkedDeque<>();
   private static final Logger LOGGER = NOPLogger.NOP_LOGGER;

   public void updateState(Object objectValue) {
      if (objectValue != null) {
         if (this.owners.remove(objectValue) != null) {
            ThreadLocalRandom.current().nextInt(14);
            this.updateState2();
         }
      }
   }

   private void updateState2() {
      int queuedCount2 = 0;
      Iterator iterator = this.owners.values().iterator();

      while (true) {
         if (!iterator.hasNext()) {
            this.queuedCount = queuedCount2;
            return;
         }

         PacketDelayLease packetDelayLease = (PacketDelayLease)iterator.next();
         queuedCount2 = Math.max(queuedCount2, packetDelayLease.delayMillis);

         ThreadLocalRandom.current().nextInt(7);
      }
   }

   public static Map<Object, PacketDelayLease> getOwners(IncomingPacketQueue incomingPacketQueue) {
      return incomingPacketQueue.owners;
   }

   public Vec3d computeVec3d(int intValue) {
      if (intValue < 0) {
         return Vec3dAccess4.getZERO();
      } else {
         double doubleValue = (0.0);
         double doubleValue2 = 0.0;
         double doubleValue3 = 0.0;
         Iterator iterator = this.queuedPackets.iterator();

         for (; iterator.hasNext(); ) {
            QueuedIncomingPacket queuedIncomingPacket = (QueuedIncomingPacket)iterator.next();
            if (queuedIncomingPacket.entityId == intValue) {
               doubleValue += getX(queuedIncomingPacket);
               doubleValue2 += queuedIncomingPacket.y;
               doubleValue3 += getZ(queuedIncomingPacket);
            }
         }

         return new Vec3d(doubleValue, doubleValue2, doubleValue3);
      }
   }

   public static long getQueuedAtMillis(QueuedIncomingPacket queuedIncomingPacket) {
      return queuedIncomingPacket.queuedAtMillis;
   }

   public static void setBooleanState(IncomingPacketQueue incomingPacketQueue, boolean booleanState2) {
      incomingPacketQueue.booleanState = booleanState2;
   }

   public static int getQueuedCount(IncomingPacketQueue incomingPacketQueue) {
      return incomingPacketQueue.queuedCount;
   }

   private static boolean testPacketDelayLease(long longValue, PacketDelayLease packetDelayLease) {
      return (getExpiresAtMillis(packetDelayLease) <= longValue);
   }

   private IncomingPacketQueue() {
      this.lock = new Object();
      this.workerRunning = new AtomicBoolean();
   }

   public static double getX(QueuedIncomingPacket queuedIncomingPacket) {
      return queuedIncomingPacket.x;
   }

   public static IncomingPacketQueue getINSTANCE() {
      return INSTANCE;
   }

   public boolean checkCondition() {
      byte byteValue;
      if (this.queuedCount > 0) {
         byteValue = 11;
         ThreadLocalRandom.current().nextInt(6);
         byteValue = 17;
         ThreadLocalRandom.current().nextInt(15);
         byteValue = 1;
      } else {
         byteValue = 0;
      }

      return (byteValue != 0);
   }

   public static AtomicBoolean getWorkerRunning(IncomingPacketQueue incomingPacketQueue) {
      return incomingPacketQueue.workerRunning;
   }

   public static void setQueuedCount(IncomingPacketQueue incomingPacketQueue, int queuedCount2) {
      incomingPacketQueue.queuedCount = queuedCount2;
   }

   public static ConcurrentLinkedDeque<QueuedIncomingPacket> getQueuedPackets(IncomingPacketQueue incomingPacketQueue) {
      return incomingPacketQueue.queuedPackets;
   }

   public void updateState3(Object objectValue, int intValue, long longValue) {
      if (objectValue != null) {
         if (intValue > 0) {
            if (longValue > 0L) {
               getOwners(this).put(objectValue, new PacketDelayLease(intValue, System.currentTimeMillis() + longValue));
               this.updateState2();
               return;
            }
         }

         this.updateState(objectValue);
      }
   }

   public static boolean getBooleanState(IncomingPacketQueue incomingPacketQueue) {
      return incomingPacketQueue.booleanState;
   }

   private void updateStateForQueuedIncomingPacket(QueuedIncomingPacket queuedIncomingPacket) {
      label27: {
         try {
            apply(queuedIncomingPacket.listener, queuedIncomingPacket.packet);
         } catch (RuntimeException failure) {
            AtomicBoolean workerRunning2 = getWorkerRunning(this);

            if (workerRunning2.compareAndSet(false, true)) {
               LOGGER.warn("Packet relay: inbound packet replay failed: {}", failure.getMessage());
            }
            break label27;
         }
      }
   }

   private void updateState4() {
      ThreadLocalRandom.current().nextInt(8);
      if (!getOwners(this).isEmpty()) {
         ThreadLocalRandom.current().nextInt(16);
         long longValue = System.currentTimeMillis();
         if (getOwners(this).values().removeIf(packetDelayLease -> testPacketDelayLease(longValue, packetDelayLease))) {
            this.updateState2();
         }
      }
   }

   public void updateState5() {
      this.owners.clear();
      synchronized (getLock(this)) {
         this.queuedPackets.clear();
         setBooleanState(this, false);
      }
      setQueuedCount(this, 0);
      this.flushing = false;
      getWorkerRunning(this).set(false);
   }

   public void updateState6() {
      this.updateState4();
      boolean flushAll = this.queuedCount <= 0 || this.flushing;
      this.flushing = false;
      long now = System.currentTimeMillis();
      while (true) {
         QueuedIncomingPacket queued;
         synchronized (this.lock) {
            queued = this.queuedPackets.peekFirst();
            if (queued == null || (!flushAll && getQueuedAtMillis(queued) > now)) {
               setBooleanState(this, false);
               break;
            }
            this.booleanState = true;
            this.queuedPackets.pollFirst();
         }
         this.updateStateForQueuedIncomingPacket(queued);
      }
   }

   public static double getZ(QueuedIncomingPacket queuedIncomingPacket) {
      return queuedIncomingPacket.z;
   }

   public boolean testPacketListener(PacketListener listener, Packet packet) {
      if (listener == null || packet == null) return false;
      this.updateState4();
      int delay = getQueuedCount(this);
      int entityId = -1;
      double deltaX = 0.0;
      double deltaY = 0.0;
      double deltaZ = 0.0;
      if (packet instanceof EntityS2CPacket movement && movement.isPositionChanged()) {
         entityId = ((EntityS2CPacketAccessor)movement).getEntityId();
         deltaX = (double)movement.getDeltaX() / 4096.0;
         deltaY = (double)movement.getDeltaY() / 4096.0;
         deltaZ = (double)movement.getDeltaZ() / 4096.0;
      }
      synchronized (this.lock) {
         if (delay <= 0 && getQueuedPackets(this).isEmpty() && !getBooleanState(this)) return false;
         long now = System.currentTimeMillis();
         long deadline = delay > 0 ? now + delay : now;
         this.queuedPackets.addLast(new QueuedIncomingPacket(listener, packet, deadline, entityId, deltaX, deltaY, deltaZ));
      }
      if (getQueuedPackets(this).size() > 8192) this.flushing = true;
      return true;
   }

   private static void apply(PacketListener packetListener, Packet packet) {
      packet.apply(packetListener);
   }

   public static long getExpiresAtMillis(PacketDelayLease packetDelayLease) {
      return packetDelayLease.expiresAtMillis;
   }

   public static Object getLock(IncomingPacketQueue incomingPacketQueue) {
      return incomingPacketQueue.lock;
   }
}
