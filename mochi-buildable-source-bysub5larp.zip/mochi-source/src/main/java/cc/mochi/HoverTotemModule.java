package cc.mochi;

import cc.mochi.event.impl.network.PacketEvent;
import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.event.types.TransferOrder;
import cc.mochi.mixin.HandledScreenAccessor;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.OptionalDouble;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.IntStream;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.screen.slot.Slot;

public final class HoverTotemModule extends Module {
   private boolean booleanState;

   public static final DoubleRangeSetting delayMSSetting;

   private final DoubleSetting sDThresholdSetting;
   private final DoubleSetting baseDelaySetting;

   public static final BooleanSetting autoOpenGUISetting;
   private final Random random;
   private final List<Long> longList;
   private final Stopwatch stopwatch;

   private boolean booleanState2;
   private int intState;

   static final boolean booleanState3;
   private final List<Double> doubleList;
   private final DoubleSetting variationSetting;

   public static final BooleanSetting ignoreOffhandSetting;

   public static boolean getBooleanState2(HoverTotemModule hoverTotemModule) {
      return hoverTotemModule.booleanState2;
   }

   @Override
   public void onEnable() {
      getStopwatch(this).updateTimestampMillis();
      super.onEnable();
   }

   public static DoubleSetting getVariationSetting(HoverTotemModule hoverTotemModule) {
      return hoverTotemModule.variationSetting;
   }

   public static void setBooleanState(HoverTotemModule hoverTotemModule, boolean booleanState4) {
      hoverTotemModule.booleanState = booleanState4;
   }

   public static Random getRandom(HoverTotemModule hoverTotemModule) {
      return hoverTotemModule.random;
   }

   public static Stopwatch getStopwatch(HoverTotemModule hoverTotemModule) {
      return hoverTotemModule.stopwatch;
   }

   static {
      byte byteValue;
      if (!HoverTotemModule.class.desiredAssertionStatus()) {
         byteValue = 1;
      } else {
         byteValue = 0;
      }

      booleanState3 = (byteValue != 0);

      delayMSSetting = new DoubleRangeSetting("Delay (MS)", 1.0, (1000.0), (200.0), 400.0, (0.5));
      ignoreOffhandSetting = new BooleanSetting("Ignore Offhand", false);
      autoOpenGUISetting = new BooleanSetting("Auto Open GUI", true);
   }

   private static ItemStack getStack(int intValue) {
      return mc.player.getInventory().getStack(intValue);
   }

   private double computeDoubleForList(List list) {
      OptionalDouble optionalDouble = list.stream().mapToDouble(objectValue -> ((Long)objectValue).doubleValue()).average();

      return optionalDouble.orElse((0.0));
   }

   private void updateState() {
      if (!this.isWorldUnavailable()) {
         if (MinecraftClientAccess48.getCurrentScreen(mc) instanceof InventoryScreen var1) {
            Slot focusedSlot = ((HandledScreenAccessor)var1).getFocusedSlot();
            if (focusedSlot != null) {
               ItemStack stack = focusedSlot.getStack();
               if (stack.getItem() != MinecraftClientAccess48.getTOTEM_OF_UNDYING()) {
               } else if (focusedSlot.getIndex() >= 9) {
                  byte byteValue;
                  label109: {
                     ItemStack offHandStack = mc.player.getOffHandStack();
                     if (!offHandStack.isEmpty()) {
                        if (offHandStack.getItem() == Items.TOTEM_OF_UNDYING || MinecraftClientAccess48.getIgnoreOffhandSetting().getValue()) {
                           byteValue = 0;
                           break label109;
                        }
                     }

                     byteValue = 1;
                  }

                  byte byteValue2 = byteValue;
                  int intValue = !this.checkCondition2() ? 1 : 0;
                  if (byteValue2 == 0) {
                     if (intValue == 0) {
                        return;
                     }

                     byteValue = 8;
                     ThreadLocalRandom.current().nextInt(4);
                  }

                  long longValue = this.computeLong();
                  Stopwatch stopwatch2 = getStopwatch(this);

                  if (stopwatch2.checkCondition2(longValue, true)) {
                     if (!getBooleanState3() && mc.player == null) {
                        byteValue = 18;
                        ThreadLocalRandom.current().nextInt(10);
                        throw new AssertionError();
                     }

                     if (!booleanState3) {
                        byteValue = 9;
                        ThreadLocalRandom.current().nextInt(3);
                        if (MinecraftClientAccess48.getInteractionManager(mc) == null) {
                           throw new AssertionError();
                        }
                     }

                     if (byteValue2 != 0) {
                        ClientPlayerInteractionManager interactionManager = MinecraftClientAccess48.getInteractionManager(mc);
                        int syncId2 = MinecraftClientAccess48.getSyncId(mc.player.currentScreenHandler);
                        int index = focusedSlot.getIndex();

                        interactionManager.clickSlot(syncId2, index, 40, MinecraftClientAccess48.getSWAP(), MinecraftClientAccess48.getPlayer(mc));
                     } else {
                        MinecraftClientAccess48.getInteractionManager(mc).clickSlot(MinecraftClientAccess48.getSyncId(MinecraftClientAccess48.getPlayer(mc).currentScreenHandler), focusedSlot.getIndex(), 0, MinecraftClientAccess48.getQUICK_MOVE(), MinecraftClientAccess48.getPlayer(mc));
                     }
                  }
               }
            }
         }
      }
   }

   public static List<Long> getLongList(HoverTotemModule hoverTotemModule) {
      return hoverTotemModule.longList;
   }

   private double computeDoubleForList2(List list) {
      OptionalDouble optionalDouble = list.stream().mapToDouble(objectValue -> (Double)objectValue).average();

      return optionalDouble.orElse((0.0));
   }

   private static void updateState2() {
      if (!(mc.currentScreen instanceof InventoryScreen)) {
         mc.setScreen(new InventoryScreen(MinecraftClientAccess48.getPlayer(mc)));
      }
   }

   private void updateState3() {
      if (getLongList(this).size() >= 2) {
         double doubleValue = this.computeDoubleForList(this.longList);

         double doubleValue2 = (0.0);
         Iterator iterator = getLongList(this).iterator();

         while (iterator.hasNext()) {
            long longValue = (Long)iterator.next();
            doubleValue2 += Math.pow((double)longValue - doubleValue, 2.0);
         }

         doubleValue2 /= (double)this.longList.size();
         double doubleValue3 = Math.sqrt(doubleValue2);
         this.doubleList.add(doubleValue3);
         if (this.doubleList.size() > 10) {
            this.doubleList.removeFirst();
         }
      }
   }

   public static void setBooleanState22(HoverTotemModule hoverTotemModule, boolean booleanState22) {
      hoverTotemModule.booleanState2 = booleanState22;
   }

   private long computeLong() {
      int intState2 = getIntState(this);

      this.intState = intState2 + 1;
      long longValue = (long)this.baseDelaySetting.intValue();
      int intValue = getVariationSetting(this).intValue();
      double value = this.sDThresholdSetting.getValue();
      double last = (getRandom(this).nextDouble() - 0.5) * (double)intValue;

      long longValue2 = (long)(last * (2.0));
      long longValue3 = System.currentTimeMillis();

      long longValue4 = longValue3 % 97L;

      longValue2 += longValue4 - (48L);
      if (this.intState % (3 + this.random.nextInt(3)) == 0) {
         longValue2 += this.random.nextBoolean() ? (long)this.random.nextInt(intValue) : (long)(-this.random.nextInt(intValue / 2));
      }

      if (this.doubleList.isEmpty()) {
         last = (0.0);
      } else {
         last = this.doubleList.getLast();
      }

      double last2 = last;

      if (last2 < value * (0.75)) {
         longValue2 += (long)((getRandom(this).nextDouble() - 0.5) * (double)intValue * 1.5);
      }

      long longValue5 = Math.max((80L), Math.min(2000L, longValue + longValue2));
      this.longList.add(longValue5);
      int intValue2 = this.longList.size();

      if (intValue2 > 10) {
         getLongList(this).removeFirst();
      }

      ThreadLocalRandom.current().nextInt(17);
      this.updateState3();
      return longValue5;
   }

   private static boolean testItemStack(ItemStack itemStack) {
      return (itemStack.getItem() == Items.TOTEM_OF_UNDYING);
   }

   public HoverTotemModule() {
      super("Hover Totem", "Puts a totem in your offhand and hotbar once hovered", -1, ModuleCategory.PLAYER);

      this.baseDelaySetting = new DoubleSetting("Base Delay", (50.0), 1000.0, (200.0), 1.0);

      this.variationSetting = new DoubleSetting("Variation", (10.0), 1000.0, 150.0, (1.0));

      this.sDThresholdSetting = new DoubleSetting("SD Threshold", (1.0), (500.0), 80.0, 1.0);
      this.stopwatch = new Stopwatch();
      this.random = new Random();
      this.longList = new ArrayList<>();
      this.doubleList = new ArrayList<>();
      this.intState = 0;

      this.booleanState2 = false;

      this.booleanState = false;

      Setting[] settingArray = new Setting[]{delayMSSetting, ignoreOffhandSetting, autoOpenGUISetting, null, null, null};

      settingArray[3] = this.baseDelaySetting;
      settingArray[4] = this.variationSetting;

      settingArray[5] = this.sDThresholdSetting;
      this.addSettings(settingArray);
   }

   private static void updateState4() {
      if (mc.currentScreen == null) {
         mc.setScreen(new InventoryScreen(MinecraftClientAccess48.getPlayer(mc)));
      }
   }

   private boolean checkCondition() {
      if (this.isWorldUnavailable()) {
         return true;
      } else {
         byte byteValue;
         label45: {
            ItemStack offHandStack = MinecraftClientAccess48.getPlayer(mc).getOffHandStack();
            if (offHandStack.getItem() != MinecraftClientAccess48.getTOTEM_OF_UNDYING()) {
               if (!ignoreOffhandSetting.getValue()) {
                  byteValue = 0;
                  break label45;
               }
            }

            byteValue = 1;
         }

         byte byteValue2 = byteValue;
         boolean booleanValue = this.checkCondition2();
         if (byteValue2 != 0) {
            if (booleanValue) {
               return true;
            }
         }

         return false;
      }
   }

   public static int getIntState(HoverTotemModule hoverTotemModule) {
      return hoverTotemModule.intState;
   }

   private boolean checkCondition2() {
      ThreadLocalRandom.current().nextInt(13);
      if (this.isWorldUnavailable()) {
         return false;
      } else {
         ThreadLocalRandom.current().nextInt(17);
         return IntStream.range(0, 9).mapToObj(intValue -> getStack(intValue)).anyMatch(itemStack -> testItemStack((ItemStack)itemStack));
      }
   }

   @Override
   public void onDisable() {
      getStopwatch(this).updateTimestampMillis();
      this.booleanState2 = false;
      this.booleanState = false;
      super.onDisable();
   }

   @EventHandler
   private void onTickEvent(TickEvent tickEvent) {
      if (!this.isWorldUnavailable()) {
         this.updateState();
         if (getBooleanState2(this)) {
            if (this.booleanState) {
               if (this.checkCondition()) {
                  if (MinecraftClientAccess48.getCurrentScreen(mc) instanceof InventoryScreen) {
                     setBooleanState22(this, false);
                     setBooleanState(this, false);
                     mc.player.closeHandledScreen();
                  }
               }
            }
         }
      }
   }

   public static boolean getBooleanState3() {
      return booleanState3;
   }

   @EventHandler
   private void onPacketEvent(PacketEvent packetEvent) {
      if (!this.isWorldUnavailable()) {
         if (packetEvent.getOrder() == TransferOrder.RECEIVE) {
            if (packetEvent.getPacket() instanceof EntityStatusS2CPacket var2) {
               if (var2.getStatus() == 35) {
                  ThreadLocalRandom.current().nextInt(14);
                  Entity entity = var2.getEntity(MinecraftClientAccess48.getWorld(mc));
                  if (entity != null) {
                     if (entity.equals(mc.player)) {
                        if (!this.checkCondition()) {
                           setBooleanState22(this, true);

                           this.booleanState = true;
                           if (autoOpenGUISetting.getValue()) {
                              mc.execute(() -> updateState4());
                           }
                        } else {
                           setBooleanState22(this, false);
                           setBooleanState(this, false);
                        }
                     }
                  }
               } else {
                  ThreadLocalRandom.current().nextInt(3);
               }
            }
         }

         if (packetEvent.getOrder() == TransferOrder.SEND) {
            if (packetEvent.getPacket().getClass().getSimpleName().contains("CloseHandledScreen")) {
               if (getBooleanState2(this)) {
                  if (!this.checkCondition()) {
                     packetEvent.setCancelled(true);
                     if (MinecraftClientAccess48.getAutoOpenGUISetting().getValue()) {
                        ThreadLocalRandom.current().nextInt(11);

                        mc.execute(() -> updateState2());
                     }
                  } else {
                     ThreadLocalRandom.current().nextInt(10);
                     this.booleanState2 = false;
                  }
               }
            }
         }
      }
   }

}
