package cc.mochi;

import java.awt.Color;

public class ColorAccess3 {
   public static Color getWHITE() {
      return Color.WHITE;
   }

   public static ButtonVariant getDANGER() {
      return ButtonVariant.DANGER;
   }
}
