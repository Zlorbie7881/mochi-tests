package cc.mochi;

public class ClickGuiTabAccess {
   public static String getDetail(ClickGuiTab clickGuiTab) {
      return clickGuiTab.detail;
   }

   public static Icon getPALETTE() {
      return Icon.PALETTE;
   }

   public static String getLabel(ClickGuiTab clickGuiTab) {
      return clickGuiTab.label;
   }

   public static ChoiceSetting getThemeSetting() {
      return ClickGuiModule.themeSetting;
   }

   public static String getKeywords(ClickGuiTab clickGuiTab) {
      return clickGuiTab.keywords;
   }

   public static Icon getIcon(ClickGuiTab clickGuiTab) {
      return clickGuiTab.icon;
   }
}
