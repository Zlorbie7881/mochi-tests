package cc.mochi;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.texture.GlTexture;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL33;

public final class GlassBackdropRenderer {
   private static boolean booleanState;

   private static int intState;
   private static final GlFramebufferTarget glFramebufferTarget = new GlFramebufferTarget();

   private static boolean booleanState2;
   private static int intState2 = -1;
   private static int intState3;

   private static int intState4 = -1;

   public static boolean isNotBooleanState2() {
      return !booleanState2;
   }

   private GlassBackdropRenderer() {
   }

   public static boolean checkCondition(float floatValue) {
      RenderSystem.assertOnRenderThread();
      if (!checkCondition3()) {
         return false;
      } else {
         MinecraftClient minecraftClient = MinecraftClient.getInstance();
         Framebuffer framebuffer = minecraftClient == null ? null : minecraftClient.getFramebuffer();
         if (framebuffer != null && framebuffer.getColorAttachment() instanceof GlTexture var3) {
            int glId = var3.getGlId();
            int textureWidth = framebuffer.textureWidth;
            int textureHeight = framebuffer.textureHeight;
            if (glId != 0 && textureWidth > 0 && textureHeight > 0 && GL11.glIsTexture(glId)) {
               OpenGlStateSnapshot openGlStateSnapshot = OpenGlStateSnapshot.capture();

               try {
                  if (checkCondition2(Math.max(1, textureWidth / 2), Math.max(1, textureHeight / 2))) {
                     GL11.glDisable(GL11.GL_BLEND);
                     GL11.glDisable(GL11.GL_DEPTH_TEST);
                     GL11.glDepthMask(false);
                     GL11.glDisable(GL11.GL_CULL_FACE);
                     GL11.glDisable(GL11.GL_SCISSOR_TEST);
                     GL11.glDisable(GL11.GL_STENCIL_TEST);
                     GL11.glColorMask(true, true, true, true);
                     GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, intState3);
                     GL11.glViewport(0, 0, intState2, intState4);
                     GL13.glActiveTexture(GL13.GL_TEXTURE0);
                     GL11.glBindTexture(GL11.GL_TEXTURE_2D, glId);
                     GL33.glBindSampler(0, 0);
                     ShaderProgramCache.bind("glass_backdrop");
                     ShaderProgramCache.uniform1i("glass_backdrop", "u_input", 0);
                     ShaderProgramCache.uniform2f("glass_backdrop", "u_texel", 1.0F / (float)textureWidth, 1.0F / (float)textureHeight);
                     ShaderProgramCache.uniform1f("glass_backdrop", "u_radius", Math.max(1.0F, floatValue));
                     ShaderProgramCache.uniform1i("glass_backdrop", "u_samplePairs", 32);
                     glFramebufferTarget.draw();

                     return true;
                  }

                  updateState2("BackdropBlur: cache framebuffer creation failed");
               } catch (RuntimeException failure) {
                  updateState2("BackdropBlur: disabled after an OpenGL failure: " + failure.getMessage());
                  return false;
               } finally {
                  openGlStateSnapshot.restore();
               }

               return false;
            } else {
               return false;
            }
         } else {
            return false;
         }
      }
   }

   public static int computeInt() {
      return intState != 0 && GL11.glIsTexture(intState) ? intState : 0;
   }

   private static boolean checkCondition2(int intState22, int intState42) {
      if (intState3 != 0 && intState2 == intState22 && intState4 == intState42 && GL30.glIsFramebuffer(intState3) && GL11.glIsTexture(intState)) {
         return true;
      } else {
         updateState();
         intState = GL11.glGenTextures();
         intState3 = GL30.glGenFramebuffers();
         if (intState != 0 && intState3 != 0) {
            GL11.glBindTexture(GL11.GL_TEXTURE_2D, intState);
            GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA8, intState22, intState42, 0, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, 0L);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, org.lwjgl.opengl.GL12.GL_CLAMP_TO_EDGE);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, org.lwjgl.opengl.GL12.GL_CLAMP_TO_EDGE);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, org.lwjgl.opengl.GL12.GL_TEXTURE_BASE_LEVEL, 0);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, org.lwjgl.opengl.GL12.GL_TEXTURE_MAX_LEVEL, 0);
            GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, intState3);
            GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, intState, 0);
            GL11.glDrawBuffer(36064);
            if (GL30.glCheckFramebufferStatus(GL30.GL_FRAMEBUFFER) != 36053) {
               updateState();
               return false;
            } else {
               intState2 = intState22;
               intState4 = intState42;
               return true;
            }
         } else {
            updateState();
            return false;
         }
      }
   }

   private static void updateState() {
      if (intState3 != 0 && GL30.glIsFramebuffer(intState3)) {
         GL30.glDeleteFramebuffers(intState3);
      }

      if (intState != 0 && GL11.glIsTexture(intState)) {
         GL11.glDeleteTextures(intState);
      }

      intState3 = 0;
      intState = 0;
      intState2 = -1;
      intState4 = -1;
   }

   private static void updateState2(String string) {
      booleanState2 = true;
      if (!booleanState) {
         booleanState = true;
      }
   }

   private static boolean checkCondition3() {
      RenderSystem.assertOnRenderThread();
      if (booleanState2) {
         return false;
      } else {
         Integer integer = ShaderProgramCache.get("glass_backdrop");
         if (integer == null || integer == 0 || !GL20.glIsProgram(integer)) {
            integer = ShaderProgramCache.loadProgram("glass_backdrop", "shaders/glass/glass.vsh", "shaders/glass/backdrop.fsh");
         }

         if (integer == 0) {
            updateState2("BackdropBlur: shader initialization failed");
            return false;
         } else if (glFramebufferTarget.isValid()) {
            return true;
         } else {
            OpenGlStateSnapshot openGlStateSnapshot = OpenGlStateSnapshot.capture();

            try {
               if (!glFramebufferTarget.ensureInitialized()) {
                  updateState2("BackdropBlur: full-screen geometry initialization failed");
                  return false;
               }
            } finally {
               openGlStateSnapshot.restore();
            }

            return true;
         }
      }
   }

   public static void updateState3() {
      RenderSystem.assertOnRenderThread();
      updateState();
      glFramebufferTarget.destroy();
      ShaderProgramCache.deleteProgram("glass_backdrop");
      booleanState2 = false;
      booleanState = false;
   }
}
