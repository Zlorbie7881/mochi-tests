package cc.mochi;

import java.awt.Color;
import net.minecraft.util.Identifier;

abstract class DelegatingRenderBackend implements UiRenderBackend {
   protected final UiRenderBackend uiRenderBackend;

   @Override
   public void drawText(String text, float x, float y, float size, Color color, FontFace font) {
      this.run(() -> this.drawText2(text, x, y, size, color, font));
   }

   private void drawLineSegment2(float startX, float startY, float endX, float endY, float thickness, Color color) {
      this.uiRenderBackend.drawLineSegment(startX, startY, endX, endY, thickness, color);
   }

   private void drawTextureRegion2(
      Identifier identifier,
      float floatValue,
      float floatValue2,
      float floatValue3,
      float floatValue4,
      float floatValue5,
      float floatValue6,
      int intValue,
      int intValue2,
      int intValue3,
      int intValue4,
      float floatValue7,
      Color color
   ) {
      this.uiRenderBackend.drawTextureRegion(identifier, floatValue, floatValue2, floatValue3, floatValue4, floatValue5, floatValue6, intValue, intValue2, intValue3, intValue4, floatValue7, color);
   }

   @Override
   public void popBloom() {
      this.run(() -> this.uiRenderBackend.popBloom());
   }

   @Override
   public void pushOpacity(float opacity) {
      this.run(() -> this.pushOpacity2(opacity));
   }

   @Override
   public void pushBloom(float intensity) {
      this.run(() -> this.pushBloom2(intensity));
   }

   protected float render(FloatRenderCall floatRenderCall) {
      return floatRenderCall.render();
   }

   private void fillAngledGradient2(float x, float y, float width, float height, float radius, Color startColor, Color endColor, float angle) {
      this.uiRenderBackend.fillAngledGradient(x, y, width, height, radius, startColor, endColor, angle);
   }

   @Override
   public boolean isFallback() {
      return this.uiRenderBackend.isFallback();
   }

   @Override
   public void fillAngledGradient(float x, float y, float width, float height, float radius, Color startColor, Color endColor, float angle) {
      this.run(() -> this.fillAngledGradient2(x, y, width, height, radius, startColor, endColor, angle));
   }

   @Override
   public void popOpacity() {
      this.run(() -> this.uiRenderBackend.popOpacity());
   }

   @Override
   public void fillCircle(float centerX, float centerY, float radius, Color color) {
      this.run(() -> this.fillCircle2(centerX, centerY, radius, color));
   }

   private void rotate2(float angle) {
      this.uiRenderBackend.rotate(angle);
   }

   private void pushBloom2(float intensity) {
      this.uiRenderBackend.pushBloom(intensity);
   }

   @Override
   public void drawTextureFromResource(String string, float x, float y, float width, float height, Color color) {
      this.run(() -> this.drawTextureFromResource2(string, x, y, width, height, color));
   }

   @Override
   public void applyClip() {
      this.run(() -> this.uiRenderBackend.applyClip());
   }

   private void scale2(float scaleX, float scaleY) {
      this.uiRenderBackend.scale(scaleX, scaleY);
   }

   @Override
   public void strokeRoundedRect(float x, float y, float width, float height, float radius, float thickness, Color color) {
      this.run(() -> this.strokeRoundedRect2(x, y, width, height, radius, thickness, color));
   }

   @Override
   public void translate(float offsetX, float offsetY) {
      this.run(() -> this.translate2(offsetX, offsetY));
   }

   private void setClip2(float x, float y, float width, float height) {
      this.uiRenderBackend.setClip(x, y, width, height);
   }

   private void strokeCircle2(float centerX, float centerY, float radius, float thickness, Color color) {
      this.uiRenderBackend.strokeCircle(centerX, centerY, radius, thickness, color);
   }

   private void drawLine2(float startX, float startY, float endX, float endY, float thickness, Color color) {
      this.uiRenderBackend.drawLine(startX, startY, endX, endY, thickness, color);
   }

   @Override
   public void setClip(float x, float y, float width, float height) {
      this.run(() -> this.setClip2(x, y, width, height));
   }

   @Override
   public void drawRoundedTexture(String string, float x, float y, float width, float height, float radius, Color color) {
      this.run(() -> this.drawRoundedTexture2(string, x, y, width, height, radius, color));
   }

   private void drawGlowOutline2(float x, float y, float width, float height, float radius, float blur, float spread, Color color) {
      this.uiRenderBackend.drawGlowOutline(x, y, width, height, radius, blur, spread, color);
   }

   private void fillRoundedRect2(float x, float y, float width, float height, float radius, Color color) {
      this.uiRenderBackend.fillRoundedRect(x, y, width, height, radius, color);
   }

   @Override
   public void drawLineSegment(float startX, float startY, float endX, float endY, float thickness, Color color) {
      this.run(() -> this.drawLineSegment2(startX, startY, endX, endY, thickness, color));
   }

   @Override
   public void popClip() {
      this.run(() -> this.uiRenderBackend.popClip());
   }

   private void fillGlowingRoundedRect2(float x, float y, float width, float height, float radius, Color color, Color color2, float blur, float spread) {
      this.uiRenderBackend.fillGlowingRoundedRect(x, y, width, height, radius, color, color2, blur, spread);
   }

   private float measureText2(String text, float size, FontFace font) {
      return this.uiRenderBackend.measureText(text, size, font);
   }

   private void drawCamouflage2(float x, float y, float width, float height, float radius) {
      this.uiRenderBackend.drawCamouflage(x, y, width, height, radius);
   }

   @Override
   public float measureFontHeight(float size, FontFace font) {
      return this.render(() -> this.measureFontHeight2(size, font));
   }

   private void translate2(float offsetX, float offsetY) {
      this.uiRenderBackend.translate(offsetX, offsetY);
   }

   @Override
   public void drawGlowOutline(float x, float y, float width, float height, float radius, float blur, float spread, Color color) {
      this.run(() -> this.drawGlowOutline2(x, y, width, height, radius, blur, spread, color));
   }

   private void drawRoundedTexture2(String string, float x, float y, float width, float height, float radius, Color color) {
      this.uiRenderBackend.drawRoundedTexture(string, x, y, width, height, radius, color);
   }

   private void pushOpacity2(float opacity) {
      this.uiRenderBackend.pushOpacity(opacity);
   }

   private void fillCircle2(float centerX, float centerY, float radius, Color color) {
      this.uiRenderBackend.fillCircle(centerX, centerY, radius, color);
   }

   protected void run(Runnable runnable) {
      runnable.run();
   }

   @Override
   public void drawShadow(float x, float y, float width, float height, float radius, float blur, float offset, Color color) {
      this.run(() -> this.drawShadow2(x, y, width, height, radius, blur, offset, color));
   }

   private boolean drawAurora2(int[] intArray, int intValue, float floatValue, float floatValue2, float floatValue3) {
      return this.uiRenderBackend.drawAurora(intArray, intValue, floatValue, floatValue2, floatValue3);
   }

   @Override
   public boolean drawAurora(int[] intArray, int intValue, float floatValue, float floatValue2, float floatValue3) {
      return this.render2(() -> this.drawAurora2(intArray, intValue, floatValue, floatValue2, floatValue3));
   }

   private void fillHorizontalGradient2(float x, float y, float width, float height, float radius, Color leftColor, Color rightColor) {
      this.uiRenderBackend.fillHorizontalGradient(x, y, width, height, radius, leftColor, rightColor);
   }

   private void drawText2(String text, float x, float y, float size, Color color, FontFace font) {
      this.uiRenderBackend.drawText(text, x, y, size, color, font);
   }

   @Override
   public void fillRect(float x, float y, float width, float height, Color color) {
      this.run(() -> this.fillRect2(x, y, width, height, color));
   }

   private void strokeRoundedRect2(float x, float y, float width, float height, float radius, float thickness, Color color) {
      this.uiRenderBackend.strokeRoundedRect(x, y, width, height, radius, thickness, color);
   }

   private void drawTextureFromResource2(String string, float x, float y, float width, float height, Color color) {
      this.uiRenderBackend.drawTextureFromResource(string, x, y, width, height, color);
   }

   @Override
   public void strokeCircle(float centerX, float centerY, float radius, float thickness, Color color) {
      this.run(() -> this.strokeCircle2(centerX, centerY, radius, thickness, color));
   }

   @Override
   public void fillGlowingRoundedRect(float x, float y, float width, float height, float radius, Color color, Color color2, float blur, float spread) {
      this.run(() -> this.fillGlowingRoundedRect2(x, y, width, height, radius, color, color2, blur, spread));
   }

   @Override
   public float measureText(String text, float size, FontFace font) {
      return this.render(() -> this.measureText2(text, size, font));
   }

   protected boolean render2(BooleanRenderCall booleanRenderCall) {
      return booleanRenderCall.render();
   }

   @Override
   public void strokeArc(float centerX, float centerY, float radius, float thickness, float startAngle, float sweepAngle, Color color) {
      this.run(() -> this.strokeArc2(centerX, centerY, radius, thickness, startAngle, sweepAngle, color));
   }

   private void fillRoundedCorners2(float x, float y, float width, float height, float topLeftRadius, float topRightRadius, float bottomRightRadius, float bottomLeftRadius, Color color) {
      this.uiRenderBackend.fillRoundedCorners(x, y, width, height, topLeftRadius, topRightRadius, bottomRightRadius, bottomLeftRadius, color);
   }

   private void fillRect2(float x, float y, float width, float height, Color color) {
      this.uiRenderBackend.fillRect(x, y, width, height, color);
   }

   @Override
   public void fillRoundedRect(float x, float y, float width, float height, float radius, Color color) {
      this.run(() -> this.fillRoundedRect2(x, y, width, height, radius, color));
   }

   @Override
   public void fillHorizontalGradient(float x, float y, float width, float height, float radius, Color leftColor, Color rightColor) {
      this.run(() -> this.fillHorizontalGradient2(x, y, width, height, radius, leftColor, rightColor));
   }

   @Override
   public void pushClip(float x, float y, float width, float height) {
      this.run(() -> this.pushClip2(x, y, width, height));
   }

   @Override
   public void rotate(float angle) {
      this.run(() -> this.rotate2(angle));
   }

   protected DelegatingRenderBackend(UiRenderBackend uiRenderBackend2) {
      this.uiRenderBackend = uiRenderBackend2;
   }

   private void drawShadow2(float x, float y, float width, float height, float radius, float blur, float offset, Color color) {
      this.uiRenderBackend.drawShadow(x, y, width, height, radius, blur, offset, color);
   }

   @Override
   public void fillVerticalGradient(float x, float y, float width, float height, float radius, Color topColor, Color bottomColor) {
      this.run(() -> this.fillVerticalGradient2(x, y, width, height, radius, topColor, bottomColor));
   }

   private void strokeArc2(float centerX, float centerY, float radius, float thickness, float startAngle, float sweepAngle, Color color) {
      this.uiRenderBackend.strokeArc(centerX, centerY, radius, thickness, startAngle, sweepAngle, color);
   }

   @Override
   public void flushBloom() {
      this.run(() -> this.uiRenderBackend.flushBloom());
   }

   @Override
   public void drawLine(float startX, float startY, float endX, float endY, float thickness, Color color) {
      this.run(() -> this.drawLine2(startX, startY, endX, endY, thickness, color));
   }

   @Override
   public void fillRoundedCorners(float x, float y, float width, float height, float topLeftRadius, float topRightRadius, float bottomRightRadius, float bottomLeftRadius, Color color) {
      this.run(() -> this.fillRoundedCorners2(x, y, width, height, topLeftRadius, topRightRadius, bottomRightRadius, bottomLeftRadius, color));
   }

   @Override
   public void pushTransform() {
      this.run(() -> this.uiRenderBackend.pushTransform());
   }

   @Override
   public void drawCamouflage(float x, float y, float width, float height, float radius) {
      this.run(() -> this.drawCamouflage2(x, y, width, height, radius));
   }

   private void fillVerticalGradient2(float x, float y, float width, float height, float radius, Color topColor, Color bottomColor) {
      this.uiRenderBackend.fillVerticalGradient(x, y, width, height, radius, topColor, bottomColor);
   }

   @Override
   public boolean drawGlassPanel(GlassPanelStyle glassPanelStyle) {
      return this.render2(() -> this.drawGlassPanel2(glassPanelStyle));
   }

   private boolean drawGlassPanel2(GlassPanelStyle glassPanelStyle) {
      return this.uiRenderBackend.drawGlassPanel(glassPanelStyle);
   }

   @Override
   public void drawTextureRegion(
      Identifier identifier,
      float floatValue,
      float floatValue2,
      float floatValue3,
      float floatValue4,
      float floatValue5,
      float floatValue6,
      int intValue,
      int intValue2,
      int intValue3,
      int intValue4,
      float floatValue7,
      Color color
   ) {
      this.run(() -> this.drawTextureRegion2(identifier, floatValue, floatValue2, floatValue3, floatValue4, floatValue5, floatValue6, intValue, intValue2, intValue3, intValue4, floatValue7, color));
   }

   private void pushClip2(float x, float y, float width, float height) {
      this.uiRenderBackend.pushClip(x, y, width, height);
   }

   private float measureFontHeight2(float size, FontFace font) {
      return this.uiRenderBackend.measureFontHeight(size, font);
   }

   @Override
   public void popTransform() {
      this.run(() -> this.uiRenderBackend.popTransform());
   }

   @Override
   public void scale(float scaleX, float scaleY) {
      this.run(() -> this.scale2(scaleX, scaleY));
   }
}
