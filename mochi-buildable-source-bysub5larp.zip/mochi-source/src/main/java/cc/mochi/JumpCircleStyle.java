package cc.mochi;

public final class JumpCircleStyle {
   public boolean booleanState;
   public boolean booleanState2;

   public float floatState;
   public float floatState2;
   public int intState;
   public float floatState3;
   public float floatState4 = 1.15F;
   public boolean booleanState3;

   public JumpCircleStyle() {
      this.floatState = 1.4F;
      this.floatState3 = 1.8F;
      this.floatState2 = 1.0F;
      this.intState = 2;
      this.booleanState2 = true;
      this.booleanState = true;
   }
}
