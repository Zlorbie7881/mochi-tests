package cc.mochi;

import java.awt.Color;

public enum MessageSeverity {
   INFO(Color.GREEN),
   WARNING(Color.ORANGE),
   ERROR(Color.RED);

   private static final MessageSeverity[] ENUM_VALUES = {INFO, WARNING, ERROR};

   private final int color;
   private final String name;

   public static MessageSeverity[] getENUM_VALUES() {
      return ENUM_VALUES;
   }

   public static int getColor(MessageSeverity messageSeverity) {
      return messageSeverity.color;
   }

   private MessageSeverity(Color color2) {
      this.color = color2.getRGB();
      this.name = ThreadLocalRandomAccess.computeString(this.name());
   }

   public int getColor2() {
      return getColor(this);
   }

   public String getName() {
      return this.name;
   }

   private static MessageSeverity[] computeMessageSeverityArray() {
      MessageSeverity[] messageSeverityArray = new MessageSeverity[]{INFO, null, null};

      messageSeverityArray[1] = WARNING;

      messageSeverityArray[2] = ERROR;
      return messageSeverityArray;
   }
}
