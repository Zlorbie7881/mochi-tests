package cc.mochi;

import java.io.File;
import java.lang.instrument.Instrumentation;
import java.net.URI;
import java.net.URL;
import java.util.concurrent.ThreadLocalRandom;

public class FabricAgentBootstrap {
   public static void registerAgentMod(String string, Instrumentation instrumentation) {
      try {
         addToFabricMods();
      } catch (Exception failure) {
         return;
      }
   }

   private static String findJarPath() {
      URI uri;
      label70: {
         URL location;
         label71: {
            String string;
            try {
               location = FabricAgentBootstrap.class.getProtectionDomain().getCodeSource().getLocation();
               string = location.toString();
               if (!string.startsWith("jar:file:")) {
                  break label71;
               }
            } catch (Exception failure) {
               return null;
            }

            ThreadLocalRandom.current().nextInt(11);

            label72: {
               int intValue;
               label73: {
                  try {
                     intValue = string.indexOf(33);
                     if (intValue >= 0) {
                        break label73;
                     }
                  } catch (Exception failure2) {
                     return null;
                  }

                  try {
                     string = string.substring(9);
                  } catch (Exception failure3) {
                     return null;
                  }

                  break label72;
               }

               try {
                  string = string.substring(9, intValue);
               } catch (Exception failure4) {
                  return null;
               }
            }

            try {
               uri = new URI(string);
               break label70;
            } catch (Exception failure5) {
               return null;
            }
         }

         try {
            uri = location.toURI();
         } catch (Exception failure6) {
            return null;
         }
      }

      try {
         File file = new File(uri);
         return file.getAbsolutePath();
      } catch (Exception failure7) {
         return null;
      }
   }

   private static void addToFabricMods() throws Exception {
      String string = findJarPath();
      if (string == null) {
         ThreadLocalRandom.current().nextInt(4);
         throw new Exception("Could not determine JAR file path");
      } else {
         File file = new File(string);
         if (!file.exists()) {
            throw new Exception("JAR file does not exist: " + string);
         } else {
            String property = System.getProperty("fabric.addMods");
            if (property != null) {
               if (!property.isEmpty()) {
                  String pathSeparator = FileAccess.getPathSeparator();
                  System.setProperty("fabric.addMods", property + pathSeparator + string);
                  return;
               }
            }

            System.setProperty("fabric.addMods", string);
         }
      }
   }
}
