package cc.mochi;

import net.minecraft.util.math.BlockPos;

public record BlockExposure(BlockPos cell, double exposure) {
   public static BlockPos getCell(BlockExposure blockExposure) {
      return blockExposure.cell;
   }

   public double getExposure() {
      return this.exposure;
   }

   public BlockPos getCell2() {
      return getCell(this);
   }
}
