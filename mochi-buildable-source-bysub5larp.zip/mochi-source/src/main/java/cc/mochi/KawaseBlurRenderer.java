package cc.mochi;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.GlTexture;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL33;

public final class KawaseBlurRenderer {
   private static final GlFramebufferTarget glFramebufferTarget = new GlFramebufferTarget();
   private static boolean booleanState;
   private static final List<RenderTarget> renderTargetList = new ArrayList<>();

   private static int intState = -1;

   private static boolean booleanState2;

   private static int intState2 = -1;

   private static boolean checkCondition(int intState3, int intState22) {
      if (intState == intState3 && intState2 == intState22 && renderTargetList.size() == 4) {
         for (RenderTarget renderTarget : renderTargetList) {
            if (!GL30.glIsFramebuffer(renderTarget.getFramebuffer()) || !GL11.glIsTexture(renderTarget.getTexture())) {
               updateState7();
               break;
            }
         }

         if (renderTargetList.size() == 4) {
            return true;
         }
      }

      updateState7();
      int intState32 = intState3;
      int intState222 = intState22;

      for (int intValue3 = 0; intValue3 < 4; intValue3++) {
         intState32 = Math.max(1, intState32 / 2);
         intState222 = Math.max(1, intState222 / 2);
         RenderTarget renderTarget2 = computeRenderTarget(intState32, intState222);
         if (renderTarget2 == null) {
            updateState7();
            return false;
         }

         renderTargetList.add(renderTarget2);
      }

      intState = intState3;
      intState2 = intState22;
      return true;
   }

   public static boolean isNotBooleanState2() {
      return !booleanState2;
   }

   public static void updateState(float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5) {
      updateState8(floatValue, floatValue2, floatValue3, floatValue4, floatValue5, ((-1.0F)));
   }

   public static void updateState2() {
      updateState(((-1.0F)), ((-1.0F)), ((-1.0F)), ((-1.0F)), 1.0F);
   }

   private static void updateState3(String string) {
      if (!booleanState) {
         booleanState = true;
      }
   }

   public static boolean testRoundedBlurRegion(RoundedBlurRegion roundedBlurRegion, float floatValue, BlurQuality blurQuality) {
      return roundedBlurRegion != null && !roundedBlurRegion.checkCondition2() ? testBlurQuality2(roundedBlurRegion.getX(), roundedBlurRegion.getY(), roundedBlurRegion.getWidth(), roundedBlurRegion.getHeight(), floatValue, roundedBlurRegion.getRadius(), blurQuality) : false;
   }

   private static boolean checkCondition2() {
      RenderSystem.assertOnRenderThread();
      if (booleanState2) {
         return false;
      } else {
         Integer integer = ShaderProgramCache.get("kawase");
         if (integer == null || integer == 0 || !GL20.glIsProgram(integer)) {
            integer = ShaderProgramCache.loadProgram("kawase", "shaders/post/kawase.vsh", "shaders/post/kawase.fsh");
         }

         if (integer == 0) {
            updateState6("KawaseBlur: shader initialization failed; using the caller's glass fallback");
            return false;
         } else if (glFramebufferTarget.isValid()) {
            return true;
         } else {
            OpenGlStateSnapshot openGlStateSnapshot = OpenGlStateSnapshot.capture();

            try {
               if (!glFramebufferTarget.ensureInitialized()) {
                  updateState6("KawaseBlur: full-screen geometry initialization failed");
                  return false;
               }
            } finally {
               openGlStateSnapshot.restore();
            }

            return true;
         }
      }
   }

   public static void updateState4(float floatValue, float floatValue2, float floatValue3, float floatValue4) {
      updateState(floatValue, floatValue2, floatValue3, floatValue4, 1.0F);
   }

   private static boolean checkCondition3(float floatValue, float floatValue2, float floatValue3, float floatValue4) {
      return Float.isFinite(floatValue)
         && Float.isFinite(floatValue2)
         && Float.isFinite(floatValue3)
         && Float.isFinite(floatValue4)
         && floatValue >= 0.0F
         && floatValue2 >= 0.0F
         && floatValue3 > 0.0F
         && floatValue4 > 0.0F;
   }

   private static int[] computeIntArray(int intValue) {
      GL13.glActiveTexture(GL13.GL_TEXTURE0);
      GL11.glBindTexture(GL11.GL_TEXTURE_2D, intValue);
      return new int[]{GL11.glGetTexLevelParameteri(3553, 0, 4096), GL11.glGetTexLevelParameteri(3553, 0, 4097)};
   }

   private static float max(float floatValue, float floatValue2, float floatValue3) {
      return Math.max(floatValue2, Math.min(floatValue3, floatValue));
   }

   public static void updateState5() {
      RenderSystem.assertOnRenderThread();
      updateState7();
      MainFramebufferBridge.delete();
      glFramebufferTarget.destroy();
      ShaderProgramCache.deleteProgram("kawase");
      booleanState2 = false;
      booleanState = false;
   }

   private static RenderTarget computeRenderTarget(int intValue, int intValue2) {
      int intValue3 = GL11.glGenTextures();
      int intValue4 = GL30.glGenFramebuffers();
      if (intValue3 != 0 && intValue4 != 0) {
         GL11.glBindTexture(GL11.GL_TEXTURE_2D, intValue3);
         GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA8, intValue, intValue2, 0, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, 0L);
         GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
         GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
         GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, org.lwjgl.opengl.GL12.GL_CLAMP_TO_EDGE);
         GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, org.lwjgl.opengl.GL12.GL_CLAMP_TO_EDGE);
         GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, intValue4);
         GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, intValue3, 0);
         GL11.glDrawBuffer(36064);
         int intValue5 = GL30.glCheckFramebufferStatus(GL30.GL_FRAMEBUFFER);
         if (intValue5 != 36053) {
            GL30.glDeleteFramebuffers(intValue4);
            GL11.glDeleteTextures(intValue3);
            return null;
         } else {
            return new RenderTarget(intValue4, intValue3, intValue, intValue2);
         }
      } else {
         if (intValue3 != 0) {
            GL11.glDeleteTextures(intValue3);
         }

         if (intValue4 != 0) {
            GL30.glDeleteFramebuffers(intValue4);
         }

         return null;
      }
   }

   private KawaseBlurRenderer() {
   }

   private static void updateState6(String string) {
      booleanState2 = true;
      if (!booleanState) {
         booleanState = true;
      }
   }

   private static void updateState7() {
      for (RenderTarget renderTarget : renderTargetList) {
         if (GL30.glIsFramebuffer(renderTarget.getFramebuffer())) {
            GL30.glDeleteFramebuffers(renderTarget.getFramebuffer());
         }

         if (GL11.glIsTexture(renderTarget.getTexture())) {
            GL11.glDeleteTextures(renderTarget.getTexture());
         }
      }

      renderTargetList.clear();
      intState = -1;
      intState2 = -1;
   }

   public static void updateState8(float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5, float floatValue6) {
      testBlurQuality2(floatValue, floatValue2, floatValue3, floatValue4, floatValue5, floatValue6, BlurQuality.QUALITY);
   }

   public static boolean testBlurQuality(float floatValue, BlurQuality blurQuality) {
      return testBlurQuality2(((-1.0F)), ((-1.0F)), ((-1.0F)), ((-1.0F)), floatValue, ((-1.0F)), blurQuality);
   }

   private static void updateState9(
      int intValue,
      int intValue2,
      int intValue3,
      int intValue4,
      int intValue5,
      int intValue6,
      float floatValue,
      boolean booleanValue,
      float floatValue2,
      float floatValue3,
      float floatValue4,
      float floatValue5,
      float floatValue6,
      float floatValue7
   ) {
      GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, intValue4);
      GL11.glViewport(0, 0, intValue5, intValue6);
      ShaderProgramCache.bind("kawase");
      GL13.glActiveTexture(GL13.GL_TEXTURE0);
      GL11.glBindTexture(GL11.GL_TEXTURE_2D, intValue);
      ShaderProgramCache.uniform1i("kawase", "u_input", 0);
      ShaderProgramCache.uniform2f("kawase", "u_sourceResolution", (float)intValue2, (float)intValue3);
      ShaderProgramCache.uniform2f("kawase", "u_outputResolution", (float)intValue5, (float)intValue6);
      ShaderProgramCache.uniform1f("kawase", "u_offset", floatValue);
      ShaderProgramCache.uniform1f("kawase", "u_darkness", booleanValue ? 0.0F : 0.0F);
      ShaderProgramCache.uniform1f("kawase", "u_strength", floatValue2);
      ShaderProgramCache.uniform4f("kawase", "u_maskRect", floatValue3, floatValue4, floatValue5, floatValue6);
      ShaderProgramCache.uniform1f("kawase", "u_maskRadius", floatValue7);
      glFramebufferTarget.draw();
   }

   private static boolean testBlurQuality2(float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5, float floatValue6, BlurQuality blurQuality) {
      RenderSystem.assertOnRenderThread();
      if (!checkCondition2()) {
         return false;
      } else {
         BlurQuality blurQuality2 = blurQuality == null ? BlurQuality.BALANCED : blurQuality;
         MinecraftClient minecraftClient = MinecraftClient.getInstance();
         if (minecraftClient != null && minecraftClient.getFramebuffer() != null) {
            GpuTexture colorAttachment = minecraftClient.getFramebuffer().getColorAttachment();
            if (!(colorAttachment instanceof GlTexture var10)) {
               updateState3("KawaseBlur: framebuffer color attachment is not a GlTexture (" + (colorAttachment == null ? "null" : colorAttachment.getClass().getName()) + ")");
               return false;
            } else {
               int glId = var10.getGlId();
               if (glId != 0 && GL11.glIsTexture(glId)) {
                  OpenGlStateSnapshot openGlStateSnapshot = OpenGlStateSnapshot.capture();

                  try {
                     int orCreate = MainFramebufferBridge.getOrCreate();
                     if (orCreate == 0) {
                        updateState3("KawaseBlur: the main framebuffer has no usable colour target");

                        return false;
                     }

                     GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, orCreate);
                     if (GL30.glCheckFramebufferStatus(GL30.GL_DRAW_FRAMEBUFFER) != 36053) {
                        updateState3("KawaseBlur: destination framebuffer is incomplete");

                        return false;
                     }

                     int[] intArray = computeIntArray(glId);
                     int intState3 = intArray[0];
                     int intState22 = intArray[1];
                     if (intState3 <= 0 || intState22 <= 0) {
                        updateState3("KawaseBlur: attached color texture has invalid dimensions");

                        return false;
                     }

                     if (checkCondition(intState3, intState22)) {
                        float floatValue7 = Float.isFinite(floatValue5) ? max(floatValue5, 0.0F, 8.0F) : 1.0F;
                        boolean booleanValue = floatValue6 <= 0.0F && checkCondition3(floatValue, floatValue2, floatValue3, floatValue4);
                        boolean booleanValue2 = floatValue6 > 0.0F && checkCondition3(floatValue, floatValue2, floatValue3, floatValue4);
                        GL11.glDisable(GL11.GL_BLEND);
                        GL11.glDisable(GL11.GL_DEPTH_TEST);
                        GL11.glDepthMask(false);
                        GL11.glDisable(GL11.GL_CULL_FACE);
                        GL11.glDisable(GL11.GL_SCISSOR_TEST);
                        GL11.glDisable(GL11.GL_STENCIL_TEST);
                        GL11.glColorMask(true, true, true, true);
                        GL13.glActiveTexture(GL13.GL_TEXTURE0);
                        GL33.glBindSampler(0, 0);
                        int texture = glId;
                        int width = intState3;
                        int height = intState22;
                        int passes = blurQuality2.getPasses();

                        for (int intValue3 = 0; intValue3 < passes; intValue3++) {
                           RenderTarget renderTarget = renderTargetList.get(intValue3);
                           updateState9(texture, width, height, renderTarget.getFramebuffer(), renderTarget.getWidth(), renderTarget.getHeight(), 0.5F + (float)intValue3, false, floatValue7, ((-1.0F)), ((-1.0F)), ((-1.0F)), ((-1.0F)), ((-1.0F)));
                           texture = renderTarget.getTexture();
                           width = renderTarget.getWidth();
                           height = renderTarget.getHeight();
                        }

                        for (int intValue4 = passes - 1; intValue4 >= 0; intValue4--) {
                           RenderTarget renderTarget2 = intValue4 == 0 ? null : renderTargetList.get(intValue4 - 1);
                           int intValue5 = renderTarget2 == null ? intState3 : renderTarget2.getWidth();
                           int intValue6 = renderTarget2 == null ? intState22 : renderTarget2.getHeight();
                           int intValue7 = renderTarget2 == null ? orCreate : renderTarget2.getFramebuffer();
                           boolean booleanValue3 = renderTarget2 == null;
                           if (booleanValue3 && booleanValue) {
                              GL11.glEnable(GL11.GL_SCISSOR_TEST);
                              GL11.glScissor(
                                 (int)Math.floor((double)floatValue), (int)Math.floor((double)floatValue2), (int)Math.ceil((double)floatValue3), (int)Math.ceil((double)floatValue4)
                              );
                           }

                           if (booleanValue3 && booleanValue2) {
                              GL11.glEnable(GL11.GL_BLEND);
                              GL14.glBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ONE_MINUS_SRC_ALPHA);
                           }

                           updateState9(
                              texture,
                              width,
                              height,
                              intValue7,
                              intValue5,
                              intValue6,
                              0.5F + (float)intValue4,
                              booleanValue3,
                              floatValue7,
                              booleanValue2 ? floatValue : ((-1.0F)),
                              booleanValue2 ? floatValue2 : ((-1.0F)),
                              booleanValue2 ? floatValue3 : ((-1.0F)),
                              booleanValue2 ? floatValue4 : ((-1.0F)),
                              booleanValue2 ? floatValue6 : ((-1.0F))
                           );
                           if (booleanValue3) {
                              GL11.glDisable(GL11.GL_SCISSOR_TEST);
                              GL11.glDisable(GL11.GL_BLEND);
                           }

                           if (renderTarget2 != null) {
                              texture = renderTarget2.getTexture();
                              width = intValue5;
                              height = intValue6;
                           }
                        }

                        return true;
                     }

                     updateState6("KawaseBlur: intermediate framebuffer creation failed");
                  } catch (RuntimeException failure) {
                     updateState6("KawaseBlur: disabled after an OpenGL failure: " + failure.getMessage());

                     return false;
                  } finally {
                     openGlStateSnapshot.restore();
                  }

                  return false;
               } else {
                  updateState3("KawaseBlur: main framebuffer has no usable GL color texture");
                  return false;
               }
            }
         } else {
            return false;
         }
      }
   }
}
