package cc.mochi;

import java.util.concurrent.ThreadLocalRandom;

public final class InstaCartCycle {
   private long longState;
   private int intState;
   private int intState2;
   private long longState2;

   private InstaCartState instaCartState = InstaCartState.IDLE;
   private long longState3;
   private boolean booleanState;

   public static InstaCartState getInstaCartState(InstaCartCycle instaCartCycle) {
      return instaCartCycle.instaCartState;
   }

   public static long getLongState(InstaCartCycle instaCartCycle) {
      return instaCartCycle.longState;
   }

   public InstaCartCycle() {
      this.longState = (-9223372036854775808L);
      this.intState2 = -1;

      this.intState = -1;
   }

   public static void setLongState(InstaCartCycle instaCartCycle, long longState4) {
      instaCartCycle.longState = longState4;
   }

   public boolean checkCondition() {
      if (getInstaCartState(this) != InstaCartState.IDLE) {
         if (this.instaCartState != InstaCartState.TAKEBACK) {
            return true;
         }
      }

      return false;
   }

   public int getIntState() {
      return this.intState;
   }

   public static void setBooleanState(InstaCartCycle instaCartCycle, boolean booleanState2) {
      instaCartCycle.booleanState = booleanState2;
   }

   public void updateState(long longValue) {
      if (this.longState == longValue) {
         setLongState(this, Long.MIN_VALUE);
      }
   }

   public static long getLongState2(InstaCartCycle instaCartCycle) {
      return instaCartCycle.longState2;
   }

   public static boolean getBooleanState(InstaCartCycle instaCartCycle) {
      return instaCartCycle.booleanState;
   }

   public int max2() {
      return this.max(this.longState3);
   }

   public boolean checkCondition2(long longValue) {
      byte byteValue;
      label37: {
         if (this.checkCondition3()) {
            if (longValue > getLongState2(this)) {
               if (longValue > getLongState32(this)) {
                  if (this.longState != longValue) {
                     byteValue = 1;
                     break label37;
                  }
               }
            }
         }

         byteValue = 0;
      }

      ThreadLocalRandom.current().nextInt(9);
      return (byteValue != 0);
   }

   public static void setLongState2(InstaCartCycle instaCartCycle, long longState22) {
      instaCartCycle.longState2 = longState22;
   }

   public boolean checkCondition3() {
      if (getInstaCartState(this) != InstaCartState.RAIL) {
         if (this.instaCartState != InstaCartState.CART) {
            if (getInstaCartState(this) != InstaCartState.COVER) {
               return false;
            }
         }
      }

      return true;
   }

   public long getLongState222() {
      return getLongState2(this);
   }

   public static void setLongState3(InstaCartCycle instaCartCycle, long longState32) {
      instaCartCycle.longState3 = longState32;
   }

   public void updateState2(long longState4) {
      ThreadLocalRandom.current().nextInt(15);
      if (!this.checkCondition2(longState4)) {
         ThreadLocalRandom.current().nextInt(16);

         throw new IllegalStateException("No placement may be queued at " + longState4);
      } else {
         this.longState = longState4;
      }
   }

   public InstaCartState getInstaCartState4() {
      return this.instaCartState;
   }

   public static long getLongState32(InstaCartCycle instaCartCycle) {
      return instaCartCycle.longState3;
   }

   public static void setInstaCartState(InstaCartCycle instaCartCycle, InstaCartState instaCartState2) {
      instaCartCycle.instaCartState = instaCartState2;
   }

   public boolean checkCondition4(long longValue) {
      if (this.checkCondition3()) {
         long longState4 = getLongState(this);

         if (longState4 != (-9223372036854775808L)) {
            if (getLongState(this) < longValue) {
               return false;
            }
         }
      }

      if (this.instaCartState == InstaCartState.HOLD) {
         if (longValue > getLongState32(this)) {
            return false;
         }
      } else {
         ThreadLocalRandom.current().nextInt(9);
      }

      return true;
   }

   public static void setIntState(InstaCartCycle instaCartCycle, int intState3) {
      instaCartCycle.intState = intState3;
   }

   public int getIntState2() {
      return this.intState2;
   }

   public void updateState3() {
      this.instaCartState = InstaCartState.IDLE;

      this.longState = Long.MIN_VALUE;

      setIntState(this, -1);
      this.intState2 = -1;

      this.booleanState = false;
   }

   public int max(long longValue) {
      return (int)Math.max(0L, Math.min(2147483647L, longValue - getLongState2(this)));
   }

   public void updateState4(long longState32, boolean booleanState2) {
      if (this.instaCartState != InstaCartState.IDLE) {
         ThreadLocalRandom.current().nextInt(6);

         throw new IllegalStateException("Cycle already active");
      } else {
         setLongState2(this, longState32);
         this.longState3 = longState32;

         this.longState = Long.MIN_VALUE;

         setIntState(this, -1);
         this.intState2 = -1;
         setBooleanState(this, booleanState2);
         this.instaCartState = InstaCartState.RAIL;
      }
   }

   public boolean getBooleanState22() {
      return getBooleanState(this);
   }

   public void resetBooleanState() {
      this.booleanState = false;
   }

   public void updateState5(long longState32) {
      if (this.checkCondition3()) {
         if (getLongState(this) == longState32) {
            this.longState = Long.MIN_VALUE;
            setLongState3(this, longState32);
            switch (getInstaCartState(this)) {
               case RAIL:
                  setIntState22(this, this.max(longState32));
                  this.instaCartState = InstaCartState.CART;
                  break;
               case CART:

                  this.intState = this.max(longState32);
                  this.instaCartState = getBooleanState(this) ? InstaCartState.COVER : InstaCartState.HOLD;

                  break;
               case COVER:
                  setInstaCartState(this, InstaCartState.HOLD);
                  break;
               default:

                  throw new IllegalStateException("No placement stage");
            }

            return;
         }
      }

      throw new IllegalStateException("Stale placement completion");
   }

   public static void setIntState22(InstaCartCycle instaCartCycle, int intState22) {
      instaCartCycle.intState2 = intState22;
   }

   public void updateInstaCartState() {
      this.instaCartState = InstaCartState.TAKEBACK;
   }
}
