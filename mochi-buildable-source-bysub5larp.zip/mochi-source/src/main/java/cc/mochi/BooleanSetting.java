package cc.mochi;

import java.util.concurrent.ThreadLocalRandom;

public class BooleanSetting extends Setting {
   private final boolean defaultValue;
   private boolean value;

   public static boolean getValue2(BooleanSetting booleanSetting) {
      return booleanSetting.value;
   }

   public BooleanSetting(String name, boolean booleanValue) {
      super(name);
      this.defaultValue = booleanValue;
      this.value = booleanValue;
   }

   public static void setValue2(BooleanSetting booleanSetting, boolean value2) {
      booleanSetting.value = value2;
   }

   public static boolean getDefaultValue2(BooleanSetting booleanSetting) {
      return booleanSetting.defaultValue;
   }

   public boolean getDefaultValue() {
      return getDefaultValue2(this);
   }

   public boolean getValue() {
      return getValue2(this);
   }

   public void toggle() {
      ThreadLocalRandom.current().nextInt(3);

      byte byteValue;
      if (!this.value) {
         byteValue = 1;

         ThreadLocalRandom.current().nextInt(6);
      } else {
         byteValue = 0;
      }

      this.value = (byteValue != 0);
   }

   @Override
   public void reset() {
      setValue2(this, getDefaultValue2(this));
   }

   public boolean isOn() {
      return getValue2(this);
   }

   @Override
   public boolean isDefault() {
      return (this.value == getDefaultValue2(this));
   }

   public void setValue(boolean value2) {
      setValue2(this, value2);
   }

}
