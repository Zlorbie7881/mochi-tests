package cc.mochi;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.state.property.IntProperty;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public class CombatPlayerAccess {
   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static double getZ(Vec3d vec3d) {
      return vec3d.z;
   }

   public static ClientWorld getWorld(MinecraftClient minecraftClient) {
      return minecraftClient.world;
   }

   public static Hand getMAIN_HAND() {
      return Hand.MAIN_HAND;
   }

   public static ActionPriority getHIGH() {
      return ActionPriority.HIGH;
   }

   public static double getX(Vec3d vec3d) {
      return vec3d.x;
   }

   public static Type getBLOCK() {
      return Type.BLOCK;
   }

   public static Type getMISS() {
      return Type.MISS;
   }

   public static IntProperty getCHARGES() {
      return RespawnAnchorBlock.CHARGES;
   }

   public static double getY(Vec3d vec3d) {
      return vec3d.y;
   }

   public static Block getGLOWSTONE() {
      return Blocks.GLOWSTONE;
   }

   public static FluidHandling getNONE() {
      return FluidHandling.NONE;
   }

   public static ShapeType getCOLLIDER() {
      return ShapeType.COLLIDER;
   }

   public static ShapeType getOUTLINE() {
      return ShapeType.OUTLINE;
   }

   public static ClientPlayerInteractionManager getInteractionManager(MinecraftClient minecraftClient) {
      return minecraftClient.interactionManager;
   }

   public static Direction getDOWN() {
      return Direction.DOWN;
   }

   public static net.minecraft.util.math.Direction.Type getHORIZONTAL() {
      return net.minecraft.util.math.Direction.Type.HORIZONTAL;
   }

   public static Block getSOUL_FIRE() {
      return Blocks.SOUL_FIRE;
   }

}
