package cc.mochi;

public class HudResizeDragHandler implements DragHandler {
   final float floatState;

   final float floatState2;

   final HudEditorScreen hudEditorScreen;

   final float floatState3;

   final float floatState4;

   final float floatState5;

   final HudElement hudElement;

   final float floatState6;

   final int intState;

   @Override
   public void drag(double doubleValue, double doubleValue2) {
      getHudEditorScreen(this).updateStateForHudElement8(getHudElement(this), getIntState(this), this.floatState3, this.floatState5, this.floatState, this.floatState4, getHudEditorScreen(this).computeFloat2(doubleValue) - this.floatState6, this.hudEditorScreen.computeFloat4(doubleValue2) - getFloatState2(this));
   }

   public static float getFloatState2(HudResizeDragHandler hudResizeDragHandler) {
      return hudResizeDragHandler.floatState2;
   }

   public static HudElement getHudElement(HudResizeDragHandler hudResizeDragHandler) {
      return hudResizeDragHandler.hudElement;
   }

   @Override
   public void release(double doubleValue, double doubleValue2) {
      getHudEditorScreen(this).updateState9();
   }

   HudResizeDragHandler(HudEditorScreen hudEditorScreen2, HudElement hudElement2, int intState2, float floatState32, float floatState52, float floatState7, float floatState42, float floatState62, float floatState22) {
      this.hudEditorScreen = hudEditorScreen2;
      this.hudElement = hudElement2;
      this.intState = intState2;
      this.floatState3 = floatState32;
      this.floatState5 = floatState52;
      this.floatState = floatState7;
      this.floatState4 = floatState42;
      this.floatState6 = floatState62;
      this.floatState2 = floatState22;
   }

   public static int getIntState(HudResizeDragHandler hudResizeDragHandler) {
      return hudResizeDragHandler.intState;
   }

   public static HudEditorScreen getHudEditorScreen(HudResizeDragHandler hudResizeDragHandler) {
      return hudResizeDragHandler.hudEditorScreen;
   }

}
