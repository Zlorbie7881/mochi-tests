package cc.mochi;

import java.util.List;
import net.minecraft.block.BlockState;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public record CoverPlacementPlan(
   BlockPos cell,
   BlockPos support,
   Direction face,
   Vec3d aimPoint,
   float yaw,
   float pitch,
   Item item,
   BlockState state,
   List<Box> collision,
   double exposureBefore,
   double exposureAfter
) {
   public BlockPos getCell() {
      return this.cell;
   }

   public Direction getFace() {
      return this.face;
   }

   public List getCollision2() {
      return getCollision(this);
   }

   public static float getYaw(CoverPlacementPlan coverPlacementPlan) {
      return coverPlacementPlan.yaw;
   }

   public float getPitch2() {
      return getPitch(this);
   }

   public static List<Box> getCollision(CoverPlacementPlan coverPlacementPlan) {
      return coverPlacementPlan.collision;
   }

   public static Item getItem(CoverPlacementPlan coverPlacementPlan) {
      return coverPlacementPlan.item;
   }

   public double getExposureBefore() {
      return this.exposureBefore;
   }

   public float getYaw2() {
      return getYaw(this);
   }

   public Item getItem2() {
      return getItem(this);
   }

   public BlockPos getSupport2() {
      return getSupport(this);
   }

   public double getExposureAfter2() {
      return getExposureAfter(this);
   }

   public static Vec3d getAimPoint(CoverPlacementPlan coverPlacementPlan) {
      return coverPlacementPlan.aimPoint;
   }

   public static double getExposureAfter(CoverPlacementPlan coverPlacementPlan) {
      return coverPlacementPlan.exposureAfter;
   }

   public static float getPitch(CoverPlacementPlan coverPlacementPlan) {
      return coverPlacementPlan.pitch;
   }

   public static BlockPos getSupport(CoverPlacementPlan coverPlacementPlan) {
      return coverPlacementPlan.support;
   }

   public CoverPlacementPlan(
      BlockPos cell,
      BlockPos support,
      Direction face,
      Vec3d aimPoint,
      float yaw,
      float pitch,
      Item item,
      BlockState state,
      List<Box> collision,
      double exposureBefore,
      double exposureAfter
   ) {
      collision = List.copyOf(collision);
      this.cell = cell;
      this.support = support;
      this.face = face;
      this.aimPoint = aimPoint;
      this.yaw = yaw;
      this.pitch = pitch;
      this.item = item;
      this.state = state;
      this.collision = collision;
      this.exposureBefore = exposureBefore;
      this.exposureAfter = exposureAfter;
   }

   public BlockState getState() {
      return this.state;
   }

   public Vec3d getAimPoint2() {
      return getAimPoint(this);
   }
}
