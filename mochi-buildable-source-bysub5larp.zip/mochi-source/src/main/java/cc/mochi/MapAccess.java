package cc.mochi;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import java.util.HashMap;
import java.util.Map;

final class MapAccess {
   private static final Map<Long, TextureHandle> textureHandleByLong = new HashMap<>();

   private MapAccess() {
   }

   static void clear() {
      textureHandleByLong.clear();
   }

   static TextureHandle computeTextureHandle(int intValue, int intValue2, int intValue3) {
      if (intValue > 0 && intValue2 > 0 && intValue3 > 0) {
         long longValue = (long)intValue << 32 ^ (long)intValue2 << 16 ^ (long)intValue3;
         TextureHandle textureHandle = textureHandleByLong.get(longValue);
         if (textureHandle != null) {
            return textureHandle;
         } else {
            if (textureHandleByLong.size() > 32) {
               textureHandleByLong.clear();
            }

            BorrowedGlTexture borrowedGlTexture = new BorrowedGlTexture(intValue, intValue2, intValue3);
            TextureHandle textureHandle2 = new TextureHandle(new BorrowedGlTextureView(borrowedGlTexture), RenderSystem.getSamplerCache().get(FilterMode.LINEAR), intValue2, intValue3, false, true);
            textureHandleByLong.put(longValue, textureHandle2);
            return textureHandle2;
         }
      } else {
         return null;
      }
   }
}
