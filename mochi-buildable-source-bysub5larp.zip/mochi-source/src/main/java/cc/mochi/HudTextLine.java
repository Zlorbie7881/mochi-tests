package cc.mochi;

import java.awt.Color;

public record HudTextLine(String label, String suffix, Color suffixColor, float labelAlpha, float visibility, boolean header) {
   public Color getSuffixColor2() {
      return getSuffixColor(this);
   }

   public float getVisibility() {
      return this.visibility;
   }

   public float getLabelAlpha2() {
      return getLabelAlpha(this);
   }

   public String getSuffix() {
      return this.suffix;
   }

   public static boolean getHeader(HudTextLine hudTextLine) {
      return hudTextLine.header;
   }

   public String getLabel() {
      return this.label;
   }

   public static Color getSuffixColor(HudTextLine hudTextLine) {
      return hudTextLine.suffixColor;
   }

   public boolean getHeader2() {
      return getHeader(this);
   }

   public static float getLabelAlpha(HudTextLine hudTextLine) {
      return hudTextLine.labelAlpha;
   }
}
