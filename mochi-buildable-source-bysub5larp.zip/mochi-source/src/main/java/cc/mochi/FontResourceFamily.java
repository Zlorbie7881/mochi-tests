package cc.mochi;

public enum FontResourceFamily {
   INTER("fonts/Inter.ttf"),
   POPPINS("fonts/Poppins-Medium.ttf", "fonts/Inter.ttf"),
   JETBRAINS_MONO("fonts/JetbrainsMono.ttf", "fonts/Inter.ttf"),
   MONACO("fonts/monaco.ttf", "fonts/Inter.ttf"),
   ICONS("fonts/font awesome 7 freesolid900.otf", "fonts/Inter.ttf");

   final String[] resources;

   private FontResourceFamily(String... resources2) {
      this.resources = resources2;
   }

   private static FontResourceFamily[] createValues() {
      return new FontResourceFamily[]{INTER, POPPINS, JETBRAINS_MONO, MONACO, ICONS};
   }
}
