package cc.mochi;

import java.util.List;

public record HudTextLayout(List<HudTextLine> lines, float[] labelWidths, float[] widths, float rowHeight, float width, float height, float textHeight) {
   public List getLines2() {
      return getLines(this);
   }

   public float[] getLabelWidths2() {
      return getLabelWidths(this);
   }

   public static float getHeight(HudTextLayout hudTextLayout) {
      return hudTextLayout.height;
   }

   public static List<HudTextLine> getLines(HudTextLayout hudTextLayout) {
      return hudTextLayout.lines;
   }

   public float getWidth2() {
      return getWidth(this);
   }

   public float getTextHeight() {
      return this.textHeight;
   }

   public static float[] getWidths(HudTextLayout hudTextLayout) {
      return hudTextLayout.widths;
   }

   public static float getRowHeight(HudTextLayout hudTextLayout) {
      return hudTextLayout.rowHeight;
   }

   public float getRowHeight2() {
      return getRowHeight(this);
   }

   public float[] getWidths2() {
      return getWidths(this);
   }

   public static float[] getLabelWidths(HudTextLayout hudTextLayout) {
      return hudTextLayout.labelWidths;
   }

   public float getHeight2() {
      return getHeight(this);
   }

   public static float getWidth(HudTextLayout hudTextLayout) {
      return hudTextLayout.width;
   }
}
