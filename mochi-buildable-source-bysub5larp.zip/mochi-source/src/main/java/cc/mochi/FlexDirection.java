package cc.mochi;

public enum FlexDirection {
   ROW,
   COLUMN,
   ROW_REVERSE,
   COLUMN_REVERSE;

   private static FlexDirection[] createValues() {
      return new FlexDirection[]{ROW, COLUMN, ROW_REVERSE, COLUMN_REVERSE};
   }
}
