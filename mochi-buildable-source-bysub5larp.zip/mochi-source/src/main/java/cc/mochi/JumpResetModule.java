package cc.mochi;

import cc.mochi.event.impl.network.PacketEvent;
import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.event.types.TransferOrder;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.EntityDamageS2CPacket;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.BlockPos.Mutable;

public class JumpResetModule extends Module {
   private final DoubleSetting chanceSetting;
   private final DoubleRangeSetting delayMsSetting;

   private final BooleanSetting randomizationSetting;
   private long longState;

   private void updateState() {
      if (MinecraftClientAccess46.getPlayer(mc) != null) {
         if (MinecraftClientAccess46.getOptions(mc) != null) {
            KeybindUtils.updateStateForKeyBinding(MinecraftClientAccess46.getJumpKey(mc.options));
            return;
         }
      }
   }

   public static BooleanSetting getRandomizationSetting(JumpResetModule jumpResetModule) {
      return jumpResetModule.randomizationSetting;
   }

   @EventHandler
   private void onTickEvent(TickEvent tickEvent) {
      KeybindUtils.updateState2();
   }

   private boolean checkCondition() {
      Box boundingBox = mc.player.getBoundingBox();
      BlockPos blockPos = BlockPos.ofFloored(MinecraftClientAccess46.getMinX(boundingBox), boundingBox.minY, boundingBox.minZ);
      BlockPos blockPos2 = BlockPos.ofFloored(boundingBox.maxX, MinecraftClientAccess46.getMaxY(boundingBox), MinecraftClientAccess46.getMaxZ(boundingBox));
      Mutable mutable = new Mutable();
      int x = blockPos.getX();

      while (x <= blockPos2.getX()) {
         int y = blockPos.getY();

         while (y <= blockPos2.getY()) {
            for (int z = blockPos.getZ(); z <= blockPos2.getZ(); z++) {
               mutable.set(x, y, z);
               BlockState blockState = MinecraftClientAccess46.getWorld(mc).getBlockState(mutable);
               if (blockState.getFluidState().isIn(FluidTags.WATER)) {
                  ThreadLocalRandom.current().nextInt(6);
                  return true;
               }

               if (blockState.getBlock() == Blocks.COBWEB) {
                  return true;
               }
            }

            y++;
         }

         x++;
      }

      return false;
   }

   private boolean checkCondition2() {
      double value = getChanceSetting(this).getValue();

      if (value >= (100.0)) {
         return true;
      } else {
         if (value <= (0.0)) {
            return false;
         } else {
            ThreadLocalRandom threadLocalRandom = ThreadLocalRandom.current();

            return (threadLocalRandom.nextDouble((100.0)) < value);
         }
      }
   }

   public JumpResetModule() {
      super("Jump Reset", "Jumps when a player's hit lands to turn knockback into height", ModuleCategory.MOVEMENT);

      this.chanceSetting = new DoubleSetting("Chance %", (0.0), 100.0, 100.0, 1.0);
      this.randomizationSetting = new BooleanSetting("Randomization", true);

      this.delayMsSetting = new DoubleRangeSetting("Delay (ms)", (0.0), (1000.0), 0.0, 0.0, 1.0);

      this.longState = (0L);

      Setting[] settingArray = new Setting[]{this.chanceSetting, null, null};

      settingArray[1] = this.randomizationSetting;
      settingArray[2] = this.delayMsSetting;
      this.addSettings(settingArray);
   }

   public static void setLongState(JumpResetModule jumpResetModule, long longState2) {
      jumpResetModule.longState = longState2;
   }

   private long computeLong() {
      double doubleValue = Math.min(this.delayMsSetting.getLowerValue2(), getDelayMsSetting(this).getUpperValue3());
      double doubleValue2 = Math.max(this.delayMsSetting.getLowerValue2(), this.delayMsSetting.getUpperValue3());
      if (getRandomizationSetting(this).isOn()) {
         if (!(doubleValue >= doubleValue2)) {
            return Math.max(0L, Math.round(ThreadLocalRandom.current().nextDouble(doubleValue, doubleValue2)));
         }
      }

      return Math.max(0L, Math.round(doubleValue));
   }

   public static DoubleRangeSetting getDelayMsSetting(JumpResetModule jumpResetModule) {
      return jumpResetModule.delayMsSetting;
   }

   private boolean checkCondition3() {
      if (mc.player != null) {
         if (mc.world != null) {
            if (!MinecraftClientAccess46.getPlayer(mc).isTouchingWater()) {
               if (!this.checkCondition()) {
                  ThreadLocalRandom.current().nextInt(10);
                  return true;
               }
            }

            return false;
         }

         ThreadLocalRandom.current().nextInt(14);
      }

      return false;
   }

   @EventHandler
   private void onPacketEvent(PacketEvent packetEvent) {
      if (packetEvent.getOrder() == TransferOrder.RECEIVE) {
         Packet packet = packetEvent.getPacket();
         if (packet instanceof EntityDamageS2CPacket) {
            EntityDamageS2CPacket packet2 = (EntityDamageS2CPacket)packet;
            if (MinecraftClientAccess46.getPlayer(mc) != null && MinecraftClientAccess46.getWorld(mc) != null) {
               if (packet2.entityId() == MinecraftClientAccess46.getPlayer(mc).getId()) {
                  DamageSource damageSource = packet2.createDamageSource(mc.world);
                  if (damageSource.getAttacker() instanceof PlayerEntity var4 && var4 != mc.player) {
                     this.updateState2();
                     return;
                  }
               }
            }
         }
      }
   }

   private void updateState2() {
      if (this.isEnabled() && MinecraftClientAccess46.getPlayer(mc) != null) {
         if (mc.world != null) {
            if (MinecraftClientAccess46.getCurrentScreen(mc) != null) {
               ThreadLocalRandom.current().nextInt(5);
               return;
            }

            long longValue = System.currentTimeMillis();
            if (longValue < this.longState) {
               return;
            }

            ThreadLocalRandom.current().nextInt(6);
            if (MinecraftClientAccess46.getPlayer(mc).hasVehicle()) {
               return;
            }

            if (!MinecraftClientAccess46.getPlayer(mc).isOnGround()) {
               return;
            }

            if (!this.checkCondition3()) {
               return;
            }

            if (!this.checkCondition2()) {
               return;
            }

            this.updateState();
            setLongState(this, longValue + this.computeLong());
            return;
         }
      }
   }

   public static DoubleSetting getChanceSetting(JumpResetModule jumpResetModule) {
      return jumpResetModule.chanceSetting;
   }

   @Override
   public void onDisable() {
      KeybindUtils.updateState();
      setLongState(this, 0L);
   }
}
