package cc.mochi;

import cc.mochi.mixin.HandledScreenAccessor;
import cc.mochi.mixin.KeyBindingAccessor;
import java.util.Iterator;
import java.util.Objects;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Predicate;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil.Key;
import net.minecraft.client.util.InputUtil.Type;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;

public final class InventoryUtils implements MinecraftAccess {
   static final boolean booleanState;

   public static boolean testItem(int intValue, Item item) {
      if (MinecraftClientAccess39.getPlayer(mc) != null) {
         if (intValue >= 0) {
            if (intValue < 9) {
               ItemStack stack = MinecraftClientAccess39.getPlayer(mc).getInventory().getStack(intValue);
               if (!stack.isEmpty()) {
                  if (stack.isOf(item)) {
                     ThreadLocalRandom.current().nextInt(5);
                     return true;
                  }
               }

               return false;
            }
         }
      }

      return false;
   }

   public static int computeIntForPredicate(Predicate predicate) {
      if (mc.player != null) {
         if (predicate != null) {
            int intValue = 0;

            while (true) {
               if (intValue >= 36) {
                  return -1;
               }

               if (predicate.test(mc.player.getInventory().getStack(intValue))) {
                  return intValue;
               }

               ThreadLocalRandom.current().nextInt(13);
               intValue++;
            }
         }
      }

      return -1;
   }

   public static boolean testTagKey(TagKey tagKey) {
      byte byteValue = 0;

      while (byteValue < Objects.requireNonNull(MinecraftClientAccess39.getPlayer(mc)).getInventory().size()) {
         if (MinecraftClientAccess39.getPlayer(mc).getInventory().getStack(byteValue).isIn(tagKey)) {
            return true;
         }

         byteValue++;

         ThreadLocalRandom.current().nextInt(13);
      }

      return false;
   }

   public static void updateStateForItem(Item item) {
      byte byteValue = 0;

      do {
         if (!getBooleanState()) {
            if (MinecraftClientAccess39.getPlayer(mc) == null) {
               throw new AssertionError();
            }
         }

         ItemStack stack = MinecraftClientAccess39.getPlayer(mc).getInventory().getStack(byteValue);
         if (stack.isEmpty()) {
            ThreadLocalRandom.current().nextInt(7);
         } else {
            if (stack.getItem().equals(item)) {
               MinecraftClientAccess39.getPlayer(mc).getInventory().setSelectedSlot(byteValue);
               return;
            }
         }
      } while (++byteValue < 9);
   }

   public static boolean testItem2(Item item) {
      int intValue = computeIntForPredicate2(objectValue -> isOf(item, (ItemStack)objectValue));

      if (intValue == -1) {
         return false;
      } else {
         mc.player.getInventory().setSelectedSlot(intValue);
         return true;
      }
   }

   public static boolean checkCondition(int intValue, int intValue2) {
      if (checkCondition3()) {
         if (intValue >= 9) {
            if (intValue < 36) {
               if (intValue2 >= 0) {
                  if (intValue2 < 9) {
                     Slot slot = MinecraftClientAccess39.getPlayer(mc).playerScreenHandler.getSlot(computeInt2(intValue));
                     Slot slot2 = mc.player.playerScreenHandler.getSlot(computeInt2(intValue2));
                     if (slot.inventory == mc.player.getInventory() && slot.getIndex() == intValue && slot.hasStack()) {
                        ThreadLocalRandom.current().nextInt(17);

                        if (slot.canTakeItems(mc.player)) {
                           if (slot2.canTakeItems(MinecraftClientAccess39.getPlayer(mc))) {
                              if (slot2.canInsert(slot.getStack()) && slot.canInsert(slot2.getStack())) {
                                 updateState2(MinecraftClientAccess39.getId(slot), intValue2);
                                 return true;
                              }
                           } else {
                              ThreadLocalRandom.current().nextInt(3);
                           }
                        }
                     }

                     return false;
                  }
               }
            }
         }
      }

      return false;
   }

   public static boolean testInventoryScreen(InventoryScreen inventoryScreen, Slot slot, int intValue) {
      if (MinecraftClientAccess39.getPlayer(mc) != null) {
         if (inventoryScreen == mc.currentScreen) {
            if (slot != null
               && MinecraftClientAccess39.getPlayer(mc).currentScreenHandler == inventoryScreen.getScreenHandler()
               && ((PlayerScreenHandler)inventoryScreen.getScreenHandler()).getCursorStack().isEmpty()
               && ((PlayerScreenHandler)inventoryScreen.getScreenHandler()).slots.contains(slot)
               && intValue >= 0
               && intValue < 9) {
               KeyBinding keyBinding = mc.options.hotbarKeys[intValue];
               Key boundKey = ((KeyBindingAccessor)keyBinding).getBoundKey();
               if (boundKey != null) {
                  if (boundKey.getCategory() != Type.MOUSE) {
                     if (boundKey.getCode() >= 0) {
                        int code;
                        if (boundKey.getCategory() == MinecraftClientAccess39.getKEYSYM()) {
                           code = boundKey.getCode();
                        } else {
                           code = -1;
                        }

                        int code2 = code;
                        int intValue2 = boundKey.getCategory() == MinecraftClientAccess39.getSCANCODE() ? boundKey.getCode() : GLFW.glfwGetKeyScancode(code2);

                        KeyInput keyInput = new KeyInput(code2, intValue2, 0);
                        if (keyBinding.matchesKey(keyInput) && code2 != 256) {
                           if (!MinecraftClientAccess39.getInventoryKey(MinecraftClientAccess39.getOptions(mc)).matchesKey(keyInput)) {
                              if (!MinecraftClientAccess39.getDropKey(mc.options).matchesKey(keyInput) && !mc.options.swapHandsKey.matchesKey(keyInput)) {
                                 if (!mc.options.pickItemKey.matchesKey(keyInput)) {
                                    for (int intValue3 = 0; intValue3 < intValue; intValue3++) {
                                       if (MinecraftClientAccess39.getHotbarKeys(MinecraftClientAccess39.getOptions(mc))[intValue3].matchesKey(keyInput)) {
                                          ThreadLocalRandom.current().nextInt(17);
                                          return false;
                                       }
                                    }

                                    ((HandledScreenAccessor)inventoryScreen).setFocusedSlot(slot);
                                    inventoryScreen.keyPressed(keyInput);
                                    HotbarSelectionManager.updateState6();
                                    return true;
                                 }

                                 ThreadLocalRandom.current().nextInt(15);
                              }
                           } else {
                              ThreadLocalRandom.current().nextInt(12);
                           }
                        }

                        return false;
                     }
                  }
               }

               return false;
            }
         }
      }

      return false;
   }

   private static boolean testSlot(Slot slot) {
      if (slot.id == 45) {
         return false;
      } else {
         if (slot.inventory == mc.player.getInventory()) {
            int index = slot.getIndex();

            if (index == 40) {
               return false;
            }
         }

         return true;
      }
   }

   public static int computeIntForPredicate2(Predicate predicate) {
      if (mc.player != null) {
         ThreadLocalRandom.current().nextInt(17);
         if (predicate != null) {
            ThreadLocalRandom.current().nextInt(17);
            int intValue = 0;

            while (!predicate.test(MinecraftClientAccess39.getPlayer(mc).getInventory().getStack(intValue))) {
               intValue++;

               if (intValue >= 9) {
                  return -1;
               }
            }

            return intValue;
         }
      }

      return -1;
   }

   public static void updateStateForTagKey(TagKey tagKey) {
      byte byteValue = 0;

      while (byteValue < Objects.requireNonNull(mc.player).getInventory().size()) {
         ItemStack stack = mc.player.getInventory().getStack(byteValue);
         if (stack.isIn(tagKey)) {
            MinecraftClientAccess39.getPlayer(mc).getInventory().setSelectedSlot(byteValue);

            break;
         }

         byteValue++;
      }
   }

   public static int computeInt() {
      if (MinecraftClientAccess39.getPlayer(mc) == null) {
         return -1;
      } else {
         return MinecraftClientAccess39.getPlayer(mc).getInventory().getSelectedSlot();
      }
   }

   public static boolean testItem3(Item item) {
      ItemStack itemStack = computeItemStack();
      if (!itemStack.isEmpty()) {
         if (itemStack.isOf(item)) {
            return true;
         }
      }

      return false;
   }

   private static boolean isOf(Item item, ItemStack itemStack) {
      return itemStack.isOf(item);
   }

   public static boolean testItem4(Item item) {
      for (byte byteValue = 0; byteValue < Objects.requireNonNull(mc.player).getInventory().size(); byteValue++) {
         ItemStack stack = MinecraftClientAccess39.getPlayer(mc).getInventory().getStack(byteValue);
         if (stack.getItem() == item) {
            return true;
         }
      }

      return false;
   }

   public static boolean checkCondition2(int intValue, int intValue2) {
      if (checkCondition3()) {
         if (intValue >= 0) {
            if (intValue < 36) {
               if (intValue2 >= 0) {
                  if (intValue2 < 9) {
                     if (intValue != intValue2) {
                        Slot slot = MinecraftClientAccess39.getPlayer(mc).playerScreenHandler.getSlot(computeInt2(intValue));
                        Slot slot2 = mc.player.playerScreenHandler.getSlot(computeInt2(intValue2));
                        if (MinecraftClientAccess39.getInventory(slot) == mc.player.getInventory()) {
                           if (slot.getIndex() == intValue) {
                              ThreadLocalRandom.current().nextInt(8);
                              ItemStack stack = slot.getStack();
                              ItemStack stack2 = slot2.getStack();
                              if (stack.isEmpty()) {
                                 if (stack2.isEmpty()) {
                                    return true;
                                 }
                              } else {
                                 ThreadLocalRandom.current().nextInt(5);
                              }

                              if (stack.isEmpty() || slot.canTakeItems(MinecraftClientAccess39.getPlayer(mc)) && slot2.canInsert(stack)) {
                                 if (!stack2.isEmpty()) {
                                    if (!slot.canInsert(stack2)) {
                                       return false;
                                    }

                                    if (stack2.getCount() > slot.getMaxItemCount(stack2)) {
                                       return false;
                                    }
                                 }

                                 updateState2(MinecraftClientAccess39.getId(slot), intValue2);
                                 return true;
                              }

                              return false;
                           }
                        }

                        return false;
                     }
                  }
               }
            }
         }
      }

      return false;
   }

   public static void updateState(int intValue) {
      updateState4(intValue, 40);
   }

   public static void updateState2(int intValue, int intValue2) {
      if (intValue2 >= 0) {
         if (intValue2 < 9) {
            updateState4(intValue, intValue2);
            return;
         }
      }
   }

   private InventoryUtils() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }

   public static void updateStateForClass(Class objectValue) {
      byte byteValue = 0;

      while (true) {
         if (byteValue >= Objects.requireNonNull(mc.player).getInventory().size()) {
            break;
         }

         ItemStack stack = mc.player.getInventory().getStack(byteValue);
         if (objectValue.isInstance(stack.getItem())) {
            MinecraftClientAccess39.getPlayer(mc).getInventory().setSelectedSlot(byteValue);
            break;
         }

         byteValue++;
      }
   }

   public static boolean testClass(Class objectValue) {
      byte byteValue = 0;

      while (byteValue < Objects.requireNonNull(MinecraftClientAccess39.getPlayer(mc)).getInventory().size()) {
         ThreadLocalRandom.current().nextInt(11);
         ItemStack stack = mc.player.getInventory().getStack(byteValue);
         if (objectValue.isInstance(stack.getItem())) {
            ThreadLocalRandom.current().nextInt(7);
            return true;
         }

         byteValue++;
      }

      return false;
   }

   public static ItemStack computeItemStack() {
      if (MinecraftClientAccess39.getPlayer(mc) == null) {
         return ItemStack.EMPTY;
      } else {
         return MinecraftClientAccess39.getPlayer(mc).getOffHandStack();
      }
   }

   public static void updateState3(int intValue) {
      if (mc.player != null) {
         if (intValue >= 0) {
            if (intValue < 9) {
               MinecraftClientAccess39.getPlayer(mc).getInventory().setSelectedSlot(intValue);
               return;
            }
         }
      }
   }

   private static void updateState4(int intValue, int intValue2) {
      updateStateForSlotActionType(intValue, intValue2, SlotActionType.SWAP);
   }

   public static void updateState5(int intValue) {
      updateStateForSlotActionType(intValue, 0, MinecraftClientAccess39.getPICKUP());
   }

   public static boolean checkCondition3() {
      if (mc.player != null) {
         if (mc.interactionManager != null) {
            if (mc.currentScreen == null) {
               if (mc.player.currentScreenHandler == MinecraftClientAccess39.getPlayer(mc).playerScreenHandler) {
                  if (MinecraftClientAccess39.getPlayer(mc).playerScreenHandler.getCursorStack().isEmpty()) {
                     if (!mc.player.isUsingItem()) {
                        ThreadLocalRandom.current().nextInt(7);
                        return true;
                     }
                  } else {
                     ThreadLocalRandom.current().nextInt(3);
                  }
               }
            }
         }
      }

      return false;
   }

   public static int computeIntForPredicate3(Predicate predicate) {
      if (MinecraftClientAccess39.getPlayer(mc) != null) {
         if (predicate != null) {
            int intValue = 9;

            ThreadLocalRandom.current().nextInt(10);

            while (!predicate.test(mc.player.getInventory().getStack(intValue))) {
               if (++intValue >= 36) {
                  return -1;
               }
            }

            return intValue;
         }
      }

      return -1;
   }

   private static void updateStateForSlotActionType(int intValue, int intValue2, SlotActionType slotActionType) {
      if (mc.player != null) {
         if (MinecraftClientAccess39.getInteractionManager(mc) != null) {
            if (intValue >= 0) {
               MinecraftClientAccess39.getInteractionManager(mc).clickSlot(MinecraftClientAccess39.getSyncId(MinecraftClientAccess39.getPlayer(mc).currentScreenHandler), intValue, intValue2, slotActionType, MinecraftClientAccess39.getPlayer(mc));
               HotbarSelectionManager.updateState6();
               return;
            }
         }
      }
   }

   static {
      byte byteValue;
      if (!InventoryUtils.class.desiredAssertionStatus()) {
         byteValue = 1;

         ThreadLocalRandom.current().nextInt(3);
      } else {
         byteValue = 0;
      }

      booleanState = (byteValue != 0);
   }

   public static int computeInt2(int intValue) {
      if (intValue < 9) {
         return intValue + 36;
      } else {
         return intValue;
      }
   }

   public static boolean getBooleanState() {
      return booleanState;
   }

   public static Slot computeSlotForHandledScreen(HandledScreen handledScreen, Predicate predicate, double doubleValue, double doubleValue2, boolean booleanValue) {
      if (handledScreen != null && mc.player != null) {
         if (predicate != null) {
            HandledScreenAccessor handledScreen2 = (HandledScreenAccessor)handledScreen;
            Slot slot22 = null;
            double maxValue = Double.MAX_VALUE;
            int intValue = Integer.MAX_VALUE;
            Iterator iterator = MinecraftClientAccess39.getSlots(handledScreen.getScreenHandler()).iterator();

            while (true) {
               if (!iterator.hasNext()) {
                  return slot22;
               }

               Slot slot2 = (Slot)iterator.next();
               if (testSlot(slot2) && slot2.hasStack()) {
                  if (predicate.test(slot2.getStack())) {
                     if (booleanValue) {
                        ThreadLocalRandom.current().nextInt(8);
                        double doubleValue3 = (double)(handledScreen2.getX() + MinecraftClientAccess39.getX(slot2)) + 8.0 - doubleValue;
                        double doubleValue4 = (double)(handledScreen2.getY() + slot2.y);

                        double doubleValue5 = doubleValue4 + (8.0) - doubleValue2;
                        double doubleValue6 = doubleValue3 * doubleValue3 + doubleValue5 * doubleValue5;
                        if (!(doubleValue6 >= maxValue)) {
                           maxValue = doubleValue6;
                           slot22 = slot2;
                        }
                     } else if (slot2.getIndex() < intValue) {
                        intValue = slot2.getIndex();
                        slot22 = slot2;
                     }
                  }
               }
            }
         }
      }

      return null;
   }
}
