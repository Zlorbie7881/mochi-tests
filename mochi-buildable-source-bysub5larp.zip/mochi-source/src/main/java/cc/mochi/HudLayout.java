package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

public class HudLayout {
   private final float defaultWidth;
   private HudPointerProvider hudPointerProvider;

   private final float defaultX;
   private final float defaultHeight;

   private float width;
   private boolean userPositioned;

   private float verticalInset;
   private float dragOffsetX;

   private final float defaultY;
   private float dragOffsetY;
   private boolean dragging = false;

   private HudHorizontalAlignment hudHorizontalAlignment;

   private float y;

   private float height;

   private float horizontalInset;
   private boolean dirty;

   private float x;

   private HudVerticalAlignment hudVerticalAlignment;

   public void updateDragging() {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (minecraftClient.mouse != null && minecraftClient.getWindow() != null) {
         if (minecraftClient.currentScreen == null) {
            this.dragging = false;
         } else {
            boolean pressed;
            float pointerX;
            float pointerY;
            if (this.hudPointerProvider != null) {
               pressed = this.hudPointerProvider.isPressed();
               pointerX = this.hudPointerProvider.getPointerX();
               pointerY = this.hudPointerProvider.getPointerY();
            } else {
               pressed = GLFW.glfwGetMouseButton(minecraftClient.getWindow().getHandle(), 0) == 1;
               pointerX = (float)(minecraftClient.mouse.getX() * (double)UiViewport.getWidth() / (double)minecraftClient.getWindow().getWidth());
               pointerY = (float)(minecraftClient.mouse.getY() * (double)UiViewport.getHeight() / (double)minecraftClient.getWindow().getHeight());
            }

            if (pressed) {
               if (!this.dragging && this.contains((double)pointerX, (double)pointerY)) {
                  this.dragging = true;
                  this.dragOffsetX = pointerX - this.x;
                  this.dragOffsetY = pointerY - this.y;
               }

               if (this.dragging) {
                  this.setPosition(pointerX - this.dragOffsetX, pointerY - this.dragOffsetY);
                  this.clampToViewport();
               }
            } else {
               this.dragging = false;
            }
         }
      }
   }

   public boolean isDirty() {
      return this.dirty;
   }

   public boolean isDragging() {
      return this.dragging;
   }

   public void setHeight(float height2) {
      this.height = height2;
   }

   public void setAlignmentAndInsets(HudHorizontalAlignment hudHorizontalAlignment2, HudVerticalAlignment hudVerticalAlignment2, float floatValue, float floatValue2) {
      this.hudHorizontalAlignment = hudHorizontalAlignment2;
      this.hudVerticalAlignment = hudVerticalAlignment2;
      this.horizontalInset = Math.max(0.0F, floatValue);
      this.verticalInset = Math.max(0.0F, floatValue2);
      this.applyAlignment();
   }

   private void updateAlignmentFromPosition() {
      float floatValue = Math.max(1.0F, (float)UiViewport.getWidth());
      float floatValue2 = Math.max(1.0F, (float)UiViewport.getHeight());
      boolean booleanValue = this.x + this.width / 2.0F >= floatValue / 2.0F;
      boolean booleanValue2 = this.y + this.height / 2.0F >= floatValue2 / 2.0F;
      this.hudHorizontalAlignment = booleanValue ? HudHorizontalAlignment.RIGHT : HudHorizontalAlignment.LEFT;
      this.hudVerticalAlignment = booleanValue2 ? HudVerticalAlignment.BOTTOM : HudVerticalAlignment.TOP;
      this.horizontalInset = Math.max(0.0F, booleanValue ? floatValue - (this.x + this.width) : this.x);
      this.verticalInset = Math.max(0.0F, booleanValue2 ? floatValue2 - (this.y + this.height) : this.y);
   }

   public float getWidth() {
      return this.width;
   }

   public float getHorizontalInset() {
      return this.horizontalInset;
   }

   public void applyAlignment() {
      float floatValue = Math.max(1.0F, (float)UiViewport.getWidth());
      float floatValue2 = Math.max(1.0F, (float)UiViewport.getHeight());
      switch (this.hudHorizontalAlignment) {
         case LEFT:
            this.x = this.horizontalInset;
            break;
         case CENTRE:
            this.x = (floatValue - this.width) / 2.0F;
            break;
         case RIGHT:
            this.x = floatValue - this.horizontalInset - this.width;
      }

      switch (this.hudVerticalAlignment) {
         case TOP:
            this.y = this.verticalInset;
            break;
         case CENTRE:
            this.y = (floatValue2 - this.height) / 2.0F;
            break;
         case BOTTOM:
            this.y = floatValue2 - this.verticalInset - this.height;
      }
   }

   public void setHudPointerProvider(HudPointerProvider hudPointerProvider2) {
      this.hudPointerProvider = hudPointerProvider2;
   }

   public void reset() {
      this.width = this.defaultWidth;
      this.height = this.defaultHeight;
      this.x = this.defaultX;
      this.y = this.defaultY;
      this.horizontalInset = this.defaultX;
      this.verticalInset = this.defaultY;
      this.hudHorizontalAlignment = HudHorizontalAlignment.LEFT;
      this.hudVerticalAlignment = HudVerticalAlignment.TOP;
      this.userPositioned = false;
      this.dirty = false;
   }

   public HudHorizontalAlignment getHudHorizontalAlignment() {
      return this.hudHorizontalAlignment;
   }

   public void setY(float y2) {
      this.y = y2;
   }

   public boolean isDefaultBounds() {
      return this.x == this.defaultX && this.y == this.defaultY && this.width == this.defaultWidth && this.height == this.defaultHeight;
   }

   public float getVerticalInset() {
      return this.verticalInset;
   }

   public float getY() {
      return this.y;
   }

   public void markUserPositioned(boolean booleanValue) {
      this.userPositioned = true;
      this.dirty = true;
      if (booleanValue) {
         this.updateAlignmentFromPosition();
      }
   }

   public void markDirty() {
      this.dirty = true;
   }

   public void clampToViewport() {
      float floatValue = Math.max(1.0F, (float)UiViewport.getWidth());
      float floatValue2 = Math.max(1.0F, (float)UiViewport.getHeight());
      float floatValue3 = Math.max(0.0F, floatValue - this.width);
      float floatValue4 = Math.max(0.0F, floatValue2 - this.height);
      float x2 = MathHelper.clamp(this.x, 0.0F, floatValue3);
      float y2 = MathHelper.clamp(this.y, 0.0F, floatValue4);
      if (x2 != this.x || y2 != this.y) {
         this.x = x2;
         this.y = y2;
         if (this.userPositioned) {
            this.updateAlignmentFromPosition();
         }
      }
   }

   public float getX() {
      return this.x;
   }

   public float getHeight() {
      return this.height;
   }

   public HudVerticalAlignment getHudVerticalAlignment() {
      return this.hudVerticalAlignment;
   }

   public boolean isUserPositioned() {
      return this.userPositioned;
   }

   public HudLayout(float x2, float y2, float width2, float height2) {
      this.dragOffsetX = 0.0F;
      this.dragOffsetY = 0.0F;
      this.hudHorizontalAlignment = HudHorizontalAlignment.LEFT;
      this.hudVerticalAlignment = HudVerticalAlignment.TOP;
      this.x = x2;
      this.y = y2;
      this.width = width2;
      this.height = height2;
      this.defaultX = x2;
      this.defaultY = y2;
      this.defaultWidth = width2;
      this.defaultHeight = height2;
      this.horizontalInset = x2;
      this.verticalInset = y2;
   }

   public void setX(float x2) {
      this.x = x2;
   }

   public void setPosition(float x2, float y2) {
      this.x = x2;
      this.y = y2;
      this.dirty = true;
      this.userPositioned = true;
      this.updateAlignmentFromPosition();
   }

   public void setWidth(float width2) {
      this.width = width2;
   }

   public boolean contains(double pointX, double pointY) {
      return pointX >= (double)this.x && pointX <= (double)(this.x + this.width) && pointY >= (double)this.y && pointY <= (double)(this.y + this.height);
   }

   public void clearUserPositioned() {
      this.userPositioned = false;
   }
}
