package cc.mochi;

import net.minecraft.component.ComponentType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttackRangeComponent;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.world.RaycastContext.ShapeType;

public class DataComponentTypesAccess {
   public static ComponentType<AttackRangeComponent> getATTACK_RANGE() {
      return DataComponentTypes.ATTACK_RANGE;
   }

   public static Type getMISS() {
      return Type.MISS;
   }

   public static ShapeType getCOLLIDER() {
      return ShapeType.COLLIDER;
   }
}
