package cc.mochi;

import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BuiltBuffer;

public class BufferSubmission {
   public static void updateStateForBufferBuilder(BufferBuilder bufferBuilder) {
      BuiltBuffer builtBuffer = bufferBuilder.end();
      if (builtBuffer != null) {
         builtBuffer.close();
      }
   }
}
