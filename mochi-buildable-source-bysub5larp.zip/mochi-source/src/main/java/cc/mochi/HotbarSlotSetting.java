package cc.mochi;

import java.util.concurrent.ThreadLocalRandom;

public final class HotbarSlotSetting extends Setting {
   private int slot;
   public static final int MIN_SLOT = 1;
   public static final int MAX_SLOT = 9;

   private final int defaultSlot;

   public static void setSlot2(HotbarSlotSetting hotbarSlotSetting, int slot2) {
      hotbarSlotSetting.slot = slot2;
   }

   @Override
   public boolean isDefault() {
      byte byteValue;
      if (getSlot2(this) == getDefaultSlot2(this)) {
         byteValue = 1;
      } else {
         byteValue = 11;
         ThreadLocalRandom.current().nextInt(9);
         byteValue = 0;

         ThreadLocalRandom.current().nextInt(13);
      }

      return (byteValue != 0);
   }

   public int getDefaultSlot() {
      return this.defaultSlot;
   }

   public int getSlot() {
      return getSlot2(this);
   }

   public void setSlot(int intValue) {
      setSlot2(this, clampSlot(intValue));
   }

   public static int getDefaultSlot2(HotbarSlotSetting hotbarSlotSetting) {
      return hotbarSlotSetting.defaultSlot;
   }

   private static int clampSlot(int intValue) {
      return Math.max(1, Math.min(9, intValue));
   }

   public static int getSlot2(HotbarSlotSetting hotbarSlotSetting) {
      return hotbarSlotSetting.slot;
   }

   public HotbarSlotSetting(String name, int intValue) {
      super(name);
      this.defaultSlot = clampSlot(intValue);
      this.slot = this.defaultSlot;
   }

   @Override
   public void reset() {
      this.slot = this.defaultSlot;
   }

   public int getSlotIndex() {
      return getSlot2(this) - 1;
   }
}
