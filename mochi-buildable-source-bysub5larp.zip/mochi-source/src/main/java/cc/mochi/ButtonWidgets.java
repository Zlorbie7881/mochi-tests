package cc.mochi;

import java.awt.Color;

public final class ButtonWidgets {
   private ButtonWidgets() {
   }

   public static void updateStateForUiContext(UiContext uiContext, String string, Rect rect, UiLayer uiLayer, ButtonVariant buttonVariant, String text, Icon icon, boolean booleanValue, float floatValue, Runnable runnable) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      boolean hovered = booleanValue && uiContext.isHovered(rect, uiLayer);
      float progress = uiContext.animateHover(string + ".h", hovered);
      float floatValue3 = uiContext.getAnimations().animateTo(string + ".p", 0.0F, 0.075F);
      float floatValue4 = floatValue * (booleanValue ? 1.0F : 0.45F);
      float radius = Math.min(8.0F, rect.getHeight() / 2.0F);
      uiContext.getUiRenderContext().pushTransform();
      uiContext.getUiRenderContext().scaleAroundPoint(1.0F - floatValue3 * 0.04F, rect.centerX(), rect.centerY());
      Color color;
      switch (buttonVariant) {
         case PRIMARY:
            Color color2 = UiContext.blendColors(themeSnapshot2.getAccent2(), ColorAccess3.getWHITE(), (themeSnapshot2.getLight4() ? 0.0F : 0.1F) * progress);
            if (progress > 0.01F) {
               uiContext.getUiRenderContext().drawDefaultShadow(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), radius, UiContext.multiplyAlpha(themeSnapshot2.getAccent2(), 0.35F * progress * floatValue4));
            }

            uiContext.getUiRenderContext().fillRoundedRect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), radius, UiContext.multiplyAlpha(color2, floatValue4));
            uiContext.getUiRenderContext().fillVerticalGradient(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), radius, UiRenderContext.withAlpha(Color.WHITE, 40.0F * floatValue4), UiRenderContext.withAlpha(ColorAccess3.getWHITE(), 0.0F));
            color = themeSnapshot2.getOnAccent();
            break;
         case SECONDARY:
            uiContext.getUiRenderContext().fillRoundedRect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), radius, UiContext.multiplyAlpha(UiContext.blendColors(themeSnapshot2.getSurfaceRaised(), themeSnapshot2.getAccentSoft2(), 0.0F), (0.75F + 0.25F * progress) * floatValue4));
            PanelRenderer.updateStateForUiContext(uiContext, rect, radius, progress, floatValue4);
            uiContext.getUiRenderContext().strokeRoundedRect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), radius, 1.0F, UiContext.multiplyAlpha(UiContext.blendColors(themeSnapshot2.getHairline2(), themeSnapshot2.getAccent2(), 0.3F * progress), floatValue4));
            color = themeSnapshot2.getPrimaryText();
            break;
         case GHOST:
            PanelRenderer.updateStateForUiContext(uiContext, rect, radius, progress, floatValue4 * 1.6F);
            color = UiContext.blendColors(themeSnapshot2.getSecondaryText2(), themeSnapshot2.getPrimaryText(), progress);
            break;
         default:
            Color danger = themeSnapshot2.getDanger();
            uiContext.getUiRenderContext().fillRoundedRect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), radius, UiRenderContext.withAlpha(danger, (40.0F + 200.0F * progress) * floatValue4));
            uiContext.getUiRenderContext().strokeRoundedRect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), radius, 1.0F, UiContext.multiplyAlpha(danger, 0.6F * floatValue4));
            color = UiContext.blendColors(danger, ColorAccess3.getWHITE(), progress);
      }

      color = UiContext.multiplyAlpha(color, floatValue4);
      float floatValue6 = text == null ? 0.0F : uiContext.measureText(text, TextStyle.LABEL);
      float floatValue7 = icon == null ? 0.0F : 11.0F;
      float floatValue8 = icon != null && text != null ? 6.0F : 0.0F;
      float floatValue9 = rect.centerX() - (floatValue6 + floatValue7 + floatValue8) / 2.0F;
      if (icon != null) {
         UiShapeRenderer.updateStateForUiRenderContext3(uiContext.getUiRenderContext(), icon, floatValue9 + floatValue7 / 2.0F, rect.centerY(), floatValue7, color);
      }

      if (text != null) {
         uiContext.drawVerticallyCenteredText(text, floatValue9 + floatValue7 + floatValue8, rect.centerY(), TextStyle.LABEL, color);
      }

      uiContext.getUiRenderContext().popTransform();
      if (booleanValue && runnable != null) {
         uiContext.getInputRouter().addClickRegion(rect, uiLayer, () -> updateStateForUiContext3(uiContext, string, buttonVariant, runnable));
      }
   }

   public static void updateStateForUiContext2(UiContext uiContext, String string, Rect rect, UiLayer uiLayer, Icon icon, float floatValue, Runnable runnable) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      boolean hovered = uiContext.isHovered(rect, uiLayer);
      float progress = uiContext.animateHover(string + ".h", hovered);
      PanelRenderer.updateStateForUiContext(uiContext, rect, Math.min(8.0F, rect.getHeight() / 2.0F), progress, floatValue * 1.8F);
      UiShapeRenderer.updateStateForUiRenderContext3(uiContext.getUiRenderContext(), icon, rect.centerX(), rect.centerY(), Math.min(11.0F, rect.getHeight() * 0.6F), UiContext.multiplyAlpha(UiContext.blendColors(themeSnapshot2.getSecondaryText2(), themeSnapshot2.getPrimaryText(), progress), floatValue));
      if (runnable != null) {
         uiContext.getInputRouter().addClickRegion(rect, uiLayer, () -> updateStateForRunnable(runnable));
      }
   }

   private static void updateStateForUiContext3(UiContext uiContext, String string, ButtonVariant buttonVariant, Runnable runnable) {
      uiContext.getAnimations().setValueForId(string + ".p", 1.0F);
      if (buttonVariant == ButtonVariant.DANGER) {
         ClientSounds.updateState2();
      } else if (buttonVariant == ButtonVariant.PRIMARY) {
         ClientSounds.updateState3();
      } else {
         ClientSounds.updateState4();
      }

      runnable.run();
   }

   public static float computeFloatForUiContext(UiContext uiContext, String text, Icon icon) {
      float floatValue = text == null ? 0.0F : uiContext.measureText(text, TextStyle.LABEL);
      float floatValue2 = icon == null ? 0.0F : 11.0F + (text == null ? 0.0F : 6.0F);
      return Math.max(24.0F, floatValue + floatValue2 + 24.0F);
   }

   private static void updateStateForRunnable(Runnable runnable) {
      ClientSounds.updateState5();
      runnable.run();
   }

   public static void updateStateForUiContext4(UiContext uiContext, String string, Rect rect, UiLayer uiLayer, ButtonVariant buttonVariant, String text, Icon icon, float floatValue, Runnable runnable) {
      updateStateForUiContext(uiContext, string, rect, uiLayer, buttonVariant, text, icon, true, floatValue, runnable);
   }
}
