package cc.mochi;

public enum DrainAction {
   BUCKET,
   WEB,
   PRE_AIM;

   private static DrainAction[] computeDrainActionArray() {
      DrainAction[] drainActionArray = new DrainAction[3];

      drainActionArray[0] = BUCKET;
      drainActionArray[1] = getWEB();
      drainActionArray[2] = getPRE_AIM();
      return drainActionArray;
   }

   public static DrainAction getPRE_AIM() {
      return PRE_AIM;
   }

   public static DrainAction getWEB() {
      return WEB;
   }
}
