package cc.mochi;

import net.minecraft.entity.LivingEntity;

public final class AttackRangeTimer {
   private long checkLimit;
   private int checkCount;
   private LivingEntity trackedEntity;

   public boolean advanceAndCheckLimit(LivingEntity livingEntity2, double doubleValue) {
      if (livingEntity2 != this.trackedEntity) {
         this.trackedEntity = livingEntity2;
         setCheckCount(this, 0);
         this.checkLimit = (long)doubleValue;
      }

      setCheckCount(this, this.checkCount + 1);
      return ((long)this.checkCount < this.checkLimit);
   }

   public void reset() {
      setLivingEntity(this, null);
      setCheckCount(this, 0);

      this.checkLimit = (0L);
   }

   public static void setCheckCount(AttackRangeTimer attackRangeTimer, int checkCount2) {
      attackRangeTimer.checkCount = checkCount2;
   }

   public static void setLivingEntity(AttackRangeTimer attackRangeTimer, LivingEntity livingEntity2) {
      attackRangeTimer.trackedEntity = livingEntity2;
   }

}
