package cc.mochi;

import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.Vec3d;

public record BlockAim(Vec3d point, float yaw, float pitch, BlockHitResult hit) {
   public static float getPitch(BlockAim blockAim) {
      return blockAim.pitch;
   }

   public static float getYaw(BlockAim blockAim) {
      return blockAim.yaw;
   }

   public Vec3d getPoint2() {
      return getPoint(this);
   }

   public BlockHitResult getHit() {
      return this.hit;
   }

   public float getPitch2() {
      return getPitch(this);
   }

   public static Vec3d getPoint(BlockAim blockAim) {
      return blockAim.point;
   }

   public float getYaw2() {
      return getYaw(this);
   }
}
