package cc.mochi;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;

public final class CombatEntityPredicates implements MinecraftAccess {
   public static boolean testLivingEntity(LivingEntity livingEntity) {
      byte byteValue = 19;
      ThreadLocalRandom.current().nextInt(13);
      if (livingEntity == null) {
         return true;
      } else {
         if (!livingEntity.isPlayer()) {
            return true;
         } else {
            if (mc.player == null) {
               return false;
            } else {
               Vec3d vec3d = mc.player.getEntityPos().subtract(livingEntity.getEntityPos());
               if (vec3d.lengthSquared() == 0.0) {
                  return true;
               } else {
                  vec3d = vec3d.normalize();
                  double doubleValue = Math.toRadians((double)livingEntity.getYaw());
                  double doubleValue2 = Math.toRadians((double)livingEntity.getPitch());
                  Vec3d vec3d2 = new Vec3d(-Math.sin(doubleValue) * Math.cos(doubleValue2), -Math.sin(doubleValue2), Math.cos(doubleValue) * Math.cos(doubleValue2)).normalize();
                  double doubleValue3 = vec3d2.dotProduct(vec3d);
                  if (doubleValue3 < ((-0.06))) {
                     byteValue = 1;
                  } else {
                     byteValue = 0;
                  }

                  return (byteValue != 0);
               }
            }
         }
      }
   }
}
