package cc.mochi;

import com.mojang.blaze3d.textures.TextureFormat;
import net.minecraft.client.texture.GlTexture;

final class BorrowedGlTexture extends GlTexture {
   public void close() {
   }

   public BorrowedGlTexture(int intValue, int intValue2, int intValue3) {
      super(4, "Mochi borrowed " + intValue, TextureFormat.RGBA8, intValue2, intValue3, 1, 1, intValue);
   }
}
