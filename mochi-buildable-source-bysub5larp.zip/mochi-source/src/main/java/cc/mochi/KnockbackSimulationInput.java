package cc.mochi;

import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public record KnockbackSimulationInput(
   Box box,
   Vec3d velocity,
   Vec3d attacker,
   boolean grounded,
   double resistance,
   double bonus,
   double gravity,
   double safeFall,
   double fallDistance,
   boolean fallsHurt,
   int leadTicks
) {
   public boolean getGrounded() {
      return this.grounded;
   }

   public static Box getBox(KnockbackSimulationInput knockbackSimulationInput) {
      return knockbackSimulationInput.box;
   }

   public double getFallDistance22() {
      return getFallDistance(this);
   }

   public double getBonus() {
      return this.bonus;
   }

   public static double getResistance(KnockbackSimulationInput knockbackSimulationInput) {
      return knockbackSimulationInput.resistance;
   }

   public double getGravity() {
      return this.gravity;
   }

   KnockbackSimulationInput createKnockbackSimulationInput(Vec3d vec3d) {
      return new KnockbackSimulationInput(
         this.box, vec3d, this.attacker, this.grounded, this.resistance, this.bonus, getGravity2(this), this.safeFall, getFallDistance(this), this.fallsHurt, this.leadTicks
      );
   }

   public static boolean getFallsHurt(KnockbackSimulationInput knockbackSimulationInput) {
      return knockbackSimulationInput.fallsHurt;
   }

   public Vec3d getVelocity() {
      return this.velocity;
   }

   public static Vec3d getAttacker(KnockbackSimulationInput knockbackSimulationInput) {
      return knockbackSimulationInput.attacker;
   }

   public static int getLeadTicks(KnockbackSimulationInput knockbackSimulationInput) {
      return knockbackSimulationInput.leadTicks;
   }

   public Box getBox2() {
      return getBox(this);
   }

   public static double getFallDistance(KnockbackSimulationInput knockbackSimulationInput) {
      return knockbackSimulationInput.fallDistance;
   }

   public boolean getFallsHurt2() {
      return getFallsHurt(this);
   }

   public double getSafeFall() {
      return this.safeFall;
   }

   public double getResistance2() {
      return getResistance(this);
   }

   public Vec3d getAttacker2() {
      return getAttacker(this);
   }

   public static double getGravity2(KnockbackSimulationInput knockbackSimulationInput) {
      return knockbackSimulationInput.gravity;
   }

   public int getLeadTicks2() {
      return getLeadTicks(this);
   }
}
