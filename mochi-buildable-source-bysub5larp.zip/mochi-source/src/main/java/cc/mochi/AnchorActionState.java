package cc.mochi;

public enum AnchorActionState {
   NONE,
   CHARGE,
   SHIELD,
   EXPLODE,
   DONE;

   public static AnchorActionState getCHARGE() {
      return CHARGE;
   }

   private static AnchorActionState[] computeAnchorActionStateArray() {
      AnchorActionState[] anchorActionStateArray = new AnchorActionState[5];

      anchorActionStateArray[0] = getNONE();
      anchorActionStateArray[1] = getCHARGE();
      anchorActionStateArray[2] = SHIELD;
      anchorActionStateArray[3] = EXPLODE;
      anchorActionStateArray[4] = DONE;
      return anchorActionStateArray;
   }

   public static AnchorActionState getNONE() {
      return NONE;
   }
}
