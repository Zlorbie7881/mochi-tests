package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Box;

public class MinecraftClientAccess7 {
   public static ClientWorld getWorld(MinecraftClient minecraftClient) {
      return minecraftClient.world;
   }

   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static double getMinY(Box box) {
      return box.minY;
   }

   public static Type getMISS() {
      return Type.MISS;
   }

}
