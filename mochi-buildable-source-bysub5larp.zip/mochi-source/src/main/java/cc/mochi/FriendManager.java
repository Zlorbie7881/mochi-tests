package cc.mochi;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;
import net.minecraft.entity.player.PlayerEntity;

public final class FriendManager {
   private static final Map<String, FriendEntry> friendEntryByString = new LinkedHashMap<>();

   public static boolean checkCondition(String string) {
      String string2 = computeString(string);
      if (string2 != null) {
         if (getFriendEntryByString().containsKey(string2)) {
            ThreadLocalRandom.current().nextInt(9);

            return true;
         }
      }

      return false;
   }

   public static void updateStateForUUID(UUID uuid) {
      if (testUUID(uuid)) {
         updateStateForUUID3(uuid);
      } else {
         updateStateForUUID2(uuid);
      }
   }

   private static boolean equals(UUID uuid, FriendEntry friendEntry) {
      return uuid.equals(friendEntry.getUuid2());
   }

   private static boolean equals2(UUID uuid, Entry entry) {
      return uuid.equals(((FriendEntry)entry.getValue()).getUuid2());
   }

   public static boolean testUUID(UUID uuid) {
      byte byteValue;
      label27: {
         if (uuid != null) {
            if (getFriendEntryByString().values().stream().anyMatch(friendEntry -> equals(uuid, friendEntry))) {
               byteValue = 1;
               break label27;
            }
         }

         byteValue = 0;
      }

      ThreadLocalRandom.current().nextInt(10);
      return (byteValue != 0);
   }

   private static String computeString(String string) {
      String string2 = computeString2(string);
      if (string2 == null) {
         return null;
      } else {
         return string2.toLowerCase(Locale.ROOT);
      }
   }

   public static Map<String, FriendEntry> getFriendEntryByString() {
      return friendEntryByString;
   }

   public static List copyOf() {
      return List.copyOf(new ArrayList<>(getFriendEntryByString().values()));
   }

   public static void clear() {
      getFriendEntryByString().clear();
   }

   public static void updateStateForUUID2(UUID uuid) {
      if (uuid != null) {
         updateStateForUUID4(uuid, uuid.toString());
      }
   }

   public static boolean testPlayerEntity(PlayerEntity playerEntity) {
      if (playerEntity != null) {
         if (!testUUID(playerEntity.getUuid())) {
            if (!checkCondition(playerEntity.getName().getString())) {
               return false;
            }
         }

         return true;
      } else {
         return false;
      }
   }

   public static void updateStateForUUID3(UUID uuid) {
      if (uuid != null) {
         getFriendEntryByString().entrySet().removeIf(entry -> equals2(uuid, entry));
      }
   }

   public static void updateState(String string) {
      String string2 = computeString(string);
      if (string2 != null) {
         friendEntryByString.remove(string2);
      }
   }

   public static Set collect() {
      return getFriendEntryByString().values().stream().map(friendEntry -> friendEntry.getUuid2()).filter(uuid -> Objects.nonNull(uuid)).collect(Collectors.toSet());
   }

   private FriendManager() {
   }

   public static void updateState2(String string) {
      updateStateForUUID4(null, string);
   }

   public static void updateStateForUUID4(UUID uuid, String string) {
      String string2 = computeString2(string);
      if ((string2 != null)) {
         String string3 = computeString(string2);
         FriendEntry friendEntry = friendEntryByString.get(string3);
         Map friendEntryByString2 = getFriendEntryByString();
         FriendEntry friendEntry2;
         UUID uuid2;
         if (uuid != null) {
            uuid2 = uuid;
         } else if (friendEntry == null) {
            uuid2 = null;

            ThreadLocalRandom.current().nextInt(11);
         } else {
            uuid2 = friendEntry.getUuid2();
         }

         friendEntry2 = new FriendEntry(uuid2, friendEntry == null ? string2 : friendEntry.getName());
         friendEntryByString2.put(string3, friendEntry2);
      }
   }

   private static String computeString2(String string) {
      if (string == null) {
         return null;
      } else {
         String string2 = string.trim();
         if (string2.isEmpty()) {
         return null;
      } else {
         return string2;
      }
      }
   }
}
