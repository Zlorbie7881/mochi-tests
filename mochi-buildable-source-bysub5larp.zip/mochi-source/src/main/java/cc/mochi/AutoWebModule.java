package cc.mochi;

import cc.mochi.event.impl.player.AttackEvent;
import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.event.impl.world.WorldChangeEvent;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Supplier;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class AutoWebModule extends Module implements PlayerStatusListener {
   private long longState;

   private Vec3d vec3d;

   private final ChoiceSetting targetsSetting;

   private boolean booleanState;

   private long longState2;

   private boolean booleanState2;

   private long timestampMillis;

   private int intState;

   private int intState2;

   private int selectedSlot3;

   private long longState3;
   private final DoubleSetting swapBackDelaySetting;

   private int selectedSlot4;

   private Entity entity;

   private WebPlacementState webPlacementState;

   private final DoubleSetting aimSpeedSetting;

   private Entity entity2;
   private final BooleanSetting stunWebSetting;

   private WebRotationState webRotationState;

   private int intState3;
   private final DoubleSetting autoPlaceDelaySetting;
   private final BooleanSetting swapBackSetting;
   private final DoubleSetting placeDelaySetting;

   private final DoubleSetting predictionTimeSetting;
   private final KeybindSetting activationKeySetting;
   private final DoubleSetting restoreDelayMsSetting;

   private int intState4;

   private boolean booleanState3;

   private int intState5;

   private long longState4;

   private long deadlineMillis;

   private final BooleanSetting silentRotationSetting;

   private String string;

   private final ChoiceSetting modeSetting;

   private long deadlineMillis2;

   private long timestampMillis2;

   private int intState6;

   private long longState5;

   private BlockPos blockPos;

   public static int getIntState6(AutoWebModule autoWebModule) {
      return autoWebModule.intState6;
   }

   public static WebRotationState getWebRotationState(AutoWebModule autoWebModule) {
      return autoWebModule.webRotationState;
   }

   private void updateState() {
      if (this.entity != null) {
         if (!getBooleanState2(this)) {
            if ((double)(System.currentTimeMillis() - getTimestampMillis2(this)) < this.autoPlaceDelaySetting.getValue()) {
               return;
            }

            if (this.computeIntForItem(Items.COBWEB) >= 0) {
               if (this.testEntity(getEntity(this))) {
                  if (getEntity(this) instanceof LivingEntity var1) {
                     ThreadLocalRandom.current().nextInt(14);
                     ObstacleTarget obstacleTarget = WorldTargetUtils.computeObstacleTargetForLivingEntity(var1, 0.0, 4.5, getPredictionTimeSetting(this).getValue());
                     if (obstacleTarget == null) {
                        this.updateState4();
                        return;
                     }

                     setBlockPos(this, obstacleTarget.getCell());
                     this.vec3d = obstacleTarget.getAimPoint();
                     setLongState4(this, System.currentTimeMillis());
                     this.selectedSlot3 = MinecraftClientAccess11.getPlayer(mc).getInventory().getSelectedSlot();
                     ActionPriority high = ActionPriority.HIGH;
                     Supplier supplier = () -> this.getVec3d3();
                     RotationProfile rotationProfile = RotationProfile.createRotationProfile().withMaxRotationSpeed(getAimSpeedSetting(this).getValue() * 60.0);

                     RotationManager.updateStateForActionPriority(this, high, supplier, rotationProfile.computeRotationProfile10((0.6)).withSilentAim(getSilentRotationSetting(this).isOn()));
                     setWebRotationState(this, WebRotationState.ROTATING);
                     return;
                  }

                  ThreadLocalRandom.current().nextInt(9);
                  this.updateState4();
                  return;
               }
            } else {
               ThreadLocalRandom.current().nextInt(7);
            }

            this.updateState4();
            return;
         }
      }
   }

   public static void setWebPlacementState(AutoWebModule autoWebModule, WebPlacementState webPlacementState2) {
      autoWebModule.webPlacementState = webPlacementState2;
   }

   public static boolean getBooleanState3(AutoWebModule autoWebModule) {
      return autoWebModule.booleanState3;
   }

   public static DoubleSetting getAimSpeedSetting(AutoWebModule autoWebModule) {
      return autoWebModule.aimSpeedSetting;
   }

   public static int getIntState4(AutoWebModule autoWebModule) {
      return autoWebModule.intState4;
   }

   public static void setEntity(AutoWebModule autoWebModule, Entity entity3) {
      autoWebModule.entity = entity3;
   }

   public static int getSelectedSlot3(AutoWebModule autoWebModule) {
      return autoWebModule.selectedSlot3;
   }

   public static WebPlacementState getIDLE() {
      return WebPlacementState.IDLE;
   }

   public static ChoiceSetting getModeSetting(AutoWebModule autoWebModule) {
      return autoWebModule.modeSetting;
   }

   private boolean testBlockPos(BlockPos blockPos2) {
      return WorldTargetUtils.testBlockPos(blockPos2, (0.0), (4.5));
   }

   private boolean equals() {
      return this.modeSetting.equals("Auto");
   }

   public static void setWebRotationState(AutoWebModule autoWebModule, WebRotationState webRotationState2) {
      autoWebModule.webRotationState = webRotationState2;
   }

   public static void setLongState2(AutoWebModule autoWebModule, long longState22) {
      autoWebModule.longState2 = longState22;
   }

   private boolean checkCondition() {
      if (mc.player != null) {
         if (mc.world != null) {
            if (MinecraftClientAccess11.getInteractionManager(mc) != null) {
               return true;
            }
         }
      }

      return false;
   }

   public static void setIntState5(AutoWebModule autoWebModule, int intState52) {
      autoWebModule.intState5 = intState52;
   }

   public static void setString(AutoWebModule autoWebModule, String string2) {
      autoWebModule.string = string2;
   }

   public static long getLongState5(AutoWebModule autoWebModule) {
      return autoWebModule.longState5;
   }

   public static boolean getBooleanState2(AutoWebModule autoWebModule) {
      return autoWebModule.booleanState2;
   }

   public static boolean getBooleanState(AutoWebModule autoWebModule) {
      return autoWebModule.booleanState;
   }

   private void updateState2() {
      if (this.checkCondition2()) {
         this.updateState10();
      } else {
         this.updateState14();
         this.updateState15();
         switch (getWebRotationState(this)) {
            case IDLE:
               this.updateState();

               break;
            case ROTATING:

               this.updateState5();
               break;
            case SETTLING:

               this.updateState7();
         }
      }
   }

   public static int getIntState2(AutoWebModule autoWebModule) {
      return autoWebModule.intState2;
   }

   private void updateState3() {
      this.entity2 = null;
      this.timestampMillis = 0L;
   }

   private void updateState4() {
      setWebRotationState(this, WebRotationState.IDLE);
      setEntity(this, null);
      setTimestampMillis2(this, 0L);

      this.longState = (0L);
      setBlockPos(this, null);
      setVec3d(this, null);
      setLongState4(this, 0L);

      setSelectedSlot3(this, -1);

      setIntState3(this, -1);
   }

   public static void setBooleanState2(AutoWebModule autoWebModule, boolean booleanState22) {
      autoWebModule.booleanState2 = booleanState22;
   }

   public static long getLongState(AutoWebModule autoWebModule) {
      return autoWebModule.longState;
   }

   private void updateState5() {
      if (this.blockPos != null) {
         if (getVec3d(this) != null) {
            if (this.testEntity(getEntity(this))) {
               if (this.testBlockPos(this.blockPos)) {
                  long longValue = System.currentTimeMillis() - getLongState4(this);

                  long longValue2 = 750L;
                  if (longValue <= 750L) {
                     BlockHitResult blockHitResult = BlockInteractUtils.computeBlockHitResultForBlockPos2(getBlockPos(this));
                     if (blockHitResult == null) {
                        ThreadLocalRandom.current().nextInt(5);

                        return;
                     }

                     if (!this.testBlockPos2(this.blockPos, blockHitResult)) {
                        return;
                     }

                     this.updateState16(getSelectedSlot3(this));
                     longValue2 = System.currentTimeMillis();

                     this.longState = longValue2 + (100L);
                     setWebRotationState(this, WebRotationState.SETTLING);
                     return;
                  }
               }
            }

            this.updateState13();
            return;
         }
      }

      this.updateState13();
   }

   public static void setIntState4(AutoWebModule autoWebModule, int intState42) {
      autoWebModule.intState4 = intState42;
   }

   private void updateStateForEntity(Entity entity3) {
      if (this.webRotationState != WebRotationState.IDLE) {
         ThreadLocalRandom.current().nextInt(8);
      } else if (this.checkCondition2()) {
      } else {
         setEntity(this, entity3);
         this.timestampMillis2 = System.currentTimeMillis();

         this.intState2 = 0;

         this.longState = (0L);
      }
   }

   public static void setSelectedSlot3(AutoWebModule autoWebModule, int selectedSlot32) {
      autoWebModule.selectedSlot3 = selectedSlot32;
   }

   @EventHandler
   private void onWorldChange(WorldChangeEvent worldChangeEvent) {
      if ((worldChangeEvent.getWorld() != mc.world)) {
         ThreadLocalRandom.current().nextInt(5);
         if (getWebRotationState(this) == WebRotationState.ROTATING) {
            this.updateState16(getSelectedSlot3(this));
         }

         this.updateState9();
         this.updateState6();
         this.updateState8();
      }
   }

   public static Entity getEntity2(AutoWebModule autoWebModule) {
      return autoWebModule.entity2;
   }

   public static Entity getEntity(AutoWebModule autoWebModule) {
      return autoWebModule.entity;
   }

   public static void setBooleanState3(AutoWebModule autoWebModule, boolean booleanState32) {
      autoWebModule.booleanState3 = booleanState32;
   }

   private boolean testBlockPos2(BlockPos blockPos2, BlockHitResult blockHitResult) {
      if (!this.testBlockPos(blockPos2)) {
         return false;
      } else {
         int intState32 = this.computeIntForItem(Items.COBWEB);

         if (intState32 == -1) {
            return false;
         } else {
            if (MinecraftClientAccess11.getPlayer(mc).getInventory().getSelectedSlot() != intState32) {
               MinecraftClientAccess11.getPlayer(mc).getInventory().setSelectedSlot(intState32);
            }

            this.intState3 = intState32;
            mc.interactionManager.interactBlock(mc.player, MinecraftClientAccess11.getMAIN_HAND(), blockHitResult);
            return true;
         }
      }
   }

   private void updateState6() {
      if (mc.player != null) {
         if (this.swapBackSetting.isOn()) {
            if (getIntState4(this) >= 0 && MinecraftClientAccess11.getPlayer(mc).getInventory().getSelectedSlot() == getIntState4(this)) {
               int intValue = this.computeInt();
               if (intValue >= 0) {
                  if (intValue < 9) {
                     MinecraftClientAccess11.getPlayer(mc).getInventory().setSelectedSlot(intValue);
                  }
               }

               return;
            }
         }
      }
   }

   public static long getLongState3(AutoWebModule autoWebModule) {
      return autoWebModule.longState3;
   }

   public static WebPlacementState getWebPlacementState(AutoWebModule autoWebModule) {
      return autoWebModule.webPlacementState;
   }

   public static void setDeadlineMillis(AutoWebModule autoWebModule, long deadlineMillis3) {
      autoWebModule.deadlineMillis = deadlineMillis3;
   }

   private Boolean computeBoolean() {
      if (this.equals2()) {
         ThreadLocalRandom.current().nextInt(5);
         if (this.swapBackSetting.isOn()) {
            return true;
         }

         ThreadLocalRandom.current().nextInt(4);
      }

      return false;
   }

   @Override
   public void onDisable() {
      if (this.webRotationState == WebRotationState.ROTATING) {
         this.updateState16(this.selectedSlot3);
      }

      this.updateState9();
      this.updateState6();
      this.updateState8();
   }

   private Vec3d getVec3d3() {
      return getVec3d(this);
   }

   public static BooleanSetting getSwapBackSetting(AutoWebModule autoWebModule) {
      return autoWebModule.swapBackSetting;
   }

   public static WebRotationState getROTATING() {
      return WebRotationState.ROTATING;
   }

   @Override
   public int getKeyCode() {
      return -1;
   }

   private void updateState7() {
      RotationManager.updateState9(this);
      if (this.blockPos != null) {
         if (mc.world != null) {
            int intState22 = 18;
            ThreadLocalRandom.current().nextInt(12);

            if (!mc.world.getBlockState(this.blockPos).isOf(Blocks.COBWEB)) {
               if (System.currentTimeMillis() < getLongState(this)) {
                  return;
               }

               intState22 = getIntState2(this);

               if (intState22 + 1 < 2) {
                  if (this.testEntity(this.entity)) {
                     if (this.computeIntForItem(Items.COBWEB) >= 0) {
                        int intState23 = getIntState2(this);

                        this.intState2 = intState23 + 1;
                        this.booleanState2 = false;
                        this.intState6 = -1;
                        setIntState5(this, -1);
                        this.blockPos = null;
                        this.vec3d = null;
                        setWebRotationState(this, WebRotationState.IDLE);
                        return;
                     }
                  }
               }

               this.updateState4();
               return;
            }
         }
      }

      ThreadLocalRandom.current().nextInt(14);
      this.updateState4();
   }

   private void updateState8() {
      this.updateState3();
      setWebPlacementState(this, WebPlacementState.IDLE);

      setBooleanState(this, false);
      this.deadlineMillis2 = 0L;

      setLongState3(this, Long.MIN_VALUE);

      setDeadlineMillis(this, (0L));
      setSelectedSlot4(this, -1);
      this.intState4 = -1;
      this.intState = -1;
      this.updateState4();
   }

   private void updateState9() {
      RotationManager.updateState(this);
      if (getBooleanState2(this)) {
         if (getIntState6(this) >= 0) {
            if (this.intState6 < 9) {
               if (MinecraftClientAccess11.getPlayer(mc) != null) {
                  if (mc.player.getInventory().getSelectedSlot() == this.intState5) {
                     mc.player.getInventory().setSelectedSlot(getIntState6(this));
                  } else {
                     ThreadLocalRandom.current().nextInt(14);
                  }
               }
            }
         }
      }

      this.booleanState2 = false;
      setLongState2(this, 0L);

      this.intState6 = -1;
      setIntState5(this, -1);
   }

   @EventHandler
   private void onAttack(AttackEvent attackEvent) {
      if (this.isEnabled()) {
         if (this.equals()) {
            Entity entity22 = attackEvent.getTarget();
            if (entity22 != null) {
               if (this.testEntity(entity22)) {
                  long timestampMillis3 = System.currentTimeMillis();
                  if (getEntity2(this) == entity22) {
                     long longValue = timestampMillis3 - getTimestampMillis(this);

                     if (longValue <= (1500L)) {
                        return;
                     }
                  } else {
                     ThreadLocalRandom.current().nextInt(6);
                  }

                  this.entity2 = entity22;
                  this.timestampMillis = timestampMillis3;

                  return;
               }
            }

            return;
         }
      }

      ThreadLocalRandom.current().nextInt(6);
   }

   private void updateState10() {
      RotationManager.updateState9(this);

      setBooleanState2(this, false);
      this.intState6 = -1;
      this.intState5 = -1;
      this.updateState4();
   }

   private void updateState11() {
      if (this.webPlacementState == WebPlacementState.IDLE) {
         if (this.checkCondition()) {
            setIntState4(this, this.computeIntForItem(Items.COBWEB));
            if (this.intState4 < 0) {
               return;
            }

            this.selectedSlot4 = mc.player.getInventory().getSelectedSlot();
            long longValue = Math.max(0L, Math.round(this.placeDelaySetting.getValue()));

            if (longValue <= (0L)) {
               this.updateState17();
               return;
            }

            this.deadlineMillis2 = System.currentTimeMillis() + longValue;
            setWebPlacementState(this, WebPlacementState.AWAIT_PLACE);
            return;
         }
      }
   }

   public static Vec3d getVec3d(AutoWebModule autoWebModule) {
      return autoWebModule.vec3d;
   }

   private boolean testEntity(Entity entity3) {
      if (entity3 != null && entity3 != mc.player) {
         if (entity3 != mc.getCameraEntity()) {
            if (entity3 instanceof LivingEntity) {
               LivingEntity entity32 = (LivingEntity)entity3;
               if (entity32.isAlive() && !entity32.isDead()) {
                  if (entity3 instanceof PlayerEntity var3) {
                     if (FriendManager.testPlayerEntity(var3)) {
                        return false;
                     }

                     ThreadLocalRandom.current().nextInt(16);
                  }

                  String selected = this.targetsSetting.getSelected();
                  switch (selected.hashCode()) {
                     case 2403731:
                        if (selected.equals("Mobs")) {
                           if (entity3 instanceof LivingEntity) {
                              if (!(entity3 instanceof PlayerEntity)) {
                                 return true;
                              }

                              ThreadLocalRandom.current().nextInt(14);
                           }

                           return false;
                        }
                        break;
                     case 1171085714:
                        if (selected.equals("Players")) {
                           return entity3 instanceof PlayerEntity;
                        }
                  }

                  return true;
               }
            }

            return false;
         }
      }

      return false;
   }

   public static void setIntState(AutoWebModule autoWebModule, int intState7) {
      autoWebModule.intState = intState7;
   }

   @Override
   public void onPlayerStatus(PlayerEntity entity3) {
      if (this.isEnabled()) {
         if (this.equals()) {
            if (this.stunWebSetting.isOn()) {
               if (entity3 != null) {
                  if (this.testEntity(entity3)) {
                     this.updateState3();
                     this.updateStateForEntity(entity3);
                  }
               }

               return;
            }
         }
      }
   }

   public static void setBlockPos(AutoWebModule autoWebModule, BlockPos blockPos2) {
      autoWebModule.blockPos = blockPos2;
   }

   public static void setLongState3(AutoWebModule autoWebModule, long longState32) {
      autoWebModule.longState3 = longState32;
   }

   private void updateState12() {
      long longValue = System.currentTimeMillis();
      boolean booleanState4 = KeybindUtils.checkCondition2(this.activationKeySetting.getKeyCode());
      byte byteValue;
      if (booleanState4 && !getBooleanState(this)) {
         byteValue = 1;

         ThreadLocalRandom.current().nextInt(11);
      } else {
         byteValue = 0;
      }

      byte byteValue2 = byteValue;
      this.booleanState = booleanState4;
      if (byteValue2 != 0) {
         this.updateState11();
      }

      switch (getWebPlacementState(this)) {
         case IDLE:

            break;
         case AWAIT_PLACE:
            if (longValue < this.deadlineMillis2) {
               return;
            }

            this.updateState17();
            break;
         case AWAIT_SWAPBACK:
            if (longValue >= this.deadlineMillis) {
               if (getLongState5(this) > getLongState3(this)) {
                  if (mc.player.getInventory().getSelectedSlot() == getIntState4(this)) {
                     int intValue = this.computeInt();
                     if (intValue >= 0) {
                        if (intValue < 9) {
                           if (intValue != getIntState4(this)) {
                              mc.player.getInventory().setSelectedSlot(intValue);
                           }
                        }
                     }
                  }

                  this.webPlacementState = WebPlacementState.IDLE;

                  return;
               }
            }

            return;
      }
   }

   public static void setTimestampMillis2(AutoWebModule autoWebModule, long timestampMillis22) {
      autoWebModule.timestampMillis2 = timestampMillis22;
   }

   public static BooleanSetting getSilentRotationSetting(AutoWebModule autoWebModule) {
      return autoWebModule.silentRotationSetting;
   }

   public static long getTimestampMillis2(AutoWebModule autoWebModule) {
      return autoWebModule.timestampMillis2;
   }

   public AutoWebModule() {
      super("Auto Web", "Web macro (On Key) and stun web (Auto)", -1, ModuleCategory.COMBAT);
      String[] stringArray = new String[2];

      stringArray[0] = "On Key";
      stringArray[1] = "Auto";
      this.modeSetting = new ChoiceSetting("Mode", "On Key", stringArray);

      this.activationKeySetting = new KeybindSetting("Activation Key", 71, false);

      this.placeDelaySetting = new DoubleSetting("Place Delay", 0.0, 100.0, 0.0, (1.0));

      this.swapBackDelaySetting = new DoubleSetting("SwapBack Delay", 0.0, (100.0), (0.0), 1.0);

      this.swapBackSetting = new BooleanSetting("SwapBack", true);

      this.stunWebSetting = new BooleanSetting("Stun Web", true);

      stringArray = new String[]{"Players", null, null};

      stringArray[1] = "Mobs";
      stringArray[2] = "Both";
      this.targetsSetting = new ChoiceSetting("Targets", "Players", stringArray);

      this.autoPlaceDelaySetting = new DoubleSetting("Auto Place Delay", (0.0), 100.0, (50.0), (1.0));

      this.restoreDelayMsSetting = new DoubleSetting("Restore Delay (ms)", 0.0, (100.0), 100.0, (1.0));

      this.predictionTimeSetting = new DoubleSetting("Prediction Time", (0.1), 2.0, 0.5, 0.1);
      this.aimSpeedSetting = new DoubleSetting("Aim Speed", 1.0, 50.0, 30.0, 1.0);
      this.silentRotationSetting = new BooleanSetting("Silent Rotation", true);
      this.webPlacementState = WebPlacementState.IDLE;

      this.longState3 = Long.MIN_VALUE;
      this.selectedSlot4 = -1;
      this.intState4 = -1;
      this.intState = -1;
      this.webRotationState = WebRotationState.IDLE;

      this.selectedSlot3 = -1;

      this.intState3 = -1;
      this.intState6 = -1;

      this.intState5 = -1;
      this.string = "On Key";
      this.addSetting(this.modeSetting);
      this.addSetting(this.activationKeySetting);
      this.addSetting(this.placeDelaySetting);
      this.addSetting(this.swapBackDelaySetting);
      this.addSetting(this.swapBackSetting);
      this.addSetting(this.stunWebSetting);
      this.addSetting(this.targetsSetting);
      this.addSetting(this.autoPlaceDelaySetting);
      this.addSetting(this.restoreDelayMsSetting);
      this.addSetting(this.predictionTimeSetting);
      this.addSetting(this.aimSpeedSetting);
      this.addSetting(this.silentRotationSetting);
      this.getSettings().removeIf(objectValue -> this.testSetting((Setting)objectValue));
      this.activationKeySetting.setVisibility(() -> this.equals2());
      this.placeDelaySetting.setVisibility(() -> this.equals2());
      this.swapBackDelaySetting.setVisibility(() -> this.computeBoolean());
      this.swapBackSetting.setVisibility(() -> this.equals2());
      this.stunWebSetting.setVisibility(() -> this.equals());
      this.targetsSetting.setVisibility(() -> this.equals());
      this.autoPlaceDelaySetting.setVisibility(() -> this.equals());
      this.restoreDelayMsSetting.setVisibility(() -> this.equals());
      this.predictionTimeSetting.setVisibility(() -> this.equals());
      this.aimSpeedSetting.setVisibility(() -> this.equals());
      this.silentRotationSetting.setVisibility(() -> this.equals());
   }

   public static void setIntState3(AutoWebModule autoWebModule, int intState32) {
      autoWebModule.intState3 = intState32;
   }

   public static void setBooleanState(AutoWebModule autoWebModule, boolean booleanState4) {
      autoWebModule.booleanState = booleanState4;
   }

   public static long getTimestampMillis(AutoWebModule autoWebModule) {
      return autoWebModule.timestampMillis;
   }

   public static WebRotationState getIDLE6() {
      return WebRotationState.IDLE;
   }

   public static KeybindSetting getActivationKeySetting(AutoWebModule autoWebModule) {
      return autoWebModule.activationKeySetting;
   }

   public static void setLongState4(AutoWebModule autoWebModule, long longState42) {
      autoWebModule.longState4 = longState42;
   }

   public static int getIntState5(AutoWebModule autoWebModule) {
      return autoWebModule.intState5;
   }

   private void updateState13() {
      RotationManager.updateState9(this);
      this.updateState16(getSelectedSlot3(this));
      this.updateState4();
   }

   @EventHandler
   private void onTickEvent(TickEvent tickEvent) {
      long longState52 = getLongState5(this);

      this.longState5 = longState52 + (1L);
      if (!this.checkCondition()) {
      } else if (!this.modeSetting.getSelected().equals(this.string)) {
         setString(this, this.modeSetting.getSelected());
         this.updateState9();
         this.updateState6();
         this.updateState8();
      } else {
         longState52 = 324593707L;

         setBooleanState3(this, true);

         label98: {
            Throwable throwable;
            label105: {
               try {
                  if (this.equals2()) {
                     this.updateState12();
                     break label98;
                  }
               } catch (Throwable failure) {
                  throwable = failure;

                  break label105;
               }

               label90:
               try {
                  this.updateState2();
                  break label98;
               } catch (Throwable failure2) {
                  throwable = failure2;

                  break label90;
               }
            }

            Throwable throwable2 = throwable;

            longState52 = 560910140L;

            setBooleanState3(this, false);
            throw UncheckedExceptions.rethrow(throwable2);
         }

         setBooleanState3(this, false);
      }
   }

   public static void setVec3d(AutoWebModule autoWebModule, Vec3d vec3d2) {
      autoWebModule.vec3d = vec3d2;
   }

   public static DoubleSetting getPredictionTimeSetting(AutoWebModule autoWebModule) {
      return autoWebModule.predictionTimeSetting;
   }

   private boolean checkCondition2() {
      AutoStunModule autoStunModule = (AutoStunModule)cc.mochi.ModuleLookup.computeModuleForClass(AutoStunModule.class);
      if (autoStunModule != null) {
         if (autoStunModule.isEnabled()) {
            if (autoStunModule.returnFalse()) {
               ThreadLocalRandom.current().nextInt(13);
               return true;
            }
         }
      } else {
         ThreadLocalRandom.current().nextInt(6);
      }

      return false;
   }

   public static int getIntState(AutoWebModule autoWebModule) {
      return autoWebModule.intState;
   }

   private void updateState14() {
      if ((getEntity2(this) != null)) {
         long longValue = System.currentTimeMillis();
         long longValue2 = longValue - this.timestampMillis;

         if (longValue2 <= 1500L) {
            if (this.testEntity(this.entity2)) {
               if (EntityDamageTracker.countDamageSince(getEntity2(this).getId(), this.timestampMillis) < 2) {
                  ThreadLocalRandom.current().nextInt(6);
                  return;
               }

               Entity entity22 = this.entity2;
               this.updateState3();
               this.updateStateForEntity(entity22);
               return;
            }
         }

         this.updateState3();
      }
   }

   private int computeIntForItem(Item item) {
      if (mc.player == null) {
         return -1;
      } else {
         int intValue = 0;

         do {
            ItemStack stack = MinecraftClientAccess11.getPlayer(mc).getInventory().getStack(intValue);
            if (!stack.isEmpty()) {
               if (stack.getItem() == item) {
                  ThreadLocalRandom.current().nextInt(9);
                  return intValue;
               }

               ThreadLocalRandom.current().nextInt(7);
            }

            intValue++;
         } while (intValue < 9);

         return -1;
      }
   }

   private boolean equals2() {
      return getModeSetting(this).equals("On Key");
   }

   public static BlockPos getBlockPos(AutoWebModule autoWebModule) {
      return autoWebModule.blockPos;
   }

   private void updateState15() {
      if (this.booleanState2) {
         if (System.currentTimeMillis() >= this.longState2) {
            ThreadLocalRandom.current().nextInt(3);
            this.booleanState2 = false;

            this.longState2 = (0L);
            if (MinecraftClientAccess11.getPlayer(mc) != null) {
               if (getIntState6(this) >= 0) {
                  ThreadLocalRandom.current().nextInt(4);
                  if (getIntState6(this) < 9) {
                     if (mc.player.getInventory().getSelectedSlot() == getIntState5(this)) {
                        MinecraftClientAccess11.getPlayer(mc).getInventory().setSelectedSlot(getIntState6(this));
                     }
                  }
               }
            }

            this.intState6 = -1;
            this.intState5 = -1;
            return;
         }
      }
   }

   private void updateState16(int intState62) {
      int selectedSlot;
      if (mc.player == null) {
         selectedSlot = -1;
      } else {
         selectedSlot = mc.player.getInventory().getSelectedSlot();
      }

      int selectedSlot2 = selectedSlot;
      if (intState62 >= 0) {
         if (intState62 < 9) {
            if (selectedSlot2 != intState62) {
               if (selectedSlot2 == this.intState3) {
                  this.intState6 = intState62;
                  setIntState5(this, selectedSlot2);

                  this.booleanState2 = true;
                  setLongState2(this, System.currentTimeMillis() + (long)this.restoreDelayMsSetting.intValue());
                  return;
               }
            }
         }
      }
   }

   private boolean testSetting(Setting setting) {
      if (setting instanceof KeybindSetting) {
         if (!setting.equals(getActivationKeySetting(this))) {
            return true;
         }
      } else {
         ThreadLocalRandom.current().nextInt(5);
      }

      return false;
   }

   public static long getLongState4(AutoWebModule autoWebModule) {
      return autoWebModule.longState4;
   }

   private void updateState17() {
      if (!this.checkCondition()) {
         setWebPlacementState(this, WebPlacementState.IDLE);
      } else {
         label110: {
            if (getIntState4(this) >= 0) {
               if (getIntState4(this) <= 8) {
                  break label110;
               }
            }

            this.intState4 = this.computeIntForItem(MinecraftClientAccess11.getCOBWEB());
            if (getIntState4(this) < 0) {
               this.webPlacementState = WebPlacementState.IDLE;
               return;
            }
         }

         int selectedSlot = MinecraftClientAccess11.getPlayer(mc).getInventory().getSelectedSlot();
         byte byteValue;
         if (selectedSlot != getIntState4(this)) {
            byteValue = 1;
         } else {
            byteValue = 0;
         }

         byte byteValue2 = byteValue;
         if (byteValue2 != 0) {
            MinecraftClientAccess11.getPlayer(mc).getInventory().setSelectedSlot(this.intState4);
         }

         boolean booleanValue = InteractionActions.testMinecraftClient2(mc, "combat.use.place.auto_web");
         if (!booleanValue) {
            if (byteValue2 != 0 && selectedSlot >= 0) {
               if (selectedSlot < 9) {
                  mc.player.getInventory().setSelectedSlot(selectedSlot);
               }
            }

            setWebPlacementState(this, WebPlacementState.IDLE);
         } else {
            setLongState3(this, getBooleanState3(this) ? this.longState5 : getLongState5(this) + 1L);
            setIntState(this, selectedSlot);
            int intValue = this.computeInt();
            int intValue2 = getSwapBackSetting(this).isOn() && byteValue2 != 0 && intValue >= 0 && intValue < 9 && intValue != this.intState4 && mc.player.getInventory().getSelectedSlot() == getIntState4(this) ? 1 : 0;
            if (intValue2 == 0) {
               setWebPlacementState(this, WebPlacementState.IDLE);
            } else {
               this.deadlineMillis = System.currentTimeMillis() + Math.max(0L, Math.round(this.swapBackDelaySetting.getValue()));
               setWebPlacementState(this, WebPlacementState.AWAIT_SWAPBACK);
            }
         }
      }
   }

   private int computeInt() {
      int intValue = 21;
      ThreadLocalRandom.current().nextInt(15);
      if (this.intState >= 0) {
         ThreadLocalRandom.current().nextInt(15);
         intValue = getIntState(this);
      } else {
         intValue = this.selectedSlot4;

         ThreadLocalRandom.current().nextInt(13);
      }

      return intValue;
   }

   public static void setSelectedSlot4(AutoWebModule autoWebModule, int selectedSlot42) {
      autoWebModule.selectedSlot4 = selectedSlot42;
   }

   @Override
   public void onEnable() {
      this.updateState8();
      this.string = getModeSetting(this).getSelected();
   }
}
