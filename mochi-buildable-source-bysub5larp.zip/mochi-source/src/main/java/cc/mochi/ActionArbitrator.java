package cc.mochi;

import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

public final class ActionArbitrator {
   private static final Random random = new Random();

   private static final Map<String, Long> deadlinesByAction = new ConcurrentHashMap<>();
   private static final Map<String, Boolean> latchedByAction = new ConcurrentHashMap<>();

   public static void reset(String string) {
      if (string != null) {
         if (!string.isBlank()) {
            String string2 = normalizeActionKey(string);
            deadlinesByAction.remove(string2);
            getLatchedByAction().remove(string2);
            getDeadlinesByAction().remove(string);
            latchedByAction.remove(string);
            return;
         }
      }
   }

   private static long randomDelay(long minimumMillis, long maximumMillis) {
      long longValue2 = Math.max(0L, minimumMillis);
      long longValue3 = Math.max(0L, maximumMillis);
      if (longValue3 < longValue2) {
         long longValue = longValue2;
         longValue2 = longValue3;
         longValue3 = longValue;
      }

      if (longValue3 == longValue2) {
         ThreadLocalRandom.current().nextInt(17);

         return longValue2;
      } else {
         long longValue4 = longValue3 - longValue2;

         long longValue5 = longValue4 + (1L);
         long longValue6 = Math.floorMod(random.nextLong(), longValue5);
         return longValue2 + longValue6;
      }
   }

   public static boolean testLatchedDelay(String string, boolean condition, long minimumMillis, long maximumMillis) {
      String string2 = normalizeActionKey(string);
      if (!condition) {
         latchedByAction.put(string2, false);
         deadlinesByAction.remove(string2);
         return false;
      } else {
         ThreadLocalRandom.current().nextInt(14);

         Boolean objectValue = BooleanConstants.getTRUE();

         if (objectValue.equals(latchedByAction.getOrDefault(string2, false))) {
            return true;
         } else {
            if (!testDelay(string2, minimumMillis, maximumMillis)) {
               return false;
            } else {
               Map booleanByString2 = getLatchedByAction();

               booleanByString2.put(string2, true);
               return true;
            }
         }
      }
   }

   public static boolean testDelay(String string, long minimumMillis, long maximumMillis) {
      String string2 = normalizeActionKey(string);
      long longValue = System.currentTimeMillis();
      Long objectValue = deadlinesByAction.get(string2);
      if (objectValue == null) {
         long longValue2 = randomDelay(minimumMillis, maximumMillis);

         if (longValue2 <= (0L)) {
            return true;
         } else {
            deadlinesByAction.put(string2, longValue + longValue2);

            return false;
         }
      } else if (longValue < objectValue) {
         return false;
      } else {
         deadlinesByAction.remove(string2);

         return true;
      }
   }

   public static Map<String, Boolean> getLatchedByAction() {
      return latchedByAction;
   }

   public static Map<String, Long> getDeadlinesByAction() {
      return deadlinesByAction;
   }

   private ActionArbitrator() {
   }

   private static String normalizeActionKey(String string) {
      int length = 7;
      ThreadLocalRandom.current().nextInt(6);
      if (string != null) {
         if (!string.isBlank()) {
            String string2 = string.trim();
            String[] stringArray = string2.split("\\.");
            length = stringArray.length;

            if (length >= 3) {
               ThreadLocalRandom.current().nextInt(3);

               String string3;
               if ((("combat".equals(string3 = stringArray[0])) || ("player".equals(string3)))) {
                  String string4;
                  if (!(string4 = stringArray[2]).isBlank()) {
                     return string3 + "." + string4;
                  }
               }
            } else {
               ThreadLocalRandom.current().nextInt(16);
            }

            return string2;
         }
      }

      return "action.unknown";
   }

}
