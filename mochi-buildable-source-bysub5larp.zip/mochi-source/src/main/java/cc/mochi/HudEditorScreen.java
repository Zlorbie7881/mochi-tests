package cc.mochi;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

public final class HudEditorScreen extends UiScreen {
   private HudElement hudElement;

   private HudElement hudElement2;
   private final ScrollModel scrollModel;

   private final KeybindCapture keybindCapture = new KeybindCapture();

   private final List<Float> floatList;
   private final ScrollModel scrollModel2;

   private boolean booleanState;

   private final SettingEditor settingEditor = new SettingEditor("hud.settings", this.keybindCapture);

   private HudElement hudElement3;
   private boolean booleanState2;
   private float floatState;

   private final List<Float> floatList2;
   private List<HudElement> hudElementList;

   private final ConfirmationDialog confirmationDialog = new ConfirmationDialog();

   private void updateStateForHudElement(HudElement hudElement4) {
      HudLayoutJson.updateStateForHudElement(hudElement4);

      this.booleanState = true;
      this.updateState4();
   }

   private float computeFloat(float floatValue) {
      return floatValue * this.computeFloat7() / this.max2();
   }

   private void updateState() {
      Iterator iterator = HudElements.computeList().iterator();

      while (iterator.hasNext()) {
         HudElement hudElement4 = (HudElement)iterator.next();
         hudElement4.updateState7();
      }

      this.booleanState = true;
      this.updateState4();
   }

   private void updateStateForHudElement2(HudElement hudElement4, int intValue, double doubleValue, double doubleValue2) {
      this.setHudElement2(hudElement4);
      this.updateStateForHudElement9(hudElement4);
      ClientSounds.updateState5();
   }

   public static List<HudElement> getHudElementList(HudEditorScreen hudEditorScreen) {
      return hudEditorScreen.hudElementList;
   }

   public static HudElement getHudElement(HudEditorScreen hudEditorScreen) {
      return hudEditorScreen.hudElement;
   }

   private Rect computeRectForHudElement(HudElement hudElement4) {
      HudLayout hudLayout = hudElement4.computeHudLayout();
      if (hudLayout == null) {
         ThreadLocalRandom.current().nextInt(4);
         return null;
      } else {
         return new Rect(this.computeFloat(hudLayout.getX()), this.computeFloat3(hudLayout.getY()), this.computeFloat(hudLayout.getWidth()), this.computeFloat3(hudLayout.getHeight()));
      }
   }

   private void updateStateForUiContext(UiContext uiContext2, HudElement hudElement4, Rect rect, Rect rect2, float floatValue) {
      ThemeSnapshot themeSnapshot2 = uiContext2.getThemeSnapshot();
      String string = computeStringForHudElement(hudElement4);
      String string2 = "hud.rail." + string;
      boolean booleanValue = HudElements.testHudElement(hudElement4);
      Rect rect3 = rect.intersection(rect2);
      float floatValue2 = uiContext2.animateHover(string2, uiContext2.isHovered(rect3, UiLayer.RAISED));
      float floatValue3 = uiContext2.animateToggle(string2 + ".sel", hudElement4 == getHudElement2(this), (0.035F));
      PanelRenderer.updateStateForUiContext(uiContext2, rect, (7.0F), floatValue2, floatValue);
      PanelRenderer.updateStateForUiContext4(uiContext2, rect, 7.0F, floatValue3, floatValue);
      String text = uiContext2.ellipsize(computeStringForHudElement(hudElement4), TextStyle.LABEL, rect.getWidth() - (50.0F));
      float x62 = rect.getX();

      x62 += (9.0F);
      float y = rect.centerY();
      TextStyle textStyle = TextStyle.LABEL;
      Color color;
      if (booleanValue) {
         color = themeSnapshot2.getPrimaryText();
      } else {
         color = themeSnapshot2.getSecondaryText2();

         ThreadLocalRandom.current().nextInt(14);
      }

      uiContext2.drawVerticallyCenteredText(text, x62, y, textStyle, UiContext.multiplyAlpha(color, floatValue));
      Rect rect4 = PanelHeaderRenderer.createRect(rect.right() - (7.0F), rect.centerY());
      PanelHeaderRenderer.updateStateForUiContext(uiContext2, string2 + ".switch", rect4, booleanValue, floatValue2, floatValue);
      uiContext2.getInputRouter().addPressRegion(rect3, UiLayer.RAISED, (intValue, doubleValue, doubleValue2) -> this.updateStateForHudElement2(hudElement4, intValue, doubleValue, doubleValue2));
      uiContext2.getInputRouter().addClickRegion(rect4.expand(3.0F).intersection(rect2), UiLayer.RAISED, () -> updateStateForHudElement3(hudElement4, booleanValue));
   }

   public static SettingEditor getSettingEditor(HudEditorScreen hudEditorScreen) {
      return hudEditorScreen.settingEditor;
   }

   private static void updateStateForHudElement3(HudElement hudElement4, boolean booleanValue) {
      byte byteValue;
      if (!booleanValue) {
         byteValue = 15;
         ThreadLocalRandom.current().nextInt(9);
         byteValue = 1;
      } else {
         byteValue = 0;
      }

      HudElements.updateStateForHudElement(hudElement4, (byteValue != 0));
      ClientSounds.updateState4();
   }

   private void updateStateForHudElement4(HudElement hudElement4, float floatValue, float floatValue2, UiContext uiContext2, int intValue, double doubleValue, double doubleValue2) {
      if (intValue == 1) {
         hudElement4.updateState5(1.0F);
         this.updateStateForHudElement6(hudElement4);
      } else {
         HudScaleDragHandler dragHandler = new HudScaleDragHandler(this, hudElement4, floatValue, floatValue2);
         dragHandler.drag(doubleValue, doubleValue2);
         uiContext2.getInputRouter().beginDrag(dragHandler);
         ClientSounds.updateState();
      }
   }

   @Override
   protected boolean checkCondition(int keyCode, boolean booleanValue, boolean booleanValue2) {
      if (this.keybindCapture.checkCondition3(keyCode)) {
         return true;
      } else if (this.confirmationDialog.getBooleanState2()) {
         if (keyCode == 256) {
            this.confirmationDialog.updateState2();
         }

         return true;
      } else if (getSettingEditor(this).checkCondition2()) {
         return this.settingEditor.checkCondition(keyCode, booleanValue);
      } else {
         if (this.hudElement2 != null) {
            if (getHudElement2(this).computeHudLayout() != null) {
               float floatValue4;
               if (booleanValue2) {
                  floatValue4 = (10.0F);
               } else {
                  floatValue4 = (1.0F);
               }

               float floatValue = floatValue4;
               if (keyCode == 263) {
                  floatValue4 = -floatValue;
               } else if (keyCode == 262) {
                  floatValue4 = floatValue;
               } else {
                  floatValue4 = 0.0F;
               }

               float floatValue2 = floatValue4;
               if (keyCode == 265) {
                  floatValue4 = -floatValue;
               } else {
                  floatValue4 = keyCode == 264 ? floatValue : (0.0F);
               }

               float floatValue3 = floatValue4;
               if (floatValue2 != 0.0F || floatValue3 != (0.0F)) {
                  HudLayout hudLayout = this.hudElement2.computeHudLayout();
                  hudLayout.setPosition(hudLayout.getX() + floatValue2, hudLayout.getY() + floatValue3);
                  hudLayout.clampToViewport();

                  this.booleanState = true;
                  this.updateState4();
                  return true;
               }
            }
         }

         if (keyCode != 256) {
            return false;
         } else if (this.settingEditor.checkCondition4()) {
            return true;
         } else if (this.hudElement != null) {
            ThreadLocalRandom.current().nextInt(7);
            setHudElement(this, null);
            ClientSounds.updateState5();
            return true;
         } else {
            this.updateState6();

            return true;
         }
      }
   }

   private static void updateState2(int intValue, double doubleValue, double doubleValue2) {
   }

   public static HudElement getHudElement2(HudEditorScreen hudEditorScreen) {
      return hudEditorScreen.hudElement2;
   }

   private float max() {
      return Math.max(1.0F, (float)UiViewport.getHeight());
   }

   public float computeFloat2(double doubleValue) {
      return (float)(doubleValue * (double)this.max2() / (double)this.computeFloat7());
   }

   private float computeFloat3(float floatValue) {
      return floatValue * this.computeFloat5() / this.max();
   }

   private static int computeIntForRect(Rect rect, double doubleValue, double doubleValue2) {
      double doubleValue3 = Math.abs(doubleValue - (double)rect.getX());

      byte byteValue;
      if (doubleValue3 <= (7.0)) {
         byteValue = 1;
      } else {
         byteValue = 0;
      }

      byte byteValue2 = byteValue;
      doubleValue3 = Math.abs(doubleValue - (double)rect.right());

      byte byteValue3;
      if (doubleValue3 <= (7.0)) {
         byteValue3 = 1;
      } else {
         byteValue3 = 0;
      }

      byte byteValue32 = byteValue3;
      byte byteValue5;
      if (Math.abs(doubleValue2 - (double)rect.getY()) <= 7.0) {
         byteValue5 = 1;
      } else {
         ThreadLocalRandom.current().nextInt(16);
         byteValue5 = 0;
      }

      byte byteValue52 = byteValue5;
      byte byteValue7;
      if (Math.abs(doubleValue2 - (double)rect.bottom()) <= 7.0) {
         byteValue7 = 1;
      } else {
         ThreadLocalRandom.current().nextInt(17);
         byteValue7 = 0;
      }

      byte byteValue72 = byteValue7;
      if (byteValue2 != 0) {
         if (byteValue52 != 0) {
            return 0;
         }
      }

      if (byteValue32 != 0 && byteValue52 != 0) {
         return 1;
      } else {
         if (byteValue2 != 0) {
            ThreadLocalRandom.current().nextInt(3);
            if (byteValue72 != 0) {
               return 2;
            }
         }

         if (byteValue32 != 0) {
            if (byteValue72 != 0) {
               return 3;
            }
         }

         return -1;
      }
   }

   private void updateStateForUiContext2(UiContext uiContext2, HudElement hudElement32, float floatValue) {
      ThemeSnapshot themeSnapshot2 = uiContext2.getThemeSnapshot();
      Rect rect = this.computeRectForHudElement(hudElement32);
      if ((rect != null)) {
         String string;
         boolean booleanValue;
         int intValue;
         int intValue2;
         int intValue3;
         label150: {
            String string2 = computeStringForHudElement(hudElement32);
            string = "hud.frame." + string2;
            booleanValue = HudElements.testHudElement(hudElement32);
            boolean hovered = uiContext2.isHovered(rect, UiLayer.BASE);
            intValue = hudElement32 == this.hudElement2 ? 1 : 0;
            intValue2 = hudElement32 == getHudElement3(this) ? 1 : 0;
            if (!hovered) {
               intValue3 = (((byte)16));
               ThreadLocalRandom.current().nextInt(12);
               if (intValue2 == 0) {
                  intValue3 = (((byte)24));
                  ThreadLocalRandom.current().nextInt(16);
                  intValue3 = 0;
                  break label150;
               }
            }

            intValue3 = 1;
         }

         float floatValue2 = uiContext2.animateHover(string, (intValue3 != 0));
         String string3 = string + ".sel";

         float floatValue3 = uiContext2.animateToggle(string3, (intValue != 0), (0.035F));
         float floatValue4 = floatValue * (booleanValue ? 1.0F : 0.55F);
         uiContext2.getUiRenderContext()
            .fillRoundedRect(
               rect.getX(),
               rect.getY(),
               rect.getWidth(),
               rect.getHeight(),
               4.0F,
               UiContext.multiplyAlpha(themeSnapshot2.getAccent2(), ((0.04F) + 0.08F * floatValue2 + (0.06F) * floatValue3) * floatValue4)
            );
         UiRenderContext uiRenderContext = uiContext2.getUiRenderContext();
         float x62 = rect.getX();
         float y5 = rect.getY();
         float w22 = rect.getWidth();
         float h5 = rect.getHeight();

         Color primaryText = themeSnapshot2.getPrimaryText();
         Color accent2 = themeSnapshot2.getAccent2();

         primaryText = UiContext.blendColors(primaryText, accent2, Math.max(floatValue3, floatValue2 * (0.6F)));

         uiRenderContext.strokeRoundedRect(
            x62,
            y5,
            w22,
            h5,
            (4.0F),
            1.0F,
            UiContext.multiplyAlpha(primaryText, ((0.18F) + (0.3F) * floatValue2 + 0.5F * floatValue3) * floatValue4)
         );
         float floatValue5 = Math.min(rect.getWidth(), rect.getHeight());

         float floatValue6 = Math.min(9.0F, floatValue5 * (0.35F));
         float floatValue7 = Math.max(floatValue3, floatValue2 * 0.7F);

         intValue3 = 39781507;
         if (floatValue7 > (0.01F)) {
            Color color = UiContext.multiplyAlpha(themeSnapshot2.getAccent2(), floatValue7 * floatValue4);
            if (floatValue3 > (0.01F)) {
               uiContext2.getUiRenderContext().pushBloom(themeSnapshot2.computeFloat3((0.6F)) * floatValue3 * floatValue4);
            }

            intValue3 = -2024047244;

            intValue3 = -2024047244;

            float[][] floatArrayArray = new float[4][];
            float[] floatArray = new float[]{rect.getX(), 0.0F, 0.0F, 0.0F};

            floatArray[1] = rect.getY();

            floatArray[2] = 1.0F;
            floatArray[3] = 1.0F;
            floatArrayArray[0] = floatArray;

            float[] floatArray2 = new float[4];

            floatArray2[0] = rect.right();

            floatArray2[1] = rect.getY();
            floatArray2[2] = ((-1.0F));
            floatArray2[3] = 1.0F;
            floatArrayArray[1] = floatArray2;

            intValue3 = 1715253930;

            float[] floatArray3 = new float[]{rect.getX(), rect.bottom(), 1.0F, 0.0F};

            floatArray3[3] = ((-1.0F));
            floatArrayArray[2] = floatArray3;

            intValue3 = 746986659;

            float[] floatArray4 = new float[4];

            floatArray4[0] = rect.right();
            floatArray4[1] = rect.bottom();

            floatArray4[2] = ((-1.0F));
            floatArray4[3] = ((-1.0F));
            floatArrayArray[3] = floatArray4;
            float[][] floatArrayArray2 = floatArrayArray;

            for (float[] floatArray5 : floatArrayArray2) {
               uiRenderContext = uiContext2.getUiRenderContext();

               intValue3 = 1066251238;

               float floatValue8 = floatArray5[0];

               uiRenderContext.drawLineSegment(floatValue8, floatArray5[1], floatArray5[0] + floatValue6 * floatArray5[2], floatArray5[1], 1.6F, color);
               uiRenderContext = uiContext2.getUiRenderContext();
               float floatValue9 = floatArray5[0];

               float floatValue10 = floatArray5[1];
               float floatValue11 = floatArray5[0];

               uiRenderContext.drawLineSegment(floatValue9, floatValue10, floatValue11, floatArray5[1] + floatValue6 * floatArray5[3], 1.6F, color);
            }

            if (floatValue3 > (0.01F)) {
               uiContext2.getUiRenderContext().popBloom();
            }
         }

         float floatValue12 = Math.max(Math.max(floatValue2, floatValue3), booleanValue ? (0.0F) : 0.7F);
         if (floatValue12 > 0.02F) {
            String string4;
            if (booleanValue) {
               string4 = computeStringForHudElement(hudElement32);
            } else {
               String string5 = computeStringForHudElement(hudElement32);
               string4 = string5 + "  ·  off";
            }

            String string42 = string4;
            if (intValue2 != 0 && hudElement32.computeHudLayout() != null) {
               String string7 = computeStringForHudElement(hudElement32);
               int intValue4 = Math.round(hudElement32.computeHudLayout().getY());
               int intValue5 = Math.round(hudElement32.computeHudLayout().getX());
               String string72 = string7;
               string42 = string72 + "  ·  " + intValue5 + ", " + intValue4;
            } else if (intValue != 0) {
               if (hudElement32.checkCondition()) {
                  String string9 = NumericSettingFormatter.computeString((double)hudElement32.computeFloat6(), 2);
                  String string10 = computeStringForHudElement(hudElement32);
                  string42 = string10 + "  ·  " + string9 + "x";
               }
            }

            float floatValue13 = uiContext2.measureText(string42, TextStyle.CAPTION);

            intValue3 = -1991101464;

            float floatValue14 = floatValue13 + (12.0F);
            float floatValue15;
            if (rect.getY() > (16.0F)) {
               floatValue15 = rect.getY() - 9.0F;
            } else {
               floatValue15 = rect.bottom() + 9.0F;
            }

            float floatValue152 = floatValue15;
            Rect rect2 = new Rect(rect.getX(), floatValue152 - 7.0F, floatValue14, 14.0F);
            uiRenderContext = uiContext2.getUiRenderContext();
            float x622 = rect2.getX();
            float y52 = rect2.getY();
            float w222 = rect2.getWidth();
            float h52 = rect2.getHeight();

            uiRenderContext.fillRoundedRect(
               x622,
               y52,
               w222,
               h52,
               (7.0F),
               UiContext.multiplyAlpha(floatValue3 > (0.5F) ? themeSnapshot2.getAccent2() : themeSnapshot2.getTheme().getCardGlass(), (0.95F) * floatValue12 * floatValue)
            );
            float x = rect2.centerX();
            float y = rect2.centerY();

            uiContext2.drawCenteredText(string42, x, y, TextStyle.CAPTION, UiContext.multiplyAlpha(floatValue3 > (0.5F) ? themeSnapshot2.getOnAccent() : themeSnapshot2.getPrimaryText(), floatValue12 * floatValue));
         }

         uiContext2.getInputRouter()
            .addPressRegion(rect.expand(hudElement32.checkCondition() ? (3.5F) : 0.0F), UiLayer.BASE, (intValue6, doubleValue, doubleValue2) -> this.updateStateForHudElement5(hudElement32, rect, intValue6, doubleValue, doubleValue2));
      }
   }

   private void updateStateForHudElement5(HudElement hudElement32, Rect rect, int intValue, double doubleValue, double doubleValue2) {
      this.updateStateForHudElement10(hudElement32, rect, intValue, doubleValue, doubleValue2);
   }

   public void updateStateForHudElement6(HudElement hudElement4) {
      HudLayout hudLayout = hudElement4.computeHudLayout();
      if (hudLayout != null) {
         hudLayout.markDirty();
      }

      setBooleanState(this, true);
   }

   public static ScrollModel getScrollModel(HudEditorScreen hudEditorScreen) {
      return hudEditorScreen.scrollModel;
   }

   @Override
   protected boolean checkCondition2(double pointX, double pointY, int intValue) {
      if (getKeybindCapture(this).checkCondition4(intValue)) {
         return true;
      } else {
         this.settingEditor.updateState3(pointX, pointY);
         return false;
      }
   }

   public static List<Float> getFloatList(HudEditorScreen hudEditorScreen) {
      return hudEditorScreen.floatList;
   }

   private static void updateState3(int intValue, double doubleValue, double doubleValue2) {
   }

   public void updateState4() {
      if (!getBooleanState(this)) {
         ThreadLocalRandom.current().nextInt(5);
      } else {
         if (DialogUiAccess.getINSTANCE() != null) {
            DialogUiAccess.getINSTANCE().getProfileManager().updateState3("default", true);
         }
      }
   }

   public void updateStateForHudElement7(HudElement hudElement4, float x, float y) {
      HudLayout hudLayout = hudElement4.computeHudLayout();
      float width2 = hudLayout.getWidth();
      float height2 = hudLayout.getHeight();
      getFloatList2(this).clear();
      this.floatList.clear();
      if (!checkCondition5()) {
         Float objectValue = 0.0F;
         float floatValue3 = this.max2();

         ArrayList arrayList = new ArrayList<>(List.of(objectValue, floatValue3 / (2.0F), this.max2()));
         objectValue = 0.0F;
         floatValue3 = this.max();

         ArrayList arrayList2 = new ArrayList<>(List.of(objectValue, floatValue3 / (2.0F), this.max()));
         Iterator iterator = getHudElementList(this).iterator();

         while (iterator.hasNext()) {
            HudElement hudElement5 = (HudElement)iterator.next();
            if (hudElement5 != hudElement4) {
               if (HudElements.testHudElement(hudElement5) && hudElement5.computeHudLayout() != null) {
                  HudLayout hudLayout2 = hudElement5.computeHudLayout();
                  arrayList.add(hudLayout2.getX());
                  arrayList.add(hudLayout2.getX() + hudLayout2.getWidth() / 2.0F);
                  arrayList.add(hudLayout2.getX() + hudLayout2.getWidth());
                  arrayList2.add(hudLayout2.getY());
                  arrayList2.add(hudLayout2.getY() + hudLayout2.getHeight() / 2.0F);
                  arrayList2.add(hudLayout2.getY() + hudLayout2.getHeight());
               }
            }
         }

         float floatValue4 = (5.0F) * this.max2() / this.computeFloat7();
         float floatValue5 = (5.0F) * this.max() / this.computeFloat5();
         float[] floatArray = computeFloatArrayForList(x, width2, arrayList, floatValue4);
         float[] floatArray2 = computeFloatArrayForList(y, height2, arrayList2, floatValue5);
         if (floatArray != null) {
            x = floatArray[0];
            this.floatList2.add(floatArray[1]);
         }

         if (floatArray2 != null) {
            y = floatArray2[0];
            this.floatList.add(floatArray2[1]);
         }
      }

      hudLayout.setPosition(x, y);
      hudLayout.clampToViewport();
   }

   private void setHudElement2(HudElement hudElement22) {
      this.hudElement2 = hudElement22;
   }

   private void updateStateForUiContext3(UiContext uiContext2, float floatValue, float floatValue2) {
      ThemeSnapshot themeSnapshot2 = uiContext2.getThemeSnapshot();
      String string;
      if (getHudElement3(this) != null) {
         string = checkCondition5() ? "Placing freely" : "Snapping  ·  hold Shift to place freely";
      } else {
         string = "Drag to move  ·  scroll to resize  ·  right-click for settings";
      }

      String string2 = string;
      float floatValue3 = uiContext2.measureText(string2, TextStyle.CAPTION);
      float floatValue4 = ButtonWidgets.computeFloatForUiContext(uiContext2, "Reset all", Icon.RESET);
      float floatValue5 = ButtonWidgets.computeFloatForUiContext(uiContext2, "Done", null);
      float floatValue6 = uiContext2.measureText("HUD editor", TextStyle.STRONG);
      float floatValue7 = 14.0F + floatValue6;

      float floatValue8 = floatValue7 + (12.0F) + floatValue3;

      float floatValue9 = floatValue8 + (14.0F) + floatValue4 + 6.0F + floatValue5 + (6.0F);
      Rect rect = new Rect(floatValue / 2.0F - floatValue9 / 2.0F, 10.0F, floatValue9, 30.0F);

      PanelRenderer.updateStateForUiContext5(uiContext2, rect, (15.0F), floatValue2);
      uiContext2.getInputRouter().addPressRegion(rect, UiLayer.RAISED, (intValue, doubleValue, doubleValue2) -> updateState2(intValue, doubleValue, doubleValue2));
      uiContext2.drawVerticallyCenteredText("HUD editor", rect.getX() + 14.0F, rect.centerY(), TextStyle.STRONG, UiContext.multiplyAlpha(themeSnapshot2.getPrimaryText(), floatValue2));
      float x62 = rect.getX();

      float x = x62 + (14.0F) + floatValue6 + 12.0F;
      float y = rect.centerY();
      TextStyle caption = TextStyle.CAPTION;
      Color color;
      if (getHudElement3(this) != null) {
         color = themeSnapshot2.getAccentText2();
      } else {
         color = themeSnapshot2.getSecondaryText2();

         ThreadLocalRandom.current().nextInt(4);
      }

      uiContext2.drawVerticallyCenteredText(string2, x, y, caption, UiContext.multiplyAlpha(color, floatValue2));
      Rect rect2 = new Rect(rect.right() - (6.0F) - floatValue5, rect.centerY() - 10.0F, floatValue5, 20.0F);
      Rect rect3 = new Rect(rect2.getX() - 6.0F - floatValue4, rect.centerY() - (10.0F), floatValue4, 20.0F);
      ButtonWidgets.updateStateForUiContext4(uiContext2, "hud.reset", rect3, UiLayer.RAISED, ButtonVariant.GHOST, "Reset all", Icon.RESET, floatValue2, () -> this.updateState8());
      ButtonWidgets.updateStateForUiContext4(uiContext2, "hud.done", rect2, UiLayer.RAISED, ButtonVariant.PRIMARY, "Done", null, floatValue2, () -> this.updateState6());
   }

   public HudEditorScreen() {
      super("HUD Editor");
      this.scrollModel2 = new ScrollModel();
      this.scrollModel = new ScrollModel();
      this.hudElementList = List.of();
      this.floatList2 = new ArrayList<>();
      this.floatList = new ArrayList<>();
      HudElements.updateState();
   }

   public static HudElement getHudElement3(HudEditorScreen hudEditorScreen) {
      return hudEditorScreen.hudElement3;
   }

   private void setBooleanState23() {
      setBooleanState2(this, false);
   }

   public void updateStateForHudElement8(HudElement hudElement4, int intValue, float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5, float floatValue6) {
      HudLayout hudLayout = hudElement4.computeHudLayout();
      float floatValue7 = floatValue;
      float floatValue22 = floatValue2;
      float floatValue112;
      float floatValue122;
      switch (intValue) {
         case 0:
            floatValue7 = floatValue + floatValue5;
            floatValue22 = floatValue2 + floatValue6;
            floatValue112 = floatValue3 - floatValue5;
            floatValue122 = floatValue4 - floatValue6;
            break;
         case 1:
            floatValue22 = floatValue2 + floatValue6;
            floatValue112 = floatValue3 + floatValue5;
            floatValue122 = floatValue4 - floatValue6;
            break;
         case 2:
            floatValue7 = floatValue + floatValue5;
            floatValue112 = floatValue3 - floatValue5;
            floatValue122 = floatValue4 + floatValue6;

            break;
         default:

            floatValue112 = floatValue3 + floatValue5;
            floatValue122 = floatValue4 + floatValue6;
      }

      float floatValue11 = Math.max(20.0F, hudElement4.getFloatConstant4());
      float floatValue12 = Math.max((16.0F), hudElement4.getFloatConstant3());
      if (floatValue112 < floatValue11) {
         label68: {
            if (intValue != 0) {
               if (intValue != 2) {
                  break label68;
               }
            }

            floatValue7 -= floatValue11 - floatValue112;
         }

         floatValue112 = floatValue11;
      }

      if (floatValue122 < floatValue12) {
         label61: {
            if (intValue != 0) {
               if (intValue != 1) {
                  ThreadLocalRandom.current().nextInt(14);
                  break label61;
               }
            }

            floatValue22 -= floatValue12 - floatValue122;
         }

         floatValue122 = floatValue12;

         ThreadLocalRandom.current().nextInt(7);
      }

      if (floatValue7 < (0.0F)) {
         floatValue112 += floatValue7;
         floatValue7 = 0.0F;
      }

      if (floatValue22 < 0.0F) {
         floatValue122 += floatValue22;

         floatValue22 = (0.0F);
      } else {
         ThreadLocalRandom.current().nextInt(7);
      }

      floatValue112 = Math.min(floatValue112, this.max2() - floatValue7);
      floatValue122 = Math.min(floatValue122, this.max() - floatValue22);
      hudLayout.setWidth(Math.max(floatValue11, floatValue112));
      hudLayout.setHeight(Math.max(floatValue12, floatValue122));
      hudLayout.setPosition(floatValue7, floatValue22);
   }

   public static float getFloatState(HudEditorScreen hudEditorScreen) {
      return hudEditorScreen.floatState;
   }

   public float computeFloat4(double doubleValue) {
      return (float)(doubleValue * (double)this.max() / (double)this.computeFloat5());
   }

   private float max2() {
      return Math.max((1.0F), (float)UiViewport.getWidth());
   }

   private void updateStateForUiContext4(UiContext uiContext2, float floatValue, float opacity) {
      ThemeSnapshot themeSnapshot2 = uiContext2.getThemeSnapshot();
      UiAnimations uiAnimations5 = uiContext2.getAnimations();
      float initialValue = getBooleanState2(this) ? (1.0F) : (0.0F);
      float y5 = this.booleanState2 ? (1.0F) : 0.0F;
      float floatValue4 = (0.3F);

      float floatValue5 = uiAnimations5.spring("hud.rail", initialValue, y5, (0.3F), (0.9F));

      float floatValue6 = (10.0F) - (182.0F) * floatValue5;

      Rect rect = new Rect(floatValue6, 12.0F, 168.0F, floatValue - (24.0F));

      if (floatValue5 < (0.99F)) {
         PanelRenderer.updateStateForUiContext5(uiContext2, rect, 14.0F, opacity);
         uiContext2.getInputRouter().addPressRegion(rect, UiLayer.RAISED, (intValue, doubleValue, doubleValue2) -> updateState7(intValue, doubleValue, doubleValue2));
         int intValue2 = 0;

         for (HudElement hudElement4 : getHudElementList(this)) {
            if (HudElements.testHudElement(hudElement4)) {
               intValue2++;
            }
         }

         uiContext2.drawVerticallyCenteredText("Elements", rect.getX() + 12.0F, rect.getY() + 16.0F, TextStyle.STRONG, UiContext.multiplyAlpha(themeSnapshot2.getPrimaryText(), opacity));
         int intValue3 = this.hudElementList.size();
         uiContext2.drawVerticallyCenteredText(intValue2 + " of " + intValue3 + " on", rect.getX() + (12.0F), rect.getY() + 28.0F, TextStyle.CAPTION, UiContext.multiplyAlpha(themeSnapshot2.getSecondaryText2(), opacity));
         floatValue4 = rect.right() - (28.0F);
         float y52 = rect.getY();

         ButtonWidgets.updateStateForUiContext2(
            uiContext2,
            "hud.rail.collapse",
            new Rect(floatValue4, y52 + (9.0F), (20.0F), 20.0F),
            UiLayer.RAISED,
            Icon.CHEVRON_LEFT,
            opacity,
            () -> this.setBooleanState222()
         );
         initialValue = rect.getX() + 4.0F;
         y5 = rect.getY();

         y5 += (42.0F);
         floatValue4 = rect.getWidth() - (8.0F);
         float h5 = rect.getHeight();

         Rect rect2 = new Rect(initialValue, y5, floatValue4, h5 - (46.0F));

         float floatValue7 = getScrollModel2(this).update(uiContext2, (float)getHudElementList(this).size() * 26.0F, rect2.getHeight());
         uiContext2.getInputRouter().addScrollRegion(rect2, UiLayer.RAISED, wheelDelta -> this.scrollModel2.scroll(wheelDelta));
         uiContext2.getUiRenderContext().pushClip(rect2.getX(), rect2.getY(), rect2.getWidth(), rect2.getHeight());
         int intValue4 = 0;

         while (true) {
            if (intValue4 >= this.hudElementList.size()) {
               uiContext2.getUiRenderContext().popClip();
               this.scrollModel2.drawScrollbar(uiContext2, rect2, (float)getHudElementList(this).size() * 26.0F, opacity);
               break;
            }

            HudElement hudElement5 = this.hudElementList.get(intValue4);
            initialValue = rect2.getX() + 2.0F;
            y5 = rect2.getY() + (float)intValue4 * 26.0F - floatValue7;
            floatValue4 = rect2.getWidth() - (4.0F);

            Rect rect3 = new Rect(initialValue, y5, floatValue4, (24.0F));
            if (!(rect3.bottom() < rect2.getY())) {
               if (!(rect3.getY() > rect2.bottom())) {
                  this.updateStateForUiContext(uiContext2, hudElement5, rect3, rect2, opacity);
               }
            }

            intValue4++;
         }
      } else {
         ThreadLocalRandom.current().nextInt(9);
      }

      if (floatValue5 > (0.01F)) {
         Rect rect4 = new Rect(
            (10.0F) - (40.0F) * ((1.0F) - floatValue5),
            (12.0F),
            30.0F,
            30.0F
         );
         PanelRenderer.updateStateForUiContext5(uiContext2, rect4, 10.0F, opacity * floatValue5);
         ButtonWidgets.updateStateForUiContext2(uiContext2, "hud.rail.expand", rect4.insetUniform(4.0F), UiLayer.RAISED, Icon.LAYOUT, opacity * floatValue5, () -> this.setBooleanState23());
      }
   }

   @Override
   protected void updateState5(double pointX, double pointY, double doubleValue3) {
      int intValue = getHudElementList(this).size() - 1;

      while (true) {
         ThreadLocalRandom.current().nextInt(15);
         if (intValue < 0) {
            return;
         }

         HudElement hudElement22 = this.hudElementList.get(intValue);
         Rect rect = this.computeRectForHudElement(hudElement22);
         if (rect != null) {
            if (rect.contains(pointX, pointY) && hudElement22.checkCondition()) {
               this.setHudElement2(hudElement22);
               hudElement22.updateState5(hudElement22.computeFloat6() + (float)doubleValue3 * 0.05F);
               this.updateStateForHudElement6(hudElement22);
               this.updateState4();
               return;
            }
         }

         intValue--;
      }
   }

   private static String computeStringForHudElement(HudElement hudElement4) {
      return hudElement4.computeString();
   }

   private void setBooleanState222() {
      setBooleanState2(this, true);
   }

   private void updateStateForHudElement9(HudElement hudElement4) {
      if (this.hudElement != hudElement4) {
         this.hudElement = hudElement4;
         getSettingEditor(this).updateState();
         this.scrollModel.reset();
      }
   }

   public static void setBooleanState2(HudEditorScreen hudEditorScreen, boolean booleanState22) {
      hudEditorScreen.booleanState2 = booleanState22;
   }

   public static boolean checkCondition3() {
      return DialogUiAccess.getCurrentScreen(MinecraftClient.getInstance()) instanceof HudEditorScreen;
   }

   private void updateStateForHudElement10(HudElement hudElement32, Rect rect, int intValue, double doubleValue, double doubleValue2) {
      this.setHudElement2(hudElement32);
      if (intValue == 1) {
         this.updateStateForHudElement9(hudElement32);
         ClientSounds.updateState5();
      } else {
         if (intValue == 0) {
            HudLayout hudLayout = hudElement32.computeHudLayout();
            if (hudLayout != null) {
               int intValue2;
               if (hudElement32.checkCondition()) {
                  intValue2 = computeIntForRect(rect, doubleValue, doubleValue2);
               } else {
                  intValue2 = -1;
               }

               int intValue22 = intValue2;
               this.hudElement3 = hudElement32;
               ClientSounds.updateState();
               if (intValue22 >= 0) {
                  ThreadLocalRandom.current().nextInt(12);

                  float x = hudLayout.getX();
                  float y = hudLayout.getY();
                  float width2 = hudLayout.getWidth();
                  float height2 = hudLayout.getHeight();
                  float floatValue = this.computeFloat2(doubleValue);
                  float floatValue2 = this.computeFloat4(doubleValue2);
                  this.uiContext.getInputRouter().beginDrag(new HudResizeDragHandler(this, hudElement32, intValue22, x, y, width2, height2, floatValue, floatValue2));
               } else {
                  ThreadLocalRandom.current().nextInt(10);
                  float floatValue3 = this.computeFloat2(doubleValue) - hudLayout.getX();
                  float floatValue4 = this.computeFloat4(doubleValue2) - hudLayout.getY();
                  this.uiContext.getInputRouter().beginDrag(new HudMoveDragHandler(this, hudElement32, floatValue3, floatValue4));
               }
            }
         }
      }
   }

   public static void setBooleanState(HudEditorScreen hudEditorScreen, boolean booleanState3) {
      hudEditorScreen.booleanState = booleanState3;
   }

   @Override
   protected boolean checkCondition4(char charValue) {
      if (this.keybindCapture.checkCondition()) {
         return true;
      } else {
         ThreadLocalRandom.current().nextInt(12);
         return this.settingEditor.checkCondition3(charValue);
      }
   }

   public static List<Float> getFloatList2(HudEditorScreen hudEditorScreen) {
      return hudEditorScreen.floatList2;
   }

   private static void updateStateForHudElement11(HudElement hudElement4, boolean booleanValue) {
      byte byteValue;
      if (!booleanValue) {
         byteValue = 13;
         ThreadLocalRandom.current().nextInt(8);
         byteValue = 1;
      } else {
         byteValue = 11;
         ThreadLocalRandom.current().nextInt(9);
         byteValue = 0;
      }

      HudElements.updateStateForHudElement(hudElement4, (byteValue != 0));
      ClientSounds.updateState4();
   }

   public static ScrollModel getScrollModel2(HudEditorScreen hudEditorScreen) {
      return hudEditorScreen.scrollModel2;
   }

   public static void setHudElement(HudEditorScreen hudEditorScreen, HudElement hudElement4) {
      hudEditorScreen.hudElement = hudElement4;
   }

   public void removed() {
      super.removed();
      this.settingEditor.updateState2();
      this.updateState4();
   }

   private void updateStateForUiContext5(UiContext uiContext2, float floatValue, float floatValue2, float floatValue3) {
      ThemeSnapshot themeSnapshot2 = uiContext2.getThemeSnapshot();
      HudElement hudElement4 = getHudElement(this);
      float floatValue4 = uiContext2.getAnimations().spring("hud.sheet", 0.0F, hudElement4 != null ? 1.0F : (0.0F), 0.32F, 0.88F);
      if (hudElement4 != null) {
         if (!(floatValue4 <= 0.01F)) {
            byte byteValue;
            label104: {
               byteValue = 13;
               ThreadLocalRandom.current().nextInt(5);
               Rect rect = this.computeRectForHudElement(hudElement4);
               if (rect != null) {
                  float floatValue5 = rect.centerX();

                  if (floatValue5 > floatValue / (2.0F)) {
                     byteValue = 1;
                     break label104;
                  }
               }

               byteValue = 0;
            }

            byte byteValue2 = byteValue;
            float floatValue6;
            if (this.booleanState2) {
               floatValue6 = (10.0F);
            } else {
               floatValue6 = 188.0F;
            }

            float floatValue62 = floatValue6;
            float floatValue7;
            if (byteValue2 != 0) {
               floatValue7 = floatValue62;
            } else {
               floatValue7 = floatValue - 10.0F - (232.0F);
            }

            float floatValue8 = floatValue7;
            float floatValue10 = (1.0F - floatValue4) * (16.0F) * (byteValue2 != 0 ? ((-1.0F)) : (1.0F));
            float floatValue11 = Math.min(floatValue2 - 60.0F, 420.0F);
            Rect rect2 = new Rect(uiContext2.getAnimations().springDefault("hud.sheet.x", floatValue8, floatValue8) + floatValue10, 50.0F, (232.0F), floatValue11);
            float opacity = floatValue3 * UiContext.clampUnit(floatValue4);
            PanelRenderer.updateStateForUiContext5(uiContext2, rect2, (14.0F), opacity);
            uiContext2.getInputRouter().addPressRegion(rect2, UiLayer.RAISED, (intValue, doubleValue, doubleValue2) -> updateState3(intValue, doubleValue, doubleValue2));
            boolean booleanValue = HudElements.testHudElement(hudElement4);
            String description = uiContext2.ellipsize(computeStringForHudElement(hudElement4), TextStyle.TITLE, rect2.getWidth() - 80.0F);
            float x = rect2.getX() + 14.0F;
            float y5 = rect2.getY();

            uiContext2.drawVerticallyCenteredText(description, x, y5 + (18.0F), TextStyle.TITLE, UiContext.multiplyAlpha(themeSnapshot2.getPrimaryText(), opacity));
            float floatValue14 = rect2.right() - (36.0F);
            float y52 = rect2.getY();

            Rect rect3 = PanelHeaderRenderer.createRect(floatValue14, y52 + (18.0F));
            PanelHeaderRenderer.updateStateForUiContext(uiContext2, "hud.sheet.switch", rect3, booleanValue, 0.0F, opacity);
            uiContext2.getInputRouter().addClickRegion(rect3.expand((3.0F)), UiLayer.RAISED, () -> updateStateForHudElement11(hudElement4, booleanValue));
            float floatValue15 = rect2.right() - (28.0F);
            float floatValue16 = rect2.getY() + 8.0F;

            ButtonWidgets.updateStateForUiContext2(uiContext2, "hud.sheet.close", new Rect(floatValue15, floatValue16, (20.0F), 20.0F), UiLayer.RAISED, Icon.CLOSE, opacity, () -> this.resetHudElement());
            float y = rect2.getY() + 34.0F;
            if (hudElement4 instanceof Module var19 && var19.getDescription() != null && !var19.getDescription().isBlank()) {
               description = var19.getDescription();
               TextStyle small = TextStyle.SMALL;
               y5 = rect2.getWidth() - 28.0F;

               for (String text : (java.lang.Iterable<String>)(java.lang.Iterable<?>)(uiContext2.wrapText(description, small, y5, 2))) {
                  uiContext2.drawVerticallyCenteredText(text, rect2.getX() + (14.0F), y, TextStyle.SMALL, UiContext.multiplyAlpha(themeSnapshot2.getSecondaryText2(), opacity));

                  y += (10.0F);
               }

               y += 4.0F;
            }

            SectionHeaderWidget.updateStateForUiContext(uiContext2, rect2.getX() + (14.0F), y + 4.0F, rect2.getWidth() - 28.0F, "Layout", null, opacity);
            y += 12.0F;
            float x62 = rect2.getX();

            float floatValue18 = x62 + (10.0F);
            float floatValue19 = rect2.getWidth() - 20.0F;
            if (hudElement4.checkCondition()) {
               Rect rect4 = new Rect(floatValue18, y, floatValue19, 31.0F);
               float floatValue20 = hudElement4.computeFloat6();
               boolean hovered = uiContext2.isHovered(rect4, UiLayer.RAISED);
               PanelRenderer.updateStateForUiContext(uiContext2, rect4, 7.0F, uiContext2.animateHover("hud.scale.h", hovered), opacity);
               uiContext2.drawVerticallyCenteredText("Scale", rect4.getX() + 8.0F, rect4.getY() + 10.0F, TextStyle.LABEL, UiContext.multiplyAlpha(themeSnapshot2.getPrimaryText(), opacity));
               String string2 = NumericSettingFormatter.computeString((double)floatValue20, 2);
               uiContext2.drawRightAlignedText(string2 + "x", rect4.right() - 8.0F, rect4.getY() + (10.0F), TextStyle.SMALL, UiContext.multiplyAlpha(themeSnapshot2.getSecondaryText2(), opacity));
               float x2 = rect4.getX() + 8.0F;
               float width2 = rect4.getWidth() - 16.0F;
               y5 = rect4.getY() + 22.0F;

               float floatValue23 = floatValue20 - (0.4F);

               float floatValue24 = floatValue23 / (3.1F);

               SliderWidgets.updateStateForUiContext3(uiContext2, "hud.scale", x2, y5, width2, floatValue24, hovered, false, opacity);
               uiContext2.getInputRouter().addPressRegion(rect4, UiLayer.RAISED, (intValue2, doubleValue3, doubleValue4) -> this.updateStateForHudElement4(hudElement4, x2, width2, uiContext2, intValue2, doubleValue3, doubleValue4));

               y += (33.0F);
            }

            float floatValue25 = ButtonWidgets.computeFloatForUiContext(uiContext2, "Reset position", Icon.RESET);
            float floatValue26 = floatValue18 + 4.0F;

            float floatValue27 = y + (2.0F);

            ButtonWidgets.updateStateForUiContext4(
               uiContext2,
               "hud.sheet.reset",
               new Rect(floatValue26, floatValue27, floatValue25, (20.0F)),
               UiLayer.RAISED,
               ButtonVariant.SECONDARY,
               "Reset position",
               Icon.RESET,
               opacity,
               () -> this.updateStateForHudElement(hudElement4)
            );
            y += (30.0F);
            List list;
            if (hudElement4 instanceof Module) {
               Module hudElement42 = (Module)hudElement4;
               list = SettingEditor.computeListForList(hudElement42.getSettings());
            } else {
               list = List.of();
            }

            List list2 = list;
            if (!list2.isEmpty()) {
               float x3 = rect2.getX() + 14.0F;

               SectionHeaderWidget.updateStateForUiContext(uiContext2, x3, y + (4.0F), rect2.getWidth() - 28.0F, "Settings", null, opacity);
               y += 12.0F;
               Rect rect5 = new Rect(rect2.getX() + (4.0F), y, rect2.getWidth() - 8.0F, rect2.bottom() - y - 6.0F);
               float floatValue29 = this.scrollModel.update(uiContext2, this.floatState, rect5.getHeight());
               uiContext2.getInputRouter().addScrollRegion(rect5, UiLayer.RAISED, getScrollModel(this)::scroll);
               uiContext2.getUiRenderContext().pushClip(rect5.getX(), rect5.getY(), rect5.getWidth(), rect5.getHeight());
               SettingEditor settingEditor2 = getSettingEditor(this);
               float floatValue30 = rect5.getX() + 2.0F;
               float y53 = rect5.getY();

               this.floatState = settingEditor2.computeFloatForUiContext(uiContext2, list2, floatValue30, y53 + (2.0F) - floatValue29, rect5.getWidth() - 6.0F, UiLayer.RAISED, rect5, opacity) + 8.0F;
               uiContext2.getUiRenderContext().popClip();
               this.scrollModel.drawScrollbar(uiContext2, rect5, getFloatState(this), opacity);
            }

            return;
         }
      }
   }

   public static KeybindCapture getKeybindCapture(HudEditorScreen hudEditorScreen) {
      return hudEditorScreen.keybindCapture;
   }

   public void close() {
      this.updateState6();
   }

   public static boolean getBooleanState2(HudEditorScreen hudEditorScreen) {
      return hudEditorScreen.booleanState2;
   }

   private void resetHudElement() {
      this.hudElement = null;
   }

   private void updateState6() {
      getSettingEditor(this).updateState2();
      this.keybindCapture.updateState();

      setBooleanState(this, true);
      this.updateState4();
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (minecraftClient != null) {
         minecraftClient.setScreen(new ClickGuiScreen());
      }
   }

   private static boolean checkCondition5() {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (minecraftClient != null) {
         if (minecraftClient.getWindow() != null) {
            long handle = minecraftClient.getWindow().getHandle();
            int intValue = GLFW.glfwGetKey(handle, 340);

            if (intValue != 1) {
               intValue = GLFW.glfwGetKey(handle, 344);

               if (intValue != 1) {
                  return false;
               }
            }

            return true;
         }
      }

      ThreadLocalRandom.current().nextInt(8);
      return false;
   }

   static float[] computeFloatArrayForList(float floatValue, float floatValue2, List list, float floatValue3) {
      float floatValue4 = floatValue3;
      float[] floatArray22 = null;
      float[] floatArray2 = new float[3];

      floatArray2[0] = (0.0F);
      floatArray2[1] = floatValue2 / (2.0F);
      floatArray2[2] = floatValue2;
      float[] floatArray23 = floatArray2;

      for (float floatValue5 : (java.lang.Iterable<Float>)(java.lang.Iterable<?>)(list)) {
         float[] floatArray = floatArray23;
         int length = floatArray23.length;

         int intValue = 0;

         while (true) {
            if (intValue >= length) {
               break;
            }

            float floatValue6 = floatArray[intValue];
            float floatValue7 = Math.abs(floatValue + floatValue6 - floatValue5);
            if (floatValue7 < floatValue4) {
               floatValue4 = floatValue7;

               floatArray2 = new float[2];

               floatArray2[0] = floatValue5 - floatValue6;

               floatArray2[1] = floatValue5;
               floatArray22 = floatArray2;
            }

            intValue++;
         }
      }

      return floatArray22;
   }

   private static void updateState7(int intValue, double doubleValue, double doubleValue2) {
   }

   public static boolean getBooleanState(HudEditorScreen hudEditorScreen) {
      return hudEditorScreen.booleanState;
   }

   private void updateState8() {
      getConfirmationDialog(this).updateStateForControlTone("Reset the whole HUD?", "Every element goes back to its designed size and corner.", "Reset", ControlTone.DANGER, () -> this.updateState());
   }

   @Override
   protected void updateStateForUiContext6(UiContext uiContext2, float width2, float height2, float opacity) {
      ThemeSnapshot themeSnapshot2 = uiContext2.getThemeSnapshot();
      this.hudElementList = HudElements.computeList();
      if (this.hudElement != null) {
         if (!this.hudElementList.contains(this.hudElement)) {
            this.hudElement = null;
         }
      }

      uiContext2.getUiRenderContext().fillRect(0.0F, (0.0F), width2, height2, UiContext.multiplyAlpha(themeSnapshot2.getTheme().getBackdropDim(), (0.32F) * opacity));
      Color color = UiContext.multiplyAlpha(themeSnapshot2.getPrimaryText(), 0.07F * opacity);
      float floatValue4 = 24.0F;

      while (floatValue4 < width2) {
         float floatValue5 = 24.0F;

         while (floatValue5 < height2) {
            uiContext2.getUiRenderContext().fillRect(floatValue4 - 0.5F, floatValue5 - 0.5F, (1.0F), 1.0F, color);
            floatValue5 += 24.0F;

            ThreadLocalRandom.current().nextInt(7);
         }

         floatValue4 += 24.0F;
      }

      this.updateStateForUiContext7(uiContext2, width2, height2, opacity);

      for (HudElement hudElement32 : getHudElementList(this)) {
         this.updateStateForUiContext2(uiContext2, hudElement32, opacity);
      }

      this.updateStateForUiContext4(uiContext2, height2, opacity);
      this.updateStateForUiContext3(uiContext2, width2, opacity);
      this.updateStateForUiContext5(uiContext2, width2, height2, opacity);
      getSettingEditor(this).updateStateForUiContext4(uiContext2, new Rect(0.0F, 0.0F, width2, height2), opacity);
      this.confirmationDialog.updateStateForUiContext(uiContext2, "hud.dialog", width2, height2, opacity);
   }

   public static ConfirmationDialog getConfirmationDialog(HudEditorScreen hudEditorScreen) {
      return hudEditorScreen.confirmationDialog;
   }

   @Override
   protected boolean checkCondition6() {
      return false;
   }

   public void updateState9() {
      setHudElement3(this, null);
      getFloatList2(this).clear();
      this.floatList.clear();
      this.booleanState = true;
      this.updateState4();
   }

   private void updateStateForUiContext7(UiContext uiContext2, float width2, float height2, float floatValue3) {
      ThemeSnapshot themeSnapshot2 = uiContext2.getThemeSnapshot();
      int intValue = this.hudElement3 != null ? 1 : 0;

      ThreadLocalRandom.current().nextInt(11);
      int intValue2 = intValue;

      float floatValue4 = uiContext2.animateToggle("hud.guides", (intValue2 != 0), (0.035F));
      if (floatValue4 <= 0.01F) {
         ThreadLocalRandom.current().nextInt(5);
      } else {
         UiRenderContext uiRenderContext = uiContext2.getUiRenderContext();

         float floatValue5 = width2 / (2.0F);

         uiRenderContext.fillRect(floatValue5 - (0.5F), (0.0F), 1.0F, height2, UiContext.multiplyAlpha(themeSnapshot2.getPrimaryText(), 0.08F * floatValue4 * floatValue3));
         UiRenderContext uiRenderContext2 = uiContext2.getUiRenderContext();

         float y = height2 / (2.0F) - 0.5F;

         uiRenderContext2.fillRect(0.0F, y, width2, (1.0F), UiContext.multiplyAlpha(themeSnapshot2.getPrimaryText(), (0.08F) * floatValue4 * floatValue3));
         uiContext2.getUiRenderContext().pushBloom(themeSnapshot2.computeFloat3(0.6F) * floatValue4 * floatValue3);
         Iterator iterator = getFloatList2(this).iterator();

         while (true) {
            if (!iterator.hasNext()) {
               for (float floatValue7 : getFloatList(this)) {
                  float floatValue8 = this.computeFloat3(floatValue7);
                  UiRenderContext uiRenderContext3 = uiContext2.getUiRenderContext();

                  float y2 = floatValue8 - 0.5F;

                  uiRenderContext3.fillRect((0.0F), y2, width2, (1.0F), UiContext.multiplyAlpha(themeSnapshot2.getAccent2(), 0.85F * floatValue4 * floatValue3));
               }

               uiContext2.getUiRenderContext().popBloom();
               return;
            }

            float floatValue10 = (Float)iterator.next();
            float floatValue11 = this.computeFloat(floatValue10);
            UiRenderContext uiRenderContext4 = uiContext2.getUiRenderContext();
            float x = floatValue11 - 0.5F;

            uiRenderContext4.fillRect(x, (0.0F), 1.0F, height2, UiContext.multiplyAlpha(themeSnapshot2.getAccent2(), (0.85F) * floatValue4 * floatValue3));
         }
      }
   }

   public static void setHudElement3(HudEditorScreen hudEditorScreen, HudElement hudElement32) {
      hudEditorScreen.hudElement3 = hudElement32;
   }

}
