package cc.mochi;

import java.awt.Color;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;

public final class ChatMessages implements MinecraftAccess {
   private static final MutableText mutableText = Text.empty().setStyle(Style.EMPTY.withFormatting(Formatting.GRAY));

   public static void updateState(String string) {
      updateStateForMutableText2(Text.literal(string));
   }

   public static void updateStateForMutableText(MutableText mutableText2, boolean booleanValue) {
   }

   public static void updateStateForMutableText2(MutableText mutableText2) {
      updateStateForMutableText(mutableText2, true);
   }

   public static void updateState2(String string) {
      updateStateForText3(Text.literal(string));
   }

   public static void updateStateForText(Text text) {
      MutableText mutableText2 = text.copy().withColor(MessageSeverity.WARNING.getColor2());

      updateStateForMutableText(mutableText2, true);
   }

   public static void updateStateForText2(Text text) {
      updateStateForMutableText(text.copy().withColor(MessageSeverity.INFO.getColor2()), true);
   }

   public static void updateState3(String string, boolean booleanValue) {
      updateStateForMutableText(Text.literal(string), booleanValue);
   }

   public static void updateStateForText3(Text text) {
      MutableText mutableText2 = text.copy().withColor(MessageSeverity.ERROR.getColor2());

      updateStateForMutableText(mutableText2, true);
   }

   private ChatMessages() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }

   public static void updateState4(String string) {
      updateStateForText(Text.literal(string));
   }

   public static void updateState5(boolean booleanValue) {
      updateStateForMutableText(Text.literal(" "), booleanValue);
   }

   public static MutableText getMutableText() {
      return mutableText;
   }

   public static MutableText computeMutableText() {
      MutableText mutableText2 = getMutableText().copy().append("[");
      String string = MessageSeverityAccess.getCLIENT_NAME().toString();
      Style empty = MessageSeverityAccess.getEMPTY();

      Color color = new Color(0, 191, 255);

      return mutableText2.append(computeMutableTextForStyle(string, empty, color, new Color(0, 255, 127))).append("]").append(" ");
   }

   public static void updateState6(String string) {
      updateStateForText2(Text.literal(string));
   }

   public static void updateState7(String string) {
   }

   public static MutableText computeMutableTextForStyle(String string, Style style, Color color, Color color2) {
      MutableText mutableText2 = Text.empty();

      int intValue = 0;

      while (intValue < string.length()) {
         float floatValue = (float)intValue / (float)(string.length() - 1);
         Color color3 = ColorAccess6.createColor2(color, color2, (double)floatValue);
         mutableText2.append(Text.literal(String.valueOf(string.charAt(intValue))).setStyle(style.withColor(TextColor.fromRgb(color3.getRGB()))));
         intValue++;
      }

      return mutableText2;
   }
}
