package cc.mochi;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class EntityMotionTracker {
   private static final MinecraftClient minecraftClient = MinecraftClient.getInstance();

   private static final Map<Integer, EntityMotionHistory> entityMotionHistoryByInteger = new HashMap<>();

   public static int getIntState(EntityMotionHistory entityMotionHistory) {
      return entityMotionHistory.intState;
   }

   public static Vec3d computeVec3dForLivingEntity(LivingEntity livingEntity) {
      EntityMotionHistory entityMotionHistory = computeEntityMotionHistoryForLivingEntity(livingEntity);
      Vec3d vec3d;
      if (getBooleanState(entityMotionHistory)) {
         vec3d = getVec3d2(entityMotionHistory);
      } else {
         vec3d = livingEntity.getVelocity();

         ThreadLocalRandom.current().nextInt(7);
      }

      return vec3d;
   }

   public static void updateStateForEntity(Entity entity) {
      if (entity != null) {
         entityMotionHistoryByInteger.remove(entity.getId());
      }
   }

   public static void setVec3d(EntityMotionHistory entityMotionHistory, Vec3d vec3d) {
      entityMotionHistory.vec3d = vec3d;
   }

   public static void setVec3d2(EntityMotionHistory entityMotionHistory, Vec3d vec3d2) {
      entityMotionHistory.vec3d2 = vec3d2;
   }

   private static Vec3d computeVec3d() {
      float yaw;
      if (RotationManager.getBooleanState()) {
         yaw = RotationManager.computeFloat2();
      } else if (Vec3dAccess2.getPlayer(minecraftClient) != null) {
         yaw = Vec3dAccess2.getPlayer(getMinecraftClient()).getYaw();
      } else {
         yaw = 0.0F;
      }

      float yaw2 = yaw;

      Vec3d vec3d = RotationMath.computeVec3d(yaw2, (0.0F));
      double doubleValue = Math.hypot(vec3d.x, vec3d.z);
      if (doubleValue < 1.0E-4) {
         return new Vec3d((1.0), (0.0), (0.0));
      } else {
         return new Vec3d(Vec3dAccess2.getX(vec3d) / doubleValue, 0.0, Vec3dAccess2.getZ(vec3d) / doubleValue);
      }
   }

   public static void setDoubleState3(EntityMotionHistory entityMotionHistory, double doubleState3) {
      entityMotionHistory.doubleState3 = doubleState3;
   }

   public static void setVec3d6(EntityMotionHistory entityMotionHistory, Vec3d vec3d6) {
      entityMotionHistory.vec3d6 = vec3d6;
   }

   public static void clear() {
      entityMotionHistoryByInteger.clear();
   }

   public static void setTimestampMillis(EntityMotionHistory entityMotionHistory, long timestampMillis) {
      entityMotionHistory.timestampMillis = timestampMillis;
   }

   public static Vec3d getVec3d6(EntityMotionHistory entityMotionHistory) {
      return entityMotionHistory.vec3d6;
   }

   public static MinecraftClient getMinecraftClient() {
      return minecraftClient;
   }

   public static void setDoubleState(EntityMotionHistory entityMotionHistory, double doubleState) {
      entityMotionHistory.doubleState = doubleState;
   }

   private static void updateStateForEntityMotionHistory(EntityMotionHistory entityMotionHistory) {
      setIntState(entityMotionHistory, -1);
      Vec3d vec3d5 = entityMotionHistory.vec3d5;
      Vec3d vec3d = getVec3d2(entityMotionHistory).subtract(entityMotionHistory.vec3d3);
      double doubleValue = Vec3dAccess2.getX(vec3d) * Vec3dAccess2.getX(vec3d5) + Vec3dAccess2.getZ(vec3d) * vec3d5.z;
      double doubleValue2 = doubleValue - entityMotionHistory.doubleState;
      if (!(Math.abs(doubleValue2) > 1.2)) {
         setDoubleState2(entityMotionHistory, MathHelper.clamp(getDoubleState2(entityMotionHistory) + doubleValue2 / getDoubleState3(entityMotionHistory), 0.0, 1.5));
      }
   }

   public static Vec3d getVec3d4(EntityMotionHistory entityMotionHistory) {
      return entityMotionHistory.vec3d4;
   }

   public static int getIntState2(EntityMotionHistory entityMotionHistory) {
      return entityMotionHistory.intState2;
   }

   public static int getAge(EntityMotionHistory entityMotionHistory) {
      return entityMotionHistory.age;
   }

   public static Vec3d getVec3d2(EntityMotionHistory entityMotionHistory) {
      return entityMotionHistory.vec3d2;
   }

   private static double computeDoubleForLivingEntity(LivingEntity livingEntity, double doubleValue) {
      int intValue = computeIntForItemStack(livingEntity.getMainHandStack());
      double attributeValue = livingEntity.getAttributeValue(EntityAttributes.ATTACK_KNOCKBACK);
      double doubleValue2 = attributeValue + (double)intValue;

      double doubleValue3 = doubleValue + doubleValue2 * (0.5);
      if (livingEntity.isSprinting()) {
         if (livingEntity instanceof PlayerEntity) {
            ThreadLocalRandom.current().nextInt(16);

            PlayerEntity livingEntity2 = (PlayerEntity)livingEntity;

            if ((double)livingEntity2.getAttackCooldownProgress((0.5F)) > 0.9) {
               doubleValue3 += (0.5);
            }
         }
      }

      return doubleValue3;
   }

   public static void setAge(EntityMotionHistory entityMotionHistory, int age) {
      entityMotionHistory.age = age;
   }

   public static Map<Integer, EntityMotionHistory> getEntityMotionHistoryByInteger() {
      return entityMotionHistoryByInteger;
   }

   public static Vec3d computeVec3dForLivingEntity2(LivingEntity livingEntity, double doubleValue) {
      EntityMotionHistory entityMotionHistory = computeEntityMotionHistoryForLivingEntity(livingEntity);
      if (entityMotionHistory == null) {
         return Vec3dAccess2.getZERO();
      } else {
         int intValue = (int)Math.ceil(MathHelper.clamp(doubleValue, (0.0), (0.5)) * 20.0);
         int intValue2 = entityMotionHistory.intState2 - entityMotionHistory.age;
         int intValue3 = getVec3d6(entityMotionHistory).lengthSquared() > 1.0E-6 && intValue2 >= 0 ? 1 : 0;
         if (intValue3 != 0) {
            intValue = Math.max(intValue, intValue2 + 3);
         }

         intValue = Math.min(intValue, 12);
         if (intValue <= 0) {
            return Vec3dAccess2.getZERO();
         } else {
            byte byteValue;
            label89: {
               if (!livingEntity.isOnGround()) {
                  if (Math.abs(getVec3d4(entityMotionHistory).y) >= 0.03) {
                     byteValue = 16;
                     ThreadLocalRandom.current().nextInt(11);
                     byteValue = 1;
                     break label89;
                  }
               }

               byteValue = 0;
            }

            byte byteValue2 = byteValue;
            double doubleValue2 = byteValue2 != 0 ? 0.91 : 0.546;
            double x = entityMotionHistory.vec3d4.x;
            double doubleValue3 = byteValue2 != 0 ? Vec3dAccess2.getY(getVec3d4(entityMotionHistory)) : Math.max(0.0, Vec3dAccess2.getY(entityMotionHistory.vec3d4));
            double z = getVec3d4(entityMotionHistory).z;
            double doubleValue4 = 0.0;
            double doubleValue5 = 0.0;
            double doubleValue6 = 0.0;

            double doubleValue7 = (0.0);
            double doubleValue8 = 0.0;

            double doubleValue9 = (0.0);
            int intValue4 = 0;

            while (true) {
               if (intValue4 >= intValue) {
                  return new Vec3d(doubleValue7, doubleValue8, doubleValue9);
               }

               if (intValue3 != 0) {
                  if (intValue4 == intValue2) {
                     doubleValue4 += getVec3d6(entityMotionHistory).x;
                     doubleValue5 += getVec3d6(entityMotionHistory).y;
                     doubleValue6 += entityMotionHistory.vec3d6.z;
                  }
               }

               doubleValue7 += x + doubleValue4;
               doubleValue8 += doubleValue3 + doubleValue5;
               doubleValue9 += z + doubleValue6;
               doubleValue4 *= doubleValue2;
               doubleValue6 *= doubleValue2;
               double doubleValue10 = doubleValue5 - 0.08;

               doubleValue5 = doubleValue10 * (0.98);
               if (byteValue2 != 0) {
                  double doubleValue11 = doubleValue3 - (0.08);

                  doubleValue3 = doubleValue11 * (0.98);
               }

               intValue4++;
            }
         }
      }
   }

   public static void setVec3d4(EntityMotionHistory entityMotionHistory, Vec3d vec3d4) {
      entityMotionHistory.vec3d4 = vec3d4;
   }

   public static double getDoubleState3(EntityMotionHistory entityMotionHistory) {
      return entityMotionHistory.doubleState3;
   }

   public static void setDoubleState2(EntityMotionHistory entityMotionHistory, double doubleState2) {
      entityMotionHistory.doubleState2 = doubleState2;
   }

   public static void setIntState2(EntityMotionHistory entityMotionHistory, int intState2) {
      entityMotionHistory.intState2 = intState2;
   }

   private static int computeIntForItemStack(ItemStack itemStack) {
      if (itemStack.isEmpty()) {
         ThreadLocalRandom.current().nextInt(13);

         return 0;
      } else {
         ItemEnchantmentsComponent enchantments = EnchantmentHelper.getEnchantments(itemStack);
         if (enchantments.isEmpty()) {
            return 0;
         } else {
            Iterator iterator = enchantments.getEnchantments().iterator();

            while (iterator.hasNext()) {
               RegistryEntry registryEntry = (RegistryEntry)iterator.next();
               if (registryEntry.matchesKey(Vec3dAccess2.getKNOCKBACK())) {
                  return enchantments.getLevel(registryEntry);
               }
            }

            return 0;
         }
      }
   }

   public static long getTimestampMillis(EntityMotionHistory entityMotionHistory) {
      return entityMotionHistory.timestampMillis;
   }

   public static double getDoubleState2(EntityMotionHistory entityMotionHistory) {
      return entityMotionHistory.doubleState2;
   }

   public static void setIntState(EntityMotionHistory entityMotionHistory, int intState) {
      entityMotionHistory.intState = intState;
   }

   public static void updateStateForEntity2(Entity entity) {
      if (entity instanceof LivingEntity var1 && var1 != Vec3dAccess2.getPlayer(minecraftClient)) {
         if (Vec3dAccess2.getPlayer(getMinecraftClient()) != null) {
            EntityMotionHistory entityMotionHistory = computeEntityMotionHistoryForLivingEntity(var1);
            if (entityMotionHistory == null) {
               return;
            }

            long timestampMillis = System.currentTimeMillis();
            if (getTimestampMillis(entityMotionHistory) > 0L) {
               long longValue = timestampMillis - entityMotionHistory.timestampMillis;

               if (longValue < 1000L) {
                  setTimestampMillis(entityMotionHistory, timestampMillis);
                  return;
               }
            }

            entityMotionHistory.timestampMillis = timestampMillis;
            double attributeValue = var1.getAttributeValue(Vec3dAccess2.getKNOCKBACK_RESISTANCE());

            double doubleValue = MathHelper.clamp(attributeValue, (0.0), (0.95));

            double doubleState3 = (1.0) - doubleValue;
            double doubleValue3 = computeDoubleForLivingEntity(Vec3dAccess2.getPlayer(minecraftClient), entityMotionHistory.doubleState2) * doubleState3;
            if (doubleValue3 <= 0.02) {
               return;
            }

            Vec3d vec3d5 = computeVec3d();
            Vec3d vec3d3 = getVec3d4(entityMotionHistory);
            double doubleValue4 = vec3d5.x * doubleValue3 - Vec3dAccess2.getX(vec3d3) * 0.5;
            double doubleValue5 = vec3d5.z * doubleValue3 - vec3d3.z * 0.5;
            double doubleValue6 = 0.0;
            if (var1.isOnGround()) {
               attributeValue = (0.4);
               double y = vec3d3.y;

               doubleValue6 = Math.min((0.4), y * (0.5) + doubleValue3) - Vec3dAccess2.getY(vec3d3);
            }

            setVec3d6(entityMotionHistory, new Vec3d(doubleValue4, doubleValue6, doubleValue5));
            setIntState2(entityMotionHistory, getAge(entityMotionHistory) + computeInt());
            entityMotionHistory.vec3d3 = vec3d3;
            entityMotionHistory.vec3d5 = vec3d5;
            setDoubleState(entityMotionHistory, doubleValue4 * Vec3dAccess2.getX(vec3d5) + doubleValue5 * Vec3dAccess2.getZ(vec3d5));
            setDoubleState3(entityMotionHistory, doubleState3);
            entityMotionHistory.intState = getIntState2(entityMotionHistory) + 1;
            return;
         }
      }
   }

   private EntityMotionTracker() {
   }

   public static void setBooleanState(EntityMotionHistory entityMotionHistory, boolean booleanState) {
      entityMotionHistory.booleanState = booleanState;
   }

   private static int computeInt() {
      int intValue = 90;
      if (minecraftClient.player != null) {
         ThreadLocalRandom.current().nextInt(4);

         if (getMinecraftClient().getNetworkHandler() != null) {
            PlayerListEntry playerListEntry = minecraftClient.getNetworkHandler().getPlayerListEntry(getMinecraftClient().player.getUuid());
            if (playerListEntry != null) {
               intValue = Math.max(0, playerListEntry.getLatency());
            }
         } else {
            ThreadLocalRandom.current().nextInt(5);
         }
      }

      int intValue2 = Math.round((float)intValue / 100.0F);

      return MathHelper.clamp(intValue2 + 1, 1, 8);
   }

   public static boolean getBooleanState(EntityMotionHistory entityMotionHistory) {
      return entityMotionHistory.booleanState;
   }

   private static EntityMotionHistory computeEntityMotionHistoryForLivingEntity(LivingEntity livingEntity) {
      int id = livingEntity.getId();
      EntityMotionHistory entityMotionHistory = getEntityMotionHistoryByInteger().get(id);
      int age = livingEntity.age;
      if (entityMotionHistory != null && getAge(entityMotionHistory) <= age) {
         if (getAge(entityMotionHistory) == age) {
            ThreadLocalRandom.current().nextInt(4);
            return entityMotionHistory;
         } else {
            Vec3d vec3d = livingEntity.getEntityPos();

            double doubleValue = (double)Math.max(1, age - getAge(entityMotionHistory));
            Vec3d vec3d2 = vec3d.subtract(entityMotionHistory.vec3d);
            if (vec3d2.lengthSquared() > 16.0) {
               ThreadLocalRandom.current().nextInt(3);
               setAge(entityMotionHistory, age);
               entityMotionHistory.vec3d = vec3d;
               entityMotionHistory.vec3d4 = Vec3dAccess2.getZERO();
               entityMotionHistory.vec3d2 = Vec3dAccess2.getZERO();
               entityMotionHistory.vec3d6 = Vec3d.ZERO;
               entityMotionHistory.intState2 = -1;
               setIntState(entityMotionHistory, -1);
               setTimestampMillis(entityMotionHistory, 0L);

               setBooleanState(entityMotionHistory, false);
               return entityMotionHistory;
            } else {
               Vec3d vec3d22 = vec3d2.multiply((1.0) / doubleValue);
               setVec3d2(entityMotionHistory, vec3d22);

               setBooleanState(entityMotionHistory, true);
               Vec3d vec3d4 = entityMotionHistory.vec3d4;
               Vec3d vec3d5 = vec3d22.subtract(entityMotionHistory.vec3d4);

               setVec3d4(entityMotionHistory, vec3d4.add(vec3d5.multiply((0.45))));
               if (getIntState(entityMotionHistory) >= 0) {
                  if (age >= entityMotionHistory.intState) {
                     updateStateForEntityMotionHistory(entityMotionHistory);
                  }
               }

               entityMotionHistory.age = age;
               entityMotionHistory.vec3d = vec3d;
               return entityMotionHistory;
            }
         }
      } else {
         if (getEntityMotionHistoryByInteger().size() >= 96) {
            entityMotionHistoryByInteger.clear();
         }

         entityMotionHistory = new EntityMotionHistory();
         entityMotionHistory.age = age;
         setVec3d(entityMotionHistory, livingEntity.getEntityPos());
         entityMotionHistoryByInteger.put(id, entityMotionHistory);
         return entityMotionHistory;
      }
   }
}
