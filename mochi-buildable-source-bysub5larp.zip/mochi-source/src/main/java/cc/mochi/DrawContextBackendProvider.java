package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;
import org.joml.Matrix3x2fStack;

public final class DrawContextBackendProvider implements RenderBackendProvider {
   @Override
   public UiRenderBackend openUnscaled(DrawContext drawContext, int intValue, int intValue2) {
      return new DrawContextRenderBackend(drawContext, 1.0F, 1.0F);
   }

   @Override
   public void drawTexture(
      DrawContext drawContext,
      int intValue,
      int intValue2,
      Identifier identifier,
      float floatValue,
      float floatValue2,
      float floatValue3,
      float floatValue4,
      float floatValue5,
      float floatValue6,
      int intValue3,
      int intValue4,
      int intValue5,
      int intValue6
   ) {
      int intValue7 = Math.max(1, MinecraftClient.getInstance().getWindow().getScaledWidth());
      int intValue8 = Math.max(1, MinecraftClient.getInstance().getWindow().getScaledHeight());
      Matrix3x2fStack matrices = drawContext.getMatrices();
      matrices.pushMatrix();
      matrices.scale((float)intValue7 / (float)Math.max(1, intValue), (float)intValue8 / (float)Math.max(1, intValue2));
      drawContext.drawTexture(
         RenderPipelines.GUI_TEXTURED, identifier, Math.round(floatValue), Math.round(floatValue2), floatValue5, floatValue6, Math.round(floatValue3), Math.round(floatValue4), intValue3, intValue4, intValue5, intValue6
      );
      matrices.popMatrix();
   }

   @Override
   public boolean isFallback() {
      return true;
   }

   @Override
   public void initialize() {
   }

   @Override
   public void resetResources() {
   }

   @Override
   public UiRenderBackend openScaled(DrawContext drawContext, int intValue, int intValue2) {
      int intValue3 = Math.max(1, MinecraftClient.getInstance().getWindow().getScaledWidth());
      int intValue4 = Math.max(1, MinecraftClient.getInstance().getWindow().getScaledHeight());
      return new DrawContextRenderBackend(drawContext, (float)intValue3 / (float)Math.max(1, intValue), (float)intValue4 / (float)Math.max(1, intValue2));
   }
}
