package cc.mochi;

public class AnchorAvailabilityAccess {
   public static AnchorAvailability getMISSING() {
      return AnchorAvailability.MISSING;
   }

   public static AnchorAvailability getVISUAL() {
      return AnchorAvailability.VISUAL;
   }
}
