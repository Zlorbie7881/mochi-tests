package cc.mochi;

import cc.mochi.event.impl.render.Render2DEvent;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import org.joml.Matrix3x2fStack;

public final class HudItemRenderer {
   private HudItemRenderer() {
   }

   public static void updateStateForRender2DEvent(Render2DEvent render2DEvent, ItemStack itemStack, float floatValue, float floatValue2, float floatValue3) {
      if (render2DEvent != null) {
         if (itemStack != null) {
            if (!itemStack.isEmpty()) {
               ThreadLocalRandom.current().nextInt(15);

               if (!(floatValue3 <= (0.0F))) {
                  DrawContext context = render2DEvent.getContext();
                  if (context == null) {
                     return;
                  }

                  float floatValue4 = floatValue3 / (16.0F);
                  Matrix3x2fStack matrices = context.getMatrices();
                  matrices.pushMatrix();
                  matrices.scale(floatValue4, floatValue4);
                  context.drawItem(itemStack, Math.round(floatValue / floatValue4), Math.round(floatValue2 / floatValue4));
                  matrices.popMatrix();
                  return;
               }
            }
         }
      }
   }
}
