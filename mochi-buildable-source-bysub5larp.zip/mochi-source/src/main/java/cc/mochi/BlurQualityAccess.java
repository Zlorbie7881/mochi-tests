package cc.mochi;

public final class BlurQualityAccess {
   private BlurQualityAccess() {
   }

   public static boolean checkCondition(float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5, float floatValue6, String string) {
      return HudBlurRenderer.testBlurQuality3(floatValue, floatValue2, floatValue3, floatValue4, floatValue5, Math.max(0.5F, floatValue6 / 8.0F), BlurQuality.computeBlurQuality(string));
   }
}
