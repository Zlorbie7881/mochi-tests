package cc.mochi;

import com.google.gson.JsonObject;
import java.util.concurrent.ThreadLocalRandom;

public final class HudLayoutJson {
   private static HudHorizontalAlignment computeHudHorizontalAlignmentForJsonObject(JsonObject jsonObject) {
      try {
         return HudHorizontalAlignment.valueOf(jsonObject.get("anchorH").getAsString());
      } catch (IllegalArgumentException failure) {
         return HudHorizontalAlignment.LEFT;
      }
   }

   public static void updateStateForJsonObject(JsonObject jsonObject, HudElement hudElement) {
      if (jsonObject != null) {
         if (hudElement != null) {
            HudLayout hudLayout = hudElement.computeHudLayout();
            if (hudLayout != null) {
               if (hudElement.checkCondition2()) {
                  JsonObject jsonObject2 = new JsonObject();
                  jsonObject2.addProperty("x", hudLayout.getX());
                  jsonObject2.addProperty("y", hudLayout.getY());
                  if (hudElement.checkCondition()) {
                     jsonObject2.addProperty("w", hudLayout.getWidth());
                     jsonObject2.addProperty("h", hudLayout.getHeight());
                  }

                  jsonObject2.addProperty("anchorH", hudLayout.getHudHorizontalAlignment().name());
                  jsonObject2.addProperty("anchorV", hudLayout.getHudVerticalAlignment().name());
                  jsonObject2.addProperty("insetX", hudLayout.getHorizontalInset());
                  jsonObject2.addProperty("insetY", hudLayout.getVerticalInset());
                  jsonObject2.addProperty("pinned", hudLayout.isUserPositioned());
                  jsonObject.add("hud", jsonObject2);
                  return;
               }
            }

            return;
         }
      }
   }

   public static void updateStateForHudElement(HudElement hudElement) {
      if (hudElement != null) {
         ThreadLocalRandom.current().nextInt(6);

         hudElement.updateState7();
      } else {
         ThreadLocalRandom.current().nextInt(7);
      }
   }

   private HudLayoutJson() {
   }

   private static HudVerticalAlignment computeHudVerticalAlignmentForJsonObject(JsonObject jsonObject) {
      ThreadLocalRandom.current().nextInt(5);

      try {
         return HudVerticalAlignment.valueOf(jsonObject.get("anchorV").getAsString());
      } catch (IllegalArgumentException failure) {
         return HudVerticalAlignment.TOP;
      }
   }

   public static void updateStateForJsonObject2(JsonObject jsonObject, HudElement hudElement) {
      if (jsonObject != null && hudElement != null) {
         HudLayout hudLayout = hudElement.computeHudLayout();
         if (hudLayout != null) {
            JsonObject asJsonObject;
            label166: {
               if (jsonObject.has("hud")) {
                  if (jsonObject.get("hud").isJsonObject()) {
                     asJsonObject = jsonObject.getAsJsonObject("hud");
                     break label166;
                  }
               }

               asJsonObject = null;
            }

            JsonObject asJsonObject2 = asJsonObject;
            if (asJsonObject2 == null) {
               byte byteValue;
               if (!jsonObject.has("hudX") && !jsonObject.has("hudY")) {
                  byteValue = 0;
               } else {
                  byteValue = 1;
               }

               byte byteValue2 = byteValue;
               if (jsonObject.has("hudX")) {
                  hudLayout.setX(jsonObject.get("hudX").getAsFloat());
               }

               if (jsonObject.has("hudY")) {
                  hudLayout.setY(jsonObject.get("hudY").getAsFloat());
               }

               if (byteValue2 != 0) {
                  hudElement.updateState6(true);
               }
            } else {
               if (asJsonObject2.has("x")) {
                  hudLayout.setX(asJsonObject2.get("x").getAsFloat());
               }

               if (asJsonObject2.has("y")) {
                  hudLayout.setY(asJsonObject2.get("y").getAsFloat());
               }

               if (hudElement.checkCondition()) {
                  if (asJsonObject2.has("w")) {
                     hudLayout.setWidth(Math.max((8.0F), asJsonObject2.get("w").getAsFloat()));
                  }

                  if (asJsonObject2.has("h")) {
                     hudLayout.setHeight(Math.max(8.0F, asJsonObject2.get("h").getAsFloat()));
                  }
               }

               if (hudLayout.isDefaultBounds()) {
                  hudLayout.reset();
               } else {
                  if (asJsonObject2.has("pinned")) {
                     if (!asJsonObject2.get("pinned").getAsBoolean()) {
                        hudLayout.clearUserPositioned();
                        hudLayout.markDirty();
                        return;
                     }
                  }

                  int intValue = asJsonObject2.has("anchorH") && asJsonObject2.has("anchorV") ? 1 : 0;
                  if (intValue != 0) {
                     HudHorizontalAlignment hudHorizontalAlignment = computeHudHorizontalAlignmentForJsonObject(asJsonObject2);
                     HudVerticalAlignment hudVerticalAlignment = computeHudVerticalAlignmentForJsonObject(asJsonObject2);
                     float asFloat;
                     if (asJsonObject2.has("insetX")) {
                        asFloat = asJsonObject2.get("insetX").getAsFloat();
                     } else {
                        ThreadLocalRandom.current().nextInt(16);
                        asFloat = 0.0F;
                     }

                     hudLayout.setAlignmentAndInsets(hudHorizontalAlignment, hudVerticalAlignment, asFloat, asJsonObject2.has("insetY") ? asJsonObject2.get("insetY").getAsFloat() : (0.0F));
                  }

                  hudElement.updateState6(intValue == 0);
               }
            }
         }
      }
   }
}
