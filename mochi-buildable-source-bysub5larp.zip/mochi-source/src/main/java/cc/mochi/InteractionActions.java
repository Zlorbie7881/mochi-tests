package cc.mochi;

import cc.mochi.mixin.MinecraftClientAccessor;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;
import net.minecraft.world.RaycastContext.ShapeType;

public class InteractionActions {
   public static boolean testMinecraftClient(MinecraftClient minecraftClient) {
      return testMinecraftClient2(minecraftClient, "combat.use.place.generic");
   }

   public static BlockHitResult computeBlockHitResultForMinecraftClient(MinecraftClient minecraftClient) {
      if (minecraftClient.crosshairTarget != null) {
         if (PlayerHitAccess.getCrosshairTarget(minecraftClient).getType() == PlayerHitAccess.getBLOCK()) {
            return (BlockHitResult)minecraftClient.crosshairTarget;
         }
      }

      return null;
   }

   private static boolean testClientPlayerEntity(ClientPlayerEntity clientPlayerEntity, Entity entity) {
      if (entity != clientPlayerEntity) {
         if (!entity.isSpectator()) {
            if (entity.canHit()) {
               return true;
            }
         }
      }

      return false;
   }

   private static boolean testWorld(World world, BlockPos blockPos, BlockState blockState, Direction direction, Vec3d vec3d) {
      VoxelShape outlineShape = blockState.getOutlineShape(world, blockPos);
      Box box = outlineShape.isEmpty() ? new Box(blockPos) : outlineShape.getBoundingBox().offset(blockPos);
      int intValue;
      switch (InteractionDirectionSwitchMap.intArray3[direction.ordinal()]) {
         case 1:
            intValue = PlayerHitAccess.getY(vec3d) >= box.maxY ? 1 : 0;
            break;
         case 2:
            intValue = vec3d.y <= box.minY ? 1 : 0;
            break;
         case 3:
            if (PlayerHitAccess.getZ(vec3d) <= box.minZ) {
               intValue = 1;
            } else {
               intValue = 0;
            }
            break;
         case 4:
            if (PlayerHitAccess.getZ(vec3d) >= box.maxZ) {
               intValue = 1;
            } else {
               intValue = 0;
            }
            break;
         case 5:

            if (PlayerHitAccess.getX(vec3d) <= box.minX) {
               intValue = 1;
            } else {
               intValue = 0;
            }
            break;
         case 6:
            if (PlayerHitAccess.getX(vec3d) >= PlayerHitAccess.getMaxX(box)) {
               intValue = 1;
            } else {
               intValue = 0;
            }
            break;
         default:

            throw new MatchException(null, null);
      }

      return (intValue != 0);
   }

   public static boolean testMinecraftClient2(MinecraftClient minecraftClient, String string) {
      if (minecraftClient.player != null) {
         if (minecraftClient.world != null) {
            if (PlayerHitAccess.getInteractionManager(minecraftClient) != null) {
               if (PlayerHitAccess.getCurrentScreen(minecraftClient) != null) {
                  return false;
               }

               if (PlayerHitAccess.getCrosshairTarget(minecraftClient) != null) {
                  ThreadLocalRandom.current().nextInt(15);
                  if (minecraftClient.crosshairTarget.getType() == PlayerHitAccess.getBLOCK()) {
                     ThreadLocalRandom.current().nextInt(6);
                     ItemStack stackInHand = minecraftClient.player.getStackInHand(PlayerHitAccess.getMAIN_HAND());
                     if (!stackInHand.isEmpty() && stackInHand.isItemEnabled(PlayerHitAccess.getWorld(minecraftClient).getEnabledFeatures())) {
                        ThreadLocalRandom.current().nextInt(16);
                        if (PlayerHitAccess.getInteractionManager(minecraftClient).getCurrentGameMode() == PlayerHitAccess.getSPECTATOR()) {
                           return false;
                        }

                        ((MinecraftClientAccessor)minecraftClient).invokeDoItemUse();
                        return true;
                     }

                     return false;
                  }
               }

               return false;
            }
         }
      }

      return false;
   }

   public static boolean testMinecraftClient3(MinecraftClient minecraftClient) {
      if (PlayerHitAccess.getPlayer(minecraftClient) != null) {
         if (minecraftClient.world != null) {
            if (PlayerHitAccess.getInteractionManager(minecraftClient) != null) {
               if (minecraftClient.currentScreen != null) {
                  return false;
               }

               ThreadLocalRandom.current().nextInt(15);
               if (PlayerHitAccess.getCrosshairTarget(minecraftClient) != null) {
                  if (PlayerHitAccess.getCrosshairTarget(minecraftClient).getType() == PlayerHitAccess.getBLOCK()) {
                     if (minecraftClient.player.isUsingItem()) {
                        return false;
                     }

                     ItemStack stackInHand = minecraftClient.player.getStackInHand(Hand.MAIN_HAND);
                     return ((!stackInHand.isEmpty() && stackInHand.isItemEnabled(minecraftClient.world.getEnabledFeatures()) ? 1 : 0) != 0);
                  }
               }

               return false;
            }
         }
      }

      return false;
   }

   public static BlockHitTarget computeBlockHitTargetForWorld(World world, ClientPlayerEntity clientPlayerEntity, Vec3d vec3d, float floatValue, float floatValue2, ItemStack itemStack) {
      if (world != null && clientPlayerEntity != null && vec3d != null) {
         if (itemStack != null) {
            if (!itemStack.isEmpty() && itemStack.getItem() instanceof BlockItem var6 && itemStack.isItemEnabled(world.getEnabledFeatures())) {
               if (clientPlayerEntity.getAbilities().allowModifyWorld) {
                  double blockInteractionRange = clientPlayerEntity.getBlockInteractionRange();
                  Vec3d vec3d2 = BlockInteractUtils.computeVec3d(floatValue2, floatValue);
                  BlockHitResult blockHitResult = world.raycast(new RaycastContext(vec3d, vec3d.add(vec3d2.multiply(blockInteractionRange)), ShapeType.OUTLINE, PlayerHitAccess.getNONE(), clientPlayerEntity));
                  if (blockHitResult instanceof BlockHitResult var11 && blockHitResult.getType() == PlayerHitAccess.getBLOCK() && !var11.isInsideBlock()) {
                     BlockPos blockPos = var11.getBlockPos();
                     BlockState blockState = world.getBlockState(blockPos);
                     if (!BlockPlacementUtils.testBlockState(blockState)) {
                        if (testWorld(world, blockPos, blockState, var11.getSide(), vec3d)) {
                           Vec3d pos = var11.getPos();
                           double doubleValue = Math.min(clientPlayerEntity.getEntityInteractionRange(), vec3d.distanceTo(pos));

                           if (doubleValue > (1.0E-4)) {
                              Vec3d vec3d3 = vec3d.add(vec3d2.multiply(doubleValue));
                              if (ProjectileUtil.getEntityCollision(
                                    world, clientPlayerEntity, vec3d, vec3d3, new Box(vec3d, vec3d3).expand(1.0), entity -> testClientPlayerEntity(clientPlayerEntity, (Entity)entity), 0.0F
                                 )
                                 != null) {
                                 ThreadLocalRandom.current().nextInt(14);
                                 return null;
                              }

                              ThreadLocalRandom.current().nextInt(9);
                           }

                           ItemPlacementContext placementContext = var6.getPlacementContext(new ItemPlacementContext(clientPlayerEntity, Hand.MAIN_HAND, itemStack, var11));
                           if (placementContext != null && placementContext.canPlace()) {
                              BlockPos blockPos2 = placementContext.getBlockPos();
                              if (world.isOutOfHeightLimit(blockPos2)) {
                                 return null;
                              }

                              BlockState placementState = var6.getBlock().getPlacementState(placementContext);
                              if (placementState != null) {
                                 if (placementState.canPlaceAt(world, blockPos2) && world.canPlace(placementState, blockPos2, ShapeContext.of(clientPlayerEntity))) {
                                    return new BlockHitTarget(var11, blockPos2, placementState);
                                 }
                              }

                              return null;
                           }

                           return null;
                        }
                     }

                     return null;
                  }

                  return null;
               }
            }
         }
      }

      return null;
   }
}
