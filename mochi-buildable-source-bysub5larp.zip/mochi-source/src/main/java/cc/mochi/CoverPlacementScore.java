package cc.mochi;

import java.util.List;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

public record CoverPlacementScore(BlockPos cell, ItemStack stack, List<Box> collision, double after, double score, double distance) {
   public static double getAfter(CoverPlacementScore coverPlacementScore) {
      return coverPlacementScore.after;
   }

   public double getAfter2() {
      return getAfter(this);
   }

   public BlockPos getCell() {
      return this.cell;
   }

   public double getScore() {
      return this.score;
   }

   public double getDistance() {
      return this.distance;
   }

   public List getCollision() {
      return this.collision;
   }

   public ItemStack getStack() {
      return this.stack;
   }
}
