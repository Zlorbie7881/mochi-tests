package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;

public final class ClientSounds {
   private static void updateStateForSoundEvent(SoundEvent soundEvent, float floatValue, float floatValue2) {
      if (ClickGuiModule.getValue8()) {
         MinecraftClient minecraftClient = MinecraftClient.getInstance();
         if (minecraftClient != null && minecraftClient.getSoundManager() != null) {
            try {
               minecraftClient.getSoundManager().play(PositionedSoundInstance.ui(soundEvent, floatValue, floatValue2));
            } catch (RuntimeException failure) {
            }
         }
      }
   }

   public static void updateState() {
      updateStateForSoundEvent((SoundEvent)SoundEvents.UI_BUTTON_CLICK.value(), 0.12F, 2.2F);
   }

   private ClientSounds() {
   }

   public static void updateState2() {
      updateStateForSoundEvent((SoundEvent)SoundEvents.BLOCK_NOTE_BLOCK_BASS.value(), 0.4F, 0.8F);
   }

   public static void updateState3() {
      updateStateForSoundEvent((SoundEvent)SoundEventsAccess.getBLOCK_NOTE_BLOCK_PLING().value(), 0.28F, 1.9F);
   }

   public static void updateState4() {
      updateStateForSoundEvent((SoundEvent)SoundEvents.UI_BUTTON_CLICK.value(), 0.35F, 1.35F);
   }

   public static void updateState5() {
      updateStateForSoundEvent((SoundEvent)SoundEventsAccess.getUI_BUTTON_CLICK().value(), 0.22F, 1.8F);
   }
}
