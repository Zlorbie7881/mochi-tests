package cc.mochi;

import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.mixin.LivingEntityAccessor;
import it.unimi.dsi.fastutil.objects.Object2IntMap.Entry;
import java.util.Iterator;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;

public class LungeSwapModule extends Module {
   private boolean booleanState;
   private final BooleanSetting holdToLungeSetting;
   private final HotbarSlotSetting swapBackSlotSetting;

   private final ChoiceSetting modeSetting;
   private int selectedSlot;

   private long longState;
   private int intState;
   private boolean booleanState2;

   private final KeybindSetting activationKeySetting;
   private final BooleanSetting swapBackToSlotSetting;
   private boolean booleanState3;

   private final BooleanSetting swapBackSetting;

   public static void setBooleanState2(LungeSwapModule lungeSwapModule, boolean booleanState22) {
      lungeSwapModule.booleanState2 = booleanState22;
   }

   public static int getSelectedSlot(LungeSwapModule lungeSwapModule) {
      return lungeSwapModule.selectedSlot;
   }

   public static void setIntState(LungeSwapModule lungeSwapModule, int intState2) {
      lungeSwapModule.intState = intState2;
   }

   public static void setLongState(LungeSwapModule lungeSwapModule, long longState2) {
      lungeSwapModule.longState = longState2;
   }

   public static boolean getBooleanState3(LungeSwapModule lungeSwapModule) {
      return lungeSwapModule.booleanState3;
   }

   public static BooleanSetting getSwapBackSetting(LungeSwapModule lungeSwapModule) {
      return lungeSwapModule.swapBackSetting;
   }

   public static BooleanSetting getHoldToLungeSetting(LungeSwapModule lungeSwapModule) {
      return lungeSwapModule.holdToLungeSetting;
   }

   @EventHandler
   private void onTickEvent(TickEvent tickEvent) {
      if (!this.isWorldUnavailable()) {
         boolean booleanState22 = KeybindUtils.checkCondition(this.activationKeySetting.getKeyCode());
         byte byteValue;
         if (booleanState22 && !getBooleanState2(this)) {
            byteValue = 1;
         } else {
            byteValue = 0;
         }

         byte byteValue2;
         label130: {
            byteValue2 = byteValue;
            this.booleanState2 = booleanState22;
            if (!getBooleanState3(this)) {
               if (!getBooleanState(this)) {
                  byteValue = 1;
                  break label130;
               }
            }

            byteValue = 0;
         }

         label124: {
            byte byteValue3 = byteValue;
            if (byteValue3 != 0) {
               if (byteValue2 != 0) {
                  this.updateState();

                  break label124;
               }
            }

            label120:
            if (byteValue3 != 0 && getHoldToLungeSetting(this).isOn() && booleanState22) {
               if (!this.modeSetting.equals("Blatant")) {
                  float attackCooldownProgress = MinecraftClientAccess42.getPlayer(mc).getAttackCooldownProgress(0.0F);

                  if (!(attackCooldownProgress >= (1.0F))) {
                     break label120;
                  }
               }

               this.updateState();
            }
         }

         if (this.booleanState3) {
            if (!CombatActionCoordinator.checkCondition()) {
               boolean booleanValue = getModeSetting(this).equals("Blatant");
               this.updateState3(this.intState);
               if (booleanValue) {
                  if (mc.player.getAttackCooldownProgress((0.0F)) < 1.0F) {
                     int intValue = (int)Math.ceil((double)MinecraftClientAccess42.getPlayer(mc).getAttackCooldownProgressPerTick());
                     ((LivingEntityAccessor)mc.player).setTicksSinceLastAttack(intValue);
                  }

                  InventorySynchronization.updateStateForMinecraftClient2(mc);
               } else if (mc.player.getAttackCooldownProgress(0.0F) >= 1.0F) {
                  InventorySynchronization.updateStateForMinecraftClient2(mc);
               }

               setLongState(this, System.currentTimeMillis() + (booleanValue ? 10L : this.computeLong()));

               this.booleanState3 = false;
               this.booleanState = true;
            }
         } else {
            if (getBooleanState(this) && System.currentTimeMillis() >= this.longState) {
               setBooleanState(this, false);
               if (getSwapBackSetting(this).isOn()) {
                  this.updateState2();
               }
            }
         }
      }
   }

   @Override
   public void onEnable() {
      setBooleanState2(this, false);
      this.booleanState3 = false;
      this.booleanState = false;

      this.intState = -1;
      this.selectedSlot = -1;
      setLongState(this, 0L);
   }

   private boolean testSetting(Setting setting) {
      if (setting instanceof KeybindSetting) {
         if (!setting.equals(this.activationKeySetting)) {
            return true;
         }
      }

      return false;
   }

   public static void setBooleanState3(LungeSwapModule lungeSwapModule, boolean booleanState32) {
      lungeSwapModule.booleanState3 = booleanState32;
   }

   public static ChoiceSetting getModeSetting(LungeSwapModule lungeSwapModule) {
      return lungeSwapModule.modeSetting;
   }

   private static String getPath(RegistryKey registryKey) {
      return registryKey.getValue().getPath();
   }

   private long computeLong() {
      return 15L + (long)(Math.random() * 16.0);
   }

   private int computeInt() {
      int intValue = 0;

      while (true) {
         if (intValue >= 9) {
            return -1;
         }

         ItemStack stack = MinecraftClientAccess42.getPlayer(mc).getInventory().getStack(intValue);
         if (this.testItemStack(stack)) {
            return intValue;
         }

         intValue++;
      }
   }

   public static boolean getBooleanState(LungeSwapModule lungeSwapModule) {
      return lungeSwapModule.booleanState;
   }

   public static void setBooleanState(LungeSwapModule lungeSwapModule, boolean booleanState4) {
      lungeSwapModule.booleanState = booleanState4;
   }

   public static HotbarSlotSetting getSwapBackSlotSetting(LungeSwapModule lungeSwapModule) {
      return lungeSwapModule.swapBackSlotSetting;
   }

   private boolean testItemStack(ItemStack itemStack) {
      if (itemStack.isEmpty()) {
         return false;
      } else {
         ItemEnchantmentsComponent itemEnchantmentsComponent = (ItemEnchantmentsComponent)itemStack.get(MinecraftClientAccess42.getENCHANTMENTS());
         if (itemEnchantmentsComponent == null) {
            return false;
         } else {
            Iterator iterator = itemEnchantmentsComponent.getEnchantmentEntries().iterator();

            while (true) {
               if (!iterator.hasNext()) {
                  return false;
               }

               Entry entry = (Entry)iterator.next();
               RegistryEntry key = (RegistryEntry)entry.getKey();
               String string = ((String)key.getKey().map(objectValue -> getPath((RegistryKey)objectValue)).orElse("")).toLowerCase();
               String string2 = ((Enchantment)key.value()).description().getString().toLowerCase();
               if (string.contains("lunge")) {
                  break;
               }

               if (string2.contains("lunge")) {
                  break;
               }
            }

            return true;
         }
      }
   }

   public static boolean getBooleanState2(LungeSwapModule lungeSwapModule) {
      return lungeSwapModule.booleanState2;
   }

   private void updateState() {
      if (this.modeSetting.equals("Legit")) {
         if (MinecraftClientAccess42.getPlayer(mc).getAttackCooldownProgress(0.0F) < 1.0F) {
            return;
         }
      }

      int intState2 = this.computeInt();
      if ((intState2 != -1)) {
         this.selectedSlot = MinecraftClientAccess42.getPlayer(mc).getInventory().getSelectedSlot();
         this.intState = intState2;

         setBooleanState3(this, true);
      }
   }

   public static void setSelectedSlot(LungeSwapModule lungeSwapModule, int selectedSlot2) {
      lungeSwapModule.selectedSlot = selectedSlot2;
   }

   private Boolean equals() {
      return getModeSetting(this).equals("Legit");
   }

   @Override
   public int getKeyCode() {
      return -1;
   }

   private void updateState2() {
      if (this.swapBackToSlotSetting.isOn()) {
         InventoryUtils.updateState3(getSwapBackSlotSetting(this).getSlotIndex());
      } else {
         if (this.selectedSlot != -1) {
            ThreadLocalRandom.current().nextInt(3);
            InventoryUtils.updateState3(getSelectedSlot(this));
         } else {
            ThreadLocalRandom.current().nextInt(8);
         }
      }
   }

   private static Boolean returnTrue() {
      return true;
   }

   private void updateState3(int intValue) {
      InventoryUtils.updateState3(intValue);
   }

   @Override
   public void onDisable() {
      if (getBooleanState(this)) {
         this.updateState2();
      }

      setBooleanState2(this, false);

      this.booleanState3 = false;

      this.booleanState = false;
      setIntState(this, -1);
      setSelectedSlot(this, -1);
      this.longState = 0L;
   }

   public LungeSwapModule() {
      super("Lunge Swap", "Swaps to the lunge spear and attacks via an activation key", -1, ModuleCategory.COMBAT);

      this.modeSetting = new ChoiceSetting("Mode", "Legit", "Legit", "Blatant");

      this.activationKeySetting = new KeybindSetting("Activation Key", 86, false);
      this.swapBackSetting = new BooleanSetting("Swap Back", true);

      this.swapBackToSlotSetting = new BooleanSetting("Swap Back To Slot", false);

      this.swapBackSlotSetting = new HotbarSlotSetting("Swap Back Slot", 1);
      this.holdToLungeSetting = new BooleanSetting("Hold To Lunge", false);
      this.booleanState2 = false;
      this.booleanState3 = false;
      this.booleanState = false;

      this.intState = -1;
      this.selectedSlot = -1;

      this.longState = (0L);

      Setting[] settingArray = new Setting[]{this.modeSetting, this.activationKeySetting, this.swapBackSetting, null, null, null};

      settingArray[3] = this.swapBackToSlotSetting;

      settingArray[4] = this.swapBackSlotSetting;
      settingArray[5] = this.holdToLungeSetting;
      this.addSettings(settingArray);
      this.getSettings().removeIf(objectValue -> this.testSetting((Setting)objectValue));
      this.swapBackSetting.setVisibility(() -> this.equals());
      this.swapBackToSlotSetting.setVisibility(() -> this.swapBackSetting.isOn());
      this.swapBackSlotSetting.setVisibility(() -> this.swapBackToSlotSetting.isOn());
      this.holdToLungeSetting.setVisibility(() -> returnTrue());
   }

}
