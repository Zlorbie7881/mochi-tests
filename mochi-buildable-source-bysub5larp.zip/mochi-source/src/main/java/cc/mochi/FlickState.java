package cc.mochi;

public enum FlickState {
   IDLE,
   PREPARE,
   FLICK,
   DONE;

   private static final FlickState[] ENUM_VALUES = {IDLE, PREPARE, FLICK, DONE};

   private static FlickState[] computeFlickStateArray() {
      FlickState[] flickStateArray = new FlickState[4];

      flickStateArray[0] = IDLE;
      flickStateArray[1] = getPREPARE();
      flickStateArray[2] = FLICK;

      flickStateArray[3] = getDONE();
      return flickStateArray;
   }

   public static FlickState[] getENUM_VALUES() {
      return ENUM_VALUES;
   }

   public static FlickState getDONE() {
      return DONE;
   }

   public static FlickState getPREPARE() {
      return PREPARE;
   }
}
