package cc.mochi;

public interface FloatRenderCall {
   float render();
}
