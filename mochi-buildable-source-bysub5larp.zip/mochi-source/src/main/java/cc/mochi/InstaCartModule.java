package cc.mochi;

import cc.mochi.event.impl.network.DisconnectEvent;
import cc.mochi.event.impl.network.PacketEvent;
import cc.mochi.event.impl.player.BowReleaseEvent;
import cc.mochi.event.impl.player.MovementSendEvent;
import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.event.impl.world.WorldChangeEvent;
import cc.mochi.event.types.TransferOrder;
import cc.mochi.mixin.ClientPlayerInteractionManagerMixin;
import cc.mochi.mixin.PersistentProjectileAccessor;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Predicate;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.AbstractRailBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.enums.RailShape;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.vehicle.AbstractMinecartEntity;
import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.BowItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public final class InstaCartModule extends Module {
   private int intState;

   private BlockPos blockPos;

   private final BooleanSetting safeModeSetting;

   private Vec3d vec3d;
   private int intState2;

   private final Queue<ProjectileState> projectileStateQueue;
   private float yaw;
   private boolean booleanState;

   private final BooleanSetting autoReleaseSetting;

   private boolean booleanState2;

   private static final Comparator<InstaCartPlan> comparator = Comparator.<InstaCartPlan>comparingInt(instaCartPlan -> instaCartPlan.getHits2())
      .reversed()
      .thenComparing(Comparator.<InstaCartPlan>comparingDouble(instaCartPlan2 -> instaCartPlan2.getDistance()).reversed())
      .thenComparing(Comparator.<InstaCartPlan>comparingInt(instaCartPlan3 -> computeIntForInstaCartPlan(instaCartPlan3)).reversed());

   private int intState3;

   private final DoubleSetting releaseChargeSetting;

   private RotationProfile rotationProfile;
   private long longState;

   private Item item;

   private ClientPlayerEntity clientPlayerEntity;

   private final Set<Integer> integerSet;

   private final ChoiceSetting aimModeSetting;

   private int intState4;

   private Vec3d vec3d2;

   private final InstaCartCycle instaCartCycle;

   private final DoubleSetting doubleSetting;

   private CoverPlacementPlan coverPlacementPlan;

   private CartInterceptPlan cartInterceptPlan;
   private float pitch;

   private final DoubleSetting releaseMarginSetting;

   private boolean booleanState3;

   private final BooleanSetting safeFallbackSetting;
   private ClientWorld clientWorld;
   private ProjectileLaunch projectileLaunch;
   private BlockPos blockPos2;

   public InstaCartModule() {
      super("InstaCart", "Places a rail and TNT minecart in the path of your Flame arrow, with optional cover", ModuleCategory.COMBAT);
      String[] stringArray = new String[2];

      stringArray[0] = "Legit";

      stringArray[1] = "Silent";
      this.aimModeSetting = new ChoiceSetting("Aim Mode", "Silent", stringArray);

      this.doubleSetting = new LegacyRotationSpeedSetting(this, "Rotation Speed", (1.0), 10.0, (10.0), (1.0));
      this.safeModeSetting = new BooleanSetting("Safe Mode", false);
      this.safeFallbackSetting = new BooleanSetting("Safe Fallback", true);
      this.autoReleaseSetting = new BooleanSetting("Auto Release", false);

      this.releaseChargeSetting = new DoubleSetting("Release Charge", (10.0), 100.0, 100.0, 1.0);

      this.releaseMarginSetting = new DoubleSetting("Release Margin", 0.0, (3.0), (1.0), (1.0));
      this.instaCartCycle = new InstaCartCycle();
      this.projectileStateQueue = new ConcurrentLinkedQueue<>();
      this.integerSet = new HashSet<>();

      this.longState = (-9223372036854775808L);

      this.intState2 = -1;

      this.intState4 = -1;

      this.intState3 = -1;
      this.intState = -1;

      Setting[] settingArray = new Setting[]{this.aimModeSetting, null, null, null, null, null, null};

      settingArray[1] = this.doubleSetting;
      settingArray[2] = this.safeModeSetting;

      settingArray[3] = this.safeFallbackSetting;
      settingArray[4] = this.autoReleaseSetting;
      settingArray[5] = this.releaseChargeSetting;

      settingArray[6] = this.releaseMarginSetting;
      this.addSettings(settingArray);
      this.safeFallbackSetting.setVisibility(() -> this.safeModeSetting.isOn());
      this.releaseChargeSetting.setVisibility(() -> this.autoReleaseSetting.isOn());
      this.releaseMarginSetting.setVisibility(() -> this.autoReleaseSetting.isOn());
   }

   public static InstaCartCycle getInstaCartCycle(InstaCartModule instaCartModule) {
      return instaCartModule.instaCartCycle;
   }

   public static void setBooleanState2(InstaCartModule instaCartModule, boolean booleanState22) {
      instaCartModule.booleanState2 = booleanState22;
   }

   private void updateStateForInstaCartPlan(InstaCartPlan instaCartPlan, List list, int intValue) {
      this.blockPos2 = instaCartPlan.getCandidate2().getRail2();
      this.blockPos = instaCartPlan.getCandidate2().getSupport2();
      int coverSteps;
      if (instaCartPlan.getCover2() == null && instaCartPlan.getLastOffset() == instaCartPlan.getCartOffset()) {
         ThreadLocalRandom.current().nextInt(15);
         coverSteps = -1;
      } else {
         coverSteps = instaCartPlan.getCoverSteps();
      }

      setIntState4(this, coverSteps);
      BlockAim blockAim = ProjectileAimPlanner.computeBlockAimForWorld3(cc.mochi.MinecraftClientAccess44.getWorld(mc), mc.player, ProjectileAimPlanner.createVec3d(cc.mochi.MinecraftClientAccess44.getPlayer(mc), computeBoxForList(list, intValue, intValue)), getBlockPos(this), Direction.UP, this.blockPos2, getYaw(this));
      Vec3d vec3d22;
      if (blockAim != null) {
         vec3d22 = blockAim.getPoint2();
      } else {
         ThreadLocalRandom.current().nextInt(7);
         vec3d22 = instaCartPlan.getCandidate2().getAimPoint2();
      }

      setVec3d2(this, vec3d22);
   }

   static MinecraftClient getMc2() {
      return mc;
   }

   public static void setCoverPlacementPlan(InstaCartModule instaCartModule, CoverPlacementPlan coverPlacementPlan2) {
      instaCartModule.coverPlacementPlan = coverPlacementPlan2;
   }

   private static boolean returnFalse(Entity entity) {
      return false;
   }

   public static Queue<ProjectileState> getProjectileStateQueue(InstaCartModule instaCartModule) {
      return instaCartModule.projectileStateQueue;
   }

   private void updateState(boolean booleanValue) {
      ActionSchedulers.updateState4(this);
      if (booleanValue) {
         RotationManager.updateState(this);
      }

      this.instaCartCycle.updateState3();
      setClientPlayerEntity(this, null);
      this.clientWorld = null;
      getIntegerSet(this).clear();
      this.projectileStateQueue.clear();
      this.projectileLaunch = null;

      this.intState2 = -1;

      this.booleanState = false;
      this.blockPos2 = this.blockPos = null;
      setItem(this, null);
      setVec3d(this, null);
      this.vec3d2 = null;
      this.booleanState3 = false;

      setIntState4(this, -1);
      setCoverPlacementPlan(this, null);
      this.cartInterceptPlan = null;
      setRotationProfile(this, null);
      this.intState3 = this.intState = -1;
      setBooleanState2(this, false);
   }

   public static CartInterceptPlan getCartInterceptPlan(InstaCartModule instaCartModule) {
      return instaCartModule.cartInterceptPlan;
   }

   private static Box computeBoxForList(List list, int intValue, int intValue2) {
      int intValue3 = list.size();

      intValue3 -= 1;
      int intValue4 = intValue2 - intValue;

      return (Box)list.get(Math.max(0, Math.min(intValue3, intValue4 + 1)));
   }

   public static float getYaw(InstaCartModule instaCartModule) {
      return instaCartModule.yaw;
   }

   public static ProjectileLaunch getProjectileLaunch(InstaCartModule instaCartModule) {
      return instaCartModule.projectileLaunch;
   }

   public static BlockPos getBlockPos2(InstaCartModule instaCartModule) {
      return instaCartModule.blockPos2;
   }

   private String computeStringForList(List list, List list2, int intValue) {
      BlockState blockState = cc.mochi.MinecraftClientAccess44.getWorld(mc).getBlockState(getBlockPos2(this));
      if (blockState.getBlock() instanceof AbstractRailBlock var5 && !((RailShape)blockState.get(var5.getShapeProperty())).isAscending()) {
         int intValue2 = ProjectilePhysics.computeIntForWorld(mc.world, getClientPlayerEntity(this), (ProjectileLanding)list.get(0), getBlockPos2(this));
         int intValue3 = getInstaCartCycle(this).max2();
         BlockAim blockAim = ProjectileAimPlanner.computeBlockAimForWorld2(cc.mochi.MinecraftClientAccess44.getWorld(mc), mc.player, ProjectileAimPlanner.createVec3d(mc.player, computeBoxForList(list2, intValue, intValue)), getBlockPos2(this), 0.0625, getYaw(this));
         if (blockAim != null) {
            this.vec3d2 = blockAim.getPoint2();
         }

         int intValue4;
         if (blockAim == null) {
            intValue4 = 1;
         } else {
            intValue4 = this.computeInt(this.yaw, getPitch(this), blockAim.getYaw2(), blockAim.getPitch2());
         }

         int intValue42 = intValue4;
         int intValue6 = intValue3 + 1;

         int intValue7 = ColorInterpolation.computeInt3(intValue, intValue6, intValue3 + 1, intValue42);

         if (!ColorInterpolation.checkCondition(intValue7, intValue2, 0)) {
            return "cart would be late (intercept " + intValue2 + ")";
         }

         if (getInstaCartCycle(this).getBooleanState22()) {
            if (getIntState4(this) >= 0) {
               intValue4 = ColorInterpolation.computeInt4(intValue7, this.intState4);

               if (!ColorInterpolation.checkCondition(intValue4, intValue2, 0)) {
                  if (!this.safeFallbackSetting.isOn()) {
                     return "cover would be late";
                  }

                  this.instaCartCycle.resetBooleanState();
                  setIntState4(this, -1);
               }
            }
         }

         return null;
      }

      return "rail missing or sloped";
   }

   public static float getPitch(InstaCartModule instaCartModule) {
      return instaCartModule.pitch;
   }

   private long getCurrentTick22() {
      return ActionSchedulers.getCurrentTick22();
   }

   private void updateState2() {
      if (getAutoReleaseSetting(this).isOn()) {
         if (this.checkCondition()) {
            if (mc.player.isUsingItem()) {
               if (cc.mochi.MinecraftClientAccess44.getUseKey(mc.options).isPressed()) {
                  if (RotationManager.computeVec3d(this) == null) {
                     if (this.longState != Long.MIN_VALUE) {
                        ItemStack activeItem = cc.mochi.MinecraftClientAccess44.getPlayer(mc).getActiveItem();
                        float pullProgress = BowItem.getPullProgress(mc.player.getItemUseTime());
                        if (!(pullProgress < Math.max((0.1F), getReleaseChargeSetting(this).floatValue() / 100.0F))) {
                           if (this.testItemStack(activeItem, pullProgress)) {
                              ProjectileLaunch projectileLaunch2 = ProjectileAimPlanner.computeProjectileLaunchForEntity(cc.mochi.MinecraftClientAccess44.getPlayer(mc), getYaw(this), this.pitch, pullProgress);
                              ClientWorld world23 = cc.mochi.MinecraftClientAccess44.getWorld(mc);
                              ClientPlayerEntity player3 = cc.mochi.MinecraftClientAccess44.getPlayer(mc);
                              Predicate predicate = objectValue -> returnFalse((Entity)objectValue);

                              List list = ProjectileAimPlanner.computeListForWorld2(world23, player3, projectileLaunch2, predicate, 0);
                              if (!this.testList(list)) {
                                 return;
                              }

                              cc.mochi.MinecraftClientAccess44.getOptions(mc).useKey.setPressed(false);
                              return;
                           }
                        }

                        return;
                     }
                  }
               }
            } else {
               ThreadLocalRandom.current().nextInt(11);
            }
         }
      }
   }

   public static void setItem(InstaCartModule instaCartModule, Item item2) {
      instaCartModule.item = item2;
   }

   public static void setIntState4(InstaCartModule instaCartModule, int intState42) {
      instaCartModule.intState4 = intState42;
   }

   private static boolean testItem(Item item2, ItemStack itemStack) {
      if (!itemStack.isEmpty()) {
         if (itemStack.isOf(item2)) {
            ThreadLocalRandom.current().nextInt(10);

            ThreadLocalRandom.current().nextInt(8);

            return true;
         }
      }

      return false;
   }

   public static void setVec3d2(InstaCartModule instaCartModule, Vec3d vec3d22) {
      instaCartModule.vec3d2 = vec3d22;
   }

   public static int getIntState3(InstaCartModule instaCartModule) {
      return instaCartModule.intState3;
   }

   private void updateState3(long longValue) {
      this.instaCartCycle.updateState(longValue);
   }

   private static boolean returnFalse2(Entity entity) {
      return false;
   }

   public static Set<Integer> getIntegerSet(InstaCartModule instaCartModule) {
      return instaCartModule.integerSet;
   }

   private BlockHitResult computeBlockHitResult() {
      if (this.blockPos2 == null) {
         return null;
      } else {
         BlockHitResult blockHitResult = BlockInteractUtils.computeBlockHitResultForBlockPos3(this.blockPos2);
         if (blockHitResult != null) {
            HitResult hitResult = BlockInteractUtils.computeHitResult2();
            if (hitResult instanceof BlockHitResult) {
               BlockHitResult hitResult2 = (BlockHitResult)hitResult;
               if (hitResult2.getType() == Type.BLOCK) {
                  if (hitResult2.getBlockPos().equals(this.blockPos2)) {
                     BlockState blockState = cc.mochi.MinecraftClientAccess44.getWorld(mc).getBlockState(getBlockPos2(this));
                     Block block = blockState.getBlock();
                     if (block instanceof AbstractRailBlock) {
                        AbstractRailBlock block2 = (AbstractRailBlock)block;
                        if (!((RailShape)blockState.get(block2.getShapeProperty())).isAscending()) {
                           ClientWorld world17 = cc.mochi.MinecraftClientAccess44.getWorld(mc);
                           Box box = new Box(getBlockPos2(this));

                           if (world17.getOtherEntities(
                                 null, box.expand((0.05)), entity -> testEntity((Entity)entity)
                              )
                              .isEmpty()) {
                              return blockHitResult;
                           }
                        }
                     }

                     return null;
                  }

                  ThreadLocalRandom.current().nextInt(3);
               }
            }
         }

         return null;
      }
   }

   public static CoverPlacementPlan getCoverPlacementPlan(InstaCartModule instaCartModule) {
      return instaCartModule.coverPlacementPlan;
   }

   private static boolean testEntity(Entity entity) {
      return entity instanceof AbstractMinecartEntity;
   }

   public static void setCartInterceptPlan(InstaCartModule instaCartModule, CartInterceptPlan cartInterceptPlan2) {
      instaCartModule.cartInterceptPlan = cartInterceptPlan2;
   }

   private boolean testItemStack(ItemStack itemStack, float floatValue) {
      if (itemStack.getItem() instanceof BowItem) {
         ThreadLocalRandom.current().nextInt(10);
         if (EnchantmentUtils.testItemStack4(itemStack, cc.mochi.MinecraftClientAccess44.getWorld(mc), Enchantments.FLAME)) {
            if (floatValue >= (0.1F)) {
               if (!mc.player.getProjectileType(itemStack).isEmpty()) {
                  if (ProjectileAimPlanner.computeIntForWorld(mc.world, null) >= 0 && this.computeIntForItem(cc.mochi.MinecraftClientAccess44.getTNT_MINECART()) >= 0) {
                     if (getSafeModeSetting(this).isOn()) {
                        if (!this.safeFallbackSetting.isOn()) {
                           if (InventoryUtils.computeIntForPredicate2(objectValue -> CartCoverPlanner.testItemStack((ItemStack)objectValue)) < 0) {
                              return false;
                           }
                        }
                     }

                     return true;
                  }
               }
            }
         } else {
            ThreadLocalRandom.current().nextInt(3);
         }
      }

      return false;
   }

   @Override
   public void onEnable() {
      this.updateState(false);

      setLongState(this, Long.MIN_VALUE);
   }

   private InstaCartPlan computeInstaCartPlanForInstaCartPlan(InstaCartPlan instaCartPlan, ProjectileLanding projectileLanding, List list, int intValue, int intValue2) {
      RailPlacementCandidate candidate2 = instaCartPlan.getCandidate2();
      int intValue3 = candidate2.computeInt3();

      Box box = computeBoxForList(list, intValue, intValue3 - 1);
      double doubleValue = CartCoverPlanner.computeDoubleForWorld(cc.mochi.MinecraftClientAccess44.getWorld(mc), cc.mochi.MinecraftClientAccess44.getPlayer(mc), candidate2.computeVec3d(), box);

      if (doubleValue <= (0.0)) {
         return instaCartPlan;
      } else {
         int intValue72 = instaCartPlan.getCartOffset() + 1;
         Object objectValue = null;

         int intValue5 = 0;
         int intValue6 = 0;

         do {
            CartInterceptPlan cartInterceptPlan2 = this.computeCartInterceptPlanForBlockPos(candidate2.getRail2(), projectileLanding, intValue3, intValue72, list, intValue, box);
            objectValue = CartCoverPlanner.computeCoverPlacementPlanForWorld2(cc.mochi.MinecraftClientAccess44.getWorld(mc), cc.mochi.MinecraftClientAccess44.getPlayer(mc), cartInterceptPlan2, candidate2.getYaw2(), this.computeList());
            if (objectValue == null) {
               return null;
            }

            intValue5 = this.computeInt(candidate2.getYaw2(), candidate2.getPitch2(), ((CoverPlacementPlan)objectValue).getYaw2(), ((CoverPlacementPlan)objectValue).getPitch2());
            int intValue7 = ColorInterpolation.computeInt4(instaCartPlan.getCartOffset(), intValue5);
            if (intValue7 == intValue72) {
               break;
            }

            intValue72 = intValue7;
            intValue6++;
         } while (intValue6 < 2);

         if (!ColorInterpolation.checkCondition(intValue72, intValue3, intValue2)) {
            return null;
         } else {
            return new InstaCartPlan(candidate2, instaCartPlan.getRailOffset2(), instaCartPlan.getCartOffset(), intValue72, candidate2.computeInt2(intValue72, intValue2), (CoverPlacementPlan)objectValue, intValue5, instaCartPlan.getDistance());
         }
      }
   }

   public static Comparator<InstaCartPlan> getComparator() {
      return comparator;
   }

   private boolean checkCondition() {
      if (cc.mochi.MinecraftClientAccess44.getPlayer(mc) != null) {
         if (cc.mochi.MinecraftClientAccess44.getWorld(mc) != null && cc.mochi.MinecraftClientAccess44.getInteractionManager(mc) != null && cc.mochi.MinecraftClientAccess44.getCurrentScreen(mc) == null) {
            ThreadLocalRandom.current().nextInt(11);

            if (!mc.isPaused()) {
               ThreadLocalRandom.current().nextInt(15);
               if (cc.mochi.MinecraftClientAccess44.getPlayer(mc).isAlive()) {
                  if (!cc.mochi.MinecraftClientAccess44.getPlayer(mc).hasVehicle()) {
                     if (mc.interactionManager.getCurrentGameMode() != cc.mochi.MinecraftClientAccess44.getSPECTATOR()) {
                        return true;
                     }
                  }
               }
            }
         }
      }

      return false;
   }

   @EventHandler
   private void onDisconnect(DisconnectEvent disconnectEvent) {
      this.updateState(true);

      this.longState = Long.MIN_VALUE;
   }

   public static DoubleSetting getReleaseChargeSetting(InstaCartModule instaCartModule) {
      return instaCartModule.releaseChargeSetting;
   }

   public static void setBooleanState3(InstaCartModule instaCartModule, boolean booleanState32) {
      instaCartModule.booleanState3 = booleanState32;
   }

   private void updateStateForList(List list) {
      Box box = (Box)list.get(0);
      int intValue = list.size();

      Box box2 = (Box)list.get(Math.min(1, intValue - 1));
      setVec3d(this, this.vec3d2.subtract(cc.mochi.MinecraftClientAccess44.getMinX(box2) - cc.mochi.MinecraftClientAccess44.getMinX(box), box2.minY - cc.mochi.MinecraftClientAccess44.getMinY(box), cc.mochi.MinecraftClientAccess44.getMinZ(box2) - box.minZ));
      RotationManager.updateStateForActionPriority(this, ActionPriority.HIGH, () -> this.getVec3d(), getRotationProfile(this));
      RotationManager.updateState11(this, this.yaw, this.pitch);
   }

   private String computeStringForList2(List list, List list2, int intValue) {
      ProjectileLanding projectileLanding = (ProjectileLanding)list.get(0);
      int intValue2 = ProjectilePhysics.computeIntForWorld(mc.world, getClientPlayerEntity(this), projectileLanding, this.blockPos2);
      if (intValue2 < 1) {
         ThreadLocalRandom.current().nextInt(11);
         return "arrow no longer meets the cart";
      } else {
         Box box = computeBoxForList(list2, intValue, intValue2 - 1);
         if (CartCoverPlanner.computeDoubleForWorld(mc.world, cc.mochi.MinecraftClientAccess44.getPlayer(mc), ProjectileAimPlanner.computeVec3dForBlockPos(getBlockPos2(this)), box) <= 0.0) {
            return "covered";
         } else {
            int intValue3 = this.instaCartCycle.max2();

            int intValue4 = Math.max(intValue, intValue3 + 1);
            setCartInterceptPlan(this, this.computeCartInterceptPlanForBlockPos(getBlockPos2(this), projectileLanding, intValue2, intValue4, list2, intValue, box));
            CoverPlacementPlan coverPlacementPlan2 = null;
            if (this.coverPlacementPlan != null && this.computeIntForItem(getCoverPlacementPlan(this).getItem2()) >= 0) {
               if (CartCoverPlanner.testWorld7(cc.mochi.MinecraftClientAccess44.getWorld(mc), cc.mochi.MinecraftClientAccess44.getPlayer(mc), getCartInterceptPlan(this), this.coverPlacementPlan)) {
                  coverPlacementPlan2 = CartCoverPlanner.computeCoverPlacementPlanForWorld(mc.world, cc.mochi.MinecraftClientAccess44.getPlayer(mc), getCoverPlacementPlan(this), this.cartInterceptPlan.getEye(), this.yaw);
               }
            }

            if (coverPlacementPlan2 == null) {
               coverPlacementPlan2 = CartCoverPlanner.computeCoverPlacementPlanForWorld2(cc.mochi.MinecraftClientAccess44.getWorld(mc), cc.mochi.MinecraftClientAccess44.getPlayer(mc), getCartInterceptPlan(this), this.yaw, this.computeList());
            }

            if (coverPlacementPlan2 == null) {
               return "no cover";
            } else {
               this.coverPlacementPlan = coverPlacementPlan2;
               intValue4 = ColorInterpolation.computeInt3(intValue, intValue3 + 1, intValue3 + 1, this.computeInt(this.yaw, getPitch(this), coverPlacementPlan2.getYaw2(), coverPlacementPlan2.getPitch2()));
               if (!ColorInterpolation.checkCondition(intValue4, intValue2, 0)) {
                  return "cover would be late (intercept " + intValue2 + ")";
               } else {
                  this.vec3d2 = coverPlacementPlan2.getAimPoint2();
                  return null;
               }
            }
         }
      }
   }

   private BlockHitResult computeBlockHitResult2() {
      if (this.coverPlacementPlan != null) {
         if (getCartInterceptPlan(this) != null) {
            BlockHitResult blockHitResult = BlockInteractUtils.computeBlockHitResultForBlockPos2(getCoverPlacementPlan(this).getCell());
            if (CartCoverPlanner.testBlockHitResult(blockHitResult, getCoverPlacementPlan(this))) {
               if (BlockInteractUtils.computeHitResult2() instanceof BlockHitResult var2) {
                  if (CartCoverPlanner.testBlockHitResult(var2, this.coverPlacementPlan)) {
                     if (CartCoverPlanner.testWorld2(cc.mochi.MinecraftClientAccess44.getWorld(mc), cc.mochi.MinecraftClientAccess44.getPlayer(mc), this.coverPlacementPlan, blockHitResult)) {
                        Box boundingBox = mc.player.getBoundingBox();
                        Box box = boundingBox.offset(
                           mc.player.lastX - cc.mochi.MinecraftClientAccess44.getPlayer(mc).getX(),
                           mc.player.lastY - cc.mochi.MinecraftClientAccess44.getPlayer(mc).getY(),
                           cc.mochi.MinecraftClientAccess44.getPlayer(mc).lastZ - cc.mochi.MinecraftClientAccess44.getPlayer(mc).getZ()
                        );

                        for (Box box2 : (java.lang.Iterable<Box>)(java.lang.Iterable<?>)(getCoverPlacementPlan(this).getCollision2())) {
                           if (box2.intersects(boundingBox) || box2.intersects(box)) {
                              return null;
                           }
                        }

                        return blockHitResult;
                     }
                  }
               } else {
                  ThreadLocalRandom.current().nextInt(16);
               }
            }

            return null;
         }
      } else {
         ThreadLocalRandom.current().nextInt(11);
      }

      return null;
   }

   public static int getIntState4(InstaCartModule instaCartModule) {
      return instaCartModule.intState4;
   }

   public static BooleanSetting getSafeModeSetting(InstaCartModule instaCartModule) {
      return instaCartModule.safeModeSetting;
   }

   private CartInterceptPlan computeCartInterceptPlanForBlockPos(BlockPos blockPos3, ProjectileLanding projectileLanding, int intValue, int intValue2, List list, int intValue3, Box box) {
      Box box2 = computeBoxForList(list, intValue3, intValue2);
      return new CartInterceptPlan(blockPos3, projectileLanding.getPath2(), intValue, intValue2, computeBoxForList(list, intValue3, intValue2 - 1), box2, ProjectileAimPlanner.createVec3d(cc.mochi.MinecraftClientAccess44.getPlayer(mc), box2), box);
   }

   public static void setRotationProfile(InstaCartModule instaCartModule, RotationProfile rotationProfile2) {
      instaCartModule.rotationProfile = rotationProfile2;
   }

   public static int[] getIntArray2() {
      return InstaCartStateSwitchMap.intArray2;
   }

   @Override
   public void onDisable() {
      ActionSchedulers.updateState4(this);
      RotationManager.updateState9(this);
      this.updateState4();
      if (this.booleanState2) {
         if (this.checkCondition2()) {
            cc.mochi.MinecraftClientAccess44.getINSTANCE().getMochiEventBus().subscribe(new InventorySnapshot(this.clientPlayerEntity, getClientWorld(this), this.intState, getIntState3(this)));
         }
      } else {
         ThreadLocalRandom.current().nextInt(16);
      }

      this.updateState(false);
   }

   private void updateState4() {
      if ((this.booleanState2)) {
         if (this.checkCondition2()) {
            ThreadLocalRandom.current().nextInt(12);
            if (InventoryUtils.computeInt() == this.intState) {
               long longState2 = this.longState;
               long currentTick22 = this.getCurrentTick22();

               if (longState2 == currentTick22 - (1L)) {
                  if (CombatTickBudget.checkCondition2()) {
                     InventoryUtils.updateState3(this.intState3);
                     ((ClientPlayerInteractionManagerMixin.ClientPlayerInteractionManagerAccessor)mc.interactionManager).mochi$syncSelectedSlot();
                     CombatTickBudget.setBooleanState222();
                     setBooleanState2(this, false);
                     return;
                  }
               }

               return;
            }
         }

         setBooleanState2(this, false);
      }
   }

   private boolean testList(List list) {
      if (!list.isEmpty()) {
         if (!list.contains(null)) {
            int intValue = (getSafeModeSetting(this).isOn()) ? 1 : 0;
            int intValue2 = this.releaseMarginSetting.intValue();
            List list2 = ProjectileAimPlanner.computeListForWorld3(mc.world, mc.player, 82, this.yaw);

            InstaCartPlan instaCartPlan = this.computeInstaCartPlanForList(list, list2, 0, 1, intValue2, (intValue != 0), -1);
            if (instaCartPlan == null && intValue != 0) {
               if (this.safeFallbackSetting.isOn()) {
                  intValue = 0;

                  instaCartPlan = this.computeInstaCartPlanForList(list, list2, 0, 1, intValue2, false, -1);
               }
            }

            if (instaCartPlan == null) {
               return false;
            }

            if (instaCartPlan.getHits2() == list.size()) {
               return true;
            }

            int intValue3 = ColorInterpolation.computeInt(computeIntForClientPlayerEntity(mc.player));

            int intValue4 = Math.max(0, instaCartPlan.getCoverSteps());
            Iterator iterator = list.iterator();

            while (iterator.hasNext()) {
               ProjectileLanding projectileLanding = (ProjectileLanding)iterator.next();
               if (this.computeInstaCartPlanForList(List.of(projectileLanding), list2, 0, intValue3, intValue2, (intValue != 0), intValue4) == null) {
                  return false;
               }
            }

            return true;
         }
      }

      return false;
   }

   public static ClientWorld getClientWorld(InstaCartModule instaCartModule) {
      return instaCartModule.clientWorld;
   }

   private boolean testBlockHitResult(BlockHitResult blockHitResult) {
      if (blockHitResult != null) {
         ThreadLocalRandom.current().nextInt(7);

         if (blockHitResult.getType() == Type.BLOCK) {
            if (blockHitResult.getBlockPos().equals(this.blockPos)) {
               if (blockHitResult.getSide() == cc.mochi.MinecraftClientAccess44.getUP()) {
                  if (this.blockPos2.equals(BlockInteractUtils.computeBlockPosForBlockHitResult(blockHitResult))) {
                     return true;
                  }
               }
            }
         }
      }

      return false;
   }

   public static void setPitch(InstaCartModule instaCartModule, float pitch2) {
      instaCartModule.pitch = pitch2;
   }

   @EventHandler
   private void onWorldChange(WorldChangeEvent worldChangeEvent) {
      this.updateState(true);

      this.longState = Long.MIN_VALUE;
   }

   public static boolean getBooleanState(InstaCartModule instaCartModule) {
      return instaCartModule.booleanState;
   }

   public static void setVec3d(InstaCartModule instaCartModule, Vec3d vec3d3) {
      instaCartModule.vec3d = vec3d3;
   }

   public static BooleanSetting getAutoReleaseSetting(InstaCartModule instaCartModule) {
      return instaCartModule.autoReleaseSetting;
   }

   private String computeStringForList3(List list, List list2, int intValue) {
      boolean booleanState22 = getInstaCartCycle(this).getBooleanState22();

      InstaCartPlan instaCartPlan = this.computeInstaCartPlanForList(list, list2, intValue, 1, 0, booleanState22, -1);
      if (instaCartPlan == null) {
         if (getInstaCartCycle(this).getBooleanState22()) {
            if (this.safeFallbackSetting.isOn()) {
               getInstaCartCycle(this).resetBooleanState();

               instaCartPlan = this.computeInstaCartPlanForList(list, list2, intValue, 1, 0, false, -1);
            }
         }
      }

      if (instaCartPlan == null) {
         return "no rail in time";
      } else {
         byte byteValue;
         label54: {
            this.updateStateForInstaCartPlan(instaCartPlan, list2, intValue);
            if (!this.projectileLaunch.checkCondition() && instaCartPlan.getHits2() < list.size()) {
               List list3 = list.subList(0, 1);
               int intValue2 = intValue + 1;

               if (this.computeInstaCartPlanForList(list3, list2, intValue, intValue2, 0, getInstaCartCycle(this).getBooleanState22(), Math.max(0, instaCartPlan.getCoverSteps())) != null) {
                  byteValue = 1;
                  break label54;
               }
            }

            byteValue = 0;
         }

         setBooleanState3(this, (byteValue != 0));
         return null;
      }
   }

   @EventHandler
   private void onAfterMovement(MovementSendEvent.After after) {
      setLongState(this, this.getCurrentTick22());
      this.yaw = after.yaw();
      setPitch(this, after.pitch());
   }

   private static int computeIntForInstaCartPlan(InstaCartPlan instaCartPlan) {
      return instaCartPlan.getCandidate2().computeInt3();
   }

   private BlockHitResult computeBlockHitResult3() {
      if (this.blockPos2 != null && this.blockPos != null) {
         ThreadLocalRandom.current().nextInt(10);

         if (this.item instanceof BlockItem var1) {
            BlockHitResult blockHitResult = BlockInteractUtils.computeBlockHitResultForBlockPos2(getBlockPos2(this));
            if (this.testBlockHitResult(blockHitResult)) {
               if (BlockInteractUtils.computeHitResult2() instanceof BlockHitResult var3) {
                  if (this.testBlockHitResult(var3)) {
                     ItemPlacementContext itemPlacementContext = new ItemPlacementContext(mc.player, cc.mochi.MinecraftClientAccess44.getMAIN_HAND(), this.item.getDefaultStack(), blockHitResult);
                     if (itemPlacementContext.getBlockPos().equals(this.blockPos2)) {
                        if (itemPlacementContext.canPlace()
                           && cc.mochi.MinecraftClientAccess44.getWorld(mc).getBlockState(this.blockPos2).canReplace(itemPlacementContext)
                           && ProjectileAimPlanner.testWorld(mc.world, this.blockPos2)
                           && mc.world.canPlace(var1.getBlock().getDefaultState(), this.blockPos2, ShapeContext.of(mc.player))) {
                           return blockHitResult;
                        }
                     }

                     return null;
                  }
               }
            }

            return null;
         }
      }

      return null;
   }

   public static int getIntState(InstaCartModule instaCartModule) {
      return instaCartModule.intState;
   }

   public static void setLongState(InstaCartModule instaCartModule, long longState2) {
      instaCartModule.longState = longState2;
   }

   private InstaCartPlan computeInstaCartPlanForList(List list, List list2, int intValue, int intValue2, int intValue3, boolean booleanValue, int intValue4) {
      if (!list.isEmpty()) {
         if (list.get(0) != null) {
            ClientPlayerEntity player6 = cc.mochi.MinecraftClientAccess44.getPlayer(mc);

            int intValue5 = Math.max(Math.max(1, intValue), intValue2);

            Box box = ((Box)list2.get(0)).union(computeBoxForList(list2, intValue, intValue5));
            List list3 = ProjectileAimPlanner.computeListForWorld(cc.mochi.MinecraftClientAccess44.getWorld(mc), player6, list, ProjectileAimPlanner.createVec3d(player6, computeBoxForList(list2, intValue, intValue5)), getYaw(this), box);

            Vec3d center = ((Box)list2.get(0)).getCenter();
            ArrayList arrayList = new ArrayList();

            for (RailPlacementCandidate railPlacementCandidate : (java.lang.Iterable<RailPlacementCandidate>)(java.lang.Iterable<?>)(list3)) {
               if (ProjectileAimPlanner.computeIntForWorld(mc.world, railPlacementCandidate.getRail2()) >= 0) {
                  int intValue6 = this.computeInt(this.yaw, this.pitch, railPlacementCandidate.getYaw2(), railPlacementCandidate.getPitch2());
                  int intValue7 = ColorInterpolation.computeInt3(intValue, intValue, intValue5, intValue6);
                  int intValue8 = ColorInterpolation.computeInt4(intValue7, 0);
                  if (ColorInterpolation.checkCondition(intValue8, railPlacementCandidate.computeInt3(), intValue3)) {
                     arrayList.add(new InstaCartPlan(railPlacementCandidate, intValue7, intValue8, intValue8, railPlacementCandidate.computeInt2(intValue8, intValue3), null, 0, railPlacementCandidate.computeVec3d().squaredDistanceTo(center)));
                  }
               }
            }

            arrayList.sort(getComparator());
            if (!booleanValue) {
               if (arrayList.isEmpty()) {
         return null;
      } else {
         return (InstaCartPlan)arrayList.get(0);
      }
            }

            ThreadLocalRandom.current().nextInt(5);
            ArrayList arrayList2 = new ArrayList();

            int intValue9 = 0;
            Iterator iterator = arrayList.iterator();

            while (iterator.hasNext()) {
               InstaCartPlan instaCartPlan2 = (InstaCartPlan)iterator.next();
               InstaCartPlan instaCartPlan42;
               if (intValue4 >= 0) {
                  ThreadLocalRandom.current().nextInt(3);
                  int intValue10 = ColorInterpolation.computeInt4(instaCartPlan2.getCartOffset(), intValue4);
                  InstaCartPlan instaCartPlan4;
                  if (ColorInterpolation.checkCondition(intValue10, instaCartPlan2.getCandidate2().computeInt3(), intValue3)) {
                     ThreadLocalRandom.current().nextInt(6);
                     instaCartPlan4 = new InstaCartPlan(instaCartPlan2.getCandidate2(), instaCartPlan2.getRailOffset2(), instaCartPlan2.getCartOffset(), intValue10, instaCartPlan2.getCandidate2().computeInt2(intValue10, intValue3), null, intValue4, instaCartPlan2.getDistance());
                  } else {
                     instaCartPlan4 = null;
                  }

                  instaCartPlan42 = instaCartPlan4;
               } else {
                  ThreadLocalRandom.current().nextInt(3);
                  int intValue11 = intValue9++;

                  if (intValue11 >= 4) {
                     break;
                  }

                  instaCartPlan42 = this.computeInstaCartPlanForInstaCartPlan(instaCartPlan2, (ProjectileLanding)list.get(0), list2, intValue, intValue3);
               }

               if (instaCartPlan42 != null) {
                  arrayList2.add(instaCartPlan42);
               }
            }

            arrayList2.sort(comparator);
            return arrayList2.isEmpty() ? null : (InstaCartPlan)arrayList2.get(0);
         }
      }

      return null;
   }

   public static boolean getBooleanState2(InstaCartModule instaCartModule) {
      return instaCartModule.booleanState2;
   }

   public static BlockPos getBlockPos(InstaCartModule instaCartModule) {
      return instaCartModule.blockPos;
   }

   public static int getIntState2(InstaCartModule instaCartModule) {
      return instaCartModule.intState2;
   }

   private void updateStateForInstaCartState(InstaCartState instaCartState, Item item2, long longState3) {
      if (this.isEnabled()) {
         if (this.getCurrentTick22() == longState3 && this.checkCondition2() && this.checkCondition() && this.instaCartCycle.getInstaCartState4() == instaCartState && RotationManager.computeVec3d(this) != null && !cc.mochi.MinecraftClientAccess44.getPlayer(mc).isUsingItem()) {
            if (InventoryUtils.computeInt() == this.intState) {
               if (InventoryUtils.testItem(getIntState(this), item2) && CombatTickBudget.checkCondition4() && !CombatTickBudget.getBooleanState5()) {
                  BlockHitResult blockHitResult = this.computeBlockHitResultForInstaCartState(instaCartState);
                  if (blockHitResult == null) {
                     this.instaCartCycle.updateState(longState3);
                     return;
                  }

                  ActionResult actionResult = mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, blockHitResult);
                  int intValue;
                  switch (getIntArray2()[instaCartState.ordinal()]) {
                     case 1:
                        if (item2 instanceof BlockItem var8 && cc.mochi.MinecraftClientAccess44.getWorld(mc).getBlockState(this.blockPos2).isOf(var8.getBlock())) {
                           intValue = 1;
                           break;
                        }

                        intValue = 0;
                        break;
                     case 3:
                        intValue = cc.mochi.MinecraftClientAccess44.getWorld(mc).getBlockState(this.coverPlacementPlan.getCell()) == getCoverPlacementPlan(this).getState() ? 1 : 0;
                        break;
                     default:

                        intValue = 1;
                  }

                  int intValue2 = intValue;
                  if (actionResult.isAccepted() && intValue2 != 0) {
                     mc.player.swingHand(cc.mochi.MinecraftClientAccess44.getMAIN_HAND());
                     this.instaCartCycle.updateState5(longState3);
                     return;
                  }

                  this.instaCartCycle.updateState(longState3);
                  return;
               }
            }
         }
      }

      getInstaCartCycle(this).updateState(longState3);
   }

   private void updateState5(String string) {
      ActionSchedulers.updateState4(this);
      if (!this.checkCondition2()) {
         this.updateState(true);
      } else {
         RotationManager.updateState9(this);
         this.instaCartCycle.updateInstaCartState();
         this.updateState4();
      }
   }

   private void updateStateForInstaCartState2(InstaCartState instaCartState, Item item2, long longState3) {
      label23: {
         try {
            this.updateStateForInstaCartState(instaCartState, item2, longState3);
         } catch (RuntimeException failure) {
            this.updateState5("interaction failed");

            break label23;
         }
      }
   }

   public static RotationProfile getRotationProfile(InstaCartModule instaCartModule) {
      return instaCartModule.rotationProfile;
   }

   private static boolean testBlockPos(BlockPos blockPos3, Entity entity) {
      if (blockPos3 != null) {
         if (entity instanceof TntMinecartEntity) {
            if (entity.getBlockPos().equals(blockPos3)) {
               return true;
            }
         }
      }

      return false;
   }

   private boolean checkCondition2() {
      if (cc.mochi.MinecraftClientAccess44.getPlayer(mc) == this.clientPlayerEntity) {
         if (cc.mochi.MinecraftClientAccess44.getWorld(mc) == this.clientWorld) {
            if (this.clientPlayerEntity != null) {
               if (this.clientWorld != null) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   public static ClientPlayerEntity getClientPlayerEntity(InstaCartModule instaCartModule) {
      return instaCartModule.clientPlayerEntity;
   }

   public static void setClientPlayerEntity(InstaCartModule instaCartModule, ClientPlayerEntity clientPlayerEntity2) {
      instaCartModule.clientPlayerEntity = clientPlayerEntity2;
   }

   private int computeInt(float floatValue, float floatValue2, float floatValue3, float floatValue4) {
      float floatValue5 = RotationMath.computeFloat2((Double)mc.options.getMouseSensitivity().getValue());
      return ColorInterpolation.computeInt5(floatValue, floatValue2, floatValue3, floatValue4, this.computeDouble(), floatValue5);
   }

   private static int computeIntForClientPlayerEntity(ClientPlayerEntity clientPlayerEntity2) {
      ClientPlayNetworkHandler networkHandler = mc.getNetworkHandler();
      PlayerListEntry playerListEntry;
      if (networkHandler == null) {
         playerListEntry = null;
      } else {
         playerListEntry = networkHandler.getPlayerListEntry(clientPlayerEntity2.getUuid());
      }

      PlayerListEntry playerListEntry2 = playerListEntry;
      return playerListEntry2 == null ? 0 : playerListEntry2.getLatency();
   }

   public static void setProjectileLaunch(InstaCartModule instaCartModule, ProjectileLaunch projectileLaunch2) {
      instaCartModule.projectileLaunch = projectileLaunch2;
   }

   private String computeString() {
      if (getIntState2(this) < 0) {
         return null;
      } else {
         Entity entityById = cc.mochi.MinecraftClientAccess44.getWorld(mc).getEntityById(this.intState2);
         if (entityById == null) {
            return getBooleanState(this) ? "arrow gone" : null;
         } else {
            this.booleanState = true;
            if (!(entityById instanceof PersistentProjectileEntity)) {
               return "arrow gone";
            } else {
               ThreadLocalRandom.current().nextInt(11);

               PersistentProjectileEntity entityById2 = (PersistentProjectileEntity)entityById;

               if (!entityById2.isRemoved() && !((PersistentProjectileAccessor)entityById2).mochi$isInGround()) {
                  if (entityById2.age >= 2) {
                     if (!entityById2.isOnFire()) {
                        return "arrow not burning";
                     }
                  }

                  return null;
               } else {
                  return "arrow landed";
               }
            }
         }
      }
   }

   private int computeIntForItem(Item item2) {
      return InventoryUtils.computeIntForPredicate2(objectValue -> testItem(item2, (ItemStack)objectValue));
   }

   private void updateState6() {
      while (true) {
         ProjectileState projectileState;
         if ((projectileState = this.projectileStateQueue.poll()) == null) {
            return;
         }

         if (!getProjectileLaunch(this).checkCondition() && projectileState.getOwner() == this.clientPlayerEntity.getId()) {
            if (!getIntegerSet(this).contains(projectileState.getId())) {
               if (!(projectileState.getVelocity2().lengthSquared() < 0.01)) {
                  double doubleValue = projectileState.getPosition2().squaredDistanceTo(getProjectileLaunch(this).getOrigin());

                  if (!(doubleValue > (2.25))) {
                     setProjectileLaunch(this, ProjectileAimPlanner.createProjectileLaunch(projectileState.getPosition2(), projectileState.getVelocity2()));
                     setIntState2(this, projectileState.getId());
                  }
               } else {
                  ThreadLocalRandom.current().nextInt(13);
               }
            }
         }
      }
   }

   @EventHandler
   private void onBowRelease(BowReleaseEvent bowReleaseEvent) {
      if (bowReleaseEvent.player() == cc.mochi.MinecraftClientAccess44.getPlayer(mc)) {
         if (getInstaCartCycle(this).getInstaCartState4() == InstaCartState.IDLE && this.checkCondition()) {
            if (RotationManager.computeVec3d(this) == null) {
               ItemStack activeItem = mc.player.getActiveItem();
               float pullProgress = BowItem.getPullProgress(mc.player.getItemUseTime());
               if (!this.testItemStack(activeItem, pullProgress)) {
                  return;
               }

               long longState2 = this.longState;

               if (longState2 == (-9223372036854775808L)) {
                  this.yaw = cc.mochi.MinecraftClientAccess44.getPlayer(mc).getYaw();
                  this.pitch = mc.player.getPitch();
               }

               ProjectileLaunch projectileLaunch2 = ProjectileAimPlanner.computeProjectileLaunchForEntity(mc.player, getYaw(this), this.pitch, pullProgress);
               List list = ProjectileAimPlanner.computeListForWorld2(cc.mochi.MinecraftClientAccess44.getWorld(mc), cc.mochi.MinecraftClientAccess44.getPlayer(mc), projectileLaunch2, objectValue -> returnFalse2((Entity)objectValue), 0);
               List list2 = ProjectileAimPlanner.computeListForWorld3(cc.mochi.MinecraftClientAccess44.getWorld(mc), mc.player, 82, this.yaw);
               int intValue = (getSafeModeSetting(this).isOn()) ? 1 : 0;

               InstaCartPlan instaCartPlan = this.computeInstaCartPlanForList(list, list2, 0, 1, 0, (intValue != 0), -1);
               if (instaCartPlan == null) {
                  if (intValue != 0 && this.safeFallbackSetting.isOn()) {
                     intValue = 0;

                     instaCartPlan = this.computeInstaCartPlanForList(list, list2, 0, 1, 0, false, -1);
                  }
               } else {
                  ThreadLocalRandom.current().nextInt(13);
               }

               if (instaCartPlan == null) {
                  return;
               }

               this.clientPlayerEntity = mc.player;
               setClientWorld(this, cc.mochi.MinecraftClientAccess44.getWorld(mc));
               this.projectileLaunch = projectileLaunch2;

               this.intState2 = -1;

               this.booleanState = false;
               this.projectileStateQueue.clear();
               this.integerSet.clear();

               for (Entity entity : cc.mochi.MinecraftClientAccess44.getWorld(mc).getEntities()) {
                  if (entity instanceof PersistentProjectileEntity) {
                     this.integerSet.add(entity.getId());
                  }
               }

               ThreadLocalRandom.current().nextInt(10);
               this.intState3 = this.intState = InventoryUtils.computeInt();

               setBooleanState2(this, false);
               setCoverPlacementPlan(this, null);
               this.cartInterceptPlan = null;
               RotationProfile rotationProfile2 = RotationProfile.createRotationProfile().withMaxRotationSpeed(this.computeDouble());

               setRotationProfile(this, rotationProfile2.computeRotationProfile10((1.0)).withSilentAim(this.aimModeSetting.equals("Silent")).computeRotationProfile7(true).computeRotationProfile4(0.0).computeRotationProfile3(0.0).computeRotationProfile9(0L));
               getInstaCartCycle(this).updateState4(this.getCurrentTick22(), (intValue != 0));
               this.updateStateForInstaCartPlan(instaCartPlan, list2, 0);
               this.updateStateForList(list2);
               return;
            }
         }
      }
   }

   public static void setIntState(InstaCartModule instaCartModule, int intState5) {
      instaCartModule.intState = intState5;
   }

   @EventHandler
   private void onBeforeMovement(MovementSendEvent.Before before) {
      long currentTick22 = this.getCurrentTick22();
      if (getInstaCartCycle(this).checkCondition3() && this.checkCondition2() && getInstaCartCycle(this).checkCondition2(currentTick22)) {
         if (this.checkCondition()) {
            if (RotationManager.computeVec3d(this) != null) {
               InstaCartState instaCartState4 = this.instaCartCycle.getInstaCartState4();
               if (instaCartState4 == InstaCartState.RAIL) {
                  if (this.booleanState3) {
                     return;
                  }
               } else {
                  ThreadLocalRandom.current().nextInt(16);
               }

               if (instaCartState4 == InstaCartState.RAIL) {
                  int intValue = ProjectileAimPlanner.computeIntForWorld(cc.mochi.MinecraftClientAccess44.getWorld(mc), getBlockPos2(this));
                  Item item2;
                  if (intValue < 0) {
                     ThreadLocalRandom.current().nextInt(16);
                     item2 = null;
                  } else {
                     item2 = mc.player.getInventory().getStack(intValue).getItem();
                  }

                  setItem(this, item2);
                  if (getItem(this) == null) {
                     this.updateState5("missing rail");
                     return;
                  }
               }

               BlockHitResult blockHitResult = this.computeBlockHitResultForInstaCartState(instaCartState4);
               if (blockHitResult == null) {
                  return;
               }

               Item item22;
               if (instaCartState4 == InstaCartState.COVER) {
                  item22 = getCoverPlacementPlan(this).getItem2();
               } else {
                  item22 = instaCartState4 == InstaCartState.CART ? cc.mochi.MinecraftClientAccess44.getTNT_MINECART() : this.item;
               }

               Item item222 = item22;
               int intState5 = this.computeIntForItem(item222);
               if (intState5 < 0) {
                  String string = String.valueOf(item222);
                  this.updateState5("missing " + string);
                  return;
               }

               if (mc.player.isUsingItem()) {
                  return;
               }

               if (InventoryUtils.computeInt() != intState5) {
                  if (!CombatTickBudget.checkCondition2()) {
                     return;
                  }

                  InventoryUtils.updateState3(intState5);
                  ((ClientPlayerInteractionManagerMixin.ClientPlayerInteractionManagerAccessor)mc.interactionManager).mochi$syncSelectedSlot();
                  CombatTickBudget.setBooleanState222();

                  this.booleanState2 = true;
               }

               setIntState(this, intState5);
               this.instaCartCycle.updateState2(currentTick22);
               ActionSchedulers.schedule2(this, () -> this.updateStateForInstaCartState2(instaCartState4, item222, currentTick22), () -> this.updateState3(currentTick22));
               return;
            }
         }

         this.updateState5("rotation lost");
      }
   }

   private Vec3d getVec3d() {
      return this.vec3d;
   }

   public static Item getItem(InstaCartModule instaCartModule) {
      return instaCartModule.item;
   }

   private List computeList() {
      ArrayList arrayList = new ArrayList();
      HashSet hashSet = new HashSet();
      int intValue = 0;

      ThreadLocalRandom.current().nextInt(4);

      do {
         ThreadLocalRandom.current().nextInt(6);

         ItemStack stack = mc.player.getInventory().getStack(intValue);
         if (CartCoverPlanner.testItemStack(stack)) {
            if (hashSet.add(stack.getItem())) {
               arrayList.add(stack);
            }
         }
      } while (++intValue < 9);

      return arrayList;
   }

   private Predicate computePredicate() {
      BlockPos blockPos22 = this.blockPos2;
      return objectValue -> testBlockPos(blockPos22, (Entity)objectValue);
   }

   public static void setIntState2(InstaCartModule instaCartModule, int intState22) {
      instaCartModule.intState2 = intState22;
   }

   @EventHandler
   private void onPacket(PacketEvent packetEvent) {
      if (packetEvent.getOrder() == TransferOrder.RECEIVE) {
         Packet packet = packetEvent.getPacket();
         if (packet instanceof EntitySpawnS2CPacket) {
            EntitySpawnS2CPacket packet2 = (EntitySpawnS2CPacket)packet;
            EntityType entityType = packet2.getEntityType();
            if (entityType != EntityType.ARROW) {
               if (entityType != EntityType.SPECTRAL_ARROW) {
                  return;
               }
            }

            if (this.projectileStateQueue.size() < 32) {
               getProjectileStateQueue(this).add(new ProjectileState(packet2.getEntityId(), packet2.getEntityData(), new Vec3d(packet2.getX(), packet2.getY(), packet2.getZ()), packet2.getVelocity()));
               return;
            }

            return;
         }
      }
   }

   @EventHandler(
      priority = -100
   )
   private void onTick(TickEvent tickEvent) {
      if (this.instaCartCycle.getInstaCartState4() == InstaCartState.IDLE) {
         getProjectileStateQueue(this).clear();
         this.updateState2();
      } else {
         if (this.checkCondition2()) {
            if (mc.player.isAlive()) {
               if (getInstaCartCycle(this).getInstaCartState4() == InstaCartState.TAKEBACK) {
                  this.updateState4();
                  if (RotationManager.computeVec3d(this) == null && !getBooleanState2(this)) {
                     this.updateState(false);
                  }

                  return;
               }

               long currentTick22 = this.getCurrentTick22();
               if (!this.instaCartCycle.checkCondition4(currentTick22)) {
                  this.updateState5(this.instaCartCycle.getInstaCartState4() == InstaCartState.HOLD ? "done" : "use did not complete");
                  return;
               }

               if (this.instaCartCycle.getInstaCartState4() == InstaCartState.HOLD) {
                  return;
               }

               if (this.checkCondition()) {
                  if (InventoryUtils.computeInt() == this.intState && !mc.player.isUsingItem()) {
                     this.updateState6();
                     String string22 = this.computeString();
                     if (string22 != null) {
                        this.updateState5(string22);
                        return;
                     }

                     int intValue = this.instaCartCycle.max(currentTick22);
                     List list = ProjectileAimPlanner.computeListForWorld2(mc.world, this.clientPlayerEntity, getProjectileLaunch(this), this.computePredicate(), intValue);
                     if (!list.isEmpty()) {
                        if (list.get(0) != null) {
                           ClientWorld world9 = cc.mochi.MinecraftClientAccess44.getWorld(mc);

                           List list2 = ProjectileAimPlanner.computeListForWorld3(world9, mc.player, 82, this.yaw);
                           String string2;
                           switch (getIntArray2()[getInstaCartCycle(this).getInstaCartState4().ordinal()]) {
                              case 1:
                                 string2 = this.computeStringForList3(list, list2, intValue);
                                 break;
                              case 2:
                                 string2 = this.computeStringForList(list, list2, intValue);
                                 break;
                              case 3:

                                 string2 = this.computeStringForList2(list, list2, intValue);
                                 break;
                              default:
                                 string2 = null;
                           }

                           string22 = string2;
                           if (string22 != null) {
                              ThreadLocalRandom.current().nextInt(12);
                              this.updateState5(string22);
                              return;
                           }

                           this.updateStateForList(list2);
                           return;
                        }
                     }

                     this.updateState5("arrow no longer reaches a block");
                     return;
                  }
               }

               this.updateState5("interrupted");
               return;
            }
         } else {
            ThreadLocalRandom.current().nextInt(17);
         }

         this.updateState(true);
      }
   }

   private BlockHitResult computeBlockHitResultForInstaCartState(InstaCartState instaCartState) {
      BlockHitResult blockHitResult;
      switch (getIntArray2()[instaCartState.ordinal()]) {
         case 1:

            blockHitResult = this.computeBlockHitResult3();
            break;
         case 2:
            blockHitResult = this.computeBlockHitResult();
            break;
         case 3:
            blockHitResult = this.computeBlockHitResult2();
            break;
         default:

            blockHitResult = null;
      }

      return blockHitResult;
   }

   private double computeDouble() {
      return RotationSpeedScale.toPercentage(this.doubleSetting.getValue()) * 21.6;
   }

   public static void setClientWorld(InstaCartModule instaCartModule, ClientWorld clientWorld2) {
      instaCartModule.clientWorld = clientWorld2;
   }

}
