package cc.mochi;

import java.util.concurrent.ThreadLocalRandom;

public final class FractalNoise {
   private final int seed;

   public double sampleOctaves(double doubleValue, int intValue) {
      return this.sampleFractal(doubleValue, intValue, 2.0, 0.5);
   }

   private double hashLatticePoint(int intValue) {
      int intValue2 = intValue * 374761393 + this.seed * 668265263;
      intValue2 = (intValue2 ^ intValue2 >>> 13) * 1274126177;
      intValue2 ^= intValue2 >>> 16;
      return (double)(intValue2 & 2147483647) / 2.147483647E9;
   }

   public FractalNoise(int seed2) {
      this.seed = seed2;
   }

   public double sampleFractal(double doubleValue, int intValue, double doubleValue2, double doubleValue3) {
      double doubleValue4 = 1.0;
      double doubleValue5 = 1.0;
      double doubleValue6 = 0.0;
      double doubleValue7 = 0.0;
      int intValue2 = Math.max(1, intValue);

      for (int intValue3 = 0; intValue3 < intValue2; intValue3++) {
         doubleValue6 += this.sample(doubleValue * doubleValue5) * doubleValue4;
         doubleValue7 += doubleValue4;
         doubleValue5 *= doubleValue2;
         doubleValue4 *= doubleValue3;
      }

      return doubleValue7 <= 0.0 ? 0.0 : doubleValue6 / doubleValue7;
   }

   public FractalNoise() {
      this(ThreadLocalRandom.current().nextInt());
   }

   public double sample(double doubleValue) {
      int intValue = (int)Math.floor(doubleValue);
      double doubleValue2 = MathUtils.computeDouble7(doubleValue - (double)intValue);
      double doubleValue3 = this.hashLatticePoint(intValue);
      double doubleValue4 = this.hashLatticePoint(intValue + 1);
      return (doubleValue3 + (doubleValue4 - doubleValue3) * doubleValue2) * 2.0 - 1.0;
   }
}
