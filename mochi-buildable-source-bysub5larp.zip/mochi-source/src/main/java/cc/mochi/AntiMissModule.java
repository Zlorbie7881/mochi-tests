package cc.mochi;

import cc.mochi.event.impl.player.AttackEvent;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;

public final class AntiMissModule extends Module {
   static final boolean booleanState;

   static {
      byte byteValue;
      if (!AntiMissModule.class.desiredAssertionStatus()) {
         byteValue = 1;
      } else {
         byteValue = 0;
      }

      booleanState = (byteValue != 0);
   }

   public static boolean checkCondition() {
      if (MinecraftClientAccess15.getPlayer(mc) == null) {
         ThreadLocalRandom.current().nextInt(6);
         return false;
      } else {
         ItemStack mainHandStack = MinecraftClientAccess15.getPlayer(mc).getMainHandStack();
         if (!mainHandStack.isIn(ItemTags.SWORDS)) {
            if (!mainHandStack.isIn(ItemTags.AXES)) {
               return false;
            }
         }

         return true;
      }
   }

   public AntiMissModule() {
      super("Anti Miss", "Doesn't let you click if it isn't on a target.", -1, ModuleCategory.COMBAT);
   }

   @EventHandler
   private void onAttackEvent(AttackEvent attackEvent) {
      if (this.isWorldUnavailable()) {
         ThreadLocalRandom.current().nextInt(7);
      } else if (!checkCondition()) {
      } else {
         if (!booleanState) {
            if (mc.crosshairTarget == null) {
               throw new AssertionError();
            }
         }

         if (MinecraftClientAccess15.getCrosshairTarget(mc).getType().equals(MinecraftClientAccess15.getMISS())) {
            attackEvent.cancel();
         }
      }
   }
}
