package cc.mochi;

public final class JumpCircleRenderStyle {
   public float floatState;
   public float floatState2 = 1.0F;
   public float floatState3;
   public boolean booleanState;
   public float floatState4;
   public boolean booleanState2;

   public float floatState5 = 1.0F;
   public float floatState6;

   public JumpCircleRenderStyle() {
      this.floatState4 = 1.0F;
      this.booleanState = true;
      this.floatState3 = 1.0F;
      this.floatState = 1.0F;
   }
}
