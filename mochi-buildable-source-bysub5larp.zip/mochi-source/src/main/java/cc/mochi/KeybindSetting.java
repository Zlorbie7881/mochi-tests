package cc.mochi;

public final class KeybindSetting extends Setting {
   private int keyCode;
   private boolean listening;
   private final int defaultKeyCode;
   private final boolean allowHoldMode;
   private boolean holdMode;

   public boolean isHoldMode() {
      return getHoldMode(this);
   }

   public static int getDefaultKeyCode2(KeybindSetting keybindSetting) {
      return keybindSetting.defaultKeyCode;
   }

   public static boolean getHoldMode(KeybindSetting keybindSetting) {
      return keybindSetting.holdMode;
   }

   public int getKeyCode() {
      return getKeyCode2(this);
   }

   public void setKeyCode(int keyCode2) {
      this.keyCode = keyCode2;
   }

   public static void setListening2(KeybindSetting keybindSetting, boolean listening2) {
      keybindSetting.listening = listening2;
   }

   public void toggleListening() {
      this.listening = ((!this.listening ? 1 : 0) != 0);
   }

   public static void setKeyCode2(KeybindSetting keybindSetting, int keyCode2) {
      keybindSetting.keyCode = keyCode2;
   }

   public boolean allowsHoldMode() {
      return this.allowHoldMode;
   }

   public static int getKeyCode2(KeybindSetting keybindSetting) {
      return keybindSetting.keyCode;
   }

   public static void setHoldMode2(KeybindSetting keybindSetting, boolean holdMode2) {
      keybindSetting.holdMode = holdMode2;
   }

   public void setHoldMode(boolean holdMode2) {
      setHoldMode2(this, holdMode2);
   }

   @Override
   public boolean isDefault() {
      if (this.keyCode == this.defaultKeyCode) {
         if (!getHoldMode(this)) {
            return true;
         }
      }

      return false;
   }

   public void setListening(boolean listening2) {
      setListening2(this, listening2);
   }

   public KeybindSetting(String name, int intValue, boolean allowHoldMode2) {
      super(name);
      this.keyCode = intValue;
      this.defaultKeyCode = intValue;
      this.allowHoldMode = allowHoldMode2;
      this.holdMode = false;
   }

   public boolean isListening() {
      return this.listening;
   }

   @Override
   public void reset() {
      setKeyCode2(this, getDefaultKeyCode2(this));

      setListening2(this, false);

      setHoldMode2(this, false);
   }

   public int getDefaultKeyCode() {
      return getDefaultKeyCode2(this);
   }

   public void toggleHoldMode() {
      this.holdMode = ((!this.holdMode ? 1 : 0) != 0);
   }
}
