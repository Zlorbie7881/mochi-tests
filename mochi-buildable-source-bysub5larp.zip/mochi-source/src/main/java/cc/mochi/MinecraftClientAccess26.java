package cc.mochi;

import cc.mochi.event.types.TransferOrder;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;

public class MinecraftClientAccess26 {
   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static TransferOrder getRECEIVE() {
      return TransferOrder.RECEIVE;
   }

   public static ClientWorld getWorld(MinecraftClient minecraftClient) {
      return minecraftClient.world;
   }
}
