package cc.mochi;

public record JumpCircleEffect(double x, double y, double z, long start, float seed, boolean water, float[] sparks, float[] embers) {
   public double getX() {
      return this.x;
   }

   public float getSeed() {
      return this.seed;
   }

   public float[] getEmbers() {
      return this.embers;
   }

   public float[] getSparks() {
      return this.sparks;
   }

   public double getY() {
      return this.y;
   }

   public long getStart() {
      return this.start;
   }

   public double getZ() {
      return this.z;
   }

   public boolean getWater() {
      return this.water;
   }
}
