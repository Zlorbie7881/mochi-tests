package cc.mochi;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public record DrainTarget(DrainAction kind, BlockPos cell, Vec3d aim, boolean rescue) {
   public static BlockPos getCell(DrainTarget drainTarget) {
      return drainTarget.cell;
   }

   public boolean getRescue2() {
      return getRescue(this);
   }

   public Vec3d getAim() {
      return this.aim;
   }

   public static boolean getRescue(DrainTarget drainTarget) {
      return drainTarget.rescue;
   }

   public DrainAction getKind() {
      return this.kind;
   }

   public BlockPos getCell2() {
      return getCell(this);
   }
}
