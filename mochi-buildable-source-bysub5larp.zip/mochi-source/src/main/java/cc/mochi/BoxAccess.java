package cc.mochi;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.PointedDripstoneBlock;
import net.minecraft.block.enums.Thickness;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Difficulty;

public class BoxAccess {
   public static double getMaxZ(Box box) {
      return box.maxZ;
   }

   public static Difficulty getPEACEFUL() {
      return Difficulty.PEACEFUL;
   }

   public static Block getFIRE() {
      return Blocks.FIRE;
   }

   public static double getMinX(Box box) {
      return box.minX;
   }

   public static Block getPOWDER_SNOW() {
      return Blocks.POWDER_SNOW;
   }

   public static Block getSOUL_FIRE() {
      return Blocks.SOUL_FIRE;
   }

   public static EquipmentSlot getFEET() {
      return EquipmentSlot.FEET;
   }

   public static double getMinZ(Box box) {
      return box.minZ;
   }

   public static double getMaxX(Box box) {
      return box.maxX;
   }

   public static HazardKind getSOUL_FIRE2() {
      return HazardKind.SOUL_FIRE;
   }

   public static double getMinY(Box box) {
      return box.minY;
   }

   public static Block getCOBWEB() {
      return Blocks.COBWEB;
   }

   public static RegistryEntry<StatusEffect> getWITHER() {
      return StatusEffects.WITHER;
   }

   public static HazardKind getCACTUS2() {
      return HazardKind.CACTUS;
   }

   public static Block getSOUL_CAMPFIRE() {
      return Blocks.SOUL_CAMPFIRE;
   }

   public static double getMaxY(Box box) {
      return box.maxY;
   }

   public static HazardKind getWITHER_ROSE() {
      return HazardKind.WITHER_ROSE;
   }

   public static Block getLADDER() {
      return Blocks.LADDER;
   }

   public static HazardKind getLAVA() {
      return HazardKind.LAVA;
   }

   public static HazardKind getCOBWEB2() {
      return HazardKind.COBWEB;
   }

   public static Block getCACTUS() {
      return Blocks.CACTUS;
   }

   public static Block getSWEET_BERRY_BUSH() {
      return Blocks.SWEET_BERRY_BUSH;
   }

   public static EnumProperty<Thickness> getTHICKNESS() {
      return PointedDripstoneBlock.THICKNESS;
   }

   public static Thickness getTIP() {
      return Thickness.TIP;
   }

   public static HazardKind getCAMPFIRE() {
      return HazardKind.CAMPFIRE;
   }

   public static HazardKind getPOWDER_SNOW4() {
      return HazardKind.POWDER_SNOW;
   }

   public static Vec3d getZERO() {
      return Vec3d.ZERO;
   }

   public static EnumProperty<Direction> getVERTICAL_DIRECTION() {
      return PointedDripstoneBlock.VERTICAL_DIRECTION;
   }

   public static HazardKind getFIRE2() {
      return HazardKind.FIRE;
   }

   public static HazardKind getDRIPSTONE() {
      return HazardKind.DRIPSTONE;
   }

}
