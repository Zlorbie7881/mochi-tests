package cc.mochi;

public final class HudBlurRenderer {
   public static boolean testBlurQuality(float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5, float floatValue6, float floatValue7, float floatValue8, float floatValue9, BlurQuality blurQuality) {
      RoundedBlurRegion roundedBlurRegion = RoundedBlurRegion.computeRoundedBlurRegion(floatValue, floatValue2, floatValue3, floatValue4, floatValue5, floatValue6, floatValue7, floatValue8);
      return KawaseBlurRenderer.testRoundedBlurRegion(roundedBlurRegion, floatValue9, blurQuality);
   }

   private HudBlurRenderer() {
   }

   public static void updateState() {
      KawaseBlurRenderer.updateState5();
   }

   public static boolean testBlurQuality2(float floatValue, BlurQuality blurQuality) {
      return KawaseBlurRenderer.testBlurQuality(floatValue, blurQuality);
   }

   public static boolean testBlurQuality3(float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5, float floatValue6, BlurQuality blurQuality) {
      return testBlurQuality(floatValue, floatValue2, floatValue3, floatValue4, floatValue5, 0.0F, 0.0F, 1.0F, floatValue6, blurQuality);
   }
}
