package cc.mochi;

import cc.mochi.event.impl.render.Render2DEvent;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.util.math.MathHelper;

public class KeyBindsModule extends Module implements HudElement {
   private final HudLayout hudLayout;

   private final BooleanSetting headerSetting;

   private final BooleanSetting onlyEnabledSetting = new BooleanSetting("Only Enabled", false);

   private final DoubleSetting bGAlphaSetting;
   private final Map<String, Float> floatByString;

   private final ChoiceSetting sortSetting;

   private static final FontFace fontFace = FontFace.MEDIUM;

   private final DoubleSetting paddingSetting;

   private static final Color color2 = new Color(255, 92, 122);

   private final BooleanSetting mouseBindsSetting = new BooleanSetting("Mouse Binds", true);

   private long timestampNanos;

   private final DoubleSetting sizeSetting;

   private static final Color color = new Color(9, 11, 18);

   private final BooleanSetting shadowSetting;
   private final BooleanSetting camoSetting;

   @Override
   public String computeString() {
      return this.getName();
   }

   @Override
   public float getFloatConstant() {
      return 70.0F;
   }

   public KeyBindsModule() {
      super("Key Binds", "Lists every module with a bound key", -1, ModuleCategory.RENDER);
      this.headerSetting = new BooleanSetting("Header", true);
      this.sortSetting = new ChoiceSetting("Sort", "Name", "Name", "Key");
      this.sizeSetting = new DoubleSetting("Size", 7.0, 24.0, 15.0, 1.0);
      this.paddingSetting = new DoubleSetting("Padding", 2.0, 14.0, 7.0, 1.0);
      this.bGAlphaSetting = new DoubleSetting("BG Alpha", 0.0, 255.0, 163.0, 5.0);
      this.shadowSetting = new BooleanSetting("Shadow", false);
      this.camoSetting = new BooleanSetting("Camo", false);
      this.hudLayout = new HudLayout(4.0F, 4.0F, 120.0F, 70.0F);
      this.floatByString = new HashMap<>();
      this.addSettings(new Setting[]{this.onlyEnabledSetting, this.mouseBindsSetting, this.headerSetting, this.sortSetting, this.sizeSetting, this.paddingSetting, this.bGAlphaSetting, this.shadowSetting, this.camoSetting});
   }

   @Override
   public HudLayout computeHudLayout() {
      return this.hudLayout;
   }

   @Override
   public float getFloatConstant2() {
      return 120.0F;
   }

   @Override
   public boolean checkCondition() {
      return false;
   }

   private List computeList() {
      ArrayList arrayList = new ArrayList();
      ModuleManager moduleManager = MochiClient.INSTANCE == null ? null : MochiClient.INSTANCE.getModuleManager();
      if (moduleManager != null && moduleManager.getModules() != null) {
         for (Module module : (java.lang.Iterable<Module>)(java.lang.Iterable<?>)(moduleManager.getModules())) {
            if (module != this && (!this.onlyEnabledSetting.getValue() || module.isEnabled())) {
               int keyCode = module.getKeyCode();
               if (keyCode != -1 && keyCode != 0 && keyCode != -1 && (this.mouseBindsSetting.getValue() || keyCode >= 0)) {
                  arrayList.add(module);
               }
            }
         }

         if (this.sortSetting.equals("Key")) {
            arrayList.sort(Comparator.<Object>comparingInt(objectValue -> ((Module)objectValue).getKeyCode()).thenComparing(objectValue2 -> ((Module)objectValue2).getName()));
         } else {
            arrayList.sort(Comparator.comparing(objectValue3 -> ((Module)objectValue3).getName(), String.CASE_INSENSITIVE_ORDER));
         }

         return arrayList;
      } else {
         return arrayList;
      }
   }

   @Override
   public void updateState() {
      this.hudLayout.setAlignmentAndInsets(HudHorizontalAlignment.RIGHT, HudVerticalAlignment.BOTTOM, HudLayoutMetrics.computeFloat4(4.0F, NotificationsModule.class), 4.0F);
   }

   @EventHandler
   private void onRender2D(Render2DEvent render2DEvent) {
      if (mc.player != null && mc.world != null) {
         if (mc.currentScreen == null || mc.currentScreen instanceof ChatScreen) {
            if (!GlCapabilities.checkCondition3()) {
               this.updateState8();
               List list = this.computeList();
               if (!list.isEmpty() || this.headerSetting.getValue()) {
                  long timestampNanos2 = System.nanoTime();
                  float floatValue = this.timestampNanos == 0L ? 0.016666668F : MathHelper.clamp((float)(timestampNanos2 - this.timestampNanos) / 1.0E9F, 0.0F, 0.1F);
                  this.timestampNanos = timestampNanos2;
                  float floatValue2 = LegacyUiTheme.computeFloat2(floatValue, 18.0F);
                  ThemeSnapshot themeSnapshot = ClickGuiModule.computeThemeSnapshot();
                  Color color3 = LegacyUiTheme.computeColorForThemeSnapshot2(themeSnapshot);
                  float value = (float)this.sizeSetting.getValue();
                  float value2 = (float)this.paddingSetting.getValue();
                  HudTextStyle hudTextStyle = new HudTextStyle(
                     fontFace,
                     value,
                     value2,
                     Math.max(2.0F, value * 0.36F),
                     8.0F * value / 14.0F,
                     6.0F * value / 14.0F,
                     12.0F * value / 14.0F,
                     color,
                     (float)this.bGAlphaSetting.getValue() / 255.0F,
                     true,
                     this.camoSetting.getValue(),
                     true,
                     3.5F,
                     color3,
                     false,
                     new Color[]{LegacyUiTheme.color3},
                     false,
                     0.0F
                  );
                  HashMap hashMap = new HashMap();

                  for (Module module : (java.lang.Iterable<Module>)(java.lang.Iterable<?>)(list)) {
                     hashMap.merge(module.getKeyCode(), 1, (objectValue, objectValue2) -> Integer.sum((Integer)objectValue, (Integer)objectValue2));
                  }

                  try (UiRenderBackend uiRenderBackend = HudBloomRenderer.computeUiRenderBackendForRender2DEvent(render2DEvent)) {
                     ArrayList arrayList = new ArrayList(list.size() + 1);
                     if (this.headerSetting.getValue()) {
                        arrayList.add(new HudTextLine("Keybinds", list.isEmpty() ? " none" : " " + list.size(), null, 1.0F, 1.0F, true));
                     }

                     for (Module module2 : (java.lang.Iterable<Module>)(java.lang.Iterable<?>)(list)) {
                        float floatValue3 = module2.isEnabled() ? 1.0F : 0.45F;
                        float floatValue4 = this.floatByString.getOrDefault(module2.getName(), floatValue3);
                        floatValue4 += (floatValue3 - floatValue4) * floatValue2;
                        this.floatByString.put(module2.getName(), floatValue4);
                        boolean booleanValue = (Integer)hashMap.getOrDefault(module2.getKeyCode(), 0) > 1;
                        arrayList.add(new HudTextLine(HudTextRenderer.replace(module2.getName()), " " + KeybindUtils.computeString(module2.getKeyCode()), booleanValue ? color2 : null, floatValue4, 1.0F, false));
                     }

                     HudTextLayout hudTextLayout = HudTextRenderer.computeHudTextLayoutForList(arrayList, hudTextStyle);
                     this.updateState4(Math.max(1.0F, hudTextLayout.getWidth2()), Math.max(1.0F, hudTextLayout.getHeight2()));
                     float x = this.hudLayout.getX();
                     float y = this.hudLayout.getY();
                     float width = (float)UiViewport.getWidth();
                     boolean booleanValue2 = x + hudTextLayout.getWidth2() / 2.0F > width / 2.0F;
                     boolean booleanValue3 = y <= 6.0F || y + hudTextLayout.getHeight2() >= (float)UiViewport.getHeight() - 6.0F;
                     boolean booleanValue4 = booleanValue2 ? x + hudTextLayout.getWidth2() >= width - 6.0F : x <= 6.0F;
                     if (this.shadowSetting.getValue()) {
                        HudBloomRenderer.drawGlowOutline(x, y, hudTextLayout.getWidth2(), hudTextLayout.getHeight2(), hudTextStyle.getRadius(), 14.0F, 3.0F, LegacyUiTheme.createColor(Color.BLACK, 0.25F));
                     }

                     HudTextRenderer.updateStateForHudTextLayout(hudTextLayout, hudTextStyle, x, y, booleanValue2, !booleanValue3 || !booleanValue4, (float)timestampNanos2 / 1.0E9F, themeSnapshot);
                  }
               }
            }
         }
      }
   }
}
