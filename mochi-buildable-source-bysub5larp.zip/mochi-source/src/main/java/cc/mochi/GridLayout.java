package cc.mochi;

import java.util.ArrayList;
import java.util.List;

public class GridLayout {
   private final int intState;
   private final int intState2;
   private int intState3;
   private LayoutInsets layoutInsets;

   private int intState4;
   public final List<GridCell> gridCellList = new ArrayList<>();

   public GridLayout(int intState22, int intState5) {
      this.intState4 = 0;
      this.intState3 = 0;
      this.layoutInsets = new LayoutInsets(0);
      this.intState2 = intState22;
      this.intState = intState5;
   }

   public void updateState() {
      for (GridCell gridCell : this.gridCellList) {
         gridCell.updateState();
      }
   }

   public GridLayout computeGridLayout(int intState42, int intState32) {
      this.intState4 = intState42;
      this.intState3 = intState32;
      return this;
   }

   public GridLayout computeGridLayoutForGridCell(GridCell gridCell) {
      this.gridCellList.add(gridCell);
      return this;
   }

   public void updateState2(int intValue, int intValue2, int intValue3, int intValue4) {
      int intValue5 = intValue + this.layoutInsets.left();
      int intValue6 = intValue2 + this.layoutInsets.top();
      int intValue7 = intValue3 - this.layoutInsets.left() - this.layoutInsets.right();
      int intValue8 = intValue4 - this.layoutInsets.top() - this.layoutInsets.bottom();
      int intValue9 = (intValue7 - this.intState4 * (this.intState2 - 1)) / this.intState2;
      int intValue10 = (intValue8 - this.intState3 * (this.intState - 1)) / this.intState;

      for (GridCell gridCell : this.gridCellList) {
         if (gridCell.intState3 < this.intState2 && gridCell.intState8 < this.intState) {
            int intState5 = intValue5 + gridCell.intState3 * (intValue9 + this.intState4);
            int intState52 = intValue6 + gridCell.intState8 * (intValue10 + this.intState3);
            int intState42 = intValue9 + (intValue9 + this.intState4) * (gridCell.intState7 - 1);
            int intState6 = intValue10 + (intValue10 + this.intState3) * (gridCell.intState2 - 1);
            gridCell.updateState2(intState5, intState52, intState42, intState6);
         }
      }
   }

   public GridLayout computeGridLayout2(int intValue) {
      this.layoutInsets = new LayoutInsets(intValue);
      return this;
   }

   public GridLayout computeGridLayout3(int intValue) {
      this.intState4 = intValue;
      this.intState3 = intValue;
      return this;
   }
}
