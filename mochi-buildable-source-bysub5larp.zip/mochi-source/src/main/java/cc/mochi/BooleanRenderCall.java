package cc.mochi;

public interface BooleanRenderCall {
   boolean render();
}
