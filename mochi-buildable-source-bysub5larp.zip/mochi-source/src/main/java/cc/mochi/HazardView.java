package cc.mochi;

import java.util.List;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public interface HazardView {
   default boolean testBox(Box box) {
      return true;
   }

   Vec3d computeVec3dForBox(Box box, Vec3d vec3d);

   default double computeDoubleForHazardKind(HazardKind hazardKind) {
      return KnockbackSimulator.computeDoubleForHazardKind(hazardKind, "Balanced");
   }

   default boolean testBox2(Box box) {
      return true;
   }

   boolean testBox3(Box box);

   boolean testBox4(Box box, Vec3d vec3d);

   default double computeDoubleForBox(Box box) {
      return (1.0);
   }

   List computeList();

   double computeDoubleForBox2(Box box);
}
