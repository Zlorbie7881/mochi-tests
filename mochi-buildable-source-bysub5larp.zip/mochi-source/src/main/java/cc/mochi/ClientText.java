package cc.mochi;

public final class ClientText {
   public static final XorText FONTS;
   public static final XorText MEDIA_COVER_ENV;
   public static final XorText MEDIA_LENGTH_ENV;

   public static final XorText MEDIA_ARTIST_ENV;

   public static final XorText RENDER_2D;

   public static final XorText MEDIA_THREAD;

   public static final XorText IMAGES;

   public static final XorText MEDIA_TITLE_ENV;

   public static final XorText USER_AGENT;
   public static final XorText PLATFORM;
   public static final XorText MEDIA_POSITION_ENV;

   public static final XorText RENDER_3D;

   public static final XorText HUD_LAYER;
   public static final XorText MEDIA_PLAYING_ENV;

   public static final XorText RENDER_BACKEND;
   public static final XorText CLIENT_NAME;

   public static final XorText CLICK_SIMULATION;

   public static final XorText RECONNECT_THREAD;

   private ClientText() {
   }

   static {
      CLIENT_NAME = XorText.fromLiteral("Mochi", new char[]{14359, 41231, 38924, 64275, 22467});
      HUD_LAYER = XorText.fromLiteral("Mochi/HudLayer", new char[]{32096, 29040, 9522, 27034, 17849, 62005, 4677, 7652, 17821, 591, 38056, 10015, 3115, 43907});
      PLATFORM = XorText.fromLiteral("Mochi/Platform", new char[]{41196, 62661, 61494, 35625, 53451, 3020, 34163, 31085, 44222, 62414, 36106, 24153, 57863, 22211});
      FONTS = XorText.fromLiteral("Mochi/Fonts", new char[]{2833, 46023, 21487, 53839, 26696, 4261, 57202, 44254, 18008, 56881, 21003});
      IMAGES = XorText.fromLiteral("Mochi/Images", new char[]{27165, 23049, 44995, 35531, 40653, 43771, 64038, 2764, 34622, 63599, 1155, 51114});
      RENDER_2D = XorText.fromLiteral("Mochi/Render2D", new char[]{64267, 7956, 35659, 56447, 64686, 37964, 35618, 54809, 49142, 23235, 12819, 48061, 30667, 30035});
      RENDER_3D = XorText.fromLiteral("Mochi/Render3D", new char[]{46144, 61824, 13355, 35293, 49965, 54057, 38926, 44785, 46442, 24714, 10602, 7060, 954, 28860});
      CLICK_SIMULATION = XorText.fromLiteral("Mochi/ClickSim", new char[]{60228, 24024, 52590, 61926, 27785, 62272, 20338, 8348, 56170, 48366, 54360, 48395, 45043, 17022});
      RENDER_BACKEND = XorText.fromLiteral("Mochi/RenderBackend", new char[]{56241, 44656, 59781, 92, 35575, 2288, 12764, 5784, 5768, 52111, 35569, 27652, 1632, 49825, 4712, 55268, 29684, 20667, 16012});
      RECONNECT_THREAD = XorText.fromLiteral("Mochi-AutoReconnect", new char[]{27472, 24713, 20460, 17298, 51502, 16009, 41920, 65464, 39347, 38003, 15943, 55660, 51250, 53234, 21300, 16100, 47352, 1778, 32444});
      MEDIA_THREAD = XorText.fromLiteral("Mochi-Spotify", new char[]{42636, 60075, 47256, 29738, 8044, 51251, 18038, 19083, 43415, 50023, 41133, 36250, 53253});
      USER_AGENT = XorText.fromLiteral("Mochi/1.0", new char[]{7689, 30564, 13022, 34904, 23108, 14312, 24278, 60022, 43656});
      MEDIA_TITLE_ENV = XorText.fromLiteral("MOCHI_SPOTIFY_TITLE", new char[]{46813, 6625, 17463, 8137, 19041, 43634, 32193, 12372, 26694, 49358, 28379, 1800, 47574, 45344, 19600, 42963, 33960, 10860, 12858});
      MEDIA_ARTIST_ENV = XorText.fromLiteral("MOCHI_SPOTIFY_ARTIST", new char[]{49271, 18783, 64933, 28901, 36680, 11824, 5299, 18470, 58225, 8284, 40639, 40968, 12453, 62909, 6892, 62099, 46828, 24959, 16092, 60855});
      MEDIA_COVER_ENV = XorText.fromLiteral("MOCHI_SPOTIFY_COVER", new char[]{50032, 6537, 14259, 19988, 45268, 46825, 24177, 48619, 12849, 63356, 54625, 47651, 8944, 21840, 1494, 9777, 57260, 32654, 28157});
      MEDIA_PLAYING_ENV = XorText.fromLiteral("MOCHI_SPOTIFY_PLAYING", new char[]{54236, 62437, 4672, 14250, 18989, 26450, 9910, 45801, 27203, 9802, 62432, 7036, 31053, 30058, 25840, 54564, 26055, 34224, 17601, 29096, 856});
      MEDIA_POSITION_ENV = XorText.fromLiteral("MOCHI_SPOTIFY_POSITION", new char[]{56848, 17973, 18236, 48061, 45629, 34370, 38324, 17647, 58733, 61109, 25509, 63073, 46968, 43593, 49664, 26160, 62450, 24273, 16887, 2408, 57396, 24574});
      MEDIA_LENGTH_ENV = XorText.fromLiteral("MOCHI_SPOTIFY_LENGTH", new char[]{1334, 2061, 44561, 52890, 17137, 8317, 62906, 36407, 45609, 1613, 53096, 5131, 51689, 62499, 22150, 30177, 24000, 48943, 48490, 47234});
   }
}
