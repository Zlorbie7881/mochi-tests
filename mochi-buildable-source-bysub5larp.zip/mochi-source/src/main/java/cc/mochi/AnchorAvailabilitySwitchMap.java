package cc.mochi;

public class AnchorAvailabilitySwitchMap {
   static final int[] intArray = new int[AnchorAvailability.values().length];

   static {
      try {
         intArray[AnchorAvailability.READY.ordinal()] = 1;
      } catch (NoSuchFieldError failure) {
      }

      try {
         intArray[AnchorAvailability.MISSING.ordinal()] = 2;
      } catch (NoSuchFieldError failure2) {
      }

      try {
         intArray[AnchorAvailability.VISUAL.ordinal()] = 3;
      } catch (NoSuchFieldError failure3) {
      }
   }
}
