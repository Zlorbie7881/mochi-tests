package cc.mochi;

public class HudScaleDragHandler implements DragHandler {
   final float floatState;

   final HudEditorScreen hudEditorScreen;

   final HudElement hudElement;

   final float floatState2;

   public static HudEditorScreen getHudEditorScreen(HudScaleDragHandler hudScaleDragHandler) {
      return hudScaleDragHandler.hudEditorScreen;
   }

   @Override
   public void drag(double doubleValue, double doubleValue2) {
      this.hudElement.updateState5((0.4F) + SliderWidgets.computeFloat(doubleValue, getFloatState2(this), getFloatState(this)) * 3.1F);
      getHudEditorScreen(this).updateStateForHudElement6(getHudElement(this));
   }

   @Override
   public void release(double doubleValue, double doubleValue2) {
      this.hudEditorScreen.updateState4();
   }

   HudScaleDragHandler(HudEditorScreen hudEditorScreen2, HudElement hudElement2, float floatState22, float floatState3) {
      this.hudEditorScreen = hudEditorScreen2;
      this.hudElement = hudElement2;
      this.floatState2 = floatState22;
      this.floatState = floatState3;
   }

   public static HudElement getHudElement(HudScaleDragHandler hudScaleDragHandler) {
      return hudScaleDragHandler.hudElement;
   }

   public static float getFloatState(HudScaleDragHandler hudScaleDragHandler) {
      return hudScaleDragHandler.floatState;
   }

   public static float getFloatState2(HudScaleDragHandler hudScaleDragHandler) {
      return hudScaleDragHandler.floatState2;
   }
}
