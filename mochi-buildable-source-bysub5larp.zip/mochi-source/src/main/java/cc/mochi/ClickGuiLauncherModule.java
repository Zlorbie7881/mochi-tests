package cc.mochi;

import java.util.concurrent.ThreadLocalRandom;

public final class ClickGuiLauncherModule extends ClickGuiModule {
   @Override
   public void onEnable() {
      if (MinecraftClientAccess18.getCurrentScreen(mc) == null) {
         ThreadLocalRandom.current().nextInt(5);
         mc.setScreen(new ClickGuiOverlayScreen());
      }

      this.setEnabled(false);
   }
}
