package cc.mochi;

final class GlyphPreloader implements GlyphLoadCallback {
   float floatState;
   float floatState2;
   float floatState3;
   boolean booleanState;
   float floatState4;

   float floatState5;
   float floatState6;
   int intState;

   @Override
   public void loadGlyph(StbFontRenderer stbFontRenderer, int intValue, float floatValue) {
      if (this.floatState5 > 0.0F) {
         Render2D.updateStateForStbFontRenderer(stbFontRenderer, intValue, floatValue);
      } else {
         PositionedGlyph positionedGlyph = stbFontRenderer.computePositionedGlyphForGlyphAtlas(intValue, Render2D.glyphAtlas);
         if (positionedGlyph != null && positionedGlyph.getSlot() != null) {
            TextureRegion slot = positionedGlyph.getSlot();
            float floatValue2 = positionedGlyph.getWidth() * this.floatState2;
            float floatValue3 = positionedGlyph.getHeight() * this.floatState2;
            if (this.booleanState) {
               float floatValue4 = (this.floatState3 + floatValue + positionedGlyph.getXOffset() * this.floatState2) / Render2D.pixelScaleX;
               float floatValue5 = (this.floatState6 + positionedGlyph.getYOffset() * this.floatState2) / Render2D.pixelScaleY;
               float floatValue6 = floatValue2 / Render2D.pixelScaleX * 0.5F;
               float floatValue7 = floatValue3 / Render2D.pixelScaleY * 0.5F;
               Render2D.updateStateForTextureHandle(
                  floatValue4 + floatValue6,
                  floatValue5 + floatValue7,
                  1.0F,
                  0.0F,
                  floatValue6,
                  floatValue7,
                  0.0F,
                  0.0F,
                  0.0F,
                  0.0F,
                  0.0F,
                  0.0F,
                  1.0F,
                  0.0F,
                  0.0F,
                  this.floatState4,
                  slot.getU0(),
                  slot.getV0(),
                  slot.getU1(),
                  slot.getV1(),
                  0.0F,
                  0.0F,
                  false,
                  slot.getTexture(),
                  this.intState,
                  this.intState,
                  this.intState,
                  this.intState
               );
            } else {
               float floatValue8 = this.floatState3 + (floatValue + positionedGlyph.getXOffset() * this.floatState2) * this.floatState;
               float floatValue9 = this.floatState6 + positionedGlyph.getYOffset() * this.floatState2 * this.floatState;
               float floatValue10 = floatValue2 * this.floatState * 0.5F;
               float floatValue11 = floatValue3 * this.floatState * 0.5F;
               Render2D.updateStateForTextureHandle(
                  floatValue8 + floatValue10,
                  floatValue9 + floatValue11,
                  1.0F,
                  0.0F,
                  floatValue10,
                  floatValue11,
                  0.0F,
                  0.0F,
                  0.0F,
                  0.0F,
                  0.0F,
                  0.0F,
                  1.0F,
                  0.0F,
                  0.0F,
                  this.floatState4,
                  slot.getU0(),
                  slot.getV0(),
                  slot.getU1(),
                  slot.getV1(),
                  0.0F,
                  0.0F,
                  true,
                  slot.getTexture(),
                  this.intState,
                  this.intState,
                  this.intState,
                  this.intState
               );
            }
         }
      }
   }

   public GlyphPreloader() {
   }
}
