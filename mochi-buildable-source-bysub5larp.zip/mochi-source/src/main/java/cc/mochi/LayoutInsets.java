package cc.mochi;

public record LayoutInsets(int top, int right, int bottom, int left) {
   public int getBottom() {
      return this.bottom;
   }

   public int getRight() {
      return this.right;
   }

   public LayoutInsets(int intValue, int intValue2) {
      this(intValue, intValue2, intValue, intValue2);
   }

   public LayoutInsets(int intValue) {
      this(intValue, intValue, intValue, intValue);
   }

   public int getTop() {
      return this.top;
   }

   public int getLeft() {
      return this.left;
   }
}
