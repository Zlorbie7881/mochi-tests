package cc.mochi;

record FramebufferAttachment(int fbo, int texture, int width, int height) {
   public int getTexture() {
      return this.texture;
   }

   public int getWidth() {
      return this.width;
   }

   public int getFbo() {
      return this.fbo;
   }

   public int getHeight() {
      return this.height;
   }
}
