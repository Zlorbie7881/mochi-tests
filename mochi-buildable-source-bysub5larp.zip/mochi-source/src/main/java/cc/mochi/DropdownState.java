package cc.mochi;

public final class DropdownState {
   private boolean booleanState;

   private float floatState;
   private long longState;
   private float floatState2;
   private String string;
   private float floatState3;

   public static float getFloatState3(DropdownState dropdownState) {
      return dropdownState.floatState3;
   }

   public float getFloatState4() {
      return getFloatState(this);
   }

   public long getLongState() {
      return this.longState;
   }

   public void resetBooleanState() {
      this.booleanState = false;
   }

   public float getFloatState32() {
      return getFloatState3(this);
   }

   public String getString() {
      return this.string;
   }

   public static void setFloatState3(DropdownState dropdownState, float floatState32) {
      dropdownState.floatState3 = floatState32;
   }

   public static float getFloatState(DropdownState dropdownState) {
      return dropdownState.floatState;
   }

   public void updateState(String string2, float floatState22, float floatState4, float floatState32) {
      setString(this, string2);
      setFloatState2(this, floatState22);
      this.floatState = floatState4;
      setFloatState3(this, floatState32);
      setBooleanState(this, true);
      setLongState(this, this.longState + 1L);
   }

   public boolean getBooleanState() {
      return this.booleanState;
   }

   public static float getFloatState2(DropdownState dropdownState) {
      return dropdownState.floatState2;
   }

   public static void setFloatState2(DropdownState dropdownState, float floatState22) {
      dropdownState.floatState2 = floatState22;
   }

   public static void setLongState(DropdownState dropdownState, long longState2) {
      dropdownState.longState = longState2;
   }

   public static void setBooleanState(DropdownState dropdownState, boolean booleanState2) {
      dropdownState.booleanState = booleanState2;
   }

   public boolean checkCondition(String string2) {
      return this.booleanState && string2 != null && string2.equals(this.string);
   }

   public float getFloatState22() {
      return getFloatState2(this);
   }

   public static void setString(DropdownState dropdownState, String string2) {
      dropdownState.string = string2;
   }
}
