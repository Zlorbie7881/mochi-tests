package cc.mochi;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public final class MathUtils {
   private static final double doubleState = Math.PI * 2;

   public static double computeDouble(double doubleValue2, double doubleValue3) {
      if (doubleValue2 > doubleValue3) {
         double doubleValue = doubleValue2;
         doubleValue2 = doubleValue3;
         doubleValue3 = doubleValue;
      }

      return doubleValue2 == doubleValue3 ? doubleValue2 : ThreadLocalRandom.current().nextDouble(doubleValue2, doubleValue3);
   }

   public static double computeDouble2(double doubleValue2, double doubleValue4, double doubleValue3) {
      if (doubleValue2 > doubleValue4) {
         double doubleValue = doubleValue2;
         doubleValue2 = doubleValue4;
         doubleValue4 = doubleValue;
      }

      if (doubleValue4 == doubleValue2) {
         return doubleValue2;
      } else {
         double doubleValue5 = Math.pow(ThreadLocalRandom.current().nextDouble(), doubleValue3);
         return doubleValue2 + (doubleValue4 - doubleValue2) * doubleValue5;
      }
   }

   public static int max2(double doubleValue) {
      return max((int)Math.round(doubleValue * 100.0));
   }

   public static long computeLong(long longValue, long longValue2, long longValue3) {
      long longValue4 = Math.min(longValue2, longValue3);
      long longValue5 = Math.max(longValue2, longValue3);
      if (longValue <= 0L) {
         return Math.max(0L, longValue4);
      } else {
         double doubleValue = ThreadLocalRandom.current().nextDouble();
         long longValue6 = Math.round(-Math.log(1.0 - doubleValue) * (double)longValue);
         return Math.max(longValue4, Math.min(longValue5, longValue6));
      }
   }

   public static double computeDouble3(double doubleValue, double doubleValue2, double doubleValue4, double doubleValue5) {
      if (doubleValue4 > doubleValue5) {
         double doubleValue3 = doubleValue4;
         doubleValue4 = doubleValue5;
         doubleValue5 = doubleValue3;
      }

      return Math.max(doubleValue4, Math.min(doubleValue5, computeDouble8(doubleValue, doubleValue2)));
   }

   private MathUtils() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }

   public static long computeLong2(long longValue, long longValue2) {
      return longValue >= longValue2 ? longValue : ThreadLocalRandom.current().nextLong(longValue, longValue2);
   }

   public static int max(int intValue) {
      return Math.max(1, Math.min(100, intValue));
   }

   public static void updateStateForList(List list) {
      if (list != null) {
         for (int intValue = list.size() - 1; intValue > 0; intValue--) {
            int intValue2 = computeInt(0, intValue + 1);
            Object objectValue = list.get(intValue);
            list.set(intValue, list.get(intValue2));
            list.set(intValue2, objectValue);
         }
      }
   }

   public static double computeDouble4(double doubleValue, double doubleValue2) {
      if (!(doubleValue2 <= 0.0) && doubleValue != 0.0) {
         double doubleValue3 = Math.abs(doubleValue % doubleValue2);
         return !(doubleValue3 < doubleValue2 * 0.001) && !(doubleValue2 - doubleValue3 < doubleValue2 * 0.001) ? doubleValue : doubleValue + (doubleValue >= 0.0 ? 1.0 : ((-1.0))) * doubleValue2 * 0.37;
      } else {
         return doubleValue;
      }
   }

   public static double computeDouble5(double doubleValue) {
      if (doubleValue <= 0.0) {
         return 0.0;
      } else {
         return ThreadLocalRandom.current().nextBoolean() ? doubleValue : -doubleValue;
      }
   }

   public static double computeDouble6(int intValue) {
      return (double)max(intValue) / 100.0;
   }

   public static Object computeObjectForList(List list) {
      return list != null && !list.isEmpty() ? list.get(computeInt(0, list.size())) : null;
   }

   public static int computeInt(int intValue, int intValue2) {
      return intValue >= intValue2 ? intValue : ThreadLocalRandom.current().nextInt(intValue, intValue2);
   }

   public static double computeDouble7(double doubleValue) {
      double doubleValue2 = Math.max(0.0, Math.min(1.0, doubleValue));
      return doubleValue2 * doubleValue2 * (3.0 - 2.0 * doubleValue2);
   }

   public static int computeInt2(double... doubleArray) {
      if (doubleArray != null && doubleArray.length != 0) {
         double doubleValue = 0.0;

         for (double doubleValue2 : doubleArray) {
            if (doubleValue2 > 0.0) {
               doubleValue += doubleValue2;
            }
         }

         if (doubleValue <= 0.0) {
            return computeInt(0, doubleArray.length);
         } else {
            double doubleValue3 = ThreadLocalRandom.current().nextDouble() * doubleValue;

            for (int intValue = 0; intValue < doubleArray.length; intValue++) {
               if (!(doubleArray[intValue] <= 0.0)) {
                  doubleValue3 -= doubleArray[intValue];
                  if (doubleValue3 <= 0.0) {
                     return intValue;
                  }
               }
            }

            return doubleArray.length - 1;
         }
      } else {
         return -1;
      }
   }

   public static double computeDouble8(double doubleValue, double doubleValue2) {
      return doubleValue2 == 0.0 ? doubleValue : doubleValue + ThreadLocalRandom.current().nextGaussian() * doubleValue2;
   }

   public static double computeDouble9(double doubleValue3, double doubleValue2, double doubleValue4) {
      if (doubleValue3 > doubleValue4) {
         double doubleValue = doubleValue3;
         doubleValue3 = doubleValue4;
         doubleValue4 = doubleValue;
      }

      if (doubleValue4 == doubleValue3) {
         return doubleValue3;
      } else {
         double doubleValue5 = Math.max(doubleValue3, Math.min(doubleValue4, doubleValue2));
         double doubleValue6 = (doubleValue5 - doubleValue3) / (doubleValue4 - doubleValue3);
         double doubleValue7 = ThreadLocalRandom.current().nextDouble();
         return doubleValue7 < doubleValue6 ? doubleValue3 + Math.sqrt(doubleValue7 * (doubleValue4 - doubleValue3) * (doubleValue5 - doubleValue3)) : doubleValue4 - Math.sqrt((1.0 - doubleValue7) * (doubleValue4 - doubleValue3) * (doubleValue4 - doubleValue5));
      }
   }

   public static long computeLong3(double doubleValue, double doubleValue2) {
      double doubleValue3 = Math.min(doubleValue, doubleValue2);
      double doubleValue4 = Math.max(doubleValue, doubleValue2);
      if (doubleValue4 <= doubleValue3) {
         return Math.round(doubleValue3);
      } else {
         double doubleValue5 = doubleValue3 + (doubleValue4 - doubleValue3) * 0.35;
         double doubleValue6 = doubleValue5 * Math.exp(0.45 * ThreadLocalRandom.current().nextGaussian());
         return Math.round(Math.max(doubleValue3, Math.min(doubleValue4, doubleValue6)));
      }
   }

   public static float computeFloat(float floatValue2, float floatValue3) {
      if (floatValue2 > floatValue3) {
         float floatValue = floatValue2;
         floatValue2 = floatValue3;
         floatValue3 = floatValue;
      }

      return floatValue2 == floatValue3 ? floatValue2 : ThreadLocalRandom.current().nextFloat(floatValue2, floatValue3);
   }

   public static double computeDouble10(double doubleValue, double doubleValue2) {
      return !(doubleValue <= 0.0) && !(doubleValue2 <= 0.0) ? doubleValue * Math.exp(doubleValue2 * ThreadLocalRandom.current().nextGaussian()) : Math.max(doubleValue, 0.0);
   }

   public static boolean checkCondition(double doubleValue) {
      if (doubleValue <= 0.0) {
         return false;
      } else {
         return doubleValue >= 1.0 ? true : ThreadLocalRandom.current().nextDouble() < doubleValue;
      }
   }

   @SafeVarargs
   public static Object computeObject(Object... objectValue) {
      return objectValue != null && objectValue.length != 0 ? objectValue[computeInt(0, objectValue.length)] : null;
   }

   public static double computeDouble11(double doubleValue) {
      if (doubleValue <= 0.0) {
         return 0.0;
      } else {
         double doubleValue2 = ThreadLocalRandom.current().nextGaussian() * (doubleValue / 3.0);
         return Math.max(-doubleValue, Math.min(doubleValue, doubleValue2));
      }
   }
}
