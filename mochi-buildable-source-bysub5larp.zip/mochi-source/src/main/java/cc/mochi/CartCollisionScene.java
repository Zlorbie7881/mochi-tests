package cc.mochi;

import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.block.BlockState;
import net.minecraft.block.SlabBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

public record CartCollisionScene(BlockPos rail, BlockPos slab, BlockState slabState, Box cart, List<Box> playerBoxes) {
   boolean testBlockPos(BlockPos blockPos) {
      Box box = new Box(blockPos);
      Iterator iterator = getPlayerBoxes(this).iterator();

      while (iterator.hasNext()) {
         Box box2 = (Box)iterator.next();
         if (box.intersects(box2)) {
            return true;
         }
      }

      return false;
   }

   public static BlockPos getSlab(CartCollisionScene cartCollisionScene) {
      return cartCollisionScene.slab;
   }

   public static Box getCart(CartCollisionScene cartCollisionScene) {
      return cartCollisionScene.cart;
   }

   public static BlockPos getRail(CartCollisionScene cartCollisionScene) {
      return cartCollisionScene.rail;
   }

   public static BlockState getSlabState(CartCollisionScene cartCollisionScene) {
      return cartCollisionScene.slabState;
   }

   public Box getCart2() {
      return getCart(this);
   }

   public List getPlayerBoxes3() {
      return getPlayerBoxes(this);
   }

   Box computeBoxForWorld(World world) {
      if (getSlab(this) != null) {
         if (!(world.getBlockState(this.slab).getBlock() instanceof SlabBlock)) {
            double x = (double)getSlab(this).getX();
            double y = (double)getSlab(this).getY();
            double z = (double)getSlab(this).getZ();
            double doubleValue = (double)(this.slab.getX() + 1);
            double y2 = (double)getSlab(this).getY();

            y2 += (0.5);
            int z2 = getSlab(this).getZ();

            return new Box(x, y, z, doubleValue, y2, (double)(z2 + 1));
         }
      }

      return null;
   }

   public BlockState getSlabState2() {
      return this.slabState;
   }

   public BlockPos getSlab72() {
      return getSlab(this);
   }

   public BlockPos getRail2() {
      return getRail(this);
   }

   BlockState computeBlockStateForWorld(World world, BlockPos blockPos) {
      if (blockPos.equals(this.rail)) {
         return BlocksAccess.getRAIL().getDefaultState();
      } else {
         if (getSlab(this) != null) {
            if (blockPos.equals(this.slab)) {
               ThreadLocalRandom.current().nextInt(4);

               return getSlabState(this);
            }
         }

         return world.getBlockState(blockPos);
      }
   }

   public static List<Box> getPlayerBoxes(CartCollisionScene cartCollisionScene) {
      return cartCollisionScene.playerBoxes;
   }

}
