package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;

public class MinecraftClientAccess35 {
   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static MochiClient getINSTANCE() {
      return MochiClient.INSTANCE;
   }

   public static Screen getCurrentScreen(MinecraftClient minecraftClient) {
      return minecraftClient.currentScreen;
   }

}
