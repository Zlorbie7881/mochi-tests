package cc.mochi;

public class AnchorAlignment {
   private final int intState;

   public static final AnchorAlignment INSTANCE5 = new AnchorAlignment(HorizontalAlignment.LEFT, VerticalAlignment.TOP);

   private final HorizontalAlignment horizontalAlignment;
   public static final AnchorAlignment INSTANCE7 = new AnchorAlignment(HorizontalAlignment.CENTER, VerticalAlignment.TOP);
   public static final AnchorAlignment INSTANCE2 = new AnchorAlignment(HorizontalAlignment.RIGHT, VerticalAlignment.TOP);
   public static final AnchorAlignment INSTANCE3 = new AnchorAlignment(HorizontalAlignment.LEFT, VerticalAlignment.CENTER);
   public static final AnchorAlignment INSTANCE6 = new AnchorAlignment(HorizontalAlignment.CENTER, VerticalAlignment.CENTER);
   public static final AnchorAlignment INSTANCE4 = new AnchorAlignment(HorizontalAlignment.RIGHT, VerticalAlignment.CENTER);

   private final VerticalAlignment verticalAlignment;
   public static final AnchorAlignment INSTANCE = new AnchorAlignment(HorizontalAlignment.LEFT, VerticalAlignment.BOTTOM);

   private final int intState2;

   public static final AnchorAlignment INSTANCE8 = new AnchorAlignment(HorizontalAlignment.CENTER, VerticalAlignment.BOTTOM);

   public static final AnchorAlignment INSTANCE9 = new AnchorAlignment(HorizontalAlignment.RIGHT, VerticalAlignment.BOTTOM);

   public PixelPoint computePixelPoint(int intValue, int intValue2, int intValue3, int intValue4) {
      int intState22;
      switch (this.horizontalAlignment) {
         case LEFT:
            intState22 = this.intState2;
            break;
         case CENTER:
            intState22 = (intValue - intValue3) / 2 + this.intState2;
            break;
         case RIGHT:
            intState22 = intValue - intValue3 - this.intState2;
            break;
         default:
            intState22 = this.intState2;
      }

      int intState3;
      switch (this.verticalAlignment) {
         case TOP:
            intState3 = this.intState;
            break;
         case CENTER:
            intState3 = (intValue2 - intValue4) / 2 + this.intState;
            break;
         case BOTTOM:
            intState3 = intValue2 - intValue4 - this.intState;
            break;
         default:
            intState3 = this.intState;
      }

      return new PixelPoint(intState22, intState3);
   }

   public AnchorAlignment(HorizontalAlignment horizontalAlignment2, VerticalAlignment verticalAlignment2) {
      this(horizontalAlignment2, verticalAlignment2, 0, 0);
   }

   public AnchorAlignment(HorizontalAlignment horizontalAlignment2, VerticalAlignment verticalAlignment2, int intState22, int intState3) {
      this.horizontalAlignment = horizontalAlignment2;
      this.verticalAlignment = verticalAlignment2;
      this.intState2 = intState22;
      this.intState = intState3;
   }
}
