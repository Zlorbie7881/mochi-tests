package cc.mochi;

public enum ActionPriority {
   LOWEST,
   LOW,
   NORMAL,
   HIGH,
   HIGHEST;

   private static ActionPriority[] createValues() {
      return new ActionPriority[]{LOWEST, LOW, NORMAL, HIGH, HIGHEST};
   }
}
