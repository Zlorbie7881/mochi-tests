package cc.mochi;

import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import java.io.InputStream;
import java.net.URI;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.GpuSampler;
import net.minecraft.client.texture.AbstractTexture;
import net.minecraft.client.texture.NativeImage.Format;
import net.minecraft.util.Identifier;
import org.lwjgl.stb.STBImage;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.slf4j.Logger;
import org.slf4j.helpers.NOPLogger;

final class ImageCache {
   private static final Logger logger = NOPLogger.NOP_LOGGER;
   private final Set<String> stringSet;

   private final ArrayDeque<String> stringArrayDeque;
   private final Map<String, TextureResource> textureResourceByString = new HashMap<>();

   private static final TextureResource textureResource = new TextureResource(null, null, null);

   private static boolean checkCondition(String string) {
      if (string.startsWith("file:")) {
         return false;
      } else {
         try {
            return !Path.of(string).isAbsolute();
         } catch (RuntimeException failure) {
            return true;
         }
      }
   }

   private static void updateStateForByteBuffer(ByteBuffer byteBuffer) {
      for (int pixelOffset = 0; pixelOffset < byteBuffer.limit(); pixelOffset += 4) {
         int intValue = byteBuffer.get(pixelOffset + 3) & 255;
         if (intValue != 255) {
            byteBuffer.put(pixelOffset, (byte)(((byteBuffer.get(pixelOffset) & 255) * intValue + 127) / 255));
            byteBuffer.put(pixelOffset + 1, (byte)(((byteBuffer.get(pixelOffset + 1) & 255) * intValue + 127) / 255));
            byteBuffer.put(pixelOffset + 2, (byte)(((byteBuffer.get(pixelOffset + 2) & 255) * intValue + 127) / 255));
         }
      }
   }

   boolean containsKey(String string) {
      return this.textureResourceByString.containsKey(string);
   }

   private void updateStateForException(String string, String string2, Exception exception) {
      if (this.stringSet.add(string)) {
         if (exception == null) {
            logger.error(string2);
         } else {
            logger.error(string2, exception);
         }
      }
   }

   ImageCache() {
      this.stringArrayDeque = new ArrayDeque<>();
      this.stringSet = new HashSet<>();
   }

   void updateState() {
      for (TextureResource textureResource2 : this.textureResourceByString.values()) {
         if (textureResource2.texture() != null) {
            textureResource2.view().close();
            textureResource2.texture().close();
         }
      }

      this.textureResourceByString.clear();
      this.stringArrayDeque.clear();
   }

   private static TextureResource computeTextureResourceForByteBuffer(String string, ByteBuffer byteBuffer, int intValue, int intValue2) {
      int intValue3 = 1;

      while (intValue >> intValue3 > 0 && intValue2 >> intValue3 > 0 && intValue3 < 8) {
         intValue3++;
      }

      GpuTexture texture = RenderSystem.getDevice().createTexture("Mochi image " + string, 5, TextureFormat.RGBA8, intValue, intValue2, 1, intValue3);
      CommandEncoder commandEncoder = RenderSystem.getDevice().createCommandEncoder();
      commandEncoder.writeToTexture(texture, byteBuffer, Format.RGBA, 0, 0, 0, 0, intValue, intValue2);
      ByteBuffer byteBuffer2 = byteBuffer;
      int intValue4 = intValue;
      int intValue5 = intValue2;

      for (int intValue6 = 1; intValue6 < intValue3; intValue6++) {
         int intValue7 = Math.max(1, intValue4 >> 1);
         int intValue8 = Math.max(1, intValue5 >> 1);
         ByteBuffer byteBuffer3 = MemoryUtil.memAlloc(intValue7 * intValue8 * 4);

         try {
            updateStateForByteBuffer2(byteBuffer2, intValue4, intValue5, byteBuffer3, intValue7, intValue8);
            commandEncoder.writeToTexture(texture, byteBuffer3, Format.RGBA, intValue6, 0, 0, 0, intValue7, intValue8);
         } catch (RuntimeException failure) {
            MemoryUtil.memFree(byteBuffer3);
            throw failure;
         }

         if (byteBuffer2 != byteBuffer) {
            MemoryUtil.memFree(byteBuffer2);
         }

         byteBuffer2 = byteBuffer3;
         intValue4 = intValue7;
         intValue5 = intValue8;
      }

      if (byteBuffer2 != byteBuffer) {
         MemoryUtil.memFree(byteBuffer2);
      }

      GpuTextureView textureView = RenderSystem.getDevice().createTextureView(texture);
      GpuSampler gpuSampler = RenderSystem.getSamplerCache().get(FilterMode.LINEAR, true);
      return new TextureResource(texture, textureView, new TextureHandle(textureView, gpuSampler, intValue, intValue2, true, false));
   }

   private static InputStream computeInputStream(String string) throws Exception {
      if (string.startsWith("file:")) {
         return Files.newInputStream(Path.of(URI.create(string)));
      } else if (!checkCondition(string)) {
         Path path = Path.of(string);
         return Files.isRegularFile(path) ? Files.newInputStream(path) : null;
      } else {
         InputStream resourceAsStream = ImageCache.class.getClassLoader().getResourceAsStream(string);
         return resourceAsStream != null ? resourceAsStream : Thread.currentThread().getContextClassLoader().getResourceAsStream(string);
      }
   }

   private TextureResource computeTextureResource(String string) {
      ByteBuffer byteBuffer = null;

      TextureResource textureResource2;
      try (InputStream inputStream = computeInputStream(string)) {
         if (inputStream == null) {
            this.updateStateForException(string, "Missing image resource " + string, null);
            return null;
         }

         byte[] byteArray = inputStream.readAllBytes();
         byteBuffer = MemoryUtil.memAlloc(byteArray.length);
         byteBuffer.put(byteArray).flip();
         MemoryStack memoryStack = MemoryStack.stackPush();

         label292: {
            try {
               IntBuffer intBuffer = memoryStack.mallocInt(1);
               IntBuffer intBuffer2 = memoryStack.mallocInt(1);
               IntBuffer intBuffer3 = memoryStack.mallocInt(1);
               ByteBuffer byteBuffer2 = STBImage.stbi_load_from_memory(byteBuffer, intBuffer, intBuffer2, intBuffer3, 4);
               if (byteBuffer2 == null) {
                  this.updateStateForException(string, "Could not decode image " + string + ": " + STBImage.stbi_failure_reason(), null);
                  textureResource2 = null;
                  break label292;
               }

               try {
                  updateStateForByteBuffer(byteBuffer2);
                  textureResource2 = computeTextureResourceForByteBuffer(string, byteBuffer2, intBuffer.get(0), intBuffer2.get(0));
               } finally {
                  STBImage.stbi_image_free(byteBuffer2);
               }
            } catch (Throwable failure) {
               if (memoryStack != null) {
                  try {
                     memoryStack.close();
                  } catch (Throwable failure2) {
                     failure.addSuppressed(failure2);
                  }
               }

               throw failure;
            }

            if (memoryStack != null) {
               memoryStack.close();
            }

            return textureResource2;
         }

         if (memoryStack != null) {
            memoryStack.close();
         }
      } catch (Exception failure3) {
         this.updateStateForException(string, "Could not load image " + string, failure3);
         return null;
      } finally {
         if (byteBuffer != null) {
            MemoryUtil.memFree(byteBuffer);
         }
      }

      return textureResource2;
   }

   TextureHandle computeTextureHandleForIdentifier(Identifier identifier) {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (minecraftClient != null && identifier != null) {
         AbstractTexture texture = minecraftClient.getTextureManager().getTexture(identifier);
         if (texture == null) {
            return null;
         } else {
            GpuTextureView glTextureView = texture.getGlTextureView();
            return glTextureView != null && !glTextureView.isClosed()
               ? new TextureHandle(glTextureView, RenderSystem.getSamplerCache().get(FilterMode.NEAREST), glTextureView.getWidth(0), glTextureView.getHeight(0), false, false)
               : null;
         }
      } else {
         return null;
      }
   }

   TextureHandle computeTextureHandle(String string) {
      TextureResource textureResource2 = this.textureResourceByString.get(string);
      if (textureResource2 != null) {
         return textureResource2.handle();
      } else {
         TextureResource textureResource3 = this.computeTextureResource(string);
         this.textureResourceByString.put(string, textureResource3 == null ? textureResource : textureResource3);
         if (!checkCondition(string)) {
            this.stringArrayDeque.addLast(string);

            while (this.stringArrayDeque.size() > 12) {
               this.updateState2(this.stringArrayDeque.removeFirst());
            }
         }

         return textureResource3 == null ? null : textureResource3.handle();
      }
   }

   private static void updateStateForByteBuffer2(ByteBuffer byteBuffer, int intValue, int intValue2, ByteBuffer byteBuffer2, int intValue3, int intValue4) {
      for (int intValue5 = 0; intValue5 < intValue4; intValue5++) {
         int intValue6 = Math.min(intValue2 - 1, intValue5 * 2);
         int intValue7 = Math.min(intValue2 - 1, intValue5 * 2 + 1);

         for (int intValue8 = 0; intValue8 < intValue3; intValue8++) {
            int intValue9 = Math.min(intValue - 1, intValue8 * 2);
            int intValue10 = Math.min(intValue - 1, intValue8 * 2 + 1);
            int intValue11 = (intValue6 * intValue + intValue9) * 4;
            int intValue12 = (intValue6 * intValue + intValue10) * 4;
            int intValue13 = (intValue7 * intValue + intValue9) * 4;
            int intValue14 = (intValue7 * intValue + intValue10) * 4;
            int intValue15 = (intValue5 * intValue3 + intValue8) * 4;

            for (int intValue16 = 0; intValue16 < 4; intValue16++) {
               int intValue17 = (byteBuffer.get(intValue11 + intValue16) & 255)
                  + (byteBuffer.get(intValue12 + intValue16) & 255)
                  + (byteBuffer.get(intValue13 + intValue16) & 255)
                  + (byteBuffer.get(intValue14 + intValue16) & 255);
               byteBuffer2.put(intValue15 + intValue16, (byte)(intValue17 + 2 >> 2));
            }
         }
      }
   }

   void updateState2(String string) {
      TextureResource textureResource2 = this.textureResourceByString.remove(string);
      if (textureResource2 != null && textureResource2.texture() != null) {
         textureResource2.view().close();
         textureResource2.texture().close();
      }
   }
}
