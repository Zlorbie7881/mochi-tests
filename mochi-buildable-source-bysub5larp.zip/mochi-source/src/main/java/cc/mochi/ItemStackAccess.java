package cc.mochi;

import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

public class ItemStackAccess {
   public static boolean testItemStack(ItemStack itemStack) {
      if (itemStack.isEmpty()) {
         return false;
      } else {
         if (itemStack.getItem() != Items.GOLDEN_APPLE
            && itemStack.getItem() != ItemsAccess.getENCHANTED_GOLDEN_APPLE()
            && itemStack.getItem() != Items.BREAD
            && itemStack.getItem() != ItemsAccess.getCOOKED_BEEF()
            && itemStack.getItem() != ItemsAccess.getCOOKED_PORKCHOP()
            && itemStack.getItem() != Items.COOKED_CHICKEN
            && itemStack.getItem() != Items.COOKED_MUTTON) {
            if (itemStack.getItem() != Items.COOKED_RABBIT) {
               if (itemStack.getItem() != Items.COOKED_SALMON
                  && itemStack.getItem() != Items.COOKED_COD
                  && itemStack.getItem() != ItemsAccess.computeItem()
                  && itemStack.getItem() != Items.CARROT
                  && itemStack.getItem() != ItemsAccess.getPOTATO()
                  && itemStack.getItem() != Items.BAKED_POTATO
                  && itemStack.getItem() != Items.MELON_SLICE) {
                  if (itemStack.getItem() != ItemsAccess.getSWEET_BERRIES()) {
                     if (itemStack.getItem() != Items.GLOW_BERRIES) {
                        if (itemStack.getItem() != ItemsAccess.getCHORUS_FRUIT()) {
                           if (itemStack.getItem() != ItemsAccess.getDRIED_KELP() && itemStack.getItem() != Items.HONEY_BOTTLE && itemStack.getItem() != Items.MUSHROOM_STEW) {
                              if (itemStack.getItem() != Items.RABBIT_STEW
                                 && itemStack.getItem() != Items.BEETROOT_SOUP
                                 && itemStack.getItem() != Items.SUSPICIOUS_STEW
                                 && itemStack.getItem() != ItemsAccess.getPUMPKIN_PIE()
                                 && itemStack.getItem() != Items.CAKE) {
                                 return false;
                              }
                           }
                        }
                     }
                  }
               }
            }
         }

         return true;
      }
   }
}
