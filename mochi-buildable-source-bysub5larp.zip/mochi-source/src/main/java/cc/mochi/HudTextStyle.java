package cc.mochi;

import java.awt.Color;

public record HudTextStyle(
   FontFace face,
   float size,
   float padding,
   float verticalPadding,
   float radius,
   float endCap,
   float grouping,
   Color surface,
   float surfaceAlpha,
   boolean blur,
   boolean camo,
   boolean rail,
   float railWidth,
   Color railColor,
   boolean gradient,
   Color[] colors,
   boolean textGlow,
   float flowSpeed
) {
   public boolean getRail() {
      return this.rail;
   }

   public FontFace getFace() {
      return this.face;
   }

   public static boolean getBlur(HudTextStyle hudTextStyle) {
      return hudTextStyle.blur;
   }

   public float getEndCap2() {
      return getEndCap(this);
   }

   public float getFlowSpeed2() {
      return getFlowSpeed(this);
   }

   public Color getSurface() {
      return this.surface;
   }

   public static float getFlowSpeed(HudTextStyle hudTextStyle) {
      return hudTextStyle.flowSpeed;
   }

   public float getPadding() {
      return this.padding;
   }

   public boolean getCamo() {
      return this.camo;
   }

   public float getVerticalPadding() {
      return this.verticalPadding;
   }

   public float getSize() {
      return this.size;
   }

   public Color getRailColor() {
      return this.railColor;
   }

   public static boolean getGradient(HudTextStyle hudTextStyle) {
      return hudTextStyle.gradient;
   }

   public static Color[] getColors(HudTextStyle hudTextStyle) {
      return hudTextStyle.colors;
   }

   public Color[] getColors2() {
      return getColors(this);
   }

   public float getRadius() {
      return this.radius;
   }

   public float getGrouping() {
      return this.grouping;
   }

   public boolean getBlur2() {
      return getBlur(this);
   }

   public float getSurfaceAlpha() {
      return this.surfaceAlpha;
   }

   public boolean getTextGlow2() {
      return getTextGlow(this);
   }

   public static boolean getTextGlow(HudTextStyle hudTextStyle) {
      return hudTextStyle.textGlow;
   }

   public static float getEndCap(HudTextStyle hudTextStyle) {
      return hudTextStyle.endCap;
   }

   public boolean getGradient2() {
      return getGradient(this);
   }

   public float getRailWidth() {
      return this.railWidth;
   }
}
