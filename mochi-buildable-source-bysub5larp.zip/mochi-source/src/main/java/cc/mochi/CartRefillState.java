package cc.mochi;

public enum CartRefillState {
   IDLE,
   HOVER,
   SILENT,
   VERIFY;

   public static CartRefillState getHOVER() {
      return HOVER;
   }

   private static CartRefillState[] computeCartRefillStateArray() {
      CartRefillState[] cartRefillStateArray = new CartRefillState[]{IDLE, null, null, null};

      cartRefillStateArray[1] = getHOVER();
      cartRefillStateArray[2] = SILENT;
      cartRefillStateArray[3] = VERIFY;
      return cartRefillStateArray;
   }
}
